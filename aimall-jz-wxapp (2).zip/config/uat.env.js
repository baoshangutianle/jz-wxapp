'use strict'
const merge = require('webpack-merge')
const prdEnv = require('./prd.env')

module.exports = merge(prdEnv, {
  NODE_ENV: '"uat1"',
  BASE_URL: '"http://jz.uat1.rscloud.com"',
  BASE_URL_BIGDATA: '"http://jz-aureuma.uat1.rscloud.com"',
  BASE_URL_AIGAME: '"http://jz.uat1.rscloud.com/api-aifun"',
  BASE_CAR_URL: '"http://jz.uat1.rscloud.com/api-apark-b"'
})
