'use strict'
const merge = require('webpack-merge')
const prdEnv = require('./prd.env')

module.exports = merge(prdEnv, {
  NODE_ENV: '"stg"',
  BASE_URL:'"https://jz.mklsoft-test.com"',
  BASE_URL_BIGDATA: '"https://jz-aureuma.mklsoft-test.com"',
  BASE_URL_AIGAME: '"https://jz.mklsoft-test.com/api-aifun"',
  BASE_CAR_URL: '"https://jz.mklsoft-test.com/api-apark-b"'
})
