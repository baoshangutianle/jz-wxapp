var merge = require('webpack-merge')
var prodEnv = require('./prd.env')

module.exports = merge(prodEnv, {
    NODE_ENV: '"dev"',
    // BASE_URL:'"http://jz.dev.rscloud.com"',
    BASE_URL:'"http://jz.uat1.rscloud.com"',
    // BASE_URL:'"https://jz.mklsoft-test.com"',
    BASE_URL_AIGAME: '"http://jz.uat1.rscloud.com/api-aifun"',
    BASE_URL_BIGDATA: '"http://jz-aureuma.uat1.rscloud.com"',
    BASE_CAR_URL: '"http://jz.uat1.rscloud.com/api-apark-b"',
    // BASE_CAR_URL: '"https://jz.mklsoft-test.com/api-apark-b"'
    // BASE_URL: '"https://foresight.aegeanpark.cn"',
    // BASE_URL_AIGAME: '"https://foresight.aegeanpark.cn/api-aifun"',
    // BASE_URL_BIGDATA: '"http://foresight.aegeanpark.cn/bigdata/aureuma/collect"',
    // BASE_CAR_URL: '"http://foresight.aegeanpark.cn/api-apark-b"',
})
