'use strict'
module.exports = {
    NODE_ENV: '"prd"',
    BASE_URL:'"https://nh.jzgc.ltd"',
    BASE_URL_BIGDATA: '"https://jz-aureuma.jzgc.ltd"',
    BASE_CAR_URL: '"https://nh.jzgc.ltd/api-apark-b"',
    BASE_URL_AIGAME: '"https://nh.jzgc.ltd/api-aifun"',
}
