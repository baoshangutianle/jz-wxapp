module.exports = [{
        path: 'pages/home',
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '南海嘉洲广场'
        }
    }, {
        path: 'pages/auth/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '授权登录'
        }
    }, {
        path: 'pages/mine/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '我的'
        }
    }, {
        path: 'pages/auth/login',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '登录'
        }
    },
    //  {
    //     path: 'pages/ar/index',
    //     config: {
    //         enablePullDownRefresh: false,
    //         navigationBarTitleText: 'AR寻宝'
    //     }
    // },
    {
        path: 'listOfActivities/index',
        subPackage: true,
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '热门活动'
        }
    }, {
        path: 'listOfActivities/details',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '热门活动'
        }
    }, {
        path: 'listOfActivities/popularList',
        subPackage: true,
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '热门活动'
        }
    }, {
        path: 'listOfActivities/popularDetails',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '热门活动'
        }
    }, {
        path: 'listOfActivities/submitSignUp',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '确认信息'
        }
    }, {
        path: 'listOfActivities/submitSuccess',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '报名成功'
        }
    }, {
        path: 'listOfActivities/myActivity',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '我的活动'
        }
    }, {
        path: 'listOfActivities/signUpDetail',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '报名详情'
        }
    }, {
        path: 'listOfActivities/shareAuth',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '活动授权'
        }
    },
    {
        path: 'pages/parkPay/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '车牌管理'
        }
    }, {
        path: 'pages/parkPay/pay',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '停车缴费'
        }
    }, {
        path: 'pages/parkPay/coupon',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '停车券'
        }
    }, {
        path: 'pages/parkPay/status',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '停车缴费'
        }
    }, {
        path: 'pages/parkPay/licence',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '增加车牌'
        }
    }, {
        path: 'pages/parkPay/charges',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '收费标准'
        }
    }, {
        path: 'pages/valuePoint/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '自助积分'
        }
    }, {
        path: 'pages/valuePoint/scan',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '扫码积分'
        }
    }, {
        path: 'pages/restaurant/index',
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '品牌指引'
        }
    }, {
        path: 'pages/restaurant/detail',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '品牌指引'
        },
    },
    {
        path: 'pages/integralMall/index',
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '在线商城'
        }
    },
    {
        path: 'pages/integralMall/detail',
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '积分商城'
        }
    },
    {
        path: 'pages/guide/index',
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '新鲜事儿'
        }
    }, {
        path: 'pages/guide/details',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '新鲜事儿'
        }
    }, {
        path: 'pages/shoppingService/detail',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '商场服务'
        }
    }, {
        path: 'pages/memberShip/detail',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '会员权益'
        }
    }, {
        path: 'pagesMine/setting',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '设置'
        }
    }, {
        path: 'pagesMine/policy',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '用户协议'
        }
    }, {
        path: 'pagesMine/protocol',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '隐私协议'
        }
    }, {
        path: 'pagesMine/editInfo',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '编辑资料'
        }
    }, {
        path: 'pagesMine/exchangeDetail',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '兑换记录'
        }
    }, {
        path: 'pages/banner/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: ''
        }
    }, {
        path: 'pages/stayTuned/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '敬请期待'
        }
    }, {
        path: 'pages/coupon/index',
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '超值领券'
        }
    }, {
        path: 'pages/coupon/details',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '优惠券'
        }
    }, {
        path: 'pagesMine/collect',
        subPackage: true,
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '我的收藏'
        }
    }, {
        path: 'pagesMine/tickets',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '小票上传记录'
        }
    }, {
        path: 'pagesMine/card',
        subPackage: true,
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '卡券详情'
        }
    }, {
        path: 'pagesMine/cardDetail',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '卡券详情'
        }
    }, {
        path: 'pagesMine/integral',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '积分详情'
        }
    },{
        path: 'pagesMine/interalRule',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '积分规则'
        }
    },{
        path: 'pages/mall/mallNavigation',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '商场导航'
        }
    },
    {
        path: 'pagesMine/exchangeRecord',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '兑换记录'
        }
    },
    {
        path: 'pages/ordermanage/orderlist',
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '订单管理'
        }
    },
    {
        path: 'pages/ordermanage/orderdetail',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '订单详情'
        }
    },
    {
        path: 'pages/luckyLottery/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '南海嘉洲广场'
        }
    },
    // {
    //     path: 'pages/luckyLottery/share',
    //     config: {
    //         enablePullDownRefresh: false,
    //         navigationBarTitleText: ''
    //     }
    // },
    {
        path: 'pages/checkIn/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '每日签到'
        }
    },
    {
        path: 'pages/checkIn/detail',
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '每日签到'
        }
    },
    // {
    //     path: 'pages/game/gashapon',
    //     config: {
    //         enablePullDownRefresh: false,
    //         navigationBarTitleText: '扭蛋游戏'
    //     }
    // },
    // {
    //     path: 'pages/game/postersShare',
    //     config: {
    //         enablePullDownRefresh: false,
    //         navigationBarTitleText: '海报分享'
    //     }
    // },
    // {
    //     path: 'pages/game/postersPreview',
    //     config: {
    //         enablePullDownRefresh: false,
    //         navigationBarTitleText: '扭蛋游戏'
    //     }
    // },
    // {
    //     path: 'pages/game/machine',
    //     config: {
    //         enablePullDownRefresh: false,
    //         navigationBarTitleText: '老虎机'
    //     }
    // },
    // {
    //     path: 'pages/game/machinePreview',
    //     config: {
    //         enablePullDownRefresh: false,
    //         navigationBarTitleText: '老虎机'
    //     }
    // },
    // {
    //     path: 'pages/game/machineList',
    //     config: {
    //         enablePullDownRefresh: true,
    //         navigationBarTitleText: '老虎机'
    //     }
    // },
    {
        path: 'confirmOrder/index',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '确认订单'
        }
    },
    {
        path: 'confirmOrder/deliveryMethods',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '配送方式'
        }
    },
    {
        path: 'confirmOrder/receiverList',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '收件人地址'
        }
    },
    {
        path: 'confirmOrder/receiverEditor',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '添加地址'
        }
    },
    {
        path: 'confirmOrder/addressLocation',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '定位地址'
        }
    },
    // 商品详情
    {
        path: 'pages/goodsDetails/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '商品详情'
        }
    },
    {
        path: 'pages/liveBroadcast/index',
        config: {
            enablePullDownRefresh: true,
            navigationBarTitleText: '直播'
        }
    },
    {
        path: 'pages/liveBroadcast/replay',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '直播回放'
        }
    },{
        path: 'pages/comingSoon/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '敬请期待'
        }
    },
    {
        path: 'pages/seckillList/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '秒杀列表'
        }
    },
    {
        path: 'pages/cart/index',
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '购物车'
        }
    },
    {
        path: 'confirmOrder/cartDetail',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '确认订单'
        }
    },
    {
        path: 'disCoupon/index',
        subPackage: true,
        config: {
            enablePullDownRefresh: false,
            navigationBarTitleText: '选择优惠券'
        }
    }

]
