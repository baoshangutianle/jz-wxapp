/***
 * desc：我的接口
 * author： gry
 * date： 2019年8月26日15:42:59
 */

import api from '@/plugins/api'
import request from '@/plugins/request'

export let getCards = (params,hideLoading)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.getCards,
            method: 'get',
            data: params,
            hideLoading:true
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}
export let getCouponNumForC = (params,hideLoading)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.getCouponNumForC,
            method: 'get',
            data: params,
            hideLoading:true
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}

export let getCouponBatchPage = (params)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.getCouponBatchPage,
            method: 'post',
            data: params,
            hideLoading:true
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}

export let getCouponNormalBatchPage = (params)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.getCouponNormalBatchPage,
            method: 'post',
            data: params,
            hideLoading:true
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}

export let buyCoupon = (params)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.buyCoupon,
            method: 'post',
            data: params,
            hideLoading:true
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}

export let getCouponDetail = (params)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.getCouponDetail,
            method: 'post',
            data: params,
            hideLoading:true
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}

export let getCouponDetail2 = (params)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.getCouponDetail2+"?couponCode="+params.couponCode,
            method: 'get',
            data: params
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}

export let getCouponUserDetail = (params)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.getCouponUserDetail,
            method: 'get',
            data: params
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}

export let getCouponDetailNormal = (params)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.getCouponDetailNormal,
            method: 'post',
            data: params
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}

export const getCouponStatus  = (params)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.getCouponStatus,
            method: 'get',
            data: params
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}
