/***
 * desc：积分接口
 * author： gry
 * date： 2019年9月8日15:23:57
 */

import api from '@/plugins/api'
import request from '@/plugins/request'

export let doScan = (params)=>{
    return new Promise(resolve=>{
        let requestOptions = {
            path: api.doScan,
            method: 'post',
            data: params,
            isLoading: 'false'
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}
