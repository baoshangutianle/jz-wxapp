<template>
    <div class="navigation">
        <web-view :src="webViewUrl"></web-view>
    </div>
</template>
<script>
export default {
    data() {
        return {
            webViewUrl: ''
        }
    },
    onShow() {
        this.webViewUrl = 'https://foresight.aegeanpark.cn/map/#/temp-m-map?' + new Date().getTime()
    },
    onHide(){
        this.webViewUrl = ''
    }
}
</script>
