<template>
    <div
        id="notice"
        class="blank"
    >
        <text
            v-if="noticeResponse.length > 0"
            class="my-car"
        >我的车辆（{{ carNumber }}/3）</text>
        <div class="main">
            <div
                v-if="noticeResponse.length==0"
                class="no-data"
            >
                <img
                    class="no-data-img"
                    src="https://img-cdn.aimall.cloud/as/20200601/e3e723312d834b6ea367e2c5cac0cd63.png"
                    mode="scaleToFill"
                    alt="无数据图片"
                >
                <p class="no-data-tip">
                    你还未绑定车牌哦<br>最多可增加3个车牌
                </p>
            </div>
            <div v-else>
                <div
                    v-for="(item,index) in noticeResponse"
                    :key="index"
                    class="flex-wrp shadow car"
                >
                    <div class="flex-item car-info">
                        <span class="car-type">
                            <span>{{ item.frontCar }}</span>
                            <span>·</span>
                            <span>{{ item.afterCar }}</span>
                        </span>
                    </div>
                    <div class="flex-item car-operate">
                        <button
                            v-if="from != 'mine'"
                            class="btn-wrap btn-pay"
                        >
                            <auth-btn @pass="checkUserInfo('pay',item)" />去支付
                        </button>
                        <button
                            v-if="from == 'mine'"
                            class="btn-wrap btn-un-bind"
                        >
                            <auth-btn @pass="checkUserInfo('unBind',item.carNumber)" />解绑车牌

                        </button>
                    </div>
                </div>
                <div
                    class="pay-money"
                    @tap="goCharges"
                >
                    <span class="pay-money-icon">
                        <img src="/static/images/message.png">
                    </span>
                    收费标准
                </div>
            </div>
            <div class="bottom-wrap">
                <button
                    :class="{'btn-operate':noticeResponse.length==0,'btn-hasadd': noticeResponse.length!=0}"
                    :disabled="noticeResponse.length >= 3"
                    class="btn-wrap btn-add"
                >
                    <auth-btn @pass="checkUserInfo('addCar','')" />增加车牌
                </button>
                <p v-if="from != 'mine'" class="car-text">如需解绑车牌请到“我的-车牌管理”解绑</p>
            </div>
        </div>
    </div>
    <!-- <div class="stayTunedcontainer">
        <span class="go_live">敬请期待....</span>
    </div> -->
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import loaderMore from '../../components/loaderMore'
import wxUtils from '@/plugins/wxUtils'
import AuthBtn from '@/components/AuthBtn'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import GzhLoginComp from '@/components/GzhLoginComp'

export default {
    components: {
        GzhLoginComp,
        loaderMore,
        AuthBtn
    },
    data() {
        return {
            from: '',//页面来源
            pageStayTime: 0, //页面停留时间
            loaderMore: true,
            noticeResponse: [],
            // sessionId: wxUtils.getSessionKeyStorage(),
            carNumber: null,
            btnDisabled: true,
            isGzhLoginShow: false
        }
    },
    computed: {
        ...mapState(['sessionId','mallCode', 'vipInfo','isLogined'])
    },
    onLoad(options) {
        this.from = options.from

        wx.setNavigationBarTitle({
            title: this.from=='mine'?'车牌管理':'停车缴费'
        })
        //从小程序码扫码登录后记录来源
        if(options.q){
            if(decodeURIComponent(utils.getCurrentPageUrlWithArgs().q)){
                const url = decodeURIComponent(utils.getCurrentPageUrlWithArgs().q);
                const params = url.split("?")[1];
                const category = params.split("&")[0].split("=")[1];
                const time = params.split("&")[1].split("=")[1];
                const type = params.split("&")[2].split("=")[1];
                wx.setStorageSync('sourceFrom',utils.getsourceFrom(category))
            }
        }
    },
    onShow(options) {
        // 获取车辆列表
        this.resetRefresh()
        // 埋点 P
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.CAR_P
        })
        this.btnDisabled = false;
    },
    onUnload() {
    //埋点 Z
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.CAR_Z,
            p_stay_time: this.pageStayTime
        })
    },

    watch: {
        vipInfo(newVal) {
            this.resetRefresh()
        }
    },
    mounted() {
        this.loaderMore = true
    },
    methods: {
        ...mapMutations(['update']),
        resetRefresh(){
            if (this.vipInfo) {
                this.getCarUserList()
            }else{
                this.noticeResponse = []
                if(utils.isFromGzh(this.scene) && !this.wxUserInfo){
                    this.isGzhLoginShow = true
                    wx.navigateTo({
                        url: `/listOfActivities/shareAuth`
                    })
                }
            }
        },
        closeGzhLogin(flag){
            this.isGzhLoginShow = false//关闭弹框
            // if(flag){
            //     this.resetRefresh()
            // }
        },
        pay(item) {
            let t = this;
            if (!t.btnDisabled) {
                t.btnDisabled = true
                //let carNumber = '京HXTT65'
                let carNumber = item.carNumber
                let data = {
                    carNumber: carNumber
                }
                wx.request({
                    url: api.getOrderDetail,
                    method: 'GET',
                    data: data,
                    header: {
                        Authorization: t.sessionId,
                        'L-A-Platform': 'mini-program' //后端日志埋点渠道
                    },
                    success(res) {
                        if (res.data.code === 200) {
                            wx.navigateTo({
                                url: `/pages/parkPay/pay?id=${item.carNumber}`
                            })
                        } else if (res.data.code === 404) {
                            t.btnDisabled = false
                            wx.showModal({
                                title: res.data.message,
                                // content: '确定要删除该图片？',
                                showCancel: false, //是否显示取消按钮
                                cancelText: '否', //默认是“取消”
                                cancelColor: 'skyblue', //取消文字的颜色
                                confirmText: '确定', //默认是“确定”
                                confirmColor: '#9975F3', //确定文字的颜色
                                success: function(res) { }
                            })
                        } else {
                            t.btnDisabled = false
                            wx.showModal({
                                title: res.data.message,
                                // content: '确定要删除该图片？',
                                showCancel: false, //是否显示取消按钮
                                cancelText: '否', //默认是“取消”
                                cancelColor: 'skyblue', //取消文字的颜色
                                confirmText: '确定', //默认是“确定”
                                confirmColor: '#9975F3', //确定文字的颜色
                                success: function(res) { }
                            })
                        }
                    }
                })
            }
        },
        // 查看详情
        goToRouter(id) {
            wx.navigateTo({
                url: `/pages/notice/details?id=${id}`
            })
        },
        // 获取车牌列表
        getCarUserList() {
            let vipId = wxUtils.getUserCodeStorage()
            let t = this
            wx.request({
                url: api.getUserCars,
                method: 'POST',
                data: {
                    vipId: vipId,
                    pageNum: 1,
                    pageSize: 20
                },
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code === 200) {
                        let busArr = []
                        if (res.data.data.list) {
                            res.data.data.list.forEach(item => {
                                let obj = {
                                    frontCar: t.subStringFront(item.carNumber),
                                    afterCar: t.subStringAfter(item.carNumber),
                                    carNumber: item.carNumber
                                }
                                busArr.push(obj)
                            })
                            t.carNumber = res.data.data.list.length
                            t.noticeResponse = busArr
                        }
                    } else {
                        let msg = {
                            title: res.data.message,
                            icon: 'none',
                            image: '../../static/images/icon-msg.png'
                        }
                        wx.showToast(msg)
                    }
                }
            })
        },
        //校验用户信息是否过期
        checkUserInfo(type,data){
             const t = this
            //调用接口确定用户是否过期
            wx.request({
                url: api.tokenIsExpired,
                method: 'GET',
                data: null,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if(res.data.code == 4001 || res.data.code == 4000 || res.data.code == 216001){
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success (res) {
                                let oldIsLogined = t.isLogined
                                wxUtils.clearLoginStorage()
                                t.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        })
                    }else if(res.data.code == 200 || res.data.code == 0){
                        if(type == 'addCar'){
                            t.addCar()
                        }else if(type == 'unBind'){
                            t.unBind(data)
                        }else if(type == 'pay'){
                            t.pay(data)
                        }
                    }else{
                        wx.showModal({
                            title: '提醒',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA'
                        })
                    }
                }
            })
        },
        // 跳转增加车牌
        addCar() {
            if (this.noticeResponse.length >= 3) {
                return;
            }
            buryPoint.setF({
                id: pointCode.CAR_F_ADD
            })
            wx.navigateTo({
                url: `/pages/parkPay/licence`
            })
        },
        // 车牌截取
        subStringFront(data) {
            return data.substring(0, 2)
        },
        subStringAfter(data) {
            return data.substring(2)
        },
        // 取消绑定
        unBind(carNumber) {
            let t = this
            wx.showModal({
                title: '确定解绑此车牌',
                // content: '确定解绑此车牌',
                cancelText: '再想想',
                confirmText: '确认解绑',
                success: function(res) {
                    if (res.confirm) {
                        let vipId = wxUtils.getUserCodeStorage()
                        let data = {
                            vipId: vipId,
                            carNumber: carNumber,
                            openId: wxUtils.getOpenIdStorage()
                        }
                        wx.request({
                            url: api.unBindingCar,
                            method: 'POST',
                            data: data,
                            header: {
                                Authorization: t.sessionId,
                                'L-A-Platform': 'mini-program' //后端日志埋点渠道
                            },
                            success(res) {
                                if (res.data.code === 200) {
                                    let success = {
                                        title: '车牌解绑成功！',
                                        icon: 'success',
                                        image: '../../static/images/icon-remove.png'
                                    }
                                    wx.showToast(success)
                                    t.resetRefresh()
                                } else {
                                    let msg = {
                                        title: res.data.message,
                                        icon: 'none',
                                        image: '../../static/images/icon-msg.png'
                                    }
                                    wx.showToast(msg)
                                }
                            }
                        })
                    } else {
                    }
                }
            })
        },
        //跳转到收费标准页面
        goCharges() {
            wx.navigateTo({
                url: `/pages/parkPay/charges`
            })
        }
    },
}
</script>

<style lang="less">
@import url(../../assets/styles/vars);
.stayTunedcontainer {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    text-align: center;
    width: 100%;
    height: 100%;
    min-height: 100vh;
    background: #f5f6fa;
    text-align: center;
    .go_live{
        color: #d5d5d5;
        font-size: 15px;
        padding-top: 150px;
        display: inline-block;
    }
}
#notice {
    width: 100vw;
    .no-data {
        font-size: 0;
        text-align: center;
        .no-data-img {
            display: inline-block;
            width: 245px;
            height: 171px;
            margin-top: 90px;
        }
        .no-data-tip {
            margin-top: 30px;
            font-size: 18px;
            line-height: 25px;
            color: @gray-color;
        }
    }
    .btn-wrap {
        position: relative;
    }
    .main {
        padding: 0 15px;
        .shadow {
            // box-shadow: 0 0 5px #bcbcbc;
            box-shadow: 0 0 10rpx 0 rgba(188, 188, 188, 0.3);

        }
        .car {
            align-items: center;
            height: 100px;
            background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/6b731cf5e4244eeeb1ffa3c8916247a5.png');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center center;
            border-radius: 4px;
            margin: 15px 0;
            .car-info {
                flex: 1;
                padding: 0 0 0 20px;
                .car-type {
                    width: 132px;
                    height: 44px;
                    line-height: 44px;
                    text-align: center;
                    font-size: 20px;
                    background-size: 100% 100%;
                    .car-img {
                        z-index: -1;
                        position: absolute;
                        width: 100%;
                        height: 100%;
                        top: 0;
                        left: 0;
                    }
                }
            }
            .car-operate {
                flex: 0 1 100px;
                .btn-pay,
                .btn-un-bind {
                    height: 34px;
                    line-height: 32px;
                    margin: 0 20px 0 0;
                    font-size: 15px;
                    white-space: nowrap;
                    border-radius: 17px;
                }
                .btn-pay {
                    background: @theme-color;
                    color: #fff;
                    border: 1px solid;
                }
                .btn-un-bind {
                    border: 1px solid @theme-color;
                    background: @white-color;
                    color: @theme-color;
                }
                button::after {
                    border: 0;
                }
            }
        }
    }
    .bottom-wrap {
        position: fixed;
        left: 15px;
        right: 15px;
        bottom: 100px;
    }
    .btn-add {
        display: block;
        margin: 18px 0 0;
        display: flex;
        align-items: center;
        justify-content: center;
        &:before {
            display: inline-block;
            content: '';
            width: 17px;
            height: 17px;
            margin-right: 8px;
            background-image: url('../../static/images/add-icon.png');
            // vertical-align: middle;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            -moz-background-size: 100% 100%;
        }
        &[disabled] {
            opacity: 0.4;
        }
    }
    .btn-hasadd {
        background: #fff;
        border: solid 1px #9975F3;
        color: #9975F3;
        &:before {
            background-image: url('../../static/images/addCar.png');
            // vertical-align: middle;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            -moz-background-size: 100% 100%;
        }
    }
    .tip {
        display: block;
        background: #eff1f8;
        font-size: 12px;
        text-align: center;
        padding: 10px;
    }
    .my-car {
        display: block;
        font-size: 15px;
        text-align: left;
        padding: 20px 15px 0;
        color: #999999;
    }
    .blank {
        width: 100vw;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        align-content: center;
        flex-wrap: wrap;
        text-align: center;
        font-size: 14px;
        color: #666666;
        .pic {
            width: 100%;
            img {
                width: 190px;
                height: 150px;
                margin: 0 auto 20px;
            }
        }
    }
    .noticeItem {
        width: 100%;
        height: 80px;
        padding-left: 20px;
        padding-right: 20px;
        display: flex;
        align-items: center;
        background-color: #fff;
        border-bottom: 1px solid #e4e4e4;
    }
    .add {
        box-shadow: 0 0 5px #bcbcbc;
        background: transparent;
        border: 0;
        display: block;
        width: 100%;
        margin: 0 15px;
    }
    .pay-money {
        font-size: 15px;
        color: #999999;
        text-align: left;
        height: 30px;
    }
    .pay-money-icon {
        display: inline-block;
        width: 14px;
        height: 14px;
        vertical-align: middle;

        img {
            width: 14px;
            height: 14px;
        }
    }
    .car-text {
        font-size: 13px;
        color: #999999;
        text-align: center;
        font-weight: 200;
        margin: 10px 0 0;
        align-items: center;
        background: #fff;
    }
}
</style>
