<template>
    <div class="charges">
        <div class="charges-con">
            <p class="charges-title">停车场收费标准</p>
            <p class="charges-text pt20">1小时内7元，超过1小时部分3.5元/0.5小时</p>
            <p class="charges-title pt20">收费标准明细</p>
            <p class="charges-text pt20">1.本停车场15分钟内免费，缴费后15分钟内离场</p>
            <p class="charges-text">2.停车8小时至24小时按全天费用收取56元，超出24小时重新计费</p>
            <p class="charges-text">3.无牌车辆停车票丢失按全天费用收取56元，隔天重新计费</p>
            <p class="charges-text">4.停车场收费处:B2层H区2号客梯厅(收费时间0:00--24:00)、B3层M区2号客梯厅(收费时间10:00--22:00)</p>
            <p class="charges-text">5.如需停车发票:请至人工收费处缴费并索取</p>
            <p class="charges-text">6.线下缴费处支付，不享受停车优惠</p>
            <p class="charges-text">7.查车服务:可点击进入南海嘉洲广场微信公众号及B2、B3电梯厅使用自动 寻车系统</p>
            <p class="charges-text">8.停车服务热线:18721928375</p>
        </div>

    </div>
</template>
<script>
export default {
    data(){
        return{
        }
    },
}
</script>
<style lang="less" scoped>
@import '../../assets/styles/vars';
.charges{
    width: 100%;
    height: 100%;
    background: @white-color;
    .charges-con{
        margin: 20px 25px;
    }
    .pt20{
        padding-top: 20px;
    }
    .charges-title{
        font-size:18px;
        color:@black-color;
        line-height:25px;
    }
    .charges-text{
        font-size:15px;
        color:@dark-color;
        line-height:21px;
        padding-bottom: 20px;
    }
}

</style>
