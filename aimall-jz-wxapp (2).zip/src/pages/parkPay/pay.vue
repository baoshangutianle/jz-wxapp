<template>
    <div class="ad-detail-box">
        <div class="ads-img">
            <div v-show="!isNewEnergy" class="car-bg">
                <span>{{ subStringFront }}</span>
                <span>{{ " " }}</span>
                <span>{{ subStringAfter }}</span>
            </div>
            <div v-show="isNewEnergy" class="carx-bg">
                <span class="pl2">{{ subStringFront }}</span>
                <span>{{ " " }}</span>
                <span>{{ subStringAfter }}</span>
            </div>
        </div>
        <div class="list-box">
            <div class="list-item">
                <div class="label">入场时间</div>
                <div class="value">
                    <p class="ads-time">{{ carOrderDetail.time }}</p>
                    <p class="ads-date">{{ carOrderDetail.date }}</p>
                </div>
            </div>

            <div class="list-item">
                <div class="label">停车时长</div>
                <div class="value">{{carOrderDetail.parkingTime }}</div>
            </div>

            <!-- <div class="list-item">
                <div class="label">停车地点</div>
                <div class="value">b4-0888</div>
            </div>-->

            <div class="list-item">
                <div class="label">停车费用</div>
                <div class="value" style="font-weight: 900;">¥{{ constLeftAmount }}元</div>
            </div>

            <div class="list-item" @click="checkUserInfo('clickCoupon')">
                <div class="label">
                    <p>停车券支付</p>
                    <p style="font-size: 12px;">
                        卡券剩余
                        <span style="color: red">{{payList.length}}张</span>
                    </p>
                </div>
                <div class="value">
                    <span
                        v-show="couponIdList.length > 0"
                        class="ads-card-expense"
                        style="font-weight: 900;font-size: 15px"
                    >停车抵用券{{couponIdList.length}}张</span>
                    <span class="ads-arrow">
                        <img src="/static/images/parkFee-car-arrow.png" />
                    </span>
                </div>
            </div>
            <!-- <div class="coupon-deduction">
                <div>
                    <p style="font-size: 15px; color: #999;">积分抵扣</p>
                    <p style="font-size: 12px; color: #999;">
                        积分余额
                        <span style="color: #ff4747;">{{ availableIntegral }}</span>
                        分,每{{vipInfo&&vipInfo.integralGradeId == 4 ? 200 : 300}}积分可抵扣7元
                    </p>
                </div>
                <div class="coupon-btn">
                    <div class="reduce-btn" @click="reduce(true)">-</div>
                    <div class="coupun-input">{{availableIntegralUser}}</div>
                    <div class="plus-btn" @click="plus">+</div>
                </div>
            </div> -->
            <!-- <div class="list-item">
                <div class="label">
                    <p>积分抵扣</p>
                    <p class="ads-tip" style="width: 237px;">
                        积分余额
                        <span class="ads-emphasis">{{ availableIntegral }}</span>
                        分,每{{vipInfo&&vipInfo.integralGradeId == 4 ? 200 : 300}}积分可抵扣7元
                    </p>
                </div>
                <div class="value flex-wrp points">
                    <span class="flex-item">
                        <button class="points-minus" @click="reduce(true)" />
                    </span>
                    <span class="flex-item">
                        <input
                            v-model="availableIntegralUser"
                            disabled
                            class="points-val"
                            type="text"
                            @input="userAvailableChange(availableIntegralUser)"
                        />
                    </span>
                    <span class="flex-item">
                        <button class="points-add" @click="plus" />
                    </span>
                </div>
            </div>-->
            <!-- <div class="asd_remark">
                 <p class="ads-tip">为了您的积分安全，支付未成功将冻结支付积分，15分钟后返还</p>
            </div>-->
        </div>
        <div class="flex-wrp ads-operate">
            <dis class="flex-item ads-operate-info">
                还需支付：
                <span
                    class="ads-emphasis ads-pay-money"
                >¥{{ carOrderDetail.leftAmount ? carOrderDetail.leftAmount : '0' }}</span>
            </dis>
            <div class="flex-item">
                <div class="btn-box">
                    <button
                        :loading="btnLoading"
                        class="btn btn-submit"
                        type="primary"
                        @click="checkUserInfo('handleSubmit')"
                    >确认支付</button>
                </div>
            </div>
        </div>
        <PayCouponDialog
            ref="PayCouponDialog"
            :isShowDialog="dialogShow"
            :payList="payList"
            :payAmount="constCouponAmount"
            @clickCouponClose="clickCouponClose"
            @clickCouponSubmit="clickCouponSubmit"
        >
            <view>test content</view>
        </PayCouponDialog>
    </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import api from '../../plugins/api'
import wxUtils from '@/plugins/wxUtils'
import moment from 'moment'
import md5 from 'md5'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import PayCouponDialog from '@/components/PayCouponDialog'
import utils from '../../plugins/utils'

export default {
    components: {
        PayCouponDialog
    },
    data() {
        return {
            utils,
            showClear: false,
            btnLoading: false,
            infoData: {},
            groupType: {},
            formType: {},
            minSellList: {},
            form: {
                trun: 1,
                startDate: '',
                endDate: ''
            },
            carOrderDetail: {},
            availableIntegral: 0,
            availableIntegralUser: 0,
            constAvailableIntegralUser: 0,
            mallCode: null,
            parkingLotOrderNo: null,
            // sessionId: wxUtils.getSessionKeyStorage(),
            isNewEnergy: false,
            // isNewEnergy: this.$root.$mp.query.id.length > 7 ? true : false,
            subStringFront: '',
            subStringAfter: '',
            constLeftAmount: 0,
            // 阻止多次提交
            btnDisabled: false,
            computeLock: false, //计算锁
            operate: '',
            dialogShow: false,
            dialogButtons: [{ text: '取消' }, { text: '确定' }],
            payList: [],
            couponIdList: [],
            // 用券抵扣金额缓存
            constCouponAmount: 0,
            // 用券抵扣掉的金额
            couponAmount: 0,
            // 积分兑换金额缓存
            integralAmount: 0,
            // 抵用券共能抵用多少钱
            allCouponAmount: 0,
            // 缓存选中抵用券数组
            couponIdListArray: []
        }
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo', 'isLogined'])
    },
    mounted() {
        // this.getOrderDetail()
        let carNumber = this.$root.$mp.query.id
        this.isNewEnergy = carNumber.length > 7 ? true : false
        this.subStringFront = carNumber.substring(0, 2)
        this.subStringAfter = carNumber.substring(2)
        // 选择租赁时间
        let query = this.$root.$mp.query
        if (query && query.date1) {
            let s = query.date1.replace(/-/g, '/')
            let e = query.date2.replace(/-/g, '/')
            let date1 = new Date(s).getTime()
            let date2 = new Date(e).getTime()

            let startDate = null
            let endDate = null

            if (date1 < date2) {
                startDate = query.date1
                endDate = query.date2
            } else {
                startDate = query.date2
                endDate = query.date1
            }
            this.form.startDate = startDate
            this.form.endDate = endDate
            this.form.trun = query.trun
        }
    },

    onLoad() {
        // let enumInfo = wx.getStorageSync('adEnumInfo')
        // if (enumInfo) {
        //     this.groupType = enumInfo.adGroup_type
        //     this.formType = enumInfo.adGroup_form
        //     this.minSellList = enumInfo.adGroup_cycle
        // }
    },

    onUnload() {
        this.infoData = {}
        this.form.trun = 1
        this.form.startDate = ''
        this.form.endDate = ''

        buryPoint.setZ({
            id: pointCode.CAR_PAY_Z
        })
    },

    onShow() {
        this.btnDisabled = false
        this.getOrderDetail()
        this.getParkCouponList()
        this.getVipInfoByMobile()
        this.getVipBasicInfo()
        this.couponIdList = []
        this.couponIdListArray = []
        this.constCouponAmount = 0
        this.couponAmount = 0
        this.integralAmount = 0
        this.allCouponAmount = 0

        //this.constCouponAmount = this.constLeftAmount
        // 埋点 P
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.CAR_PAY_P
        })
    },

    methods: {
        ...mapMutations(['update']),
        //获取会员基本信息（不包含头像）
        getVipBasicInfo() {
            utils.getVipInfo().then(vipInfo => {
                this.update({
                    vipInfo: vipInfo
                })
            })
        },
        getOrderDetail() {
            let t = this
            // let carNumber = '京HXTT65'
            let carNumber = this.$root.$mp.query.id
            let data = {
                carNumber: carNumber
            }
            wx.request({
                url: api.getOrderDetail,
                method: 'GET',
                data: data,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code === 200) {
                        if (!res.data.data.leftAmount) {
                            res.data.data.leftAmount = 0
                        }
                        // res.data.data.leftAmount = 50
                        t.constLeftAmount = res.data.data.leftAmount
                        t.constCouponAmount = res.data.data.leftAmount
                        t.carOrderDetail = res.data.data
                        t.carOrderDetail.time = moment(res.data.data.parkingInTime).format('HH:mm:ss')
                        t.carOrderDetail.date = moment(res.data.data.parkingInTime).format('YYYY年MM月DD日')

                        // t.carOrderDetail.parkingTime = Math.floor(res.data.data.parkingTime / 60)
                        t.carOrderDetail.parkingTime = utils.formatSeconds(res.data.data.parkingTime)
                        t.availableIntegralUser = 0
                    }
                }
            })
        },
        // 获取积分
        getVipInfoByMobile() {
            let mobile = wxUtils.getPhoneStorage()
            let t = this
            let data = {
                mobile: mobile
            }
            wx.request({
                url: api.getVipInfoByMobile,
                method: 'GET',
                data: data,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code === 200 && res.data.data) {
                        if (res.data.data.availableIntegral) {
                            t.availableIntegral = res.data.data.availableIntegral
                            t.constAvailableIntegralUser = res.data.data.availableIntegral
                            console.log(t.availableIntegral, t.constAvailableIntegralUser)
                        }
                        t.mallCode = res.data.data.mallCode
                    } else if (res.data.code == 4000 || res.data.code == 4001) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = t.isLogined
                                wxUtils.clearLoginStorage()
                                t.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        })
                    } else {
                        let success = {
                            title: res.data.message,
                            icon: 'none'
                        }
                        wx.showToast(success)
                    }
                }
            })
        },
        // 加减
        reduce(flag) {
            let t = this
            // if(flag){
            //     this.operate = 'reduce'
            // }else{
            //     this.operate = 'plus'
            // }
            if (t.computeLock) {
                return
            }

            // 除了4，其他都是300
            const num = this.getCardNum()
            // 当前输入框中的积分
            let data = t.availableIntegralUser * 1000 / 1000
            // 积分常量
            let constAva = t.constAvailableIntegralUser * 1000 / 1000

            if (data > constAva) {
                t.availableIntegralUser = constAva
                t.availableIntegral = 0
            } else if (data <= 0) {
                t.availableIntegralUser = 0
                t.availableIntegral = constAva
            } else if (num == 200) {
                if (data - 200 > constAva) {
                    t.availableIntegralUser = constAva
                    t.availableIntegral = 0
                } else {
                    t.availableIntegralUser = data - 200
                    t.availableIntegral = constAva - t.availableIntegralUser
                }
            } else {
                if (data - 300 > constAva) {
                    t.availableIntegralUser = constAva
                    t.availableIntegral = 0
                } else {
                    t.availableIntegralUser = data - 300
                    t.availableIntegral = constAva - t.availableIntegralUser
                }
            }
            if (flag != 'fail') {
                t.computeLock = true
                t.findIntegralConvert(t.availableIntegralUser).finally(() => {
                    t.computeLock = false
                })
            }

            // 当前输入框中的积分
            // let data = t.availableIntegralUser
            // if (data != '' && data != 0) {
            //     data = Number(data) + num
            // }
            // t.availableIntegralUser = data
            // if (data !== 0) {
            //     t.findIntegralConvert(data).finally(()=>{
            //         t.computeLock = false
            //     })
            // } else {
            //     t.computeLock = false
            // }
        },
        //获取相应卡增减积分
        getCardNum() {
            let integralGradeId = this.vipInfo && this.vipInfo.integralGradeId
            let num = integralGradeId == 4 ? 200 : 300
            return num
        },
        plus() {
            let t = this
            if (t.computeLock) {
                return
            }

            // 除了4，其他都是300
            const num = this.getCardNum()

            if (t.carOrderDetail.leftAmount == 0) {
                let success = {
                    title: '您已达到金额抵扣上限',
                    icon: 'none'
                    // image: '../../static/images/icon-msg.png'
                }
                wx.showToast(success)
                return
            }
            if (t.availableIntegral < num) {
                let success = {
                    title: '您的积分不足',
                    icon: 'none'
                    // image: '../../static/images/icon-msg.png'
                }
                wx.showToast(success)
                return
            }
            // 当前输入框中的积分
            let data = t.availableIntegralUser * 1000 / 1000
            // 积分常量
            let constAva = t.constAvailableIntegralUser * 1000 / 1000
            if (data >= constAva) {
                t.availableIntegralUser = constAva
                t.availableIntegral = 0
            } else if (data < 0) {
                t.availableIntegralUser = 0
                t.availableIntegral = constAva
            } else if (num == 200) {
                if (data + 200 > constAva) {
                    t.availableIntegralUser = constAva
                    t.availableIntegral = 0
                } else {
                    t.availableIntegralUser = data + 200
                    t.availableIntegral = constAva - t.availableIntegralUser
                }
            } else {
                if (data + 300 > constAva) {
                    t.availableIntegralUser = constAva
                    t.availableIntegral = 0
                } else {
                    t.availableIntegralUser = data + 300
                    t.availableIntegral = constAva - t.availableIntegralUser
                }
            }
            t.computeLock = true
            t.findIntegralConvert(t.availableIntegralUser).finally(() => {
                t.computeLock = false
            })

            // if (data != '' || data == 0) {
            //     data = Number(data) + num
            // }
            // if (Number(constAva) - Number(data) < 0) {
            //     if (Number(data) > 100) {
            //         data = Number(data) - 100
            //     } else {
            //         data = 0
            //     }
            // } else {
            //     if (data > constAva) {
            //         data = constAva
            //         let success = {
            //             title: '当前可用积分不足',
            //             icon: 'none',
            //             image: '../../static/images/icon-msg.png'
            //         }
            //         wx.showToast(success)
            //     }
            // }
            // t.availableIntegralUser = data
            // if (data !== 0) {
            //     t.findIntegralConvert(data).finally(()=>{
            //         t.computeLock = false
            //     })
            // } else {
            //     t.computeLock = false
            // }
        },
        // 用户输入积分change
        userAvailableChange(data) {
            let t = this
            let constAva = t.constAvailableIntegralUser
            if (Number(data) > constAva) {
                data = constAva
                let success = {
                    title: '当前可用积分不足',
                    icon: 'none',
                    image: '../../static/images/icon-msg.png'
                }
                wx.showToast(success)
            }
            t.availableIntegralUser = data
            if (data !== 0) {
                t.findIntegralConvert(data).finally(() => {
                    t.computeLock = false
                })
            } else {
                t.computeLock = false
            }
        },
        // 积分兑换金额
        findIntegralConvert(data) {
            let t = this
            const moneydata = data
            return new Promise(resolve => {
                let mobile = wxUtils.getPhoneStorage()
                let Data = {
                    mobile: mobile,
                    integral: data,
                    mallCode: t.mallCode
                }
                wx.request({
                    url: api.findIntegralConvert,
                    method: 'POST',
                    data: Data,
                    header: {
                        Authorization: t.sessionId,
                        'L-A-Platform': 'mini-program' //后端日志埋点渠道
                    },
                    success(res) {
                        if (res.data.code === 200) {
                            t.computeLock = false
                            t.integralAmount = res.data.data.convertAmount
                            t.countNumberFunc()

                            // if (t.couponAmount + 7 > t.allCouponAmount) {
                            //     t.couponAmount = t.allCouponAmount
                            // }
                            // if (t.constLeftAmount - res.data.data.convertAmount - t.couponAmount < 0) {
                            //     //判断积分不足情况已经已到上线情况

                            //     t.reduce()
                            //     if (moneydata >= t.getCardNum()) {
                            //         let success = {
                            //             title: '您已达到金额抵扣上限 ',
                            //             icon: 'none'
                            //             // image: '../../static/images/icon-msg.png'
                            //         }
                            //         wx.showToast(success)
                            //     } else {
                            //         let success = {
                            //             title: '您的积分不足',
                            //             icon: 'none'
                            //             // image: '../../static/images/icon-msg.png'
                            //         }
                            //         wx.showToast(success)
                            //     }
                            // } else {
                            //     t.integralAmount = res.data.data.convertAmount
                            //     // 判断应付金额-积分兑换的金额是否仍然小于抵用券可兑换的金额
                            //     if (t.allCouponAmount > t.constLeftAmount - res.data.data.convertAmount) {
                            //         // t.carOrderDetail.leftAmount = 0;
                            //         t.clickCouponSubmit(t.couponIdListArray)
                            //     } else {
                            //         t.carOrderDetail.leftAmount = t.constLeftAmount - res.data.data.convertAmount - t.allCouponAmount
                            //     }
                            //     t.constCouponAmount = t.constLeftAmount - res.data.data.convertAmount
                            // }
                        } else {
                            t.reduce('fail')
                            let success = {
                                title: res.data.message,
                                icon: 'none'
                                // image: '../../static/images/icon-msg.png'
                            }
                            wx.showToast(success)
                        }
                        resolve()
                    },
                    fail() {
                        t.computeLock = false
                    }
                })
            })
        },
        // 提交
        handleSubmit() {
            let t = this
            if (!t.btnDisabled) {
                t.btnDisabled = true
                // 埋点 F
                buryPoint.setF({
                    id: pointCode.CAR_PAY_F_PAY
                })
                let key = '40a2a2fc-a019-4a9c-8d83-3d13e52cfb8c'
                let totalAmount = t.constLeftAmount
                let vipId = wxUtils.getUserCodeStorage()
                let mobile = wxUtils.getPhoneStorage()
                let integral = t.availableIntegralUser
                let parkingLotOrderNo = t.carOrderDetail.parkingLotOrderNo
                let couponIds = t.couponIdList
                let busArr = []
                let openId = wxUtils.getOpenIdStorage()
                busArr.push('totalAmount=' + totalAmount)
                busArr.push('vipId=' + vipId)
                busArr.push('integral=' + integral)
                busArr.push('parkingLotOrderNo=' + parkingLotOrderNo)
                busArr.push('mobile=' + mobile)
                busArr.push('openId=' + openId)
                // 根据ASCII针对key进行排序
                var s1 = Array.prototype.sort.call(busArr, function(a, b) {
                    for (var i = 0; i < a.length; i++) {
                        if (a.charCodeAt(i) == b.charCodeAt(i)) continue
                        return a.charCodeAt(i) - b.charCodeAt(i)
                    }
                })
                // 添加key
                let sign = s1.join('&') + '&key=' + key
                let data = {
                    totalAmount: totalAmount,
                    vipId: vipId,
                    integral: t.availableIntegralUser,
                    mobile: mobile,
                    parkingLotOrderNo: parkingLotOrderNo,
                    // MD5加密 然后转成大写
                    sign: md5(sign).toUpperCase(),
                    couponIds: couponIds,
                    openId: wxUtils.getOpenIdStorage()
                }
                // console.log(data)
                wx.request({
                    url: api.verifyOrder,
                    method: 'POST',
                    data: JSON.stringify(data),
                    header: {
                        Authorization: t.sessionId,
                        'L-A-Platform': 'mini-program' //后端日志埋点渠道
                    },
                    success(res) {
                        if (res.data.code === 200) {
                            t.handlePayment(res)
                            // 跳转至金科收银台小程序
                            // appid暂时写死   发生产时需要修改   可全局配置   目前金科还未提供生产的appid
                            // wx.navigateToMiniProgram({
                            //     // appId: 'wxfbb998275db834d9', //金科收银台测试小程序生产APPID
                            //     appId: 'wx31edd5740a6eb912', //金科收银台测试小程序APPID
                            //     path: 'pages/index/index',
                            //     extraData: {
                            //         prePayId: res.data.data.prePayId
                            //     },
                            //     envVersion: 'release', //develop 开发版 trial 体验版 release 正式版
                            //     success(res) {
                            //         // 打开成功
                            //         console.log('打开成功', res)
                            //         t.btnDisabled = false
                            //     },
                            //     fail(res) {
                            //         wx.request({
                            //             url: api.cancelOrder,
                            //             method: 'POST',
                            //             data: JSON.stringify(data),
                            //             header: {
                            //                 Authorization: t.sessionId,
                            //                 'L-A-Platform': 'mini-program' //后端日志埋点渠道
                            //             },
                            //             success(res) {
                            //                 t.getOrderDetail()
                            //                 t.getParkCouponList()
                            //                 t.getVipInfoByMobile()
                            //                 t.couponIdList = []
                            //                 t.couponIdListArray = []
                            //                 t.couponAmount = 0
                            //                 t.integralAmount = 0
                            //                 t.constCouponAmount = t.constLeftAmount
                            //                 t.$refs.PayCouponDialog.dedAmount = 0
                            //             }
                            //         })
                            //         console.log('打开失败', res)
                            //         t.btnDisabled = false
                            //     }
                            // })
                        } else if (res.data.code === 201) {
                            t.btnDisabled = false
                            //如果支付金额为0，则直接跳转支付成功页面
                            if (t.carOrderDetail.leftAmount == 0) {
                                const careNumber = t.subStringFront + t.subStringAfter
                                wx.redirectTo({
                                    url: `/pages/parkPay/status?type=success&id=${careNumber}`
                                })
                            }
                        } else {
                            let success = {
                                title: res.data.message,
                                icon: 'none',
                                image: '../../static/images/icon-msg.png'
                            }
                            wx.showToast(success)
                            t.btnDisabled = false
                        }
                    }
                })
            }
        },
        handlePayment(res) {
            let param = JSON.parse(res.data.data.payInfo)
            // console.log(param)
            wx.requestPayment({
                timeStamp: param.timeStamp,
                nonceStr: param.nonceStr,
                package: param.package,
                signType: param.signType,
                paySign: param.paySign,
                success: response => {
                    // console.log('支付成功')
                    wx.navigateBack()
                },
                fail: err => {
                    console.log(err)
                }
            })
            /** 第二步，根据后台返回的订单id生成商户订单 */
            // wx.request({
            //     url: '/testApi/wxPay/unifiedorder', // 生成订单接口
            //     method: 'POST',
            //     data: {
            //         openId: '获取到的该用户的openid,必传',
            //         totalFee: res.paidAmount, // 商品支付价格
            //         uid: res.uid // 后台生成的订单id
            //     },
            //     success: result => {
            //         /** 第三步，调用微信支付接口发起支付（我们后台返回的是JSON字符串，所以要转为JSON对象） */
            //         let param = JSON.parse(result)
            //         uni.requestPayment({
            //             timeStamp: param.timeStamp,
            //             nonceStr: param.nonceStr,
            //             package: param.package,
            //             signType: param.signType,
            //             paySign: param.paySign,
            //             success: response => {
            //                 console.log('支付成功')
            //             },
            //             fail: err => {
            //                 console.log(err)
            //             }
            //         })
            //     },
            //     fail: err => {
            //         console.log(err)
            //     }
            // })
        },
        // 获取停车券
        getParkCouponList() {
            let t = this
            let Data = {
                memberCode: wxUtils.getUserCodeStorage(),
                // memberCode: '51000367',
                mobile: wxUtils.getPhoneStorage(),
                mallCode: t.mallCode,
                systemName: 'min'
            }
            wx.request({
                url: api.parkCouponList,
                method: 'POST',
                data: Data,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code == 200) {
                        if (res.data.data && res.data.data.length > 0) {
                            res.data.data.forEach(item => {
                                item.checked = false
                            })
                            t.payList = res.data.data
                        }
                    } else {
                        t.payList = []
                    }
                },
                fail(err) {
                    console.log(err)
                }
            })
        },
        //校验用户信息是否过期
        checkUserInfo(type) {
            const t = this
            wx.request({
                url: api.tokenIsExpired,
                method: 'GET',
                data: null,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code == 4001 || res.data.code == 4000 || res.data.code == 216001) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = t.isLogined
                                wxUtils.clearLoginStorage()
                                t.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        })
                    } else if (res.data.code == 200 || res.data.code == 0) {
                        if (type == 'clickCoupon') {
                            t.clickCoupon()
                        } else if (type == 'handleSubmit') {
                            t.handleSubmit()
                        }
                    } else {
                        wx.showModal({
                            title: '提醒',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA'
                        })
                    }
                }
            })
        },
        // 点击券弹窗
        clickCoupon() {
            if (this.payList.length == 0) {
                let success = {
                    title: '没有可用券！',
                    icon: 'none'
                    // image: '../../static/images/icon-msg.png'
                }
                wx.showToast(success)
            } else {
                this.dialogShow = true
            }
        },
        clickCouponClose() {
            this.dialogShow = false
        },
        clickCouponSubmit(data) {
            let t = this
            let busAmount = 0
            let busBoolean = false
            let busArray = []
            let constArray = []
            // console.log(data);
            data.forEach(item => {
                if (item.checked) {
                    busBoolean = true
                    busAmount += item.amount
                    busArray.push(item.couponId)
                    constArray.push(item)
                }
            })
            if (!busBoolean) {
                t.couponIdListArray = []
                // t.carOrderDetail.leftAmount = t.constLeftAmount - t.integralAmount
                t.allCouponAmount = 0
                t.couponAmount = 0
            } else {
                t.couponIdListArray = constArray
                t.allCouponAmount = busAmount
                if (t.constLeftAmount - t.integralAmount < busAmount) {
                    t.couponAmount = t.constLeftAmount - t.integralAmount
                    // t.carOrderDetail.leftAmount = 0
                } else {
                    t.couponAmount = busAmount
                    // t.carOrderDetail.leftAmount = t.constLeftAmount - busAmount - t.integralAmount
                }
            }
            t.countNumberFunc()
            // console.log('最终金额：', t.carOrderDetail.leftAmount, '券抵扣：', t.couponAmount, '积分抵扣：', t.integralAmount,"券一共能抵",t.allCouponAmount)
            t.couponIdList = busArray
        },
        // 核心计算方法
        countNumberFunc() {
            let t = this
            // 券抵扣金额
            let couponAmount = t.allCouponAmount * 100
            // 积分抵扣的金额
            let integralAmount = t.integralAmount * 100
            // 允许用券抵扣的金额
            t.constCouponAmount = (t.constLeftAmount * 100 - integralAmount) / 100
            // 用户需要支付的实际金额
            t.carOrderDetail.leftAmount = (t.constLeftAmount * 100 - couponAmount - integralAmount) / 100 < 0 ? 0 : (t.constLeftAmount * 100 - couponAmount - integralAmount) / 100
        }
    }
}
</script>

<style lang='less' scoped>
@import '../../assets/styles/vars';
.ad-detail-box {
    background-color: #f9f9f9;
}
.ads-img {
    display: block;
    width: 100%;
    height: 215px;
    background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/948a3dca6f344165a83a11172893fe8d.png');
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    text-align: center;
    .car-bg,
    .carx-bg {
        margin: 0 auto;
        width: 215px;
        height: 142px;
        padding-top: 90px;
        background-repeat: no-repeat;
        background-size: 100%;
        background-position: center center;
        text-align: center;
        .pl2 {
            padding-left: 3px;
        }
        span {
            line-height: 121px;
            color: #fff;
        }
    }
    .car-bg {
        background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191107/1749558509784f20b3b6f56fdfc3e77b.png');
    }
    .carx-bg {
        background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191107/5224cd2921a64284945e7620f9a83ec3.png');
    }
}
.ads-time {
    font-size: 15px;
}
.ads-date {
    font-size: 12px;
}
.gray-box {
    height: 8px;
    background-color: @bg-color;
}
.ads-operate {
    align-items: center;
    box-sizing: border-box;
    margin-top: 15px;
    padding: 15px 0 20px;
    background: #fff;
    border-top: 1px solid @line-color;
    position: fixed;
    bottom: 0;
    width: 100%;
    .ads-operate-info {
        font-size: 15px;
        color: @gray-color;
        padding: 0 0 0 15px;
        .ads-pay-money {
            font-size: 20px;
            font-weight: bold;
        }
    }
}
.ads-emphasis {
    color: #ff4747 !important;
}
.ads-tip {
    font-size: 12px;
}
.list-box {
    padding: 0 15px;
    padding-bottom: 70px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    background: #fff;
    .list-item {
        // padding-right: 15px;
        // min-height: 49px;
        padding: 15px 0;
        display: flex;
        display: -webkit-flex;
        flex-direction: row;
        // align-items: center;
        justify-content: space-between;
        -webkit-justify-content: space-between;
        -webkit-align-items: center;
        -moz-align-items: center;
        -ms-align-items: center;
        -o-align-items: center;
        align-items: center;
        background-color: @white-color;
        position: relative;
        border-bottom: 1px solid #eff1f8;

        .label {
            width: 100px;
            // line-height: 49px;
            font-size: 15px;
            color: @gray-color;
            &.input-num-lable {
                line-height: 35px;
            }
        }
        .value {
            font-size: 16px;
            color: @black-color;
            text-align: right;
            &.wathet {
                color: @wathet-color;
            }
            span {
                color: @wathet-color;
            }
            .ads-card-expense {
                margin-right: 2px;
                font-size: 12px;
                color: #333;
            }
        }

        .input-num-box {
            font-size: 16px;
            color: @theme-color;
            text-align: right;
            display: flex;
            display: -webkit-flex;
            flex-direction: row;
            justify-content: flex-end;
            -webkit-align-items: center;
            -moz-align-items: center;
            -ms-align-items: center;
            -o-align-items: center;
            align-items: center;
            position: relative;
            .input-trun {
                width: 80px;
                height: 35px;
                margin-right: 10px;
                text-align: center;
                padding-right: 2px;
                border-radius: 4px;
                border: 0.5px solid @border-color;
            }
        }
    }
    .ads-arrow {
        img {
            display: inline-block;
            width: 5px;
            height: 9px;
        }
    }
    .date-box {
        margin-right: 15px;
        margin-bottom: 16px;
        padding: 0 20px;
        height: 35px;
        display: flex;
        display: -webkit-flex;
        flex-direction: row;
        -webkit-align-items: center;
        -moz-align-items: center;
        -ms-align-items: center;
        -o-align-items: center;
        align-items: center;
        border: 0.5px solid @border-color;
        border-radius: 4px;
        .date-item {
            flex: 1;
            padding-left: 15px;
            border: none;
            color: @theme-color;
        }
        .gray {
            color: #ccc;
        }
        .sp {
            display: block;
            width: 20px;
            color: @border-color;
        }
    }
}
.btn-box {
    padding-right: 15px;
    background-color: @white-color;
    button {
        height: 44px;
        border-radius: 22px;
        border: 0;
    }
}
.points {
    height: 28px;
    font-size: 12px;
    color: @black-color;
    .points-minus,
    .points-add,
    .points-val {
        display: inline-block;
        height: 28px;
        line-height: 26px;
        text-align: center;
        border: 1px solid @border-color;
        border-radius: 4px;
        color: @black-color;
        background: transparent;
    }
    .points-minus,
    .points-add {
        width: 28px;
        padding: 0;
        border-radius: 4px;
        font-size: 16px;
        font-weight: bold;
    }
    .points-val {
        width: 56px;
    }
    .points-minus {
        margin-right: 5px;
        display: flex;
        display: -webkit-flex;
        -webkit-align-items: center;
        -moz-align-items: center;
        -ms-align-items: center;
        -o-align-items: center;
        align-items: center;
        justify-content: center;
        &:before {
            display: inline-block;
            content: '';
            width: 8px;
            height: 2px;
            background: @black-color;
        }
    }
    .points-add {
        position: relative;
        margin-left: 5px;
        &:before {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            display: inline-block;
            content: '';
            width: 9px;
            height: 2px;
            background: @black-color;
        }
        &:after {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            display: inline-block;
            content: '';
            width: 2px;
            height: 9px;
            background: @black-color;
        }
    }
}
.btn-submit {
    font-size: 18px;
    outline: none;
    border: 0;
    background: #9975f3;
    border-radius: 22px;
}
.asd_remark {
    padding-top: 10px;
    font-size: 12px;
    color: #999;
}
.asd_remark .ads-tip {
    padding-bottom: 20px;
}
.coupon-deduction {
    padding: 30rpx 0;
    border-bottom: 2rpx solid #eff1f8;
    .coupon-btn {
        position: absolute;
        right: 15px;
        margin-top: -29px;
        .reduce-btn,
        .plus-btn {
            display: inline-block;
            background: #fff;
            height: 50rpx;
            border: 2rpx solid #f7f7f7;
            border-radius: 8rpx;
            line-height: 50rpx;
            text-align: center;
            width: 25px;
            font-size: 15px;
        }
        .coupun-input {
            display: inline-block;
            width: 100rpx;
            height: 50rpx;
            border: 2rpx solid #f7f7f7;
            border-radius: 8rpx;
            line-height: 50rpx;
            text-align: center;
            margin-left: 20rpx;
            margin-right: 20rpx;
            font-size: 13px;
        }
    }
}
</style>
