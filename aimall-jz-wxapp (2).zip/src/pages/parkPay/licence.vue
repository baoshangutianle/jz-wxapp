<template>
    <div>
        <div class="bind-tit">
            <div class="bind-tit-name">请输入您的车牌</div>
        </div>

        <div class="flex-wrp">
            <keyboard
                ref="myKeyboard"
                :plate-num.sync="plateNum"
                :show.sync="show"
                @close="close"
            />
        </div>
        <div class="w100 flex-center btn-wrap">
            <button
                :disabled="plateNum.length<7"
                class="btn-operate bind-btn flex-center"
                @click="checkUserInfo('addSubmit')"
            >确 定</button>
        </div>
    </div>
</template>

<script>
// import keyboard from 'mpvue-keyboard'
import { mapState, mapMutations } from 'vuex'
import md5 from 'md5'
import keyboard from '@/components/CarKeyboard'
import api from '../../plugins/api'
import wxUtils from '@/plugins/wxUtils'
import { setTimeout } from 'timers'
export default {
    components: { keyboard },
    data() {
        return {
            show: false,
            plateNum: '',
            // sessionId: wxUtils.getSessionKeyStorage()
        }
    },
    computed: {
        ...mapState(['sessionId','mallCode', 'vipInfo','isLogined'])
    },
    methods: {
        ...mapMutations(['update']),
        keyboardChange() {
            this.$refs.myKeyboard.clearNumber()
        },
        //校验用户信息是否过期
        checkUserInfo(type,data){
             const t = this
            //调用接口确定用户是否过期
            wx.request({
                url: api.tokenIsExpired,
                method: 'GET',
                data: null,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if(res.data.code == 4001 || res.data.code == 4000 || res.data.code == 216001){
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success (res) {
                                let oldIsLogined = t.isLogined
                                wxUtils.clearLoginStorage()
                                t.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        })
                    }else if(res.data.code == 200 || res.data.code == 0){
                        if(type == 'addSubmit'){
                            t.addSubmit()
                        }
                    }else{
                        wx.showModal({
                            title: '提醒',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA'
                        })
                    }
                }
            })
        },
        addSubmit() {
            let memberCode = wxUtils.getUserCodeStorage()
            let mobile = wxUtils.getPhoneStorage()
            let openId = wxUtils.getOpenIdStorage()
            let t = this
            if (t.plateNum.length < 6) {
                let msg = {
                    title: '请输入正确车牌号！',
                    icon: 'none',
                    image: '../../static/images/icon-msg.png',
                    duration: 1000
                }
                wx.showToast(msg)
            } else {
                let data = {
                    carNumber: t.plateNum,
                    vipId: memberCode,
                    openId: openId,
                    mobile: mobile
                }
                let busArr = []
                for (var key in data) {
                    busArr.push(key + '=' + data[key])
                }
                // 根据ASCII针对key进行排序
                var s1 = Array.prototype.sort.call(busArr, function(a, b) {
                    for (var i = 0; i < a.length; i++) {
                        if (a.charCodeAt(i) == b.charCodeAt(i)) continue
                        return a.charCodeAt(i) - b.charCodeAt(i)
                    }
                })
                // 添加key
                let key = '40a2a2fc-a019-4a9c-8d83-3d13e52cfb8c'
                let sign = s1.join('&') + '&key=' + key
                // 添加key
                data.sign = md5(sign).toUpperCase()

                wx.request({
                    url: api.bindingCar,
                    method: 'POST',
                    data: data,
                    header: {
                        Authorization: t.sessionId,
                        'L-A-Platform': 'mini-program' //后端日志埋点渠道
                    },
                    success(res) {
                        if (res.data.code === 200) {
                            let success = {
                                title: '车牌绑定成功',
                                icon: 'success'
                            }
                            wx.showToast(success)
                            t.plateNum = ''
                            setTimeout(() => {
                                t.keyboardChange()
                                // wx.navigateBack({
                                //     delta: 1
                                // })
                                wx.navigateBack({
                                    url: `/pages/parkPay/index?from=mine`
                                })
                            }, 1500)
                        } else {
                            let msg = {
                                title: res.data.message,
                                icon: 'none',
                                image: '../../static/images/icon-msg.png'
                            }
                            wx.showToast(msg)
                        }
                    }
                })
            }
        }
    }
}
</script>
<style lang="less" scoped>
@import url(../../assets/styles/vars);
.bind-tit {
    width: 100vw;
    /* height: 180px; */
}
.bind-tit-name {
    font-size: 15px;
    color: #666;
    margin: 15px 0 0 15px;
}
.btn-wrap {
    .bind-btn {
        position: relative;
        top: 180px;
        color: #ffffff;
        width: 100%;
    }
}
</style>
