<template>
    <div class="ad-detail-box">
        <ul class="list-box">
            <li v-for="(item,index) in data"
                :key="index"
                class="flex-wrp list-item">
                <span class="flex-item list-item-radio">
                    <radio id="test"/>
                </span>
                <span class="flex-item list-item-info">
                    <label class="flex-wrp"
                           for="test">
                        <span class="flex-item shadow list-item-val">
                            <span class="list-val">0.5小时</span>
                        </span>
                        <span class="flex-item shadow flex-wrp list-item-other">
                            <p class="list-item-name">图层停车车券1</p>
                            <p class="list-item-time-range">有效期:2019-07-01至2017-10-01</p>
                        </span>
                    </label>
                </span>
            </li>
        </ul>
    </div>
</template>

<script>
// import api from '../../../plugins/api'
// import request from '../../../plugins/request'
export default {

    data() {
        return {
            data:[1,2,3,4,5]
        };
    }
}

</script>

<style lang='less' scoped>
@import '../../assets/styles/vars';
.shadow{
    box-shadow: 0 0 5px #BCBCBC;
}
.list-box{
    padding: 0 15px;
    .list-item{
        margin-top: 10px;
        align-items: center;
        .list-item-radio{
            flex: 0 1 16px;
        }
        .list-item-info{
            height: 60px;
            align-items: center;
            label{
                width: 100%;
                height: 100%;
                .list-item-val{
                    overflow: hidden;
                    flex: 0 1 81px;
                    display: flex;
                    align-items: center;
                    font-size: 18px;
                    color: #9975F3;
                    justify-content: center;
                    border-radius: 0 5px 5px 0;
                    border-right: 1px dashed @gray-color;
                }
                .list-item-other{
                    flex-direction: column;
                    justify-content: center;
                    overflow: hidden;
                    padding-left: 10px;
                    border-radius: 5px 0 0 5px;
                    .list-item-name{
                        font-size: 13px;
                    }
                    .list-item-time-range{
                        margin-top: 4px;
                        font-size: 12px;
                    }
                }
            }
        }
    }
}
</style>
