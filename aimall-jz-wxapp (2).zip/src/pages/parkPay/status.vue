<template>
    <div class="status-box">
        <div class="status-info">
            <div class="status-icon" v-if="status == 'success'">
                <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190911/5b94913ab7af41109d8d4cf660433929.png" />
                <p class="status-text">支付成功</p>
            </div>
            <div  class="status-icon" v-else>
                <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190911/06cd776d205f47a481d0ead23c13617d.png"/>
                <p class="status-text">支付失败</p>
            </div>
            <div class="status-btn">
                <button class="go-home" @tap="goDetail">
                    返回
                </button>
            </div>



            <!-- <p v-if="status==1"
               class="status-coupon">
                卡券剩余<span class="status-emphasis">3</span>张
            </p>
            <p v-if="status==2"
               class="status-coupon">
                这里是失败原因
            </p> -->
        </div>
        <!-- <ul class="status-other">
            <li class="flex-wrp status-other-item">
                <span class="flex-item name">有效离场时间</span>
                <sapn class="flex-item val">16:10:00</sapn>
            </li>
            <li class="flex-wrp status-other-item">
                <span class="flex-item name">缴费信息</span>
                <sapn class="flex-item val status-cost">¥5元</sapn>
            </li>
        </ul>
        <button v-if="status==2"
                class="btn btn-cost">
            重新支付
        </button> -->

    </div>
</template>

<script>
// import api from '../../../plugins/api'
// import request from '../../../plugins/request'
export default {

    data() {
        return {
            status: 'success',
            carNumber: null
        };
    },
    onLoad(){
        this.status = this.$root.$mp.query.type;
        this.carNumber = this.$root.$mp.query.id;
    },
    methods: {
        goDetail(data) {
            if(this.status == "success"){
                wx.navigateTo({
                    url: `/pages/parkPay/index`
                })
            }else{
                wx.navigateTo({
                    url: `/pages/parkPay/pay?id=${this.carNumber}`
                })
            }

        },
    }
}

</script>

<style lang="less">
@import '../../assets/styles/vars';
.status-box{
    padding: 0 15px;
    .status-info{
        text-align: center;
        .status-icon{
            border-radius: 50%;
            padding-top: 80px;
            img{
                width: 84px;
                height: 84px;
                border-radius: 50%;
                margin: 0 auto;
            }
        }
        .status-text{
            padding-top: 30px;
            font-size: 18px;
            font-weight: bold;
        }
        .go-home{
            height:50px;
            background:rgba(255,255,255,1);
            color: #9975F3;
            border: solid 1px #9975F3;
            margin-top: 60px;
        }
        .status-coupon{
            margin-top: 5px;
            font-size: 12px;
            color: @gray-color;
        }
    }
    .status-other{
        margin-top: 29px;
        .status-other-item{
            justify-content: space-between;
            border-top: 1px solid #EFF1F8;
            &:last-child{
                border-bottom: 1px solid #EFF1F8;
            }
            .flex-item{
                flex: 0 1 auto;
                font-size: 15px;
                padding: 15px 0;
                &.status-cost{
                    font-weight: 600;
                }
            }
        }
    }
}
.btn{
    margin: 27px 26px 0;
    font-size: 15px;
    background: @theme-color;
    color: @white-color;
    border: 1px solid;
    &.btn-back-fail{
        background: @white-color;
        color: @theme-color;
    }
}

</style>
