<template>
    <div id="auth">
        <div class="uesrInput">
            <div class="uesrInput-con">
                <input
                    v-model="loginRequest.userCode"
                    type="number"
                    placeholder="请输入您的手机号"
                    maxlength="20"
                    placeholder-style="color:#CECECE"
                >
                <img
                    v-if="loginRequest.userCode"
                    src="/static/images/clear.png"
                    @click="clear(1)"
                >
            </div>
        </div>
        <div class="uesrInput">
            <view class="uesrInput-con">
                <input
                    v-model="loginRequest.code"
                    class="password"
                    type="text"
                    placeholder="请输入验证码"
                    maxlength="6"
                    placeholder-style="color:#CECECE"
                >
                <view class="code-wrap">
                    <view
                        v-if="remainingTime>0"
                        class="btn-code-time"
                    >{{ remainingTime }}s重新发送</view>
                    <view
                        v-else
                        class="btn-code"
                        @click="sendCode"
                    >发送验证码
                    </view>
                </view>
            </view>
        </div>
        <div class="uesrInput uesrInput-agree">
            <div class="uesrInput-con uesrInput-con-check">
                <div class="check-wrap">
                    <span
                        :class="{checked:true, click:isAgree}"
                        @click="agreeStatusChange"
                    />
                </div>
                <!-- <div class="
                        user-agree-text">
                    我同意<span
                        class="emphasis"
                        @tap="toDetail('policy')"
                    >《隐私协议》
                    </span>和<span
                        class="emphasis"
                        @tap="toDetail('protocol')"
                    >《隐私协议》</span>
                </div> -->
                <div class="
                        user-agree-text">
                    我同意<span
                        class="emphasis"
                        @tap="toDetail('policy')"
                    >《用户协议》
                    </span>
                </div>
            </div>
        </div>
        <button
            :disabled="!isAgree || !loginRequest.code || !loginRequest.userCode"
            class="btn-operate btn-login"
            style="font-weight:400"
            @click="login"
        >
            手机登录
        </button>
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import secret from '../../plugins/secret'
import wxUtils from '@/plugins/wxUtils'

export default {
    data() {
        return {
            showPassword: false,
            password: '',
            loginRequest: {
                userCode: '',
                code: ''
            },
            timer: null,
            remainingTime: 0,
            isAgree: false,
            form: '',
            formId: ''

        }
    },
    computed: {
        ...mapState(['wxUserInfo', 'isVip', 'vipInfo'])
    },
    onShow(){
        //判断来源有无参数
        if(this.$root.$mp.query.form){
            this.form = this.$root.$mp.query.form
            this.formId = this.$root.$mp.query.formId
        }else{
            this.form = ''
            this.formId = ''
        }

        console.log("login="+this.form)
    },
    methods: {
        ...mapMutations(["update"]),
        toDetail(type) {
            wx.navigateTo({
                url: `/pagesMine/${type}`
            })
        },
        // 清除输入框
        clear(type) {
            this.loginRequest.userCode = ''
        },
        // 显示或隐藏密码
        passwordHandler() {
            this.showPassword = !this.showPassword
        },
        // 忘记密码
        forgetPassword() {
            utils.showToast('请联系楼层管理员重置密码')
        },
        agreeStatusChange: function(e) {
            this.isAgree = !this.isAgree
        },
        clearTimer() {
            let that = this
            if (that.timer) {
                clearInterval(that.timer)
                that.timer = null
                that.remainingTime = 0
            }
        },
        setTimer() {
            let that = this
            that.clearTimer()
            that.remainingTime = 60
            that.timer = setInterval(() => {
                that.remainingTime = that.remainingTime - 1
                if (that.remainingTime == 0) {
                    clearInterval(that.timer)
                }
            }, 1 * 1000);
        },
        validateField(type, value) {
            var result = true

            if (!value) {
                result = false
            }

            if (type == "phone") {
                if (!value || value.length != 11 || value.slice(0, 1) != 1) {
                    result = false
                }
            }

            return result
        },
        sendCode() {
            let that = this

            let mobile = this.loginRequest.userCode
            if (!this.validateField("phone", mobile)) {
                return utils.showToast('您输入的号码有误')
            }
            var channel = 'applet'//渠道
            var sign = utils.md5Encrypt(mobile + 'M^hk6oOMSSGrm0mOml55^X4%vfGpqdLQX*5a1X@8fqpdsfw@' + channel)//签名
            let params = {
                mobile: mobile,
                channel: channel,
                sign: sign
            }
            let requestOptions = {
                path: api.getVertCode,
                method: 'post',
                data: params
            }
            request(requestOptions)
                .then(res => {
                    if (res.code == 200) {
                        that.setTimer()
                    }
                })
                .catch(err => {
                    wx.showModal({
                        title: '',
                        content: err.message,
                        showCancel: false,
                        confirmText: '确定'
                    })
                })
        },
        // 登录
        login() {
            let vm = this
            let phone = vm.loginRequest.userCode
            let code = vm.loginRequest.code
            if (!vm.validateField("phone", phone)) {
                return utils.showToast('您输入的号码有误')
            }
            if (!vm.validateField("code", code)) {
                return utils.showToast('您输入的验证码有误')
            }
            wxUtils.loginByPhone(phone, code, async function(data) {
                wxUtils.setPhoneStorage(phone)

                //重置表单
                vm.reset()

                let { sessionId, userCode,newFlag } = data
                wxUtils.setUserCodeStorage(userCode)
                await vm.update({
                    isLogined: true,
                    sessionId: sessionId
                });
                if(newFlag){
                    wxUtils.registerIntergral().then(()=>{
                        utils.getVipInfo().then(vipInfo => {
                            vm.update({
                                vipInfo: vipInfo
                            });
                            if(vm.form && vm.form !=''){
                                if(vm.form == 'game'){
                                     wx.reLaunch({
                                        url: `/pages/home?pageId=${vm.form}&activityId=${vm.formId}`
                                    })
                                }
                            }else{
                                wx.switchTab({
                                    url: '/pages/mine/index'
                                })
                            }
                        })
                    })
                }else{

                    utils.getVipInfo().then(vipInfo => {
                        vm.update({
                            vipInfo: vipInfo
                        });
                        if(vm.form && vm.form !=''){
                            wx.reLaunch({
                                url: `/pages/home?pageId=${vm.form}&activityId=${vm.formId}`
                            })
                        }else{
                            wx.switchTab({
                                url: '/pages/mine/index'
                            })
                        }
                    })
                }
            })
        },
        reset() {
            let vm = this
            vm.loginRequest = {}
            vm.isAgree = false
        }
    },
    onUnload() {
        let that = this
        that.clearTimer()
        that.reset()
    }
}
</script>

<style lang="less" scoped>
@import '../../assets/styles/vars';

.emphasis {
    color: #75c5c1;
}
#auth {
    padding: 41px 15px 0;
    .uesrInput {
        margin-bottom: 20px;
        position: relative;
        .uesrInput-con {
            position: relative;
            input {
                height: 44px;
                line-height: 21px;
                padding: 0 15px;
                line-height: 35px;
                font-size: 15px;
                color: #333333;
                border: 1px solid #cecece;
                border-radius: 4px;
                &:focus {
                    border: 1px solid @theme-color;
                    color: red;
                }

                &.password {
                    padding: 0 120px 0 15px;
                }
            }
            img {
                width: 15px;
                height: 15px;
                position: absolute;
                top: 50%;
                right: 10px;
                transform: translateY(-50%);
                z-index: 10;
            }
            .eye {
                width: 14px;
                height: 10px;
                right: 30px;
                bottom: 12px;
            }
        }
        &.uesrInput-agree {
            font-size: 12px;
            line-height: 17px;
            color: @gray-color;
            .uesrInput-con-check {
                display: flex;
                flex-direction: row;
                align-items: center;
            }
        }
    }
    button {
        &.btn-login {
            margin: 90px 0 0;
            width: 100%;
            background-color: #9975F3;
        }
    }
    // 选择同意条款
    .check-wrap {
        padding: 5px;
        padding-top: 10px;
        .checked {
            box-sizing: border-box;
            display: inline-block;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background-clip: content-box;
            border: 1px solid #9975F3;
            padding: 3px;
        }
        .click {
            background-color: #9975F3;
        }
    }

    .code-wrap {
        position: absolute;
        display: inline-block;
        right: 0;
        top: 0;
        .btn-code {
            font-size: 15px;
            color: #cecece;
            padding: 10px;
        }
        .btn-code-time {
            font-size: 15px;
            color: @pink-color;
            padding: 10px;
        }
    }
    .forgetPassword {
        font-size: 13px;
        color: #666666;
    }
}

// input::-webkit-input-placeholder {
//     color: red;
// }
// input:focus::-webkit-input-placeholder {
//     color: @theme-color;
// }
</style>
