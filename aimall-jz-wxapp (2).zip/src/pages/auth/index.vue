<template>
    <div id="auth">
        <div class="logo">
            <img
                src="https://img-cdn.aimall.cloud/as/20200528/ee59feb89c614a47a69413aa11e1eabe.png"
                alt="logo"
                mode="scaleToFill"
            >
        </div>
        <h4 class="auth-company">南海嘉洲广场</h4>
        <button class="btn-operate auth">
            <auth-btn
                auth="user"
                v-if="nullUserInfo"
                @pass="authLogin"
            />
            <auth-btn
                v-else
                auth="phone"
                @pass="authLogin"
            />
            微信授权登录
        </button>
        <!-- <view
            class="btn-phone"
            @click="phoneLogin"
        >
            手机号登录
        </view> -->
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils'
import api from '@/plugins/api'
import utils from '@/plugins/utils';
import AuthBtn from '@/components/AuthBtn';
export default {
    components: {
        AuthBtn
    },
    data() {
        return {
            nullUserInfo:false,
            form:'',
            formId:''
        }
    },
    computed: {
        ...mapState(['wxUserInfo', 'vipInfo'])
    },
    methods: {
        ...mapMutations(["update"]),
        // 授权手机号登录
        authLogin() {
            let vm = this
            wx.navigateBack()
        },
        phoneLogin() {
            const t = this
            //根据参数回跳到相应页面
            if(t.form && t.form !=''){
                wx.navigateTo({
                    url: `/pages/auth/login?form=${t.form}&formId=${t.formId}`
                })
            }else{
               wx.navigateTo({
                    url: '/pages/auth/login'
                })
            }

        }
    },
    onLoad() {
    //刷新session
        wxUtils.getUserSession()
    },
    onShow(){
        if(!wx.getStorageSync('isLogined')){
            this.nullUserInfo = true
        }else{
            this.nullUserInfo = false
        }
        //判断来源有无参数
        if(this.$root.$mp.query.form){
            this.form = this.$root.$mp.query.form
            this.formId = this.$root.$mp.query.formId
        }else{
            this.form = ''
            this.formId = ''
        }
    }
}
</script>

<style lang="less">
@import '../../assets/styles/common';
#auth {
    text-align: center;
    .logo{
        margin-top: 79px;
        text-align: center;
        img {
            display: inline-block;
            width: 76px;
            height: 76px;
        }
    }
    .auth-company {
        font-size: 18px;
        line-height: 25px;
        color: @black-color;
        margin-top: 27px;
    }
    button {
        &.auth{
            margin-top: 84px;
            font-weight: normal;
        }
    }
    .btn-phone {
        display: inline-block;
        margin: 23px auto 0;
        font-size: 15px;
        color: @theme-color;
    }
}
</style>
