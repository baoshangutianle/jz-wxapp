<template>
    <div id="shoppingService">
        <img mode="widthFix" src="https://img-cdn.aimall.cloud/as/20200602/473e936dc80f4f8992f35ac3a42d5c8e.PNG" style="width:100%"/>
        <!-- <div class="shopping_img">
            <img
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/08a63fd889d8415e8e9cd05db00ef581.png"
                alt=""
            >
            <p class="shopping-title">南海嘉洲广场</p>
            <p class="shopping_subtitle">为您贴心的商场服务</p>
        </div> -->
        <!-- <ul class="pb50">
            <li
                v-for="(item,index) in itemList"
                :key="index"
            >
                <ServiceItem :item="item" />
            </li>
            <li>
                <div class="customer_service">
                    <introduceTitle text="顾客服务" />
                    <ul class="customer_ul">
                        <li
                            v-for="(option,index) in optionList"
                            :key="index"
                        >
                            <img
                                :src="option.img"
                                alt=""
                            > -->
                            <!-- <img src="../../static/images/icon1.png" alt=""> -->
                            <!-- <p>{{ option.text }}</p>
                        </li>
                    </ul>
                </div>
            </li>
            <li>
                <div class="introduce">
                    <introduceTitle text="爱琴海介绍" />
                    <p>南海嘉洲广场是国内首个文化体验商业综合体，地处上海市闵行区吴中路 1588 号，地铁十号线龙柏新村站 3 号出口。总建筑面积 55 万m²，由 24 万m²商业主 Mall、10 万m²家居 Mall、9.5 万m²的国际街区以及 5 万m²的城市生态公园所构成。 其中由国际建筑大师安藤忠雄亲自打造 4800 m²的光的空间&新华书店，将艺术人文与 商业融为一体。以先锋建筑形态致敬城市的上海之眼购物街，必将成为魔都打卡新地标。 还引进冰雪世界、国际马术俱乐部、空中有机农场等新型休闲娱乐体验模式。是一个集 萃文化、情感、生态、摩登的高端商业中心。
                    </p>
                </div>
            </li>
            <li />
            <li class="qrcode-li">
                <img
                    class="qrcode-img"
                    src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190916/dcbda86c3ef64093993348e8ec33e62c.png"
                >
                <p class="qrcode-text">关注南海嘉洲广场公众号</p>
                <p class="qrcode-text">获取更多优惠详情</p>
            </li> -->
            <!-- <li>
                <div class="introduce noborder">
                    <introduceTitle text='大天使机器人介绍'></introduceTitle>
                    <p>“云绅”智能服务机器人是上海云绅智能科技有限公司针对购物中心、家居卖场的纵深细分场景而研发的导购机器人。 目前，云绅服务机器人在此细分场景中的核心技术和体验在全球范围内均处于领先地位。 云绅服务机器人的外观设计简约而不简单，充满着科技感，各一个小细节中都彰显着设计人员的匠心和追求，可谓是服机器人里的颜值典范。 依托于红星美凯龙的数量众多的购物中心、家居卖场资源，云绅有机会获得第一手的商场运营数据和用户数据，洞察商场端和用户端的真实需求，使得云绅在产品研发和场景测试方面拥有着得天独道的优势。 云绅服务机器人致力于成为用户最信任的移动商场服务台，为用户提供传统商场服务台能提供的绝大多数服务，还解决传统商场服务台数量少且难以找到的痛点。通过计算机视觉、语音、界面等多模态的交互专业而友好地为用户提供地图导览、导航带路、门店介绍、活动介绍、购物餐饮推荐等服务。 云绅服务机器人还致力于成为最懂用户的商场导购专家，用户在商场里的知心朋友。云绅服务机器人还能将获取到用户视觉交互、语音交互、屏幕交互数据与商场的线上线下数据，随着数据的积累和打通，云绅可以智能分析出多维度的用户画像和用户可能感兴趣的门店和产品，并进行相关推荐，真正地做到线下商场场景的千人千面的个性化的推荐功能，提升商场线下流量的转化率。
                    </p>
                </div>
            </li> -->
        <!-- </ul> -->
    </div>
</template>

<script>
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import PhoneAuth from '../../components/PhoneAuth'
import AuthBtn from '../../components/AuthBtn'
import ServiceItem from '../../components/ServiceItem'
import introduceTitle from '../../components/introduceTitle'
export default {
    components: {
        PhoneAuth,
        AuthBtn,
        ServiceItem,
        introduceTitle
    },
    data() {
        return {
            itemList: [{
                title: '服务台',
                text: '南海嘉洲广场购物中心1楼',
                time: ' 10:00AM - 22:00PM',
                phone: ' 021-60906008'
            }
            ],
            optionList: [
                {
                    text: '指导向引',
                    img: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/2bb87c88adc3452883acaaf1c4538726.png'
                },
                {
                    text: '失物招领',
                    img: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/24a0299b7e354de49bf24cef6a98c939.png'
                },
                {
                    text: '活动报名',
                    img: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/d804bc59a1ab49108d22a060daf8b233.png'
                },
                {
                    text: '便利租借',
                    img: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/775012b20a5b41cda84a4137a4e3b819.png'
                },
                {
                    text: '免洗洗手液',
                    img: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/2b6a1f69148e42358ff6b6c0e5f5fc1a.png'
                },
                {
                    text: '母婴便利',
                    img: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/72f966f9b25b457d9f3b4c65beb6bfc0.jpg'
                },
                {
                    text: '针线包',
                    img: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/39bca639e5834da59f2e854b426b5e68.png'
                },
                {
                    text: '包装服务',
                    img: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/0331c0460ddd463f9edf7caa9fca49ec.png'
                },
                {
                    text: '医药箱',
                    img: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/e8031a60f429487b90f2441c2cc0926b.png'
                }
            ],
            qrCode: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190916/dcbda86c3ef64093993348e8ec33e62c.png'
        }
    },
    onShow() {
    // 方法都在 ServiceItem 组件中
    }
}
</script>

<style lang="less">
#shoppingService {
    .shopping_img {
        width: 100%;
        height: 166px;
        text-align: center;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190910/b7dfc8e8a4ae45ed8d3a29f5a811a7f9.png');
        padding-top: 31px;
        box-sizing: border-box;
        img {
            width: 41px;
            height: 38px;
            margin: 0px auto 13px;
        }
        .shopping-title {
            font-size: 18px;
            font-family: PingFangHK;
            font-weight: 400;
            color: rgba(255, 255, 255, 1);
            line-height: 30px;
            margin-bottom: 2px;
        }
        .shopping_subtitle {
            font-size: 14px;
            font-family: PingFangHK;
            font-weight: 300;
            color: rgba(255, 255, 255, 1);
            line-height: 20px;
        }
    }
    //
    .customer_service {
        height: 380px;
        border-bottom: 1px solid #e7e7e7;
        padding: 30px 25px;
        background-color: #ffffff;
        box-sizing: border-box;
        .shopping_ptext {
            position: relative;
        }
        .shopping_title {
            color: #333333;
            font-weight: 500;
            font-size: 18px;
            margin-left: 15px;
        }
        .shopping_icon {
            position: absolute;
            top: 7px;
            left: 0px;
            width: 4px;
            height: 10px;
            background: #9975F3;
            border-radius: 3px;
        }
        .customer_ul {
            li {
                padding-top: 25px;
                width: 33.33%;
                float: left;
                text-align: center;
                img {
                    width: 30px;
                    height: 30px;
                    margin-left: 40px;
                }
                p {
                    font-size: 13px;
                    font-family: PingFangHK;
                    font-weight: 300;
                    color: rgba(51, 51, 51, 1);
                    line-height: 18px;
                    margin-top: 20px;
                }
                .shopping_icon {
                    width: 4px;
                    height: 10px;
                    background: #9975F3;
                    border-radius: 3px;
                }
            }
        }
    }
    .qrcode-li {
        background: #fff;
        text-align: center;
        padding-top: 30px;
        padding-bottom: 15px;
    }
    .qrcode-img {
        width: 152px;
        height: 152px;
        padding-bottom: 8px;
        display: inline-block;
    }
    .qrcode-text {
        color: #999;
        font-size: 15px;
        padding-bottom: 3px;
    }
    .introduce {
        padding: 30px 25px;
        background-color: #fff;
        p {
            font-size: 15px;
            font-family: PingFangSC;
            font-weight: 300;
            color: rgba(102, 102, 102, 1);
            line-height: 21px;
        }
    }
}
.pb50 {
    padding-bottom: 50px;
}
.introduce.noborder {
    border: none !important;
}
</style>
