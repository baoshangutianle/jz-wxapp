/* eslint-disable vue/order-in-components */
<template>
    <div id="home" :class="{'mask':isMask}">
        <div v-if="scene===1011 || scene===1047 || scene===1124" class="focus">
            <div v-show="officiaAccountState" class="officia-account">
                <official-account />
            </div>
            <div class="tip" @click="toggleOfficiaAccountState">
                <div>关注公众号，惊喜早知道！</div>
                <div :class="['arrow',{'up':officiaAccountState}]" />
            </div>
        </div>
        <view class="aqh-swiper">
            <swiper
                :circular="true"
                :indicator-dots="true"
                :autoplay="true"
                indicator-color="#B5B5B5"
                indicator-active-color="#fff"
                previous-margin="40rpx"
                next-margin="40rpx"
                @change="onBannerChange"
            >
                <block v-for="(item,index) in imgUrls" :key="index">
                    <swiper-item>
                        <!-- "slide-image" -->
                        <image
                            :src="item.pictureUrl"
                            :class="['slide-image',{'slide-image-act':index==nowIdx}]"
                            mode="scaleToFill"
                            @click="toBannerUrl(item)"
                        />
                    </swiper-item>
                </block>
            </swiper>
        </view>
        <view class="nav navUrls">
            <ul>
                <li
                    v-for="(item, index) in navUrls"
                    :key="index"
                    :data-path="item.path"
                    :data-id="item.id"
                >
                    <div v-if="item.auth">
                        <auth-btn auth="user" @pass="toNavPath(item)" />
                        <div class="nav_div">
                            <image :src="item.url" class="nav_img" mode="widthFix" />
                        </div>

                        <p class="nav-sub-text">{{ item.text }}</p>
                    </div>
                    <div v-else @tap="toNavPath(item)">
                        <div class="nav_div">
                            <image :src="item.url" class="nav_img" mode="widthFix" />
                        </div>
                        <p class="nav-sub-text">{{ item.text }}</p>
                    </div>
                </li>
            </ul>
        </view>
        <view class="nav navList">
            <ul>
                <li
                    v-for="(item, index) in navUrlsList"
                    :key="index"
                    :data-path="item.path"
                    :data-id="item.id"
                >
                    <div v-if="item.auth">
                        <auth-btn auth="user" @pass="toNavPath(item)" />
                        <div class="nav_div">
                            <image :src="item.url" class="nav_img" mode="widthFix" />
                        </div>
                        <p class="nav-sub-text">{{ item.text }}</p>
                    </div>
                    <div v-else @tap="toNavPath(item)">
                        <div class="nav_div">
                            <image :src="item.url" class="nav_img" mode="widthFix" />
                        </div>
                        <p class="nav-sub-text">{{ item.text }}</p>
                    </div>
                </li>
            </ul>
        </view>
        <!-- <view class="home-bg"></view> -->
        <!--   <view class="online-mall">
            <view class="title">
                <p>在线商城</p>
                <div class="list-more" data-path="pages/integralMall/index" data-type="onlineMall" @click="toLineMall(null)">
                    查看全部
                    <img class="icon-arrow" src="/static/images/icon-home-arrow.png" alt="箭头" />
                </div>
            </view>
            <view class="mall-main">
                <div class="mall-item"  v-for='item in imgList' :key='item.id'>
                    <img @click="toLineMall(item.id)" :src="item.url" alt="">
                </div>
             <div class="mall-item">
                    <img @click="toLineMall('2')" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200215/9ec622a8ab2d4380bc92bac78d2bec4e.png" alt="">
                </div>
            </view>
        </view>-->
        <view class="home-bg" v-if="timer && seckillList.length"></view>
        <view class="zhinan" v-if="timer && seckillList.length">
            <view class="title zhinan-title">
                <p>
                    <img class="icon_fresh.png" src="/static/images/icon_seckill.png" alt />限时秒杀
                </p>
                <div class="count-time">
                    <count-down :timer='timer' :colorFul='true'/>
                </div>
                <div
                    class="list-more"
                    data-path="pages/seckillList/index"
                    @click="toNavPath"
                >
                    查看全部
                    <img class="icon-arrow" src="/static/images/home_arrow_right.png" alt="箭头" />
                </div>
            </view>
            <Seckill :data="seckillList" />
        </view>
        <view class="home-bg" v-if="coupons&&coupons.length"></view>
        <!-- <u-count-down :timestamp="86400" :show-days="false"></u-count-down> -->
        <view v-if="coupons&&coupons.length" class="coupon">
            <view class="title">
                <p>
                    <img class="icon_fresh.png" src="/static/images/icon_coupon.png" alt />超值领券
                </p>
                <div class="list-more" data-path="pages/coupon/index" data-type="guideMoreCoupon">
                    <auth-btn
                        auth="user"
                        @pass="toNavPath({path:'pages/coupon/index',type:'guideMoreCoupon'})"
                    />更多优惠券
                    <img class="icon-arrow" src="/static/images/home_arrow_right.png" alt="箭头" />
                </div>
            </view>
            <view class="coupon-con">
                <ul>
                    <li v-for="(item,index) in coupons" :key="index" class="coupon-item">
                        <!-- <auth-btn auth="user" @pass="goCouponDetail(item)" /> -->
                        <coupon-item-simple :data="item" />
                    </li>
                </ul>
            </view>
        </view>
        <view class="home-bg"></view>
        <view class="zhinan">
            <view class="title zhinan-title">
                <p>
                    <img class="icon_fresh.png" src="/static/images/icon_fresh.png" alt />新鲜事儿
                </p>
                <div
                    class="list-more"
                    data-path="pages/guide/index"
                    data-type="guideMore"
                    @click="toNavPath"
                >
                    查看全部
                    <img class="icon-arrow" src="/static/images/home_arrow_right.png" alt="箭头" />
                </div>
            </view>
            <view
                v-for="(item, index) in tideList"
                :key="index"
                class="floor"
                @click="toGuideDetails(item)"
            >
                <article-comp :data="item" />
            </view>
        </view>
        <div class="loadmore-show">
            <!-- <load-more /> -->
            <div
                class="reachText"
                data-path="pages/guide/index"
                data-type="guideMore"
                @click="toNavPath"
            >
                <span class="reach-text">查看更多</span>
            </div>
        </div>
        <!-- <auth-know :is-show="isAuthKnowShow"></auth-know> -->
        <layer-page v-if="isLayer" />
        <div class="tipPage" v-if="isMask">
            <img
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191028/a16e8948b045417ba6b743a9815a7e37.png"
                @click="toMyPage"
                mode="widthFix"
            />
        </div>
    </div>
</template>
<script>
import moment from 'moment'
import { mapState, mapMutations } from 'vuex'
import utils from '@/plugins/utils'
import wxUtils from '@/plugins/wxUtils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import { getCouponBatchPage, getCouponNormalBatchPage } from '@/service/mine'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import CouponItemSimple from '@/components/CouponItemSimple'
import ArticleComp from '@/components/ArticleComp'
import Seckill from '@/components/Seckill'
import LayerPage from '@/components/LayerPage'
import AuthBtn from '@/components/AuthBtn'
import LoadMore from '@/components/loadMore'
import uCountDown from '@/components/uview/u-count-down'
import countDown from '@/components/countDown'
export default {
    components: {
        CouponItemSimple,
        ArticleComp,
        LayerPage,
        AuthBtn,
        LoadMore,
        uCountDown,
        Seckill,
        countDown
    },
    data() {
        return {
            swiperH: '', //swiper高度
            nowIdx: 0, //当前swiper索引
            imgList: [],
            officiaAccountState: false,
            pageStayTime: 0, //页面停留时间
            isAuthKnowShow: false,
            imgUrls: [],
            seckillList: [
            ],
            navUrls: [
                {
                    url: 'https://img-cdn.aimall.cloud/as/20200527/bf3d02d11a8e4fd5a619b08835539306.png',
                    text: '停车缴费',
                    // path: '',
                    path: 'pages/parkPay/index',
                    id: '',
                    auth: true
                },
                {
                    url: 'https://img-cdn.aimall.cloud/as/20200618/2b76127f098944b193635c97861d318e.png',
                    text: '自助积分',
                    path: 'pages/valuePoint/index',
                    id: pointCode.HOME_GRADE,
                    auth: true
                },
                // {
                //     url: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/afec612158ac471ea30aac59829a782d.png',
                //     text: '虚拟逛店',
                //     path: 'pages/stayTuned/index',
                //     id: pointCode.HOME_VIP
                // },
                {
                    url: 'https://img-cdn.aimall.cloud/as/20200527/c3ea24d6c6584a3198be44a5d1cf56ff.png',
                    text: '热门活动',
                    path: 'listOfActivities/popularList',
                    id: pointCode.HOME_ACTIVITY
                },
                {
                    url: 'https://img-cdn.aimall.cloud/as/20200527/e25a2786c4aa4143966954b11ca67f98.png',
                    text: '每日签到',
                    path: 'pages/checkIn/index',
                    id: ''
                }
            ],
            navUrlsList: [
                {
                    url: 'https://img-cdn.aimall.cloud/as/20200527/0fcc229e6f0541dcbdf67061a6031ec0.png',
                    text: '商场服务',
                    path: 'pages/shoppingService/detail',
                    id: pointCode.HOME_SHOP,
                    auth: true
                },
                {
                    url: 'https://img-cdn.aimall.cloud/as/20200527/a47d82d61a924fec8d2898a7eb27b600.png',
                    text: '会员权益',
                    path: 'pages/memberShip/detail',
                    id: pointCode.HOME_VIP,
                    auth: true
                },
                 {
                    url: 'https://img-cdn.aimall.cloud/as/20200527/96abc914e7bc46e1a1a4f562094bfda9.png',
                    text: '抽奖游戏',
                    // path: 'pages/comingSoon/index', 
                    path: 'pages/luckyLottery/index', 
                    id: '' 
                },
                {
                    url: 'https://img-cdn.aimall.cloud/as/20200527/27160b5053354f36b7bcc0124369d303.png',
                    text: '直播',
                    // path: 'pages/comingSoon/index',
                    path: 'pages/liveBroadcast/index',
                    id: ''
                },
                //  {
                //     url: '',
                //     text: '扭蛋',
                //     // path: 'pages/comingSoon/index',
                //     path: 'pages/game/gashapon',
                //     id: ''
                // },
                //  {
                //     url: '',
                //     text: '老虎机',
                //     // path: 'pages/comingSoon/index',
                //     path: 'pages/game/machine',
                //     id: ''
                // }
                // {
                //     url: 'https://img-cdn.aimall.cloud/as/20200527/e25a2786c4aa4143966954b11ca67f98.png',
                //     text: '每日签到',
                //     path: 'pages/checkIn/index',
                //     id: ''
                // },
                // {
                //     url: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191120/27f15f406ed5443e9176fc50e63dcea8.png',
                //     text: '商场导航',
                //     path: 'pages/mall/mallNavigation',
                //     id: pointCode.HOME_NAVIGATE
                // },
               
            ],
            // 潮逛列表
            tideList: [],
            isLayer: false,
            coupons: [],
            gashaponId: '',
            timer: 0,
        }
    },
    computed: {
        ...mapState(['mallCode', 'scene', 'sessionId', 'vipInfo', 'isMask'])
    },
    onLoad(options) {
        //用于从分享页面跳转到分享页的功能
        if (options.pageId) {
            //这个pageId的值存在则证明首页的开启来源于用户点击来首页,同时可以通过获取到的pageId的值跳转导航到对应的详情页
            if (options.pageId == 'activites') {
                wx.navigateTo({
                    url: `/listOfActivities/popularDetails?id=${options.id}&share=1`
                })
            } else if (options.pageId == 'restaurant') {
                wx.navigateTo({
                    url: `/pages/restaurant/detail?id=${options.id}&type=${options.type}`
                })
            } else if (options.pageId == 'guide') {
                wx.navigateTo({
                    url: `/pages/guide/details?id=${options.id}&type=${options.type}`
                })
            } else if (options.pageId == 'goActivities') {
                wx.navigateTo({
                    url: `/listOfActivities/popularList`
                })
            } else if (options.pageId == 'integralMall') {
                wx.navigateTo({
                    url: `/pages/integralMall/detail?id=${options.id}`
                })
            } else if (options.pageId == 'lotteryShare') {
                if (options.luckyPrizeId) {
                    wx.navigateTo({
                        url: `/pages/luckyLottery/share?activityId=${options.activityId}&luckyPrizeId=${options.luckyPrizeId}`
                    })
                } else {
                    wx.navigateTo({
                        url: `/pages/luckyLottery/index?activityId=${options.activityId}`
                    })
                }
            } else if (options.pageId == 'game') {
                wx.navigateTo({
                    url: `/pages/luckyLottery/index?activityId=${options.activityId}`
                })
            } else if (options.pageId == 'gashaponGame') {
                // wx.navigateTo({
                //         url: `/pages/game/gashapon?activityId=${options.activityId}`
                //     })
            } else if (options.pageId == 'gashaponShare') {
                wx.navigateTo({
                    url: `/pages/game/postersPreview?activityId=${options.activityId}&prizeId=${options.prizeId}`
                })
            } else if (options.pageId == 'machineGame') {
                wx.navigateTo({
                    url: `/pages/game/machineList?activityId=${options.activityId}`
                })
            } else if (options.pageId == 'machineShare') {
                wx.navigateTo({
                    url: `/pages/game/machinePreview?activityId=${options.activityId}&prizeId=${options.prizeId}`
                })
            }
        }
        if (options.q) {
            if (decodeURIComponent(utils.getCurrentPageUrlWithArgs().q)) {
                const url = decodeURIComponent(utils.getCurrentPageUrlWithArgs().q)
                const params = url.split('?')[1]
                const category = params.split('&')[0].split('=')[1]
                const time = params.split('&')[1].split('=')[1]
                const type = params.split('&')[2].split('=')[1]
                wx.setStorageSync('sourceFrom', utils.getsourceFrom(category))
            }
        }
    },
    onShow() {
        let vm = this
        this.pageStayTime = new Date().getTime()
        if (wxUtils.getOpenIdStorage()) {
            buryPoint.setP({
                id: pointCode.HOME_P
            })
            //获取openId后调用弾层
            this.isLayer = true
        } else {
            wxUtils.getUserSession(function() {
                buryPoint.setP({
                    id: pointCode.HOME_P
                })
            }) //获取微信用户信息
            //获取openId后调用弾层
            this.isLayer = true
        }
        vm.timer = 0;
        vm.getMemberNotice()
        vm.queryEffective()
    },
    onHide() {
        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.HOME_Z,
            p_stay_time: this.pageStayTime
        })
    },
    methods: {
        queryEffective () {
            let position = { path: api.queryEffective, hideLoading: true }
            request(position).then(res => {
                if (res.code == 200 && res.data && res.data.length) {
                    let start = res.data[0].startTime
                    let end = res.data[0].endTime
                    this.timer = (new Date(end).getTime() - new Date(start).getTime()) / 1000;
                    this.queryEffectiveGoods(res.data[0].id) 
                }
            })
        },
        queryEffectiveGoods (id) {
            let position = { 
                path: api.queryEffectiveGoods, 
                hideLoading: true, 
                data: {
                    roundId: id
                } 
            }
            request(position).then(res => {
                if (res.code == 200 && res.data && res.data.length) {
                    res.data.forEach((v,idx)=>{
                        v.goodsPrice = (v.goodsPrice/100).toFixed(2)
                        v.seckillPrice = (v.seckillPrice/100).toFixed(2)
                    })
                    this.seckillList = res.data;
                    
                }
            })
        },
        onBannerChange(e) {
            this.nowIdx = e.target.current
            // console.log(e)
        },
        ...mapMutations(['update', 'setMaskStatus']),
        //跳转我的信息界面
        toMyPage() {
            wx.switchTab({
                url: '/pages/mine/index'
            })
        },
        toggleOfficiaAccountState() {
            this.officiaAccountState ? (this.officiaAccountState = false) : (this.officiaAccountState = true)
        },
        async goCouponDetail(data) {
            let { couponId, couponBatchId, couponName, chargeOffStatus } = data
            let params = {
                mallCode: this.mallCode,
                couponId: couponId,
                couponBatchId: couponBatchId
            }
            //埋点
            buryPoint.setF({
                id: pointCode.HOME_CARD,
                p_action_id: couponId,
                p_action: couponName
            })
            wx.navigateTo({
                url: `/pages/coupon/details?couponId=${couponId}&couponBatchId=${couponBatchId}`
            })
        },
        toBannerUrl(item) {
            var url = item.jumpUrl
            //var title = item.resourceName
            //埋点
            buryPoint.setF({
                id: pointCode.HOME_BANNER,
                p_action_id: item.id, 
                p_action: item.resourceName
            })
            // 判断是否是抽奖活动
            if (url && url.indexOf('game=1') > -1) {
                // 抽奖活动
                let options = url.split('?')[1]
                wx.navigateTo({
                    url: `/pages/luckyLottery/index?${options}`
                })
            } else if (url && url.indexOf('pages/game/gashapon') > -1) {
                // 扭蛋抽奖
                let options = url.split('?')[1]
                //  wx.navigateTo({
                //     url: `/pages/game/gashapon?${options}`
                // })
            } else if (url && url.indexOf('listOfActivities/details') > -1) {
                // 热门活动
                if (url.split('&')[1] && url.split('&')[1].split('=')[1]) {
                    let options = url.split('&')[1].split('=')[1]
                    wx.navigateTo({
                        url: `/listOfActivities/popularDetails?id=${options}`
                    })
                }
            } else if (url && url.indexOf('pages/guide/detail') > -1) {
                // 新鲜事
                let options = url
                    .split('?')[1]
                    .split('&')[0]
                    .split('=')[1]
                let putType = url
                    .split('?')[1]
                    .split('&')[1]
                    .split('=')[1]
                wx.navigateTo({
                    url: `/pages/guide/details?id=${options}&type=${putType}`
                })
            } else if (url) {
                const title = '南海嘉洲广场'
                wx.navigateTo({
                    url: `/pages/banner/index?url=${url}&title=${title}`
                })
            }
        },
        toGuideDetails(item) {
            //埋点
            buryPoint.setF({
                id: pointCode.HOME_GUIDE,
                p_action_id: item.id,
                p_action: item.title
            })
            wx.navigateTo({
                url: `/pages/guide/details?id=${item.id}&type=${item.putType}`
            })
        },
        showAuthPop() {
            let wxUserInfo = Object.assign(wxUtils.getUserStorage())
            if ((Object.prototype.toString.call(wxUserInfo) == '[object Object]' && wxUserInfo) || (Object.prototype.toString.call(wxUserInfo) == '[object String]' && wxUserInfo.length > 0)) {
                this.isAuthKnowShow = false
            } else {
                this.isAuthKnowShow = true
            }
        },
        // 获取轮播图片
        getBanner() {
            let position = { path: api.getEffectCmsResource, hideLoading: true }
            request(position).then(res => {
                if (res.code == 200) {
                    this.imgUrls = res.data
                }
            })
        },
        // 获取分类图片
        getImage() {
            let position = { path: api.getFirstPageCategoryList, hideLoading: true }
            request(position).then(res => {
                if (res.code == 200) {
                    this.imgList = res.data && res.data
                }
            })
        },
        //获取首页8个icon
        queryIcon() {
            let position = { path: api.queryIcon, method: 'post', data: { orderBy: 'function_sort' }, hideLoading: true }
            request(position).then(res => {
                if (res.code == 200) {
                    if (res.data.records) {
                        res.data.records.forEach((v,idx)=>{
                            if (idx>=0 && idx<4) {
                                this.navUrls[idx].url = v.functionIcon ? v.functionIcon : this.navUrls[idx].url
                                this.navUrls[idx].text = v.functionName ? v.functionName : this.navUrls[idx].text
                            } else if (idx>=4 && idx<8) {
                                this.navUrlsList[idx-4].url = v.functionIcon ? v.functionIcon : this.navUrlsList[idx-4].url
                                this.navUrlsList[idx-4].text = v.functionName ? v.functionName : this.navUrlsList[idx-4].text
                            }
                        })
                    }
                }
            })
        },
        // 获取潮逛指南数据
        getCmsContent() {
            let position = { path: api.getCmsContent, method: 'post', data: { putChannel: 1, putPosition: 1 }, hideLoading: true }
            request(position)
                .then(res => {
                    if (res.code == 200) {
                        var records = res.data.records
                        records = records.slice(0, 5)
                        records.map(item => {
                            var limit = 32
                            if (item.title.length > limit) {
                                item.title = item.title.substr(0, limit) + '...'
                            }
                            limit = 10
                            if (item.author.length > limit) {
                                item.author = item.author.substr(0, limit) + '...'
                            }
                            return item
                        })
                        records.forEach(item => {
                            item.startTime = moment(item.startTime).format('YYYY-MM-DD hh:mm:ss')
                            item.endTime = moment(item.endTime).format('YYYY-MM-DD hh:mm:ss')
                        })
                        this.tideList = records
                    }
                })
                .catch(err => {})
        },
        // nav跳转
        toNavPath(e) {
            // debugger
            var data = e.currentTarget ? e.currentTarget.dataset : e
            let { path, id, type } = data
            if (type == 'guideMoreCoupon') {
                buryPoint.setF({
                    id: pointCode.HOME_CARD_MORE
                })
            } else if (type == 'guideMore') {
                buryPoint.setF({
                    id: pointCode.HOME_GUIDE_MORE
                })
            } else {
                if (data.text == '每日签到') {
                    id = 16
                }
                buryPoint.setF({
                    id
                })
            }
            if (path == 'pages/game/gashapon') {
                wx.navigateTo({
                    url: '/' + path+'?activityId='+this.gashaponId
                })
            } else {
                // console.log(1111, `path:${path}`)
                if (path == '') {
                    wx.showToast({
                        icon: 'none',
                        title: '敬请期待...'
                    })
                } else {
                    wx.navigateTo({
                        url: '/' + path
                    })
                }
            }
        },
        getGashaponNo() {
            let position = { path: api.getGashaponNo, method: 'get', data: {}, hideLoading: true }
            request(position).then(res => {
                if (res.code == 200) {
                    this.gashaponId = res.data
                }
            })
        },
        //会员通知提醒接口
        getMemberNotice() {
            if (wx.getStorageSync('wxUserCode')) {
                let position = {
                    path: api.getMemberNotice,
                    method: 'post',
                    data: {
                        memberCode: wx.getStorageSync('wxUserCode') ? wx.getStorageSync('wxUserCode') : '',
                        mallCode: 'HXSGSH01',
                        noticeType: '10'
                    },
                    hideLoading: true
                }
                request(position).then(res => {
                    if (res.code == 200) {
                        if (res.data.noticeBody) {
                            wx.showToast({
                                title: JSON.parse(res.data.noticeBody).couponName,
                                icon: 'none',
                                duration: 5000
                            })
                        }
                    }
                })
            }
        },
        freshPage() {
            this.getBanner()
            this.getCmsContent()
            this.getCoupons()
            this.getGashaponNo()
            this.queryIcon()
        },
        async getCoupons() {
            let currMallCode = this.mallCode
            if (!currMallCode) {
                let data = await utils.getMalls()
                currMallCode = data.mallCode
            }
            let params = Object.assign(
                {},
                {
                    pageNum: 1,
                    pageSize: 2
                },
                {
                    mallCode: currMallCode,
                    sourtRule: 1
                }
            )
            let res
            res = await getCouponBatchPage(params)
            let list = res.list
            this.coupons = list
        },
        // 去抽奖
        toLuck() {
            console.log('抽奖')
            wx.navigateTo({
                url: '/pages/luckyLottery/index'
            })
        },
        // 去在线商城
        toLineMall(option) {
            console.log(option)
            // 餐饮美食 品牌服饰
            // 与商品列表页约定 格式[1,2] / [美食，美食二级业态第一个] [服饰, 美食二级业态第一个] 待确认业态id
            getApp().globalData.categoryId = option
            wx.switchTab({
                url: '/pages/integralMall/index'
            })
        }
    },
    mounted() {
        this.freshPage()
        this.getImage()
    },
    // 下拉刷新
    onPullDownRefresh() {
        this.freshPage()
        //刷新完成后关闭
        wx.stopPullDownRefresh()
    },
    onTabItemTap(item) {
        //埋点
        buryPoint.setF({
            id: pointCode.TABBAR_F_HOME
        })
    },
    // 分享
    onShareAppMessage() {
        return {
            title: '南海嘉洲广场',
            desc: '',
            path: 'pages/home',
            success: function(res) {
                console.log(res)
            },
            fail: function(err) {
                console.log(err)
            }
        }
    }
}
</script>
<style lang="less">
#home {
    position: relative;
    width: 100%;
    height: 100%;

    .focus {
        .tip {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #ee7a68;
            color: #fff;
            font-size: 14px;
            padding: 10px 10px;
            .arrow {
                width: 16px;
                height: 16px;
                background-image: url('../static/images/arrow.png');
                background-position: center;
                background-repeat: no-repeat;
                background-size: cover;
                transition: transform 0.5s;
                &.up {
                    transform: rotate(180deg);
                }
            }
        }
    }

    .aqh-swiper {
        // width: 100%;
        // height: 424rpx;
        swiper {
            width: 100%;
            height: 360rpx;
            margin: 20rpx 0;
            swiper-item {
                display: flex;
                align-items: center;
            }
        }
        .slide-image {
            // width: 94%;
            // height: 90%;
            // margin-left: 20rpx;
            // margin-right: 20rpx;
            // border-radius: 15rpx;
            // border: 1rpx solid;
            // width: 100%;
            // height: 100%;
            // display: block;
            // transform: scale(0.95);
            transition: all 0.3s ease;
            border-radius: 12rpx;

            width: 100%;
            height: 80%;
        }
        .slide-image-act {
            width: 100%;
            height: 100%;
            margin-left: 12rpx;
            margin-right: 12rpx;
            // width: 100%;
            // height: 100%;
            // transform: scale(1);
        }
    }

    .nav {
        ul {
            display: flex;
            padding: 20px 20px 20px;
            justify-content: space-around;
            padding-bottom: 0px;
            margin-bottom: 15px;
            padding-left: 0px;
            padding-right: 0px;
            li {
                position: relative;
                font-size: 12px;
                text-align: center;
                overflow: hidden;
                //flex: 1;
                .nav-sub-text {
                    margin-top: 5px;
                    font-size: 13px;
                    color: #909090;
                }
            }
        }
    }
    .nav_div {
        width: 48px;
        height: 48px;
        overflow: hidden;
        margin: 0 auto;
        text-align: center;
    }
    .navUrls ul li:nth-child(1) {
        text-align: left;
        .nav_img {
            width: 48px;
            height: 48px;
            //padding-left: 10px;
        }
    }
    .navUrls ul li:nth-child(2) {
        //text-align: center;
        .nav_img {
            width: 48px;
            height: 48px;
        }
    }
    .navUrls ul li:nth-child(3) {
        .nav_img {
            width: 48px;
            height: 48px;
            margin-bottom: 6.5px;
        }
    }
    .navUrls ul li:last-child {
        //text-align: right;
        .nav_img {
            width: 48px;
            height: 48px;
            margin-bottom: 9px;
            //padding-right: 3px;
        }
    }
    .navList ul li:nth-child(1) {
        //text-align: left;
        .nav_img {
            width: 48px;
            height: 48px;
            //padding-left: 10px;
        }
    }
    .navList ul li:nth-child(2) {
        // text-align: center;
        .nav_img {
            width: 48px;
            height: 48px;
        }
    }
    .navList ul li:nth-child(3) {
        // text-align: center;
        .nav_img {
            width: 48px;
            height: 48px;
        }
    }
    .navList ul li:last-child {
        //text-align: right;
        .nav_img {
            //padding-right: 10px;
            width: 48px;
            height: 48px;
        }
    }
    .navList ul {
        padding-top: 5px;
    }
    .items {
        overflow: hidden;
        justify-content: space-between;
        padding-top: 15px;
        padding-left: 15px;
        flex-wrap: wrap;
        margin-bottom: -15px;
        .item {
            box-sizing: border-box;
            float: left;
            margin-bottom: 15px;
            width: 50%;
            height: 80px;
            padding: 0px 15px 0 0;
            .content {
                background-color: #eff1f8;
                border-radius: 4px;
                display: flex;
                height: 80px;
                padding: 15px;
                box-sizing: border-box;
                .info {
                    flex: 2;
                    text {
                        font-size: 12px;
                        color: #999;
                    }
                }
                .img {
                    flex: 1;
                    image {
                        width: 48px;
                        height: 48px;
                    }
                }
            }
        }
    }
    .coupon {
        margin-top: 20px;
    }
    .title {
        display: flex;
        justify-content: space-between;
        padding: 0 15px;
        height: 24px;

        p {
            color: #333333;
            font-size: 18px;
            font-weight: 500;
            line-height: 24px;
            display: flex;
            align-items: center;
            .icon_fresh {
                height: 18px;
                width: 18px;
                display: inline-block;
                margin-right: 3px;
            }
        }

        .list-more {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            font-size: 12px;
            line-height: 24px;
            color: #9975f3;
            .icon-arrow {
                display: inline-block;
                width: 10px;
                height: 10px;
                margin-left: 6px;
            }
        }
    }

    .lingjuan {
        .juan {
            display: flex;
            justify-content: space-between;
            padding: 15px;

            > view {
                width: 165px;
                height: 58px;
                padding: 0 8px;
                display: flex;
                position: relative;
                box-sizing: border-box;
                overflow: hidden;

                &::before,
                &::after {
                    content: '';
                    position: absolute;
                    width: 6px;
                    height: 6px;
                    background-color: #fff;
                    border-radius: 50%;
                    top: -3px;
                    left: 34%;
                }

                &::after {
                    top: auto;
                    bottom: -3px;
                }

                h4 {
                    height: 24px;
                    line-height: 24px;
                }

                p {
                    font-size: 12px;
                    height: 14px;
                }

                image {
                    flex: 1;
                    height: 43px;
                    margin: 8px 8px 0 0;
                }

                .info {
                    flex: 2;
                    border-left: 1px dashed #ccc;
                    padding-left: 10px;
                }
            }

            .left {
                background: #008fef;
                margin-right: 15px;
            }

            .right {
                background: #0a6a44;
            }
        }
    }
    .home-bg {
        width: 100%;
        height: 8px;
        background: #f5f6fa;
    }
    .zhinan {
        .zhinan-title {
            position: relative;
            padding-bottom: 13px;
            .count-time {
                left: 110px;
                top: 2px;
                position: absolute;
                color: #8053F2;
                display: flex;
                justify-content: center;
                align-items: center;
            }
        }
        .floor {
            display: flex;
            padding: 10px 0;
            margin: 0 16px;
            font-size: 0;
        }
    }
    .coupon-con {
        margin: 15px 0 0;
        padding: 0 18px 30px;
        .coupon-item {
            position: relative;
            display: inline-block;
            box-sizing: border-box;
            width: 50%;
            &:first-child {
                padding-right: 7.5px;
                .coupon-list {
                    float: left;
                }
            }
        }
    }
    .zhinan {
        margin-top: 20px;
    }
}

* {
    box-sizing: border-box;
}

.pt10 {
    padding-top: 10px;
}
.tipPage {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.53);
    z-index: 9999;
    img {
        position: absolute;
        bottom: 0;
        width: 100%;
    }
}
#home.mask {
    height: 100vh;
    overflow: hidden;
}
.loadmore-show {
    .reachText {
        color: #e7e7e7;
        text-align: center;
        width: 100%;
        font-size: 14px;
        padding-top: 45px;
        letter-spacing: 1px;
        position: relative;
        padding-bottom: 30px;
    }
    .reach-text {
        display: block;
        position: relative;
        text-align: center;
    }
    .reach-text:before,
    .reach-text:after {
        content: '';
        position: absolute;
        top: 50%;
        background: #f7f7f7;
        width: 32%;
        height: 1px;
    }
    .reach-text:before {
        left: 2%;
    }
    .reach-text:after {
        right: 2%;
    }
}
.online-mall {
    margin-top: 15px;
}
.mall-main {
    display: flex;
    padding: 20px 15px 24px;
    .mall-item {
        flex: 1;
        height: 80px;
        &:first-child {
            padding-right: 21px;
        }
        img {
            width: 100%;
            height: 100%;
        }
    }
}
</style>
