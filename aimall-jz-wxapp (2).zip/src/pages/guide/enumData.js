export default {
    time: [
        {
            name: '最新',
            id: '',
        },
        {
            name: '最热',
            id: 'time',
        },
    ],
    type: [
        {
            name: '全部',
            id: '',
        },
        {
            name: '商场发布',
            id: '1',
        },
        {
            name: '门店发布',
            id: '2',
        },
    ]
}
