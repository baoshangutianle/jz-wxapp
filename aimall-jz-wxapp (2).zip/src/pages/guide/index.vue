<template>
    <div id="listOfActivities">
        <div class="search-btn">
            <div class="search-btn-wrap">
                <img class="icon-search" src="/static/images/icon-common-search@2x.png" />
                <input
                    v-model="ipt"
                    class="search-input"
                    type="text"
                    placeholder="搜索"
                    @confirm="searchPopConfrim"
                />
                <img
                    v-show="ipt"
                    class="btn-clear"
                    src="/static/images/icon-common-clear@2x.png"
                    @tap="clearSearch()"
                />
            </div>
        </div>
        <div class="activity-content">
            <!-- <ConditionFiltr
                :filter-data="filterData"
                :isshow="isShowModal[currModal]"
                @updateIsShow="updateIsShow"
                @chooseData="getFilter"
            />-->
            <sel-enum-guide :type-data="timeData" :floor-data="typeData" @change="selectData" />
            <scroll-view
                :scroll-y="true"
                :style="{'height': '100%'}"
                class="actives-con"
                lower-threshold="100"
                @scrolltolower="scrollToLower"
            >
                <ul>
                    <li v-for="item in promtionPage" :key="item.id" @click="toDetails(item)">
                        <article-comp :data="item" />
                    </li>
                </ul>
                <load-more v-if="reachFinish" />
            </scroll-view>
            <blank-page
                :show-blank-page="hasFetchData&&promtionPage.length===0"
                :blank-page-content="`“${ipt}…”`"
            />
        </div>

        <!-- </scroll-view> -->
        <!-- </view> -->
        <!-- <search-comp :is-show="isSearchPopShow"
                     @cancel="myEvent"
                     @confirm="searchPopConfrim"
        @myevent="myEvent" />-->
    </div>
</template>

<script>
import moment from 'moment'
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import ConditionFiltr from '../../components/ConditionFiltr'
import wxUtils from '@/plugins/wxUtils'
import SearchComp from '@/components/SearchComp'
import ArticleComp from '@/components/ArticleComp'
import { debuglog } from 'util'
import { INTELSORT, ALLSORT } from '../../plugins/constants'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import BlankPage from '@/components/blankPage'
import { constants } from 'zlib'
import loadMore from '@/components/loadMore'
import SelEnumGuide from '@/components/SelEnumGuide'
import enumData from './enumData'

export default {
    components: {
        ConditionFiltr,
        SearchComp,
        ArticleComp,
        loadMore,
        SelEnumGuide,
        BlankPage
    },
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            timeData: [],
            typeData: [],
            loaderMore: true,
            ipt: '',
            isShowModal: {
                time: false,
                type: false
            },
            currModal: 'time',
            getPromtionPageRequest: {
                pageNo: 1,
                pageSize: 20,
                putChannel: 1,
                putPosition: 1,
                orderBy: '',
                ownerType: '',
                titleLike: ''
            },
            page: {
                pageNo: 1,
                pageSize: 20
            },
            promtionPage: [],
            order: ['red', 'yellow', 'blue', 'green', 'red'],
            toView: 'red',
            scrollTop: 100,
            isSearchPopShow: false,
            isClear: false,
            serachVal: false,
            reachFinish: false,
            query: {},
            hasFetchData: false //拉取数据状态
        }
    },
    onShow() {
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.GUIDE_P
        })
    },
    mounted() {
        this.timeData = enumData['time']
        this.typeData = enumData['type']
        this.resetRefresh()
    },
    onUnload() {
        this.ipt = ''
        this.serachVal = false
        this.reachFinish = false
        this.loaderMore = true
        this.hasFetchData = false
        this.isSearchPopShow = false
        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.GUIDE_Z,
            p_stay_time: this.pageStayTime
        })
    },
    methods: {
        selectData(operate, data) {
            if (operate == 'type') {
                this.query.orderBy = data.id
            } else if (operate == 'floor') {
                this.query.ownerType = data.id
            }
            this.getFilter()
        },
        myEvent(val) {
            this.isClear = val.clear
            this.getPromtionPageRequest.pageNo = 1
            this.ipt = ''
            this.isSearchPopShow = false
            this.getPromtionPageRequest.titleLike = this.ipt
            this.getPromtionPage(0)
        },
        clearSearch() {
            this.getPromtionPageRequest.pageNo = 1
            this.ipt = ''
            this.isSearchPopShow = false
            this.getPromtionPageRequest.titleLike = this.ipt
            this.serachVal = false
            this.getPromtionPage(0)
        },
        searchPopCancel() {
            this.isSearchPopShow = false
        },
        searchPopConfrim(val) {
            this.promtionPage = []
            // this.ipt = val
            this.serachVal = true
            this.isSearchPopShow = false
            this.resetRefresh()
            //埋点
            buryPoint.setF({
                id: pointCode.GUIDE_F_SEARCH,
                p_action_id: this.ipt,
                p_action: this.ipt
            })
        },
        resetRefresh() {
            //重置刷新
            this.getPromtionPageRequest.pageNo = 1
            this.getPromtionPageRequest.titleLike = this.ipt
            this.getPromtionPage(0)
        },
        toSearch() {
            this.isSearchPopShow = true
        },
        //到达底部
        scrollToLower(e) {
            if (this.loaderMore) {
                this.getPromtionPageRequest.pageNo++
                this.getPromtionPage(1)
            }
        },
        upper(e) {
            console.log(e)
        },
        lower(e) {
            console.log(e)
        },
        scroll(e) {
            console.log(e)
        },
        tap(e) {
            for (var i = 0; i < this.order.length; ++i) {
                if (this.order[i] === this.toView) {
                    this.toView = this.order[i + 1]
                    break
                }
            }
        },
        tapMove(e) {
            this.scrollTop = this.scrollTop + 10
        },
        getFilter(val) {
            // const INTELSORT = '智能排序';
            // const ALLSORT = '筛选';
            // this.ipt = ''
            // this.getPromtionPageRequest.titleLike = this.ipt

            // this.getPromtionPageRequest.orderBy = val['最新'];
            // this.getPromtionPageRequest.ownerType = val['全部'];
            this.getPromtionPageRequest.pageNo = 1
            this.getPromtionPage(0)
        },
        updateIsShow(val) {
            this.isShowModal[this.currModal] = !this.isShowModal[this.currModal]
        },
        getPromtionPage(times) {
            this.hasFetchData = false
            let { pageNo, pageSize } = this.getPromtionPageRequest
            let params = {
                putChannel: 1,
                putPosition: 1,
                titleLike: this.ipt
            }
            Object.assign(
                params,
                {
                    pageNo,
                    pageSize
                },
                this.query
            )

            let requestOptions = {
                path: api.getCmsContent,
                method: 'post',
                data: params
            }

            request(requestOptions).then(res => {
                this.hasFetchData = true
                this.reachFinish = false
                if (res.data.records.length == 0 && times == 0) {
                    this.promtionPage = []
                    this.loaderMore = false
                    return
                }
                if (0 <= res.data.records.length && res.data.records.length < this.page.pageSize) {
                    this.loaderMore = false
                    this.reachFinish = true
                }
                var records = res.data.records
                records.map(item => {
                    var limit = 28
                    if (item.title.length > limit) {
                        item.title = item.title.substr(0, limit) + '...'
                    }
                    limit = 10
                    if (item.subtitle.length > limit) {
                        item.subtitle = item.subtitle.substr(0, limit) + '...'
                    }
                    limit = 10
                    if (item.author.length > limit) {
                        item.author = item.author.substr(0, limit) + '...'
                    }
                    return item
                })
                records.forEach(item => {
                    item.startTime = moment(item.startTime).format('YYYY-MM-DD hh:mm:ss')
                    item.endTime = moment(item.endTime).format('YYYY-MM-DD hh:mm:ss')
                })
                let list = records
                if (times == 1) {
                    this.promtionPage = this.promtionPage.concat(list)
                } else {
                    this.promtionPage = list
                }
            })
        },
        toDetails(item) {
            //埋点
            buryPoint.setF({
                id: pointCode.GUIDE_F_DETAIL,
                p_action_id: item.id,
                p_action: item.title
            })
            wx.navigateTo({
                url: `/pages/guide/details?id=${item.id}&type=${item.putType}`
            })
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        console.log('下拉刷新')
        this.loaderMore = true
        this.resetRefresh()
        wx.stopPullDownRefresh()
    },
    // 页面滚动到底部
    onReachBottom() {
        if (this.loaderMore) {
            this.getPromtionPageRequest.pageNo++
            this.getPromtionPage(1)
        } else {
            if (this.promtionPage.length > 4) {
                this.reachFinish = true
            } else {
                this.reachFinish = false
            }
        }
    }
}
</script>

<style lang="less">
@import '../../assets/styles/vars';
page {
    height: 100%;
}
#listOfActivities {
    // height: 100%;
    min-height: 100vh;
    background-color: #fff;
    display: flex;
    flex-direction: column;
    .activity-content {
        background: #fff;
        flex: 1;
        display: flex;
        flex-direction: column;
        .filter-box {
            height: 50px;
            border-bottom: solid 1px @border-color;
        }
        .actives-con {
            flex: 1;
            height: 100%;
            padding-top: 0px;
            // padding-bottom: 15px;
        }
    }
    .actives-list {
        min-height: 100vh;
        background: #ffffff;
    }
    .actives-con {
        padding: 20px 15px 30px;
        width: 100%;
        box-sizing: border-box;
    }
    .actives-con ul {
        padding-top: 20px;
    }
    .actives-con ul li:nth-child(1) {
        padding-top: 0px;
    }
    .actives-con ul li {
        padding-top: 20px;
        // height: 80px;
        // border-bottom: 1px solid #eff1f8;
        cursor: pointer;
        display: flex;
    }
    .actives-con ul li:last-child {
        border-bottom: none;
    }
    .actives-time {
        font-size: 12px;
        color: #999999;
    }
    .btn-clear {
        z-index: 10;
        width: 15px;
        height: 16px;
        padding: 9.5px;
        position: absolute;
        top: 50%;
        right: 15px;
        transform: translateY(-50%);
        font-size: 15px;
    }

    .search-btn {
        text-align: left;
        line-height: 50%;
        .search-btn-wrap {
            background-color: #ffffff;
            border-radius: 4px;
        }
        .icon-search {
            position: absolute;
            top: 50%;
            left: 15%;
        }
        .search-input {
            height: 38px;
            line-height: 28px;
            width: 90%;
            background: #ffffff;
            display: inline-block;
            padding-left: 30px;
            background-color: #ffffff;
        }
    }
}
</style>
