<template>
    <div id="guide-container">
        <div
            v-if="type==1"
            class="guide-detail guide-detail-1"
        >
            <div>
                <p class="guide-title">{{ title }}</p>
                <div class="guide-div">
                    <div class="guide-oper">
                        <span class="guide-aut">{{ author }}</span>
                    </div>
                    <div class="guide-first-rate">
                        <div class="guide-read">
                            <span class="guide-read-icon">
                                <image src="/static/images/eye_show.png" />
                            </span>
                            <span class="guide-read-val">{{ clickNumber }}</span>
                        </div>
                    </div>
                </div>

                <div class="guide-con">
                    <wxParse :content="content" />
                </div>

                <!-- 吸底 -->
                <div class="restaurant-footer">
                    <div>
                        <span>
                            <share-btn :shareNum="shareNum"/>
                        </span>
                        <span>
                            <collect-comp
                                :content-id="contentId"
                                :content-type="2"
                                :collectNum="collectNum"
                                :collectState="collectState"
                                @getCollectNum="getshareNum"
                            />
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div
            v-if="type==2"
            class="guide-detail guide-detail-2"
        >
            <div>
                <div class="guide-imgs">
                    <img
                        v-for="(item,index) in pictures"
                        :src="item"
                        :key="index"
                        mode="widthFix"
                        alt="图片"
                    >
                </div>
                <div class="guide-info">
                    <div class="guide-desc">
                        <span class="guide-desc-text">{{ !isDescAll ? partDesc : allDesc }}</span>
                        <span
                            v-if="!isDescAll && isShowBtn"
                            class="guide-desc-all"
                            @click="isDescAll = true"
                        >全文</span>
                        <span
                            v-if="isDescAll && isShowBtn"
                            class="guide-desc-all"
                            @click="isDescAll = false"
                        >收起</span>
                    </div>
                    <div class="guide-todo">
                        <div class="guide-rate">
                            <div class="guide-read">
                                <span class="guide-read-icon">
                                    <image src="/static/images/eye_show.png" />
                                    <!-- <image src="../../static/images/eye_hide.png"></image> -->
                                </span>
                                <span class="guide-read-val">{{ clickNumber }}</span>
                            </div>
                        </div>
                        <div class="share-btn-container">
                            <div class="btn-share-wrap">
                                <img
                                    class="active-icon-real"
                                    src="/static/images/icon_share2.png"
                                    alt=""
                                >
                                <button
                                    class="active-icon"
                                    open-type="share"
                                />
                            </div>

                            <span class="share-num">{{shareNum}}</span>
                        </div>
                        <guide-collect
                            :content-id="contentId"
                            :content-type="2"
                            :collectNum="collectNum"
                            :collectState="collectState"
                            @getCollectNum="getshareNum"
                        />
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>

<script>
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import wxUtils from '@/plugins/wxUtils'
import wxParse from 'mpvue-wxparse'
import ShareBtn from '@/components/ShareBtn'
import GuideCollect from '@/components/GuideCollect'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import CollectComp from '@/components/CollectComp'

export default {
    components: {
        wxParse,
        ShareBtn,
        GuideCollect,
        CollectComp
    },
    data() {
        return {
            pageStayTime: 0,//页面停留时间
            contentId: '',
            id: '',
            type: '',
            title: '',
            subTitle: '',
            author: '',
            content: '',
            clickNumber: '',
            allDesc: "",
            partDesc: "",
            isDescAll: true,
            isShowBtn: false,
            pictures: [],
            shareNum: '',
            collectNum: '',
            collectState: false
        }
    },
    onLoad() {
        this.contentId = '';
        this.type = '1';
        this.title = '';
        this.subTitle = '';
        this.author = '';
        this.content = ' ';
        this.clickNumber = '';
        this.allDesc = "";
        this.partDesc = "";
        this.isDescAll = true;
        this.isShowBtn = false;
        this.shareNum = ''
        this.collectNum  = ''
        this.collectState = false
        this.getDetailById()
        this.getshareNum()
    },
    methods: {
        getDetailById() {
            this.type = this.$root.$mp.query.type;
            let id = this.$root.$mp.query.id;
            this.id = this.$root.$mp.query.id;
            let opsiton = { path: api.getCmsContentById + id }
            request(opsiton).then(res => {
                if (res.code == 200) {
                    let data = res.data;
                    this.contentId = data.id
                    //图文
                    this.title = data.title;
                    this.subTitle = data.subtitle;
                    this.author = data.author;
                    this.content = data.ownerType == 1 ? data.content : data.mainBody;
                    this.clickNumber = data.clickNumber * 1 + data.virtualReading * 1;

                    //图片

                    this.pictures = data.pictures
                    if (data.mainBody && data.mainBody.length > 25) {
                        this.allDesc = data.mainBody;
                        this.partDesc = this.allDesc.slice(0, 25) + '...'
                        this.isDescAll = false;
                        this.isShowBtn = true;
                    } else {
                        this.allDesc = data.mainBody;
                        this.partDes = this.allDesc;
                        this.isDescAll = true;
                        this.isShowBtn = false;

                    }
                }
            })
        },
        //获取转发、收藏个数
        getshareNum(item){
            //证明是从操作收藏取消收藏过来的
            let collectFlag
            if(item == 'collectFlag'){
                collectFlag = true
            }else {
                collectFlag = false
            }
            let wxUserCode = wx.getStorageSync('wxUserCode') ? wx.getStorageSync('wxUserCode') :''
            let requestOptions = {
                    //path: api.shareNum,
                    path: api.creatCollect,
                    method: 'post',
                    data: {
                        "contentId": this.id,
                        "contentType": '2',
                        "userCode": wxUserCode,
                        "collectFlag": collectFlag
                    }
                }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    if(collectFlag){
                        var msg = this.collectState ? '取消收藏' : '已收藏'
                        wx.showToast({
                            icon: 'success',
                            title: msg
                        })
                    }
                    this.shareNum = res.data.relayNum ? res.data.relayNum :''
                    this.collectNum = res.data.collectNum ? res.data.collectNum :''
                    this.collectState = res.data.collectState ? res.data.collectState : false
                }
            })
        }
    },
    onShareAppMessage() {
         //转发调用接口
        let wxUserCode = wx.getStorageSync('wxUserCode') ? wx.getStorageSync('wxUserCode') :''
        let requestOptions = {
                path: api.shareAdd,
                method: 'post',
                data: {
                    "contentId": this.id,
                    "contentType": '2',
                    "userCode": wxUserCode
                }
            }
        request(requestOptions).then(res => {
            if (res.code == 200) {
                this.getshareNum()
            }
        })
        return {
            title: this.title,
            desc: this.subTitle,
            path: 'pages/home?pageId=guide&id=' + this.id + '&type=' + this.type,
            success: function(res) {
            },
            fail: function(err) {
                console.log(err)
            }
        }
    },
    onShow() {
        this.pageStayTime = new Date().getTime()

        buryPoint.setP({
            id: pointCode.GUIDE_DETAIL_P,
            p_id: this.$root.$mp.query.id
        })
    },
    onUnload() {
    //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.GUIDE_DETAIL_Z,
            p_id: this.$root.$mp.query.id,
            p_stay_time: this.pageStayTime
        })
    },
}
</script>

<style lang="less">
@import '../../assets/styles/vars';
@import url('~mpvue-wxparse/src/wxParse.css');
#guide-container {
    overflow: hidden;
    .guide-share {
        z-index: 3;
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
    }
    .guide-todo {
        position: absolute;
        display: inline-block;
        bottom: 20px;
        right: 0px;
        width: 100%;
        .icon-share {
            overflow: visible;
            background: none;
            border: none;
            image {
                width: 20px;
                height: 20px;
                position: absolute;
            }
        }
        .iscollect {
            color: #9975F3;
        }
    }
    .guide-rate {
        .guide-read {
            float: left;
            padding-left: 20px;
            .guide-read-icon {
                display: inline-block;
                image {
                    width: 18px;
                    height: 11px;
                }
            }
            .guide-read-val {
                margin-left: 5px;
                font-size: 15px;
                color: @gray-color;
            }
        }
    }
    .guide-detail {
        position: relative;
        display: flex;
        flex-direction: column;
        margin-bottom: 110px;
        padding-bottom: 20px;
        &.guide-detail-2 {
            margin-bottom: 0;
        }
    }
    .guide-detail-1 {
        background: #ffffff;
        padding: 10px 13px 0;
        .activies-img {
            width: 100%;
            height: 194px;
            border-radius: 4px;
        }
        .guide-title {
            font-size: 20px;
            color: #333333;
            font-weight: bold;
            padding-top: 3px;
            line-height: 28px;
        }
        .guide-oper {
            font-size: 15px;
            color: #999999;
            padding-top: 10px;
            width: 100%;
        }
        .guide-aut {
            display: inline-block;
        }
        .guide-rate {
            margin: 10px 0 40px;
        }
        .guide-con {
            padding: 20px 0 0;
            font-size: 15px;
            color: #333333;
            .wxParse {
                text-align: center;
                image {
                    display: block;
                    width: 100% !important;
                }
            }
        }
    }
    .guide-detail-2 {
        & > div {
            width: 100%;
        }
        .guide-imgs {
            display: flex;
            width: 100%;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .guide-imgs image {
            width: 100%;
        }
        .guide-info {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 0 15px 40px 17px;
            background: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.3) 17%, rgba(0, 0, 0, 0.65) 61%, rgba(0, 0, 0, 0.82) 100%);
            // background: #000;
            // opacity: 0.6;

            .guide-desc {
                font-size: 15px;
                color: rgb(255, 255, 255, 0);
                font-weight: bold;
                padding-top: 38px;
                padding-bottom: 60px;

                .guide-desc-text {
                    // display: inline-block;
                    transition: all 5s;
                    overflow: hidden;
                    font-weight: 100;
                    color: rgb(255, 255, 255, 0);
                    &.show {
                        display: inline-block;
                    }
                    &.hide {
                        display: none;
                    }
                }
                .guide-desc-all {
                    font-size: 13px;
                    // background:rgba(0,0,0,.8);
                    background: rgba(0, 0, 0, 3);
                    box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.5);
                    border-radius: 4px;
                    padding: 2px 7px;
                    margin-left: 10px;
                    color: #fff;
                    &:active {
                        color: @theme-color;
                    }
                }
            }
        }
        .guide-read {
            .guide-read-val {
                // color: #fff;
                color: rgb(255, 255, 255);
            }
        }
    }
    .collect-comp-container {
        position: absolute;
        align-items: center;
        justify-content: center;
        //width: 32px;
        height: 32px;
        // border-radius: 50%;
        // box-shadow: 0px 3px 10px rgba(0,0,0,.1);
        // background: #fff;
        right: 25px;
    }
    .share-btn-container {
        display: inline-block;
        position: absolute;
        z-index: 99;
        right: 100px;
        .btn-share-wrap {
            position: relative;
            display: inline-block;
            width: 20px;
            height: 20px;
            overflow: hidden;
            .active-icon {
                z-index: 2;
                opacity: 0;
                display: inline-block;
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                width: 100% !important;
                height: 100% !important;
                margin: 0 !important;
                padding: 0 !important;
            }
            .active-icon-real {
                display: inline-block;
                width: 100%;
                height: 100%;
                &:hover {
                    opacity: 0.8;
                }
            }
        }
    }

    .guide-div {
        position: relative;
    }
    .guide-first-rate {
        position: absolute;
        z-index: 99;
        top: 10px;
        right: 15px;
        .guide-read {
            float: left;
            padding-left: 20px;
            .guide-read-icon {
                display: inline-block;
                image {
                    width: 18px;
                    height: 11px;
                }
            }
            .guide-read-val {
                margin-left: 5px;
                font-size: 15px;
                color: @gray-color;
                font-weight: 200;
            }
        }
    }
    .share-num{
        color: #ffffff;
        font-size: 15px;
        vertical-align: top;
        padding-left: 8px;
    }
}
</style>
