<template>
    <div>
        <div class="share" :class="{'bigPhoneFalg':bigPhoneFalg,'ipadFalg':ipadFalg}">
            <img class="bg"
             src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/284e52b3c7a345398e9736c96d3c29d1.png"
             mode="widthFix" />
            <div class="content">
                <img class="top"
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/d7829a0087d942c29e873f5eec4eeead.png"
                mode="widthFix" />
                <div class="imgPage icon">
                    <img :src="iconUrl" mode="widthFix">
                </div>
                <div class="imgPage font">
                    <div class="title">{{title}}</div>
                    <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/1ed6407e1159424ab6ecb58aa1e02256.png" mode="widthFix">
                </div>
                <div class="imgPage tip">
                    <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191031/e4d7e9d0a8354902a5c08c0e73e9acf6.png" mode="widthFix">
                </div>
                <ul class="list" :style="{width:list.length*174+'rpx'}">
                    <li v-for="(item,index) in list"
                        :key="index">
                        <div class="imgPage">
                            <img :src="item.couponImageUrl">
                        </div>
                        <div class="name">{{item.prizeName}}</div>
                    </li>
                </ul>
            </div>
            <div class="button" @click="toIndex">我也去试试</div>
        </div>
        <prize-Page :activityId ='activityId' :luckyPrizeId='luckyPrizeId' :openFalg="openFalg" :lotteryStatus="lotteryStatus" :lotteryName="title" :lotteryImg="iconUrl" @close ="closePage"/>
        <!-- <div @click="openFalg = true">点击事件</div> -->
    </div>
</template>
<script>
import prizePage from '../../components/prizePage'
import api from '@/plugins/api'
import request from '@/plugins/request'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
export default {
    components:{
       prizePage
    },
    data() {
        return {
            openFalg:false,
            lotteryStatus:true,
            activityId:'',
            luckyPrizeId:'',
            title: '',
            iconUrl:'', //中奖商品
            bigPhoneFalg:false, //大手机适配样式
            ipadFalg:false,//平板适配样式
            list: [],
            pageStayTime: 0, //页面停留时间
        }
    },
    onLoad(options){
        var t = this
        t.activityId = options.activityId
        t.luckyPrizeId = options.luckyPrizeId
        t.getActivityDetail()
        buryPoint.setP({
            id: pointCode.LOTTERY_SHARE_P,
            p_v1: 1
        })
        wx.getSystemInfo({
            success(res){
                if(res.screenHeight >= res.screenWidth*2){
                   t.bigPhoneFalg = true
                }else if(res.windowWidth > 550){
                   t.ipadFalg = true
                }else{
                   t.bigPhoneFalg = false
                   t.ipadFalg = false
                }
            }
        })
    },
    onShow(){
        this.pageStayTime = new Date().getTime()
    },
    onUnload() {
        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.LOTTERY_SHARE_Z,
            p_stay_time: this.pageStayTime,
            p_v1: 1
        })
    },
    methods:{
        toIndex(){
            buryPoint.setF({
                id: pointCode.LOTTERY_TRY_f,
                p_v1: 1
            })
            wx.navigateTo({url:`/pages/luckyLottery/index?activityId=${this.activityId}&pageShare=pageShare`})
        },
        closePage(status){
            this.openFalg = status
        },
        // 根据活动id查详情
        getActivityDetail() {
            let requestOptions = {
                path: api.getActivityDetail + this.activityId
            }
            request(requestOptions).then(res => {
                if(res.code ==200|| res.code == 0){
                    let data = res.data
                    data.prizeVos.map(item =>{
                        if(item.id == this.luckyPrizeId){
                           this.title = item.prizeName
                           this.iconUrl = item.couponImageUrl
                        }
                    })
                    this.list = data.prizeVos.filter((item,index) =>{
                        return index <= 3
                    })
                }
            })
        },
    }
}
</script>
<style lang="less" scoped>
.share {
    position: fixed;
    height: 100%;
    width: 100%;
    //background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/284e52b3c7a345398e9736c96d3c29d1.png') no-repeat center center;
    //background-size: 100% auto;
    .bg {
        width: 100%;
        position: absolute;
       // top:-26%;
    }
    .content {
        position: absolute;
        top: 0;
        width: 100%;
        z-index: 10;
        .top{
            width: 85%;
            margin: 15px auto;
        }
    }
    .imgPage {
        margin: 0 auto;
        img {
            width: auto;
            height: auto;
        }
    }
    .icon {
        width: 180px;
        margin-top: -20px;
        img {
            width: 100%;
            height: 180px;
        }
    }
    .font {
        width: 60%;
        position: relative;
        img {
            width: 243px;
            height: 37px;
        }
        .title {
            font-size: 15px;
            color: #ffffff;
            text-align: center;
            position: absolute;
            top: 0;
            width: 100%;
            line-height: 37px;
        }
    }
    .tip {
        width: 90%;
        margin-bottom: 10px;
        img {
            width: 342px;
            height: 34px;
        }
    }
    .list {
        margin: 0px auto 0;
        li {
            float: left;
            margin:0 3.5px;
            .imgPage{
                border-radius:5px;
                width:80px;
            }
            img {
                width: 80px;
                height: 80px;
                vertical-align: top;
            }
            .name {
                font-size: 12px;
                color: #ffffff;
                text-align: center;
                text-overflow: ellipsis;
                overflow: hidden;
                width: 80px;
                white-space: nowrap;
            }
        }
    }
    .button {
        width: 205px;
        height: 54px;
        position: absolute;
        bottom: 5%;
        background-image: linear-gradient(#f87191, #e04164);
        border-radius: 54px;
        text-align: center;
        line-height: 54px;
        color: #fff;
        font-size: 18px;
        left: 0;
        right: 0;
        margin: auto;
    }
}
.bigPhoneFalg{
    .bg{top:-12%;}
    .content{
        .icon{margin-top:-15px;}
        .tip{margin:10px auto;}
    }
    .button{bottom: 8%;}
}
.ipadFalg{
    .bg{top:-50%;}
    .content{
        .top{margin: 0 auto;width:70%;}
        .font{margin-top:-23px;}
        .tip{width:70%;
          img{width:100%;}
        }
    }
    .button{bottom: 2%;}
}
</style>
