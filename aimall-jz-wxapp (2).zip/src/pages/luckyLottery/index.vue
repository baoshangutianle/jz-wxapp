<template>
    <div class="luck">
        <!-- 抽奖标题 -->
        <div class="luck-title"></div>
        <!-- 抽奖转盘 -->
        <div class="prize" :class="{flashing:flashing}">
            <!-- 内容 -->
            <div class="content" :animation="musicAnimation">
                <div
                    class="item"
                    :style="{transform:  'rotateZ('+(360/prizeList.length*index +180/prizeList.length)+'deg)'}"
                    v-for="(item,index) in prizeList"
                    :key="item.id"
                >
                    <p>{{item.prizeName}}</p>
                    <img :src="item.couponImageUrl" alt />
                </div>
            </div>
            <!-- 按钮 -->
            <!-- <div class="btn">
                <auth-btn @pass="StartLOttery" />
            </div> -->
            <div class="btn">
  <div class="pointer"></div>
  <auth-btn @pass="StartLOttery" />
  </div>
        </div>
        <!-- 转盘底座 -->
        <div class="rotarybase">
            <span>-{{costIntegral}} 积分抽奖</span>
        </div>
        <!-- 活动规则 -->
        <div class="rules">
            <h3>活动规则</h3>
            <ul>
                <li v-for="(item,index) in rules" :key="index">{{item}}</li>
            </ul>
        </div>
        <!-- logo -->
        <div class="logo"></div>
        <!-- 不能抽奖提示模态框 -->
        <div class="cant-draw" v-show="isShowDraw">
            <div class="main">
                <!-- 不能抽奖 -->
                <div v-show="!isLuckDraw">
                    <img
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191030/5a62c9d523c8470d9cd3c84ad8aa6a78.png"
                        alt
                    />
                    <p>{{msg}}</p>
                    <div class="footer-btn">
                        <button @click="gotIt">知道了</button>
                    </div>
                </div>
                <!-- 300积分抽奖 -->
                <div class="tipPage" v-show="isLuckDraw">
                    <div class="img">
                        <span>{{costIntegral}}</span>
                        <br />
                        <span>积分</span>
                    </div>
                    <p>{{msg}}</p>
                    <p style="padding-top:0">抽奖未完成退出，积分不退还。</p>
                    <div class="footer-btn">
                        <button @click="luckyTry">立刻抽奖</button>
                    </div>
                    <div class="close">
                        <div class="line"></div>
                        <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/5ec255d63c534452916ebc09c6b28911.png"
                            @click="isShowDraw=false"/>
                    </div>
                </div>
            </div>
        </div>
        <!-- 抽奖结果模态框 -->
        <prize-Page
            :openFalg="openFalg"
            :lotteryStatus="lotteryStatus"
            :lotteryName="lotteryName"
            :lotteryImg="lotteryImg"
            :activityId="activityId"
            :luckyPrizeId="hitPrizeId"
            :pageSource="pageSource"
            @close="closePage"
        />
    </div>
</template>
<script>
import prizePage from '@/components/prizePage'
import AuthBtn from '@/components/AuthBtn'
import { mapState, mapMutations } from 'vuex'
import api from '@/plugins/api'
import request from '@/plugins/request'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import wxUtils from '@/plugins/wxUtils'
export default {
    data() {
        return {
            activityId: '', // 活动id
            hitPrizeId: '', // 中奖id
            activityName: '', //活动名称
            //---------动画----------
            musicAnimation: null, // 动画对象
            tempId: undefined, // 定时器ID
            acceleration: 0.25, // 加速的加速度
            r_acceleration: 0.01, // 减速的加速度
            firstTimes: 8, // 加速度次数
            duration: 6000, //转盘持续时间
            prizeNo: 0, //第几个中奖
            isRound: false, //是否开始
            angle: 0, // 初始度数
            //---------活动数据---------
            flashing: false, // 转盘背景闪动
            prizeList: [], //奖品集合
            rules: [], // 规则
            costIntegral: 0, //消耗积分
            // --------抽奖模态框----------------//
            isShowDraw: false, // 是否显示
            isLuckDraw: false, // 是否可以抽奖
            msg: '', //提示消息
            //--------- 抽奖结果模态框-----------//
            openFalg: false, // 是否显示
            lotteryStatus: false, // 是否中奖
            lotteryName: '', // 中奖商品名称
            lotteryImg: '', // 中奖商品图片src
            // ---------------登录----------------//
            isLoginPromptShow: true,
            flashingId: undefined,
            pageStayTime: 0, //页面停留时间
            pageSource: 0,
            errCode: ''
        }
    },
    components: {
        prizePage,
        AuthBtn
    },
    onLoad(options) {
        console.log(options, 'onload')
        if (typeof options.qrCode != 'undefined') {
            this.pageSource = 2
        } else if (typeof options.pageShare != 'undefined') {
            this.pageSource = 1
        } else {
            this.pageSource = 0
        }

        buryPoint.setP({
            id: pointCode.LOTTERY_P,
            p_v1: this.pageSource
        })
        this.activityId = options.activityId // 测试id
        if (this.activityId) {
            this.getActivityDetail()
        }
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo', 'isLogined']),
        // 奖品数量
        prizeNum() {
            return this.prizeList.length
        },
        // 计算中奖商品的角度
        difference() {
            return (this.prizeList.length - this.prizeNo) / this.prizeNum * 360 - 360 / this.prizeNum / 2
        }
    },
    watch: {
        isRound() {
            if (this.isRound) {
                this.animation()
            }
        }
    },
    methods: {
        ...mapMutations(['update']),
        // 根据活动id查详情
        getActivityDetail() {
            let requestOptions = {
                path: api.getActivityDetail + this.activityId
            }
            request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    let data = res.data || []
                    data.prizeVos.unshift({ id: null, couponImageUrl: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191102/1b0d20cdb5fc446b8df705a05a69f9ab.png', prizeName: '谢谢参与' })
                    if (data.prizeVos.length % 2) {
                        //保证偶数
                        data.prizeVos.pop()
                    }
                    this.prizeList = data.prizeVos
                    this.costIntegral = data.costIntegral || 0
                    this.activityName = data.activityName || 'A+CLUB会员'
                    this.angle = 180 / this.prizeList.length
                    if (data.activityRules) {
                        this.rules = data.activityRules.split('\n')
                    } else {
                        this.rules = []
                    }
                }
            })
        },
        // 登录
        login() {
            console.log('组件内部登录')
        },
        // 点击抽奖
        StartLOttery() {
            // 节流
            if (this.isRound) return
            console.log('抽奖')
            clearInterval(this.tempId)
            this.query()
        },
        // 查询是否可以抽奖
        query() {
            const t = this
            wx.request({
                url: api.checkMemberLotteryEligible + this.activityId,
                method: 'GET',
                data: null,
                header: {
                    Authorization: this.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    t.errCode = res.data.code
                    if (res.data.code == 4001 || res.data.code == 4000) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = t.isLogined
                                wxUtils.clearLoginStorage()
                                t.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index?form=game&formId=${t.activityId}`
                                })
                            }
                        })
                    } else if (res.data.code == 200 || res.data.code == 0) {
                        t.isLuckDraw = res.data.ok
                        console.log('是否可以抽奖', res.data.ok)
                        if (t.isLuckDraw) {
                            // 可以抽奖
                            t.msg = `使用 ${t.costIntegral} 积分抽奖一次`
                            buryPoint.setF({
                                id: pointCode.LOTTERY_START_F,
                                p_v1: t.pageSource
                            })
                        } else {
                            // 不能抽奖
                            t.msg = res.data.message
                        }
                        t.isShowDraw = true
                    } else {
                        let mes
                        if (res.data.code == 500) {
                            mes = '网络开了小差，请重新尝试'
                        } else {
                            mes = res.data.message
                        }
                        if (t.errCode == 400008) {
                            buryPoint.setF({
                                id: pointCode.LOTTERY_INTEGRAL_F,
                                p_v1: t.pageSource
                            })
                        } else if (t.errCode == 400003) {
                            buryPoint.setF({
                                id: pointCode.LOTTERY_ALREADY_F,
                                p_v1: t.pageSource
                            })
                        }
                        wx.showModal({
                            title: '提醒',
                            content: mes,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA'
                        })
                    }
                }
            })
            // let requestOptions = {
            //     path: api.checkMemberLotteryEligible + this.activityId
            // }
            // request(requestOptions).then(res => {
            //     if (res.code == 200 || res.code == 0) {
            //         this.isLuckDraw = res.ok
            //         console.log('是否可以抽奖', res.ok)
            //         if (this.isLuckDraw) {
            //             // 可以抽奖
            //             this.msg = `使用 ${this.costIntegral} 积分抽奖一次`
            //             buryPoint.setF({
            //                 id: pointCode.LOTTERY_START_F,
            //                 p_v1: this.pageSource
            //             })
            //         } else {
            //             // 不能抽奖
            //             this.msg = res.message
            //         }
            //         this.isShowDraw = true
            //     }
            // })
        },
        // 抽奖
        luckyTry() {
            buryPoint.setF({
                id: pointCode.LOTTERY_IMMEDIATELY_F,
                p_v1: this.pageSource
            })
            let requestOptions = {
                path: api.luckyTry,
                method: 'post',
                data: {
                    raffleActivityId: this.activityId,
                    source: 1 //小程序入口标识
                }
            }
            request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    console.log(res)
                    if (res.data) {
                        // 中奖了  获取中奖商品id
                        this.lotteryStatus = true
                        this.hitPrizeId = res.data.prizeId
                        console.log(this.hitPrizeId)
                        this.hitPrize()
                    } else {
                        // 未中奖 获取文案
                        this.lotteryStatus = false
                        let msg = res.message || '谢谢参与'
                        this.notHitPrize(msg)
                    }
                    // 关闭弹窗
                    this.isShowDraw = false
                    //  开始动画
                    let setTimeId = setTimeout(() => {
                        clearTimeout(setTimeId)
                        this.isRound = true
                    }, 200)
                }
            })
        },
        // 中奖执行逻辑
        hitPrize() {
            this.prizeList.forEach((v, i) => {
                if (v.id === this.hitPrizeId) {
                    this.lotteryStatus = true
                    this.lotteryName = v.prizeName
                    this.lotteryImg = v.couponImageUrl
                    this.prizeNo = i
                }
            })
            console.log('中奖了,奖品:' + this.lotteryName)
        },
        // 未中奖逻辑
        notHitPrize(msg) {
            console.log('未中奖')
            this.lotteryStatus = false
            this.hitPrizeId = ''
            this.lotteryName = msg || '谢谢参与~'
            this.lotteryImg = ''
            this.prizeNo = 0
        },
        animation() {
            let t = this
            let angle = t.angle
            let duration = t.duration
            let add = angle ? 360 - t.angle % 360 : 0
            var firstTimes = t.firstTimes
            let sumAngle = 360 * firstTimes + t.angle + add + (t.prizeNum - this.prizeNo) * (360 / t.prizeNum) - 180 / t.prizeNum
            let animation = wx.createAnimation({
                duration: duration,
                timingFunction: 'ease-out',
                transformOrigin: '50% 50% 0'
            })
            animation.rotateZ(sumAngle).step()
            t.musicAnimation = animation.export()
            setTimeout(() => {
                t.isRound = false
                t.openFalg = true
                t.angle = sumAngle
            }, duration + 100)
        },
        // animation1() {
        //     var self = this
        //     var difference = this.difference
        //     var speed = 0
        //     var duration = this.duration
        //     var acceleration = self.acceleration // 加速的加速度
        //     var racceleration = self.r_acceleration // 减速的加速度
        //     var firstTimes = self.firstTimes //  执行48次 加速到highSpeed
        //     var highSpeed = firstTimes * acceleration // 最高速度
        //     var oneAngel = self.angle + firstTimes * (firstTimes - 1) / 2 * acceleration + highSpeed // 第一阶段的旋转度数
        //     var secondTimes = 10 // 速度为highSpeed 继续执行10次
        //     var twoAngel = oneAngel + secondTimes * firstTimes * acceleration // 第二阶段的旋转度数
        //     var three = highSpeed / racceleration // 执行three次 速度从highSpeed减速到0
        //     var add = 360 - (twoAngel + three * (three - 1) / 2 * racceleration) % 360 + difference // 使最后刚好转到起点位置
        //     var twoAngelEnd = twoAngel + add // 第三阶段开始
        //     var threeAngel = twoAngelEnd + three * (three - 1) / 2 * racceleration // 最后的旋转度数
        //     let animation = wx.createAnimation({
        //         duration: duration,
        //         timingFunction: 'ease-out',
        //         transformOrigin: '50% 50% 0'
        //     })
        //     animation.rotateZ(threeAngel).step()
        //     self.musicAnimation = animation.export()
        //     setTimeout(() => {
        //         this.openFalg = true
        //         this.isRound = false
        //     }, duration + 200)
        //     return false
        //     // this.tempId = setInterval(() => {
        //     //     let animation = wx.createAnimation({
        //     //         duration: 10,
        //     //         transformOrigin: '50% 50% 0'
        //     //     })
        //     //     if (self.angle < oneAngel) {
        //     //         speed += acceleration
        //     //         self.angle += speed
        //     //     } else if (self.angle >= oneAngel && self.angle < twoAngel) {
        //     //         self.angle += speed
        //     //     } else if (self.angle.toFixed(2) === twoAngel.toFixed(2)) {
        //     //         self.angle += add
        //     //     } else if (self.angle > twoAngel && self.angle <= threeAngel) {
        //     //         speed -= racceleration
        //     //         console.log(speed.toFixed(3), racceleration.toFixed(3))
        //     //         if (+speed.toFixed(3) <= +racceleration.toFixed(3)) {
        //     //             console.log('动画结束')
        //     //             clearInterval(this.tempId)
        //     //             speed = 0
        //     //             self.angle = threeAngel % 360
        //     //             self.isRound = false
        //     //             setTimeout(() => {
        //     //                 self.openFalg = true
        //     //             }, 300)
        //     //             return false
        //     //         }
        //     //         self.angle += speed
        //     //     }
        //     //     // animation.rotateZ(self.angle).step()
        //     //     // self.musicAnimation = animation.export()
        //     // }, 10)
        // },
        // 关闭中奖结果模态框
        closePage(status) {
            this.openFalg = status
        },
        closeLoginPrompt() {
            this.isLoginPromptShow = false //关闭弹框
        },
        // 知道了埋点  需要区分积分不足还是已经抽过奖了
        gotIt() {
            this.isShowDraw = false
            // if(this.errCode == 400008){
            //     buryPoint.setF({
            //         id: pointCode.LOTTERY_INTEGRAL_F,
            //         p_v1: this.pageSource
            //     })
            // }else if(this.errCode == 400003){
            //     buryPoint.setF({
            //         id: pointCode.LOTTERY_ALREADY_F,
            //         p_v1: this.pageSource
            //     })
            // }
        }
    },
    // 分享
    onShareAppMessage(options) {
        let t = this
        let title
        if (t.lotteryStatus) {
            title = `我在${t.activityName}中抽中了${t.lotteryName}，你也来试试吧`
        } else {
            title = `${t.activityName}正在火热进行中，快来试试吧`
        }
        return {
            title: title,
            imageUrl: this.lotteryImg,
            path: 'pages/home?pageId=lotteryShare&activityId=' + this.activityId + '&luckyPrizeId=' + this.hitPrizeId,
            success: function(res) {
                // t.openFalg = false
                // 转发成功
                wx.showToast({
                    title: '转发成功',
                    icon: 'success',
                    duration: 2000
                })
            }
        }
    },
    onShow() {
        this.pageStayTime = new Date().getTime()
        let pageSource = this.pageSource

        this.flashingId = setInterval(() => {
            this.flashing = !this.flashing
        }, 500)
        let animation = wx.createAnimation({
            duration: 0,
            transformOrigin: '50% 50% 0'
        })
        animation.rotateZ(0).step()
        this.musicAnimation = animation.export()
        this.isShowDraw = false
        this.angle = 0
        this.isRound = false
        clearInterval(this.tempId)
        console.log('show')
    },
    onUnload() {
        this.openFalg = false
        this.pageSource = ''
        clearInterval(this.flashingId)
        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.LOTTERY_Z,
            p_stay_time: this.pageStayTime
        })
    }
}
</script>
<style scoped lang='less'>
// 容器
.luck {
    position: fixed;
    width: 100%;
    top: 0;
    bottom: 0;
    overflow: auto;
    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/2d05db4210b34b95b3bfa252b059a73c.png') no-repeat top center;
    background-size: 100% auto;
    padding-top: 37px;
    box-sizing: border-box;
}
// 标题
.luck-title {
    width: 320px;
    height: 135px;
    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/929d15ff5fbe4117a7e8304f4dbe1a6c.png') no-repeat center center;
    margin: 0 auto;
}
// 转盘
.prize {
    width: 312px;
    height: 312px;
    margin: 0 auto;
    position: relative;
    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191106/0ff8eb1d3a274a119288cde45c96958a.png') no-repeat center center;
    background-size: 100%;
    border-radius: 50%;
    overflow: hidden;
    .content {
        width: 81%;
        height: 81%;
        position: absolute;
        top: 9.5%;
        left: 9.5%;
        box-sizing: border-box;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/457b0a33ff58412ba3aaa12013336723.png') no-repeat center center;
        background-size: 100%;
        border-radius: 50%;
        border: 2px #fff solid;
        .item {
            width: 1px;
            height: 50%;
            position: absolute;
            left: 50%;
            transform-origin: center bottom !important;
            box-sizing: border-box;
            padding-top: 5px;
            // background-color: red;
            p {
                min-width: 90px;
                text-align: center;
                position: relative;
                font-size: 12px !important;
                color: #b04b5f;
                font-weight: 300;
                transform: translateX(-50%);
                white-space: nowrap;
            }
            img {
                display: block;
                margin-top: 2px;
                width: 45px;
                height: 45px;
                position: relative;
                transform: translateX(-50%);
            }
            // &:nth-child(1) img {
            //     // width: 30px;
            //     // height: 30px;
            // }
        }
    }

    // 按钮
    // .btn {
    //     width: 101px;
    //     height: 128px;
    //     position: absolute;
    //     top: 47%;
    //     left: 50%;
    //     transform: translate(-50%, -50%);
    //     background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/7db1535e67cc45129f64d8feeac2eef2.png') no-repeat center center;
    //     background-size: 100% 100%;
    // }
    .btn {
        width: 101px;
        height: 128px;
        height: 101px;
        position: absolute;
        top: 46%;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/7db1535e67cc45129f64d8feeac2eef2.png') no-repeat center center;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191116/5e6ad588659a49828ff1f27850f85a8f.png') no-repeat center center;
        background-size: 100% 100%;
        .pointer {
            position: absolute;
            width: 20px;
            height: 31px;
            left: 50%;
            transform: translate(-50%, -99%);
            background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191116/aa2eb29e07c242e49bfcac870d5d5ef3.png') no-repeat center center;
            background-size: 100% 100%;
        }
    }
}

//转盘外圈煽动
.flashing {
    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191106/8c1c31844a3d4a6aaa46cd3a3c4a2482.png') no-repeat center center;
    background-size: 100%;
}
// 转盘底座
.rotarybase {
    width: 245px;
    height: 81px;
    margin: -2.5px auto 0;
    background-color: #fff;
    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191106/20bd7583b548437d8a67d8e0e06a8c87.png') no-repeat center center;
    background-size: 100% 100%;
    padding-top: 45px;
    box-sizing: border-box;
    color: #fff;
    font-size: 14px;
    text-align: center;
}
//  规则
.rules {
    height: 262px;
    margin: 27px 16px;
    padding: 19px 17px 25px;
    background: rgba(225, 118, 141, 1);
    border-radius: 11px;
    opacity: 0.7929;
    overflow: auto;
    h3 {
        font-size: 20px;
        font-weight: 600;
        color: rgba(255, 255, 255, 1);
        line-height: 28px;
        text-align: center;
        padding-bottom: 6px;
    }
    li {
        padding-top: 10px;
        font-size: 13px;
        font-weight: 300;
        color: rgba(255, 255, 255, 1);
        line-height: 18px;
    }
} 
// logo
.logo {
    // width: 104px;
    // height: 122px;
    // margin: 0 auto;
    // background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/d4f2e8427766489f883049a0885dd435.png') no-repeat center center;
    height: 250rpx;
    background: url('https://aimall-jz.oss-cn-shenzhen.aliyuncs.com/as/WechatIMG1220.png') no-repeat center center/30%;
    // background-size: 104px 44px;
}
//抽奖失败模态框
.cant-draw {
    position: fixed;
    z-index: 999;
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 100;
    .main {
        width: 302px;
        height: 279px;
        box-sizing: border-box;
        padding: 28px 0 25px;
        background-color: #fff;
        margin: 30% auto;
        text-align: center;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191030/d9482f7dd6ca4ce08ec702126c052d52.png') no-repeat center center;
        background-size: 100%;
        .img {
            display: block;
            margin: 0 auto;
            width: 82px;
            height: 82px;
            background-color: #f45870;
            border-radius: 50%;
            text-align: center;
            padding-top: 21px;
            box-sizing: border-box;
            span {
                font-size: 20px;
                color: #fff;
                line-height: 20px;
            }
        }
        p {
            max-width: 90%;
            margin: 0 auto;
            font-size: 17px;
            color: #f45870;
            padding-top: 25px;
        }
        .footer-btn {
            height: 45px;
            padding-top: 25px;
            display: flex;
            button {
                width: 123px;
                height: 45px;
                background-image: linear-gradient(#f87191, #e04164);
                border-radius: 23px;
                font-size: 16px;
                line-height: 44px;
                color: #fff;
                justify-content: space-between;
            }
            .back {
                line-height: 44px;
                color: #e04164;
                background-image: linear-gradient(#fff, #fff);
                border: 1px solid #e04164;
            }
        }
    }
}
//抽奖提示框
.tipPage {
    position: relative;
    .close {
        bottom: -110px;
        width: 100%;
        position: absolute;
        .line {
            width: 1.5px;
            height: 30px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.4);
        }
        img {
            width: 50px;
            height: 50px;
            margin: 0 auto;
        }
    }
}
// 登录
.login {
    width: 100%;
    height: 200px;
    position: fixed;
    bottom: 0px;
}
</style>
