<template>
    <div class="orderDetail">
        <!-- 收货人信息 -->
         <div class="order-info" v-if="orderDistribute.distributeWay==2&&(orderDistribute.distributeStatus=='2'||orderDistribute.distributeStatus=='3')">
            <p class="color3">
                <span>{{orderDistribute.consigneeName?orderDistribute.consigneeName:''}}</span>
                <span>{{orderDistribute.consigneeMobile?orderDistribute.consigneeMobile:''}}</span>
            </p>
            <p class="grey">{{orderDistribute.consigneeAddress?orderDistribute.consigneeAddress:''}}</p>
        </div>
        <div class="freightBox">
            <product-info :product="orderGoods"></product-info>
        </div>
         <!-- 自提订单 -->
        <div class="qrCodeBox" v-if="isShow">
            <div>
                <!-- <img src="../../static/images/add-icon.png" alt=""> -->
               <div class="card-qrcode-wrap">
                    <div class="card-qrcode">
                        <qrcode-comp
                            :data="qrCode"
                            width="174"
                            height="174"
                        />
                    </div>
                </div>
                <div class="grey chargeOffCodeBox" >
                    核销码：{{orderGoods.goodsExtract?orderGoods.goodsExtract.extractCode:''}}
                </div>
            </div>

        </div>
        <div class="freightStatusBox" v-if="isShow">
            <span class="left">有效期：</span>
            <span class="right">{{orderGoods.goodsExtract?orderGoods.goodsExtract.deadlineTime:''}}</span>
        </div>
        <div class="freightBox" v-if="isShow">
            <div v-if="orderGoods.goodsType==1">
                <span class="left">自提地点：</span>
                <div class="right">{{orderGoods.goodsExtract?orderGoods.goodsExtract.extractAddress:''}}</div>
            </div>
            <div>
                <span>
                    <div class="left">营业时间：</div>
                    <div class="right">{{orderGoods.goodsExtract?orderGoods.goodsExtract.businessTime:''}}</div>
                </span>
            </div>
        </div>
        <div class="freightStatusBox">
            <span class="left">状态</span>
            <span class="right"
                :class="{'orange':orderDistribute.distributeStatus=='1',
                'red':orderDetail.orderStauts=='N'&&orderDistribute.orderPay&&orderDistribute.orderPay.resultCode=='F',
                'green':orderDistribute.distributeStatus=='2'||orderDistribute.distributeStatus=='4',
                'grey':orderDistribute.distributeStatus=='3'||orderDistribute.distributeStatus=='5'||orderDetail.orderStatus=='R'
                }"
                >
                    <span v-if="orderDetail.orderStatus=='N'&&orderDetail.orderPay&&orderDetail.orderPay.resultCode=='F'" >待支付</span>
                    <span v-else-if="orderDetail.orderStatus=='R'">已退款</span>
                    <span v-else-if="orderDistribute.distributeStatus=='4'">到店自提</span>
                    <span v-else>{{orderDistribute.distributeStatusDesc}}</span>

                    <!-- <span v-if="orderDetail.orderStatus=='N'">{{orderDetail.orderStatusDesc}}</span>
                    <span v-else>{{orderDistribute.distributeStatusDesc?orderDistribute.distributeStatusDesc:''}}</span> -->
                </span>
        </div>
        <div class="freightBox">
            <div v-if="orderDistribute.distributeWay==2&&orderDetail.orderStatus=='P'">
                <span class="left">运费</span>
                <span class="right">{{orderDetail.freightFee=='null'?'':'￥'+orderDetail.freightFeeDesc}}</span>
            </div>
             <div class="none">
                <span class="left">实付</span>
                <span class="right">
                    <span v-if="orderGoods.buyWay ===1">{{orderDetail.useIntegral!='null'?orderDetail.useIntegral:''}}积分</span>
                    <span v-if="orderGoods.buyWay ===2">¥{{orderDetail.payPrice!='null'?orderDetail.payPriceDesc:''}}</span>
                    <span v-if="orderGoods.buyWay ===3">{{orderDetail.useIntegral!='null'?orderDetail.useIntegral:''}}积分 + ¥{{orderDetail.payPrice?orderDetail.payPriceDesc:''}}</span>
                </span>
            </div>
        </div>
        <div class="freightStatusBox">
            <span class="left">备注</span>
            <span class="right">{{orderDetail.remark?orderDetail.remark:''}}</span>
        </div>
        <div class="freightBox Mtb110">
            <div>
                <span class="left">订单编号</span>
                <span class="green right ml40" @tap="textPaste(orderDetail.orderNoStr)" v-if="orderDistribute.distributeStatus!=2&&orderDistribute.distributeStatus!=3||orderDetail.orderStatus=='N'">复制</span>
                <span class="right">{{orderDetail.orderNoStr?orderDetail.orderNoStr:''}}</span>

            </div>
             <div v-if="orderDetail.orderStatus!='N'&&(orderDistribute.distributeStatus==2||orderDistribute.distributeStatus==3)">
                <span class="left">{{orderDistribute.expressCompany?orderDistribute.expressCompany:''}}</span>
                <span class="green right ml40" @tap="textPaste(orderDistribute.logisticsNo)">复制</span>
                <span class="right">{{orderDistribute.logisticsNo?orderDistribute.logisticsNo:''}}</span>
            </div>
            <div>
                <span class="left">支付方式</span>
                <span class="right" >
                    {{orderPay.payTypeDesc?orderPay.payTypeDesc:''}}
                </span>
            </div>
            <div class="none">
                <span class="left">下单时间</span>
                <span class="right">{{orderDetail.createTimeDesc?orderDetail.createTimeDesc:''}}</span>
            </div>
        </div>
        <div class="bottomBox"  v-if="orderDistribute.distributeStatus==2">
            <div class="plain-status btnBox">
                <span @click.stop="operateOrder">确认收货</span>
            </div>
        </div>
        <canvas style="margin-top:-340px;width: 686rpx;height: 686rpx;background:#f1f1f1;opacity:0;left:-400px"
                canvas-id="mycanvas" v-if="isShow"/>
    </div>

</template>

<script>
// import wxUtils from '@/plugins/wxUtils'Z
import ProductInfo from '@/components/confirmOrder/productInfo'
import request from '@/plugins/request'
import api from '@/plugins/api'
import QrcodeComp from '@/components/QrcodeComp'
export default {
    name: 'orderDetail',
    components:{
        QrcodeComp,
        ProductInfo
    },
    data() {
        return{
            orderDetail:{},//当前订单的详情
            orderGoods:{},
            // orderNo:this.$mp.query.orderNo,//订单号
            orderDistribute:{},//订单配送对象
            orderPay:{},
            qrCode:'',//二维码
            isShow:false

        }
    },
    mounted() {
        // this.queryOrderDetail()
    },
    onShow() {
        this.queryOrderDetail()


    },
    methods: {
         setQrCode() {
            let id = this.$root.$mp.query.orderNo;
            //let data = `{type:1,extractCode:${this.orderGoods.goodsExtract.extractCode}}`
            let data = "form=order&extractCode=" + this.orderGoods.goodsExtract.extractCode;
            if (!this.qrCode) {
                this.qrCode = data
            }
        },
        // 复制
        textPaste(copyData){
            console.log('复制',copyData)
             wx.setClipboardData({
                data: copyData,
                success: function (res) {
                    wx.getClipboardData({   // 这个api是把拿到的数据放到电脑系统中的
                    success: function (res) {
                        console.log(res.data)
                    }
                    })
                }
                })
        },
        queryOrderDetail(){
             let requestOptions = {
                path: api.queryOrderDetail,
                method: 'get',
                data: {
                    orderNo:this.$mp.query.orderNo
                }
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    if (res.data) {
                     this.orderDetail = res.data
                     this.orderGoods = res.data.orderGoods?res.data.orderGoods:{}
                     this.orderGoods.thumbnail = this.orderGoods.thumbnail?this.orderGoods.thumbnail.split(',')[0]:''
                     this.orderDistribute = res.data.orderDistribute?res.data.orderDistribute:{}
                     this.orderPay = res.data.orderPay?res.data.orderPay:{}
                     this.isShow=this.orderDetail.orderStatus=='P'&& this.orderDistribute.distributeStatus==4&&this.orderGoods.goodsExtract!=null
                     console.log('isSHow',this.isShow)
                     this.setQrCode()
                    }
                }
            })
        },
         operateOrder(){
             let orderNo = this.$mp.query.orderNo
             wx.showModal({
                title: '提示',
                content: '一旦确定收货，不能在更改',
                success (res) {
                    if (res.confirm) {
                        let params = {orderNo}
                        console.log(params)
                        let requestOptions = {
                            path: api.receiptOrder+ '?orderNo=' + orderNo,
                            method: 'post',
                            data: params,
                            hideLoading: false
                        }
                        request(requestOptions).then(res => {
                            console.log(res)
                            if(res.code==200){
                                wx.showToast({
                                    title:'订单收货成功',
                                    icon: 'success',
                                    duration: 2000
                                })
                                wx.navigateTo({
                                    url:'/pages/ordermanage/orderlist'
                                })
                            }
                        })
                    }

                }
            })
        },
    },
    onUnload(){
        this.qrCode = "";
        this.isShow = false;
    }
}
</script>

<style lang="less" scoped>
.orderDetail {
    // position: relative;
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background-color: #f7f7f7;
   >div  {
       background-color: #fff;
       padding: 30rpx 24rpx;
       box-sizing: border-box;
       font-size: 30rpx;
       margin-bottom: 24rpx;
   }
   .grey {
            color:#999;
        }
        .red {
            color: #EA0000FF;
        }
        .orange {
            color: #FF6B00;
        }
        .green {
            color:#9975F3;
        }
        .color3{
            color: #333;
        }
   .left {
        float: left;
        color: #999;
    }
    .right {
        float: right;
    }
    .Mtb110 {
        margin-bottom: 300rpx
    }
    .ml40 {
        margin-left: 40rpx;
    }
    .chargeOffCodeBox {

        text-align: center;
    }
    .order-info {
        width: 100%;
        height: 150rpx;
        span {
          margin-right: 20rpx;
        }
        p {
            line-height: 42rpx;
        }
    }
    .actives-item {
        position: relative;
            overflow: hidden;
            width: 100%;
            // margin: 24rpx 0;
            height: 246rpx;
            .actives-info {
                // margin: 32rpx 24rpx 0 24rpx;
                overflow: hidden;
                display: flex;
                .activies-img {
                    position: relative;
                    width: 176rpx;
                    height: 176rpx;
                    margin-right: 18rpx;
                    // padding: 14px;
                    // border: 1px solid #ccc;
                    border-radius: 10rpx;
                    box-sizing: border-box;
                }
                .actives-content {
                    width: 520rpx;
                    overflow: hidden;
                    .actives-title {
                        .actives-title-left {
                            width: 346rpx;
                            float: left;
                            font-size: 30rpx;
                            line-height:42rpx;
                            p {
                                display: -webkit-box;
                                -webkit-box-orient: vertical;
                                -webkit-line-clamp: 2;
                                overflow: hidden;
                            }
                        }
                        .actives-title-right {
                            float :right;
                            font-size: 30rpx;
                        }
                    }
                    .actives-des {
                        overflow: hidden;
                        .orderstate {
                            margin-top: 5px;
                            margin-right: 5px;
                            color: #9975F3;
                            line-height: 22px;
                            text-align: right;
                            font-size: 14px;
                            border-radius: 13px;
                        }
                    }
                }
            }

    }
    .freightStatusBox {
        height: 108rpx;
        line-height: 60rpx;
    }
    .freightBox {
        // height: 220rpx;
        padding: 0 24rpx;
        >div {
            line-height:110rpx;
            height:110rpx;
            border-bottom: 1px solid rgba(239,239,239,1);
        }
        .none {
            border: none;
        }
    }
    .btnBox {
        border-radius: 28rpx;
        width: 180rpx;
        height: 56rpx;
        font-size: 30rpx;
        line-height: 56rpx;
        text-align: center;
        margin: 50rpx 20rpx  ;
        float: right;
         &.actives-status {
            color: #fff;
            background: #9975F3;
        }
        &.plain-status{
            color: #9975F3;
            border: 1px solid #9975F3;
        }
    }
    .bottomBox {
        position: fixed;
        bottom: 0;
        width: 100%;
        margin-bottom: 0;
        padding: 0;
    }
    .qrCodeBox {
        height: 600rpx;
        width: 100%;
        position: relative;
        .card-qrcode-wrap{
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            top: 20px;
            margin: 20px auto;
            width: 186px;
            height: 186px;
            // margin: 24px;
            // background: #DCDCDC;
            display: inline-block;
        }
        .card-qrcode {
            display: inline-block;
            width: 174px;
            height: 174px;
            padding-top: 6px
        }
        .chargeOffCodeBox {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            bottom: 20px;
        }
    }
}
</style>
