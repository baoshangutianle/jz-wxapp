<template>
    <div id="orderList">
        <div class="orderList">
             <ul class="flex-wrp tabs">
                <li class="flex-item tab">
                    <span :class="{'active':tab==='0'}" @tap="changeTab('0')">全部</span>
                </li>
                <li class="flex-item tab">
                    <span :class="{'active':tab==='1'}" @tap="changeTab('1')">待付款</span>
                </li>
                <li class="flex-item tab">
                    <span :class="{'active':tab==='3'}" @tap="changeTab('3')">待发货</span>
                </li>
                <li class="flex-item tab">
                    <span :class="{'active':tab==='4'}" @tap="changeTab('4')">待收货</span>
                </li>
             </ul>
        </div>
        <view class="section">
            <scroll-view :scroll-y="true"
                         class="actives-list"
                         :class="{'allPage':listData.length == 0 }"
                         >
                         <!-- @bindscrolltoupper="upper"
                         @scrollToLower="onReachBottom"
                         @bindscroll="scroll"
                         @scroll-into-view="toView"
                         @scroll-top="scrollTop" -->
                <div class="actives-con">
                    <ul>
                        <li  v-for="(item,index) in listData"
                            :key="index"
                            class="my-shadow actives-item"
                            @tap="toDetails(item)"
                            >
                            <!-- <auth-btn @pass="toDetails(item)" /> -->
                            <div class="actives-info">
                                 <img :src="item.orderGoods.thumbnail" class="activies-img" />
                                <!-- 订单描述部分 -->
                                <div class="actives-content">
                                    <div class="actives-title">
                                        <div class="actives-title-left">
                                            <!-- 商品描述 -->
                                            <p>{{item.orderGoods.goodsName}}</p>
                                        </div>
                                        <span class="actives-title-right" 
                                        :class="{'orange':item.orderDistribute.distributeStatus=='1',
                                        'red':item.orderStatus=='N'&&item.orderPay&&item.orderPay.resultCode=='F',
                                        'green':item.orderDistribute.distributeStatus=='2'||item.orderDistribute.distributeStatus=='4',
                                        'grey':item.orderDistribute.distributeStatus=='3'||item.orderDistribute.distributeStatus=='5'||item.orderStatus=='R'
                                        }"
                                        >
                                            <span v-if="item.orderStatus=='N'&&item.orderPay&&item.orderPay.resultCode=='F'">待支付</span>
                                            <span v-else-if="item.orderStatus=='R'">已退款</span>
                                            <span v-else-if="item.orderDistribute.distributeStatus=='4'">到店自提</span>
                                            <span v-else>{{item.orderDistribute.distributeStatusDesc}}</span>
                                        </span>
                                    </div>
                                     <div class="actives-title">
                                        <div class="actives-title-left grey">{{item.orderGoods.shopName?item.orderGoods.shopName:''}}</div>
                                        <!-- <span class="actives-title-right grey">{{item.orderGoods.floorName?item.orderGoods.floorName:''}}</span> -->
                                    </div>
                                    <div class="actives-title">
                                        <div class="actives-title-left">
                                            <span class="grey">商品规格：</span>
                                            {{item.orderGoods.specsValue}}</div>
                                        <span class="actives-title-right grey">x{{item.orderGoods?item.orderGoods.buyCount:''}}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="orderInfo">
                                <div class="freight">
                                    <p v-if="item.orderDistribute&&item.orderDistribute.distributeWay==2&&item.orderStatus=='P'">
                                        <span class="grey">运费:</span><span>{{item.freightFee=='null'?'':'￥'+item.freightFeeDesc}}</span>
                                    </p>
                                    <p class="actual-payment">
                                        <span class="grey"> 实付:</span>
                                            <span>
                                                <span v-if="item.orderGoods.buyWay ===1">{{item.useIntegral!='null'?item.useIntegral:''}}积分</span>
                                                <span v-if="item.orderGoods.buyWay ===2">¥{{item.payPrice!='null'?item.payPriceDesc:''}}</span>
                                                <span v-if="item.orderGoods.buyWay ===3">{{item.useIntegral!='null'?item.useIntegral:''}}积分 + ¥{{item.payPrice?item.payPriceDesc:''}}</span>
                                            </span>
                                    </p>
                                </div>
                               <div class="btnOuterBox">
                                    <div class="actives-status btnBox"
                                        v-if="item.orderDistribute&&item.orderDistribute.distributeStatus=='2'"
                                        @click.stop="operateOrder(item,'receipt')">
                                        <span>确认收货</span>
                                    </div>
                                    <div class="actives-status btnBox"
                                        v-if="item.orderStatus=='N'"
                                        @click.stop="repayOrder(item)">
                                        <span>继续支付</span>
                                    </div>
                                    <div class="plain-status btnBox"
                                        v-if="item.orderStatus=='N'"
                                        @click.stop="operateOrder(item,'cancel')">
                                        <span>取消订单</span>
                                    </div>
                               </div>
                            </div>
                        </li>
                    </ul>
                    <div v-if="listData.length ==0 && requstFalg"
                         class="tipPage">
                        <block-page :type="typeText"></block-page>
                        <div class="grey">暂无订单信息</div>
                        <div class="goIntegral"
                             @click="toIntegral">
                             去在线商城看看</div>
                    </div>
                    <load-more v-if="reachFinish&&listData.length>=11" />
                    
                </div>
            </scroll-view>
        </view>
    </div>
</template>

<script>
import utils from '@/plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import moment from 'moment'
import SearchComp from '@/components/SearchComp'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import loadMore from '@/components/loadMore'
import BlankPage from '@/components/blankPage'
import BlockPage from '@/components/blockPage'
import { setTimeout } from 'timers'
import { mapState, mapMutations } from 'vuex'
import AuthBtn from '@/components/AuthBtn'
import wxUtils from '../../plugins/wxUtils'
export default {
    components: {
        SearchComp,
        loadMore,
        BlankPage,
        BlockPage,
        AuthBtn
    },
    data() {
        return {
            tab: '0',
            nopayFlag: false,
            total: 0, //全部列表总数
            nopayTotal: 0, //待付款列表总数
            pageStayTime: 0, //页面停留时间
            listData: [], // 全部列表
            NopayList: [], //待付款列表
            requstFalg: false, //接口是否调通
            activityNameLike: '',
            ipt: '搜索',
            listFrom: {
                pageNum: 1,
                pageSize: 20,
                nunpay:0,//待付款的
                waitsend:0,//待发货
                waitdelivery:0,//待收货
                memberCode: null
            },
            pageNum: 1,
            toView: 'red',
            scrollTop: 100,
            isClear: false,
            reachFinish: false,
            hasFetchData: false, //拉取数据状态
            typeText: '暂无订单',
            allDataMount:0
        }
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo'])
        
    },
    mounted() {},
    onShow() {
        if (this.vipInfo) {
            this.listFrom.memberCode = this.vipInfo.memberCode
        }
        let tabIndex = wx.getStorageSync('tabIndex')
        this.tab = tabIndex?tabIndex :'0'
        console.log(tabIndex,'tabINdex')
        this.resetRefresh()
    },
    onHide() {
        this.hidePage()
    },
    onUnload() {
        this.hidePage()
    },
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh()
        this.resetRefresh()
    },
    methods: {
        changeTab(index){
            this.tab = index
            wx.setStorage({
                key: 'tabIndex',
                data: index
            })
            this.getOrderList(index)
        },
        hidePage() {
            this.hasFetchData = false
        },
        resetRefresh() {
            //重置刷新
            this.reachFinish = false
            this.nopayFlag = false
            this.listFrom.pageNum = 1
            this.pageNum = 1
            this.requstFalg = false
            this.getOrderList(this.tab)
        },
        // 获取订单列表
        getOrderList(code){
            this.allDataMount = 0
            console.log('请求接口了',code)
            this.hasFetchData = false
            this.reachFinish = false
            let params = {
                tabCode :code
            }
            let requestOptions = {
                path: api.getOrderList,
                method: 'post',
                data: params,
                hideLoading: false
            }
            request(requestOptions).then(res => {
                console.log(res)
                if(res.code==200){
                    this.requstFalg = true
                    let list  = res.data
                    if(list){
                        console.log(list.length)
                        this.listData = list
                        if(list.length>0){
                             this.reachFinish = true
                            this.listData.forEach(item=>{
                                 item.orderDistribute=item.orderDistribute?item.orderDistribute:{}
                                 item.orderGoods=item.orderGoods?item.orderGoods:{}
                                 item.orderPay=item.orderPay?item.orderPay:{}
                                 item.orderGoods.thumbnail = item.orderGoods.thumbnail?item.orderGoods.thumbnail.split(',')[0]:''
                                 console.log(item.orderGoods.thumbnail.split(',')[0])
                                 this.allDataMount  +=Number(item.orderGoods.buyCount?item.orderGoods.buyCount:0)
                             })
                             console.log(this.listData,this.allDataMount)
                        }
                    }
                }

            })
        },
        // 跳转至详情页
        toDetails(item) {
            console.log('详情',item)
            wx.navigateTo({
                url: `/pages/ordermanage/orderdetail?orderNo=${item.orderNoStr}`
            })
        },
        repayOrder(item){
            let _this = this
            wx.login({
                success(res) {
                    console.log(res.code)
                     let miniAppletTempAuthCode = res.code    
                        let params = {orderNo:item.orderNoStr,miniAppletTempAuthCode}
                        console.log(params)
                        let requestOptions = {
                            path: api.repayOrder,
                            method: 'post',
                            data: params,
                            hideLoading: false
                        }
                        request(requestOptions).then(res => {
                            console.log(res)
                            if(res.code==200){
                                let payargs = res.data
                                wx.requestPayment({
                                    timeStamp: payargs.timeStamp,
                                    nonceStr: payargs.nonceStr,
                                    package: payargs.dataPackage,
                                    signType: payargs.signType,
                                    paySign: payargs.paySign
                                })
                                _this.getOrderList(_this.tab)
                            }
                        })
                }
            })
        },
        operateOrder(item,type){
            console.log(this.tab)
            console.log(item,type)
            let _this = this
                      wx.showModal({
                        title: '提示',
                        content: type=='receipt'?'请确认是否已经收到商品，继续确认收货？':'订单取消后不可恢复，确认取消订单？',
                        success (res) {
                            if (res.confirm) {
                                let params = {orderNo:item.orderNoStr}
                                console.log(params)
                                let requestOptions = {
                                    path: type=='receipt'?api.receiptOrder+ '?orderNo=' + item.orderNoStr:api.cancelOrder+ '?orderNo=' + item.orderNoStr,
                                    method: 'post',
                                    data: params,
                                    hideLoading: false
                                }
                                request(requestOptions).then(res => {
                                    console.log(res,res.code,type,res.code==200,this,_this)
                                    if(res.code==200){
                                        _this.getOrderList(_this.tab)
                                        wx.showToast({
                                            title: type=='receipt'?'订单收货成功':'取消订单成功',
                                            icon: 'success',
                                            duration: 2000
                                        })
                                        console.log('取消订单')
                                    }
                                    
                                    
                                })
                            } 
                           
                        }
                    })
            
        },
        //兑换记录
        toIntegral() {
            wx.switchTab({
                url: `/pages/integralMall/index`
            })
        }
    },
    // 触底加载更多
    onReachBottom() {
        // if(this.listData.length == 0 && this.NopayList.length == 0){
        //      return
        // }
        // if (this.listFrom.pageNum * this.listFrom.pageSize > this.total && this.pageNum * this.listFrom.pageSize > this.nopayTotal) {
        //     if(this.listData.length == 0 && !this.nopayFlag){
        //        return
        //     }
        //     this.reachFinish = true
        // } else {
        //     this.listFrom.pageNum++
        //     if (this.pageNum * this.listFrom.pageSize <= this.nopayTotal) {
        //         this.pageNum++
        //         this.getNopayRecordList()
        //     }
        //     this.getRecordList()
        // }
    }
}
</script>

<style lang="less">
@import '../../assets/styles/vars';
Page {
    background-color: #f4f4f4;
}
#orderList {
    background-color: #f4f4f4;
    .orderList{
        position: relative;
        height: 106rpx;
    }
    .tabs {
        z-index: 99;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: #fff;
        border-bottom: 1px solid #ddd;
        font-size: 30rpx;
    }
    .my-shadow{
        box-shadow:none;
    }
    .actives-con {
        // margin: 24rpx 0 ;
        .grey {
            color:#999;
        }
        .red {
            color: #EA0000FF;
        }
        .orange {
            color: #FF6B00;
        }
        .green {
            color:#9975F3;
        }
        .actives-item {
            overflow: hidden;
            width: 100%;
            padding-bottom: 0;
            background: #ffffff;
            margin: 24rpx 0;
            // height: 434rpx;
            .actives-info {
                margin: 32rpx 24rpx 0 24rpx;
                overflow: hidden;
                display: flex;
                .activies-img {
                    position: relative;
                    width: 176rpx;
                    height: 176rpx;
                    margin-right: 18rpx;
                    // padding: 14px;
                    // border: 1px solid #ccc;
                    border-radius: 10rpx;
                    box-sizing: border-box;
                }
                .actives-content {
                    width: 520rpx;
                    overflow: hidden;
                    .actives-title {
                        .actives-title-left {
                            width: 346rpx;
                            float: left;
                            font-size: 30rpx;
                            line-height:42rpx;
                            p {
                                display: -webkit-box;
                                -webkit-box-orient: vertical;
                                -webkit-line-clamp: 2;
                                overflow: hidden; 
                            }
                        }
                        .actives-title-right {
                            float :right;
                            font-size: 30rpx;
                        }
                    }
                    .actives-des {
                        overflow: hidden;
                        .orderstate {
                            margin-top: 5px;
                            margin-right: 5px;
                            color: #9975F3;
                            line-height: 22px;
                            text-align: right;
                            font-size: 14px;
                            border-radius: 13px;
                        }
                    }
                }
            }
            .orderInfo {
              width: 100%;
              box-sizing: border-box;
              font-size: 30rpx;
              padding: 24rpx;
              .freight {
                  float: left;
                  width: 100%;
                  height: 110rpx;
              }
              .btnOuterBox {
                .btnBox {
                    border-radius: 28rpx;
                    float: right;
                    width: 180rpx;
                    height: 56rpx;
                    font-size: 30rpx;
                    line-height: 56rpx;
                    text-align: center;
                    margin-bottom: 30rpx;
                    // margin: 102rpx 0 20rpx 0 ;
                        &.actives-status {
                        margin-left: 24rpx; 
                        color: #fff;
                        background: #9975F3;
                    }
                    &.plain-status{
                        margin-left: 24rpx; 
                        color: #9975F3;
                        border: 1px solid #9975F3;
                    }
                }

              }
             
            }
        }
    }
}
.tipPage {
    text-align: center;
    height: 95vh;
    width: 100%;
    background: #ffffff;
    position: relative;
    .blockPage{height:auto!important;}
}
.goIntegral {
    color: #9975F3;
    text-decoration: underline;
    text-align: center;
    margin-top: 15px;
    width: 100%;
}
.allPage {
    background: #ffffff !important;
}
</style>
