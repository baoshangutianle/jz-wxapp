<template>
    <div class="banner-container">
        <web-view :src="url"></web-view>
    </div>
</template>

<script>
export default {
    data() {
        return {
            url: ''
        }
    },
    onLoad(options){
        if(options.url){
            this.url = options.url
        }else{
            wx.navigateBack({delta: 2})
        }
        if(options.title){
            wx.setNavigationBarTitle({
                title: options.title
            })
        }
    }
}
</script>

<style lang="less">
@import "../../assets/styles/common";
.banner-container {

}
</style>
