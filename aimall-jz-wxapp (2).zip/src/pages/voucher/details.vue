<template>
    <div id="stockPurchaseDetails">
        <div class="actives-deail">
            <img 
                class="activies-img"
                src="/static/images/mine_background.png"
            >
            <p class="actives-title">爱家庭 | 乐友奶粉节放“价”开启，大牌精选，省心而来！</p>
            <div class="actives-oper">
                <span class="actives-aut">南海嘉洲广场</span>
                <div class="actives-todo">
                    <span class="active-icon" />
                    <span class="active-icon" />
                </div>
            </div>
            <div class="actives-con">
                <p>
                    三亚龙湾朋博乐青奢宿设计美宿位于亚龙湾旅游度假区的魅力乡村博士存，距离亚龙湾海边八分钟
                    车程，距离热带天堂公园五分钟车程；
                </p>
                <p>
                    新派中式禅意庭院、恒温泳池、私家园林，邀月餐厅给您更加私密轻松惬意的度假环境；
                </p>
                <p>
                    客房内双层隔音玻璃，科勒卫浴，高端品牌洗浴用品，纯棉贡缎床品，乳胶床垫给您带来亲肤体验及
                    美好的睡眠环境；朋博乐特有主人文化的前台接待为您提供更具温馨的入住服务。
                </p>
            </div>
        </div>
        
    </div>
</template>

<script>
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'

export default {
    data() {
        return {
           
        }
    },
    // onLoad(options) {
    //     this.status = options.status
    //     this.promotionShopId = Number(options.promotionShopId)
    //     this.promotionShow(options.id, options.type)
    // },
    methods: {
        promotionShow(id, type) {
            let shopNo = wx.getStorageSync('accountInfo').shopVo.shopCode
            let requestOptions = {
                path: api.promotionShow,
                method: 'post',
                data: {
                    promotionId: id,
                    promotionType: type,
                    shopNo: shopNo
                }
            }
            request(requestOptions).then(res => {
                this.promotionShowResponse = res.data
            })
        }
       
    }
}
</script>

<style lang="less">
#stockPurchaseDetails {
    padding-top: 10px;
    padding-bottom: 85px;
    background: #ffffff;
    .actives-deail{
        padding: 13px;
    }
    .activies-img{
        width: 100%;
        height: 194px;
        border-radius: 4px;
    }
    .actives-title{
        font-size: 20px;
        color: #333333;
        padding-top: 3px;
    }
    .actives-oper{
        font-size: 15px;
        color: #999999;
        padding-top: 5px;
        width: 100%;
    }
    .actives-aut{
        display: inline-block;
    }
    .actives-todo{
        float: right;
    }
    .active-icon{
        width: 16px;
        height: 16px;
        display: inline-block;
        border: solid 1px #9975F3;
        margin-left: 15px;
        vertical-align: middle;
    }
    .actives-con{
        padding-top: 10px;
        font-size: 15px;
        color: #333333;
    }
}
</style>
