<template>
    <div id="voucherList">
        <view class="section">
            <scroll-view
                scroll-y
                class="voucher-list"
                @bindscrolltoupper="upper"
                @bindscrolltolower="lower"
                @bindscroll="scroll"
                @scroll-into-view="toView"
                @scroll-top="scrollTop"
            >
                <div class="search-btn">
                    <input
                        class="search-input"
                        type="text"
                        placeholder="搜索">
                </div>
                <div class="voucher-con">
                    <div class="voucher-select">
                        <ul>
                            <li>
                                <span>智能排序</span>
                                <span>|</span>
                            </li>
                            <li>
                                <span>全部分类</span>
                                <span>、</span>
                            </li>
                            <li>
                                <span>筛选</span>
                                <span>|</span>
                            </li>
                        </ul>
                    </div>
                    <div class="voucher-ul">
                        <ul>
                            <li>
                                <navigator url="/pages/voucher/details" hover-class="navigator-hover">
                                    <div class="voucher-left">
                                        <img
                                            class="activies-img"
                                            src="/static/images/mine_background.png"
                                        >

                                    </div>
                                    <div class="voucher-r">
                                        <p class="voucher-money">800元</p>
                                        <p class="voucher-remark">
                                            满6800元可减800元
                                        </p>
                                        <p class="voucher-type">Adidas抵扣券</p>
                                        <p class="voucher-time">有效期：2019-07-01至2017-10-01</p>
                                    </div>
                                </navigator>
                            </li>
                        </ul>
                    </div>
                </div>
            </scroll-view>
        </view>
    </div>
</template>

<script>
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import { debuglog } from 'util';

export default {
    data() {
        return {
            loaderMore: true,
            getPromtionPageRequest: {
                pageNum: 1,
                pageSize: 20,
                shopNo: '',
                shopRole: ''
            },
            promtionPage: [],
            order: ['red', 'yellow', 'blue', 'green', 'red'],
            toView: 'red',
            scrollTop: 100
        }
    },
    onShow() {
        this.loaderMore = true
        //this.getPromtionPageRequest.pageNum = 1
        this.promtionPage = []
        //this.getPromtionPage(0)
        this.getCardsList();
    },
    methods: {
        upper(e) {
            console.log(e)
        },
        lower(e) {
            console.log(e)
        },
        scroll(e) {
            console.log(e)
        },
        tap(e) {
            for (var i = 0; i < this.order.length; ++i) {
                if (this.order[i] === this.toView) {
                    this.toView = this.order[i + 1]
                    break
                }
            }
        },
        tapMove(e) {
            this.scrollTop = this.scrollTop + 10
        },
        getCardsList(){
            let params = {
                path: api.getCards
            }
            request(params).then( res => {
                console.log()
            }).catch( err => {
                console.log(err)
            })
        },
        getPromtionPage(times) {
            this.getPromtionPageRequest.shopNo = wx.getStorageSync('accountInfo').shopVo.shopCode
            this.getPromtionPageRequest.shopRole = wx.getStorageSync('accountInfo').shopVo.roleName
            let requestOptions = {
                path: api.getPromtionPage,
                method: 'post',
                data: this.getPromtionPageRequest
            }
            request(requestOptions).then(res => {
                if (res.data.list.length == 0) {
                    this.loaderMore = false
                    return
                }
                if (res.data.list.length < 20) this.loaderMore = false
                let list = res.data.list
                if (times == 1) {
                    this.promtionPage = this.promtionPage.concat(list)
                } else {
                    this.promtionPage = list
                }
            })
        },
        toDetails(id, type, promotionShopId, status) {
            // wx.navigateTo({
            //     url: `/pages/listOfActivities/details?id=${id}&type=${type}&promotionShopId=${promotionShopId}&status=${status}`
            // })
            wx.navigateTo({
                url: `/listOfActivities/details`
            })
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        this.loaderMore = true
        //this.getPromtionPageRequest.pageNum = 1
        //this.getPromtionPage(0)
        wx.stopPullDownRefresh()
    },
    // 页面滚动到底部
    onReachBottom() {
        if (this.loaderMore) {
            //this.getPromtionPageRequest.pageNum++
            //this.getPromtionPage(1)
        }
    }
}
</script>

<style lang="less">
#voucherList {
    min-height: 100vh;
    background-color: #f2f2f2;
    .voucher-list{
        min-height: 100vh;
        background: #FFFFFF;
    }
    .search-btn {
        height: 44px;
        background: #eff1f8;
        text-align: center;
        padding: 0 15px;
    }
    .search-input {
        width: 100%;
        height: 28px;
        background: #ffffff;
        display: inline-block;
        border-radius: 10px;
        margin-top: 7px;
        font-size: 13px;
    }
    .voucher-con{
        padding: 15px;
    }
    .voucher-select{
        width: 100%;

        overflow: hidden;
        ul li{
            float: left;
            width: 33%;
            text-align: center;
            font-size: 12px;
        }
    }
    .voucher-ul ul li{
        width: 100%;
        height: 90px;
        overflow: hidden;
    }
    .voucher-left{
        background: #ffffff;
        border-radius: 4px;
        padding: 10px;
        float: left;
        box-shadow:0px 0px 5px 0px rgba(188,188,188,0.5);
        img{
            width: 70px;
            height: 70px;
        }
    }
    .voucher-r{
        padding-left: 10px;
        display: inline-block;
        border-radius: 4px;
        background: #ffffff;
        box-shadow:0px 0px 5px 0px rgba(188,188,188,0.5);
        .voucher-money{
            font-size: 18px;
            color: #333333;
            padding-top: 6px;
        }
        .voucher-remark,.voucher-type{
            font-size: 12px;
            color: #333333;
        }
        .voucher-time{
            font-size: 10px;
            color: #333333;
        }
    }
}

</style>
