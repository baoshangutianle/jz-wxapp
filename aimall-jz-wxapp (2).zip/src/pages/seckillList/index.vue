<template>
<view class="seckill">
  <view class="header">
    <view class="label">本场还剩</view><count-down :timer='timer' :colorFul='false' v-if="timer"/>
  </view>
  <view class="list">
    <scroll-view scroll-x class="scroll-x">
      <div v-for="(item,idx) in timeList" :key="idx" class="view_item" @click="tabClick(item,idx)">
        <div class="time" :class="{time_active:idx==activeIndex}">{{item.startTime}}</div>
        <div class="text" :class="{text_active:idx==activeIndex}">{{item.status == 0 ? '即将开始' : item.status == 1 ? '正在抢购' : '已结束'}}</div>
      </div>
    </scroll-view>
    <div class="goodsList">
      <div class="goods" v-for="(item,idx) in goodsList" :key='idx'>
        <image :src="item.thumbnail " class="image"  />
        <div class="intrdu">
          <div class="title">{{item.goodsName}}</div>
          <div class="speed">
            <div class="outProg">
              <div class="innerProg" :style="{width:((item.buyCount/item.seckillNum)*88/100)+'px'}"></div>
            </div>
            <div class="percent">{{ item.buyCount/item.seckillNum }}%</div>
            <div class="salesOut">已抢{{item.buyCount}}件</div>
          </div>
          <div class="priceBuy">
            <div class="price">
              <div class="orig"><span class="icon">￥</span>{{item.seckillPrice }}</div>
              <div class="pres">原价:￥{{item.goodsPrice }}</div>
            </div>
            <div class="btnSold" @click="toBuy(item)">去抢购</div>
          </div>
        </div>
      </div>
    </div>
  </view>
</view>
</template>
<script>
import api from '@/plugins/api'
import request from '@/plugins/request'
import countDown from '@/components/countDown'
import utils from '../../plugins/utils'
export default {
    data() {
      return {
        activeIndex: 0,
        timeList: [
        ],
        goodsList: [
        ],
        timer: 0
      }
    },
    components: {
      countDown
    },
    onLoad () {
      this.timer = 0;
      this.queryEffective()
    },
    methods: {
      tabClick(item,idx) {
        this.activeIndex = idx
        this.queryEffectiveGoods(item.id)
      },
      toBuy (item) {
        wx.navigateTo({
            url: `/pages/goodsDetails/index?roundId=${item.roundId}&goodsId=${item.goodsId}`
        })
      },
      queryEffective () {
            let position = { path: api.queryEffective, hideLoading: true }
            request(position).then(res => {
                if (res.code == 200 && res.data && res.data.length) {
                    let start = res.data[0].startTime
                    let end = res.data[0].endTime
                    this.timer = (new Date(end).getTime() - new Date(start).getTime()) / 1000;
                    this.timeList = res.data;
                    res.data.forEach((item,idx)=>{
                      item.startTime = utils.transTime(item.startTime)
                    })
                    this.queryEffectiveGoods(res.data[0].id) 
                }
            })
        },
        queryEffectiveGoods (id) {
            let position = { 
                path: api.queryEffectiveGoods, 
                hideLoading: true, 
                data: {
                    roundId: id
                } 
            }
            request(position).then(res => {
                if (res.code == 200 && res.data && res.data.length) {
                    res.data.forEach((v,idx)=>{
                        v.goodsPrice = (v.goodsPrice/100).toFixed(2)
                        v.seckillPrice = (v.seckillPrice/100).toFixed(2)
                    })
                    this.goodsList = res.data;
                    
                } else {
                    this.goodsList = [];
                }
            })
        },
    }
}
</script>
<style lang="less">
@import '../../assets/styles/vars';
.seckill {
  .header {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 40px;
    background:linear-gradient(147deg,rgba(179,116,248,1) 0%,rgba(136,98,238,1) 100%);
    color:rgba(255,255,255,1);
    .label {
      font-size:13px;
      font-weight:400;
      letter-spacing: 1px;
      
    }
    
  }
  .list {
    background-color: #F7F7F7;
    height: calc(100vh - 40px);
  }
  .time {
    font-size:15px;
    font-family:PingFangSC-Semibold,PingFang SC;
    font-weight:600;
    line-height:21px;
    color: #999999;
    margin-bottom: 4px;
  }
  .text {
    display: flex;
    align-items: center;
    justify-content: center;
    letter-spacing: 1px;
    font-size:12px;
    font-family:PingFangSC-Light,PingFang SC;
    font-weight:300;
    color: #999999;
  }
  .time_active {
    color:rgba(153,117,243,1);
  }
  .text_active {
    width:68px;
    height:20px;
    border-radius:12px;
    background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
    color:rgba(255,255,255,1);
  }
  .goodsList {
    padding: 0 12px;
    .goods {
      padding:12px;
      margin: 12px 0;
      display: flex;
      justify-content: space-around;
      align-items: center;
      background:rgba(255,255,255,1);
      border-radius:6px;
      .image {
        width:120px;
        height:114px;
        margin-right: 18px;
      }
      .intrdu {
        flex: 1
      }
      .title {
        font-size:15px;
        font-family:PingFangSC-Regular,PingFang SC;
        font-weight:400;
        color:rgba(51,51,51,1);
        word-break: break-all;
        text-overflow: ellipsis;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        display: -webkit-box;
        overflow: hidden;
      }
      .speed {
        display: flex;
        align-items: center;
        // justify-content: space-between;
        margin: 7px 0 16px 0;
        .outProg {
          width:80px;
          height:10px;
          background:rgba(217,217,217,1);
          border-radius:5px;
          .innerProg {
            // width:70px;
            height:10px;
            background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
            border-radius:5px;
          }
        }
        .percent {
          font-size:12px;
          font-family:PingFangSC-Regular,PingFang SC;
          font-weight:400;
          color:rgba(153,153,153,1);
          margin:0 12px 0 7px
        }
        .salesOut {
          font-size:12px;
          font-family:PingFangSC-Regular,PingFang SC;
          font-weight:400;
          color:rgba(153,153,153,1);
        }
      }
      .priceBuy {
        display: flex;
        align-items: center;
        justify-content: space-between;
        .price {
          .orig {
            font-size:18px;
            font-family:PingFangSC-Medium,PingFang SC;
            font-weight:500;
            color:rgba(234,82,5,1);
            .icon {
              font-size: 10px;
            }
          }
          .pres {
            font-size:12px;
            font-family:PingFangSC-Light,PingFang SC;
            font-weight:300;
            color:rgba(153,153,153,1);
            text-decoration: line-through;
          }
        }
        .btnSold {
          display: flex;
          justify-content: center;
          align-items: center;
          width:72px;
          height:28px;
          background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
          border-radius:15px;
          font-size:15px;
          font-family:PingFangSC-Regular,PingFang SC;
          font-weight:400;
          color:rgba(255,255,255,1);
        }
      }
    }

  }
}

.scroll-x{
    white-space:nowrap;
    display:flex;
    background: #f7f7f7;
}
 
.view_item{
    display:inline-block;
    padding:12px 50rpx;
}
 
.view_item_time{
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:15px;
    color:#9975F3;
}
 
.view_item_hint{
    width:68px;
    height:20px;
    background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:12px;
    color:#FFFFFF;
}
 
/* 隐藏scrollbar */
::-webkit-scrollbar{
    width: 0;
    height: 0;
    color: transparent;
}
</style>