<template>
    <div id="game_shapon">
        <div class="game_shapon_content">
            <div class="game_cover"></div>
        </div>
        <div class="luck-title">
               <image
                    src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191206/3c472765de5a436eab28d494096c32dd.png"
                />
        </div>
        <div class="game-btn" v-if="!vipInfo">
            <image
               src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191206/f5648cf9837842309b6328432a997e1d.png"/>
            <auth-btn auth="user" @pass="onGotUserInfo" v-if="!isAuth && !vipInfo" />
            <auth-btn auth="phone" v-if="isAuth && !vipInfo" />
        </div>
        <div class="game-btn" v-if="vipInfo" @click="startDraw">
                <image
                  src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191206/f5648cf9837842309b6328432a997e1d.png"/>
        </div>
        <p class="rules">-{{costIntegral}} 积分抽奖</p>
        <div class="logo">
                  <image
                   src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191206/3cba2257e9ae4a628e80e6b36053ede8.png"/>
        </div>

        <!-- 中奖/未中奖弹出框 -->
        <div class="gash_prize" v-if="prizeLayer">
            <div class="record_close" @click="closeLayer('prize')">
                <image
                    src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191209/cc0ea015e52c4ccaa536f93b0d4493e6.png"
                />
            </div>
            <div class="gash_prize_con">
                <div class="gash_prize_top">
                    <p class="gash_prize_title" v-if="drawn">恭喜您抽中</p>
                    <p class="gash_prize_title" v-if="!drawn">送你个小心心</p>
                    <image
                        class="gash_prize_img"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/b9b75c75d53240f388d1d8ab9e450f01.png"
                    />
                    <div class="gash_prize_goods">
                        <image v-if="drawn" :src="prizeImageUrl" />
                        <image
                            v-else
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png"
                        />
                    </div>
                    <div class="gash_prize_name">
                        <p class="prize_name" v-if="drawn">{{prizeName}}</p>
                        <p class="prize_name2" v-if="drawn">
                            可在
                            <span class="prize_span">我的卡包</span>查看
                        </p>
                        <p class="prize_name" v-if="!drawn">好可惜，没抽中</p>
                        <p class="prize_name2" v-if="!drawn">{{errMsg}}</p>
                    </div>
                </div>
                <div class="gash_prize_bottom">
                    <image
                        class="layer_bottom_bg"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191126/e2a7d4f3e3434850b8dbd3fedec6ad0e.png"
                    />
                    <span class="layer_go" v-if="!drawn"  @click="goView(0)">去首页看看</span>
                    <span class="layer_go" v-if="drawn"  @click="goView(1)">去卡包查看</span>
                </div>
            </div>
        </div>
        <!-- 抽奖提示模态框 -->
        <div class="shapon_layer" v-if="layer">
            <div class="gash_prize_close" v-if="noInterg !== 4" @click="closeLayer('layer')">
                <image
                    src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191209/cc0ea015e52c4ccaa536f93b0d4493e6.png"
                />
            </div>
            <div class="shapon_layer_con">
                <div class="shapon_layer_top">
                    <div class="layer_interg">
                        <image
                            v-if="noInterg === 2"
                            class="layer_interg_img"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191209/f959fc5ac1e94131a5944444bd3e13b6.png"
                        />
                        <image
                            v-if="noInterg === 3  || noInterg === 0"
                            class="layer_interg_img"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/f98375f440d844eabe852574e3e14b38.png"
                        />
                        <image
                            v-if="noInterg === 4"
                            class="layer_interg_img"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191202/1c4d43c5079f48db9778abbfed69a525.png"
                        />

                        <div class="layer_interg_div" v-if="noInterg === 2">
                            <p class="layer_interg_text">{{costIntegral}}</p>
                            <p class="layer_interg_text">积分</p>
                        </div>
                    </div>
                    <div class="shap_interg">
                        <div class="shap_interg_con">
                            <!-- 积分抽奖 -->
                            <p class="layer_shap_remark" v-if="noInterg==2">
                                使用 {{costIntegral}} 积分抽奖一次
                                <br />未完成抽奖积分不退还
                            </p>
                            <!-- 不能抽奖 -->
                            <p class="layer_shap_remark" v-if="noInterg==3">
                                {{msg}}
                            </p>
                            <!-- 大屏开始游戏 -->
                            <p class="layer_shap_remark" v-if="noInterg === 4">
                                请关注大屏
                                <br />游戏已经开始哦！
                            </p>
                            <!-- 二维码已过期 -->
                            <p class="layer_shap_remark" v-if="noInterg === 0">
                                二维码已过期
                                <br />请至屏幕前重新扫码
                            </p>
                        </div>
                    </div>
                </div>
                <div class="shapon_layer_bottom" v-if="noInterg !== 4">
                    <span class="layer_shap" v-if="noInterg === 2" @click="startPrize">立即抽奖</span>
                    <span class="layer_shap" v-if="noInterg === 3" @click="closeLayer('code')">知道了</span>
                    <span class="layer_shap" v-if="noInterg === 0" @click="scanAgain">知道了</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import utils from '@/plugins/utils'
import wxUtils from '@/plugins/wxUtils'
import request from '@/plugins/request'
import api from '@/plugins/api'
import AuthBtn from '@/components/AuthBtn'
import { mapState, mapMutations } from 'vuex'
import bigScreenGame from '@/plugins/bigScreenGame'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
export default {
    components: {
        AuthBtn
    },
    data() {
        return {
            activityName: '', //活动名称
            isCanClick: false,
            activityId: null,
            prizeList: [],
            isCloseDialog: false, //是否关闭中奖结果弹框
            isAuth: null,
            // 是否可以抽奖
            isShowDraw: false, // 是否显示
            prizeStatus: 0, // 抽奖状态
            msg: ``, //提示消息
            // 抽奖结果模态框数据
            openFalg: false, // 是否显示
            costIntegral: 300, //消耗积分
            lotteryStatus: false, // 是否中奖
            lotteryName: '', // 中奖商品名称
            lotteryImg: '', // 中奖商品图片src
            setIntervalStatus: null,
            status: null, //此轮游戏状态
            pageStayTime: 0,
            dialogStayTime: 0,
            layer: false,
            prizeImageUrl: '',
            p_action:'扭蛋游戏',
            // intergNum: 300,
            noInterg: 2,
            bigScreen: true,
            drawn: false, //是否中奖
            prizeName: '',
            prizeLayer: false,
            errMsg: '',
            stayTime: 0,
            curErrorcode: 0
        }
    },
    mounted() {
        this.resetData()
        clearInterval(this.setIntervalStatus)
        this.setIntervalStatus = null
        this.roundId = utils.getCurrentPageUrlWithArgs().roundId
        //刷新session
        wxUtils.getUserSession()
        let userInfo = wxUtils.getUserStorage()
        userInfo ? (this.isAuth = true) : (this.isAuth = false)
        this.fnGetGameTime()
        this.setIntervalStatus = setInterval(() => {
            this.updateStatus()
        }, 1000)
    },
    onShow() {
        // this.resetData()
        // clearInterval(this.setIntervalStatus)
        // this.setIntervalStatus = null
        // this.roundId = utils.getCurrentPageUrlWithArgs().roundId
        // //刷新session
        // wxUtils.getUserSession()
        // let userInfo = wxUtils.getUserStorage()
        // userInfo ? (this.isAuth = true) : (this.isAuth = false)
        // this.fnGetGameTime()
        // this.setIntervalStatus = setInterval(() => {
        //     this.updateStatus()
        // }, 1000)
        // this.pageStayTime = new Date().getTime()
    },
    onLoad() {
        this.stayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.BIG_GASHAPON_Index_P,
        })
    },
    onHide() {
        this.stayTime = new Date().getTime() - this.stayTime
        buryPoint.setZ({
            id: pointCode.BIG_GASHAPON_Index_Z,
            p_stay_time: this.stayTime,
            p_id: this.activityId
        })

        //重置信息
        this.resetData()
    },
    onUnload() {
        this.stayTime = new Date().getTime() - this.stayTime
        buryPoint.setZ({
            id: pointCode.BIG_GASHAPON_Index_Z,
            p_stay_time: this.stayTime,
            p_id: this.activityId
        })

        //重置信息
        this.resetData()
    },
    methods: {
        ...mapMutations(['update']),
        //获取活动id
        fnGetGameTime() {
            bigScreenGame.getShaponActivityId(res => {
                if (res.data.data) {
                    this.activityId = res.data.data.activityId
                    this.getActivityDetail()
                }
            })
        },
        openShare() {},
        cancelData() {
            this.start = false
            this.dmData = []
            this.layer = false
            this.noInterg = 2
            this.barrage = true
            this.bigScreen = false
            this.drawn = false
            this.prizeLayer = false
        },
        /**
         * @param {String} 关闭弹框类型
         * @desc 弹框关闭操作
         */
        closeLayer(type) {
            if (type === 'prize') {
                this.resetData()
            }
            if(type === 'code'){
                if(this.curErrorcode === 400008){
                    buryPoint.setF({
                        id: pointCode.BIG_GASHAPON_Index_KNOW_F,
                        p_action_id: pointCode.BIG_GASHAPON_Index_KNOW_F,
                        p_action: this.p_action,
                        p_id: this.activityId
                    })
                }else if(this.curErrorcode === 400003){
                    buryPoint.setF({
                        id: pointCode.BIG_GASHAPON_Index_Finish_F,
                        p_action_id: pointCode.BIG_GASHAPON_Index_Finish_F,
                        p_action: this.p_action,
                        p_id: this.activityId
                    })
                }
            }
            this.cancelData()
        },
        // 开始抽奖
        startPrize() {
            if (this.status === 2) {
                let _this = this
                clearInterval(this.setIntervalStatus)
                this.setIntervalStatus = null
                // 只允许从相机扫码
                wx.scanCode({
                    onlyFromCamera: false,
                    success(res) {
                        // _this.roundId = res.result;  //todo
                        // _this.roundId = res.result.split('?')[1].split('=')[1] //todo
                        // _this.fnStartGame()
                        _this.roundId = res.result.split('?')[1].split('=')[1] //todo
                        _this.resetData()
                        _this.setIntervalStatus = setInterval(() => {
                            _this.updateStatus()
                        }, 1000)
                    }
                })
            } else if (this.status === 1) {
                wx.showToast({
                    title: '不好意思，游戏正在进行中',
                    icon: 'none',
                    duration: 2000
                })
                return
            } else {
                this.fnStartGame()
            }
        },
        /**
         *  @desc 抽奖开始
         */
        fnStartGame() {
            //api调用 返回结果处理 res

            if (!this.setIntervalStatus) {
                this.setIntervalStatus = setInterval(() => {
                    this.updateStatus()
                }, 1000)
            }
            let wxUserInfo = wx.getStorageSync('vipInfo')
            bigScreenGame.startGame(this.roundId, wxUserInfo.memberCode, res => {
                if (res.data.data.code === 0) {
                    this.updateRoundMsg()
                    this.noInterg = 4
                    this.isCloseDialog = true
                    buryPoint.setF({
                        id: pointCode.BIG_GASHAPON_Index_GO_F,
                        p_action_id: pointCode.BIG_GASHAPON_Index_GO_F,
                        p_action: this.p_action,
                        p_id: this.activityId
                    })
                } else if (res.data.data.code === 1000) {
                    this.noInterg = 0
                    this.isCloseDialog = false
                }
            })
        },
        // 根据活动id查详情
        getActivityDetail() {
            let requestOptions = {
                path: api.getActivityDetail + this.activityId
            }
            request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    this.isCanClick = true
                    let data = res.data
                    this.costIntegral = data.costIntegral || 0
                    // this.prizeList = data.prizeVos
                    // this.rules = data.activityRules.split('\n')
                    // this.baseAlign = this.angle
                    // this.activityName = data.activityName || 'A+CLUB会员'
                }
            })
        },
        //授权登录
        onGotUserInfo(e) {
            this.isAuth = true
        },
        updateStatus() {
            let t = this
            bigScreenGame.updateStatus(this.roundId, res => {
                if (!res.data.data) {
                    return
                }
                this.status = res.data.data.status
                let data = res.data.data.data ? JSON.parse(res.data.data.data) : ''

                if (this.status === 2 && data && data.isLogin && this.isCloseDialog) {
                    this.layer = false
                    wx.showModal({
                        title: '温馨提示',
                        content: '用户信息已过期，请重新登录',
                        showCancel: false,
                        confirmText: '确认',
                        confirmColor: '#4694FA',
                        success(res) {
                            let oldIsLogined = t.isLogined
                            wxUtils.clearLoginStorage()
                            t.update({
                                vipInfo: null,
                                sessionId: '',
                                isLogined: oldIsLogined
                            })
                            wx.navigateTo({
                                url: `/pages/auth/index`
                            })
                        }
                    })
                    clearInterval(this.setIntervalStatus)
                    this.setIntervalStatus = null
                    return
                }

                if (this.status === 2 && data && data.isGameOver && this.isCloseDialog) {
                    this.layer = false
                    clearInterval(this.setIntervalStatus)
                    this.setIntervalStatus = null
                    this.isCloseDialog = false
                    return
                }

                if (data && data.sessionId) return

                if (data && !data.flag && this.isCloseDialog) {
                    console.log('谢谢参与')
                    // let msg = data.errMsg
                    this.errMsg = data.errMsg || '据说笑一笑，中奖几率增加10倍'
                    this.drawn = false
                    this.layer = false
                    this.prizeLayer = true
                    this.isCloseDialog = false
                } else if (data && data.flag && this.isCloseDialog) {
                    console.log('中奖')
                    //中奖
                    this.drawn = true
                    this.layer = false
                    this.prizeImageUrl = data.prizeImageUrl
                    this.prizeName = data.prizeName
                    this.prizeLayer = true
                    this.isCloseDialog = false
                }
            })
        },
        scanAgain() {
            this.layer = false
            let _this = this
            // 只允许从相机扫码
            wx.scanCode({
                onlyFromCamera: false,
                success(res) {
                    // _this.roundId = res.result;  //todo
                    _this.roundId = res.result.split('?')[1].split('=')[1] //todo
                    _this.resetData()
                    _this.setIntervalStatus = setInterval(() => {
                        _this.updateStatus()
                    }, 1000)
                }
            })
        },
        goView(status) {
            if (status == 1) {
                wx.navigateTo({ url: '/pagesMine/card' })
                buryPoint.setF({
                    id: pointCode.BIG_GASHAPON_GO_CARDTICKET,
                    p_action_id: pointCode.BIG_GASHAPON_GO_CARDTICKET,
                    p_action: this.p_action,
                    p_id: this.activityId
                })
            } else {
                buryPoint.setF({
                    id: pointCode.BIG_GASHAPON_GOHOME_F,
                    p_action_id: pointCode.BIG_GASHAPON_GOHOME_F,
                    p_action: this.p_action,
                    p_id: this.activityId
                })
                wx.switchTab({ url: '/pages/home' })
            }
            this.resetData()
        },
        /**
         * @desc 点击扭一扭
         */
        startDraw() {
            // this.layer=true
            // 节流
            if (!this.isCanClick) return
            this.isDisable = false
            // 是否登录
            if (this.vipInfo) {
                this.query()
            } else {
                // 未登录
                console.log('未登录')
            }
        },
        // 查询是否可以抽奖
        query() {

            const _this = this
            wx.request({
                url: api.checkMemberLotteryEligible + _this.activityId,
                method: 'GET',
                data: null,
                header: {
                    Authorization: wx.getStorageSync('sessionId'),
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code == 4001 || res.data.code == 4000) {
                        _this.layer = false
                        wx.showModal({
                            title: '温馨提示',
                            content: '用户信息已过期，请重新登录',
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = _this.isLogined
                                wxUtils.clearLoginStorage()
                                _this.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        })
                        clearInterval(_this.setIntervalStatus)
                        _this.setIntervalStatus = null
                    } else if (res.data.code == 200 || res.data.code == 0) {
                       if (res.data.ok) {
                            if (_this.status === 2) {
                                // 二维码已过期
                                _this.noInterg = 0
                            } else {
                                // 可以抽奖
                                _this.noInterg = 2
                            }
                            _this.layer = true
                        }
                    } else if(res.data.code === 400003){
                        // 不能抽奖
                        // buryPoint.setF({
                        //     id: pointCode.BIG_GASHAPON_Index_Finish_F
                        // })
                        _this.curErrorcode = 400003
                        _this.noInterg = 3
                        _this.msg = res.data.message || `连不上网络，请刷新重试！`
                        _this.layer = true
                    } else if(res.data.code === 400008){
                        // 不能抽奖
                        // buryPoint.setF({
                        //     id: pointCode.BIG_GASHAPON_Index_KNOW_F
                        // })
                        _this.curErrorcode = 400008
                        _this.noInterg = 3
                        _this.msg = res.data.message || `连不上网络，请刷新重试！`
                        _this.layer = true
                    }else{
                        wx.showModal({
                            title: '提醒',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA'
                        })
                    }
                }
            })

        },
        //用户信息传给大屏
        updateRoundMsg() {
            let wxUserInfo = wx.getStorageSync('vipInfo')

            let obj = {
                sessionId: wx.getStorageSync('sessionId'),
                avatarUrl: wxUserInfo && wxUserInfo.avatarUrl,
                nickName: wxUserInfo && wxUserInfo.memberName
            }
            let data = {
                data: JSON.stringify(obj)
            }
            bigScreenGame.updateRoundMsg(this.roundId, data, res => {})
        },
        resetData() {
            clearInterval(this.setIntervalStatus)
            this.setIntervalStatus = null
            this.layer = false
            this.prizeLayer = false
            this.isCloseDialog = false
        }
    },
    computed: {
        ...mapState(['vipInfo', 'isLogined', 'isVip', 'wxUserInfo'])
    },
    beforeDestroy() {
        clearInterval(this.setIntervalStatus)
        this.setIntervalStatus = null
    }
}
</script>
<style lang="less">
#game_shapon {
    position: relative;
    .game_shapon_content {
        position: fixed;
        height: 100%;
        width: 100%;
        padding-top: 70%;
        box-sizing: border-box;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191202/40992b5a0ee6490bbcbb4c4fb8ce20df.png') no-repeat top center;
        background-size: 100% auto;

    }        
    .shapon_layer {
            height: 800px;
            background: rgba(0, 0, 0, 0.7);
            position: absolute;
            z-index: 399;
            top: 0px;
            left: 0px;
            right: 0px;
        }
        .layer_interg {
            position: relative;
            height: 90px;
            width: 90px;
            text-align: center;
            margin: 0 auto;
            top: 15px;
        }
        .layer_interg_div {
            position: absolute;
            color: #fff;
            font-size: 20px;
            top: 10px;
            left: 25px;
        }
    .layer_interg_img {
            height: 90px;
            width: 90px;
        }
    .gash_prize {
        background: rgba(0, 0, 0, 0.7);
        position: absolute;
        height: 842px;
        z-index: 299;
        top: 0px;
        left: 0px;
        right: 0px;
    }
    .gash_prize_close {
        position: absolute;
        z-index: 99;
        top: 41px;
        right: 34px;
        width: 38px;
        height: 38px;
        image {
            width: 38px;
            height: 38px;
        }
    }
    .gash_prize_top {
        width: 307px;
        height: 381px;
        position: relative;
        margin: 0 auto;
        padding-top: 80px;
        text-align: center;
    }
    .gash_prize_title {
        width: 129px;
        height: 27px;
        position: absolute;
        z-index: 399;
        top: 85px;
        color: #ffffff;
        font-size: 15px;
        font-weight: 400;
        width: 100%;
    }
    .gash_prize_goods {
        width: 100%;
        height: 142px;
        position: absolute;
        z-index: 399;
        top: 115px;
        image {
            width: 150px;
            height: 142px;
        }
    }
    .gash_prize_bottom {
        margin: 0 auto;
        position: relative;
        padding-top: 55px;
        text-align: center;
        width: 151px;
        height: 48px;
    }
    .layer_bottom_bg {
        width: 151px;
        height: 48px;
    }
    .layer_go {
        font-size: 20px;
        color: #ffffff;
        font-weight: 500;
        position: absolute;
        top: 65px;
        left: 0;
        z-index: 399;
        width: 100%;
        text-align: center;
    }
    .record_close {
        width: 38px;
        height: 38px;
        position: absolute;
        z-index: 99;
        top: 31px;
        right: 33px;
        image {
            width: 100%;
            height: 100%;
        }
    }
    .gash_prize_img {
        width: 100%;
        height: 100%;
    }
    .gash_prize_name {
        width: 100%;
        position: absolute;
        z-index: 99;
        bottom: 25px;
        text-align: center;
    }
    .prize_name {
        color: #ffffff;
        font-size: 24px;
        font-weight: 600;
    }
    .prize_name2 {
        color: #ffffff;
        font-size: 15px;
        font-weight: 400;
        padding-top: 16px;
    }
    .layer_shap {
        height: 60px;
    }
    .shapon_layer_bottom {
        position: relative;
        width: 151px;
        height: 48px;
        top: 55px;
        left: 117px;
        text-align: center;
        color: #fff;
        font-size: 20px;
        line-height: 48px;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191126/e2a7d4f3e3434850b8dbd3fedec6ad0e.png') no-repeat;
        background-size: 100%;
        span{
            display: inline-block;
            width: 100%;
            height: 100%;
        }
    }
    .shapon_layer_con{
        position: relative;
        top: 170px;
    }
    .shapon_layer_top {
        width: 305px;
        height: 222px;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/76d65823e88a4653ac921cb5600d5bab.png') no-repeat;
        background-size: 100%;
        //background: linear-gradient(224deg, rgba(222, 188, 100, 1) 0%, rgba(213, 165, 74, 1) 100%, rgba(248, 216, 136, 1) 100%, rgba(248, 216, 136, 1) 100%);
        border-radius: 8px;
        position: relative;
        top: 0px;
        left: 35px;
        text-align: center;
    }

    .shap_interg {
        height: 50px;
        background: rgba(255, 255, 255, 1);
        border-radius: 4px;
        position: absolute;
        padding: 38px 48px;
        z-index: 199;
        top: 85px;
        left: 10px;
        right: 10px;
        bottom: 10px;
        text-align: center;
    }
    .shap_interg_con {
        .layer_shap_remark {
            font-size: 18px;
            color: #a4761d;
        }
    }

    .game_cover {
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        position: absolute;
        z-index: 199;
        top: 0px;
        left: 0px;
        right: 0px;
    }
    .luck-title {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        top: 85px;
        width: 354px;
        height: 160px;
        image{
        width: 100%;
        height: 100%;
        }
    }
    .game-btn {
        width: 100%;
        height: 100%;
        margin: 0 auto;
        font-size: 32px;
        font-weight: 600;
        color: #fff;
        position: relative;
        display: flex;
        top: 280px;
        justify-content: center;
        align-items: center;
        flex-wrap: wrap;
        text-align: center;
        image{
            width: 200px;
            height: 171px;
        }
        span {
            text-align: center;
            width: 100%;
            padding: 0;
        }
    }
    .rules {
        width: 100%;
        text-align: center;
        height: 25px;
        font-size: 18px;
        color: rgb(252, 244, 245);
        line-height: 25px;
        position: absolute;
        z-index: 199;
        top: 490px;
    }
    .game-start {
        margin-top: 20px;
        width: 200px;
        height: 56px;
        font-size: 20px;
        font-family: PingFangHK-Regular, PingFangHK;
        color: rgba(244, 88, 112, 1);
        line-height: 28px;
    }
    .logo {
        position: absolute;
        top: 610px;
        left: 50%;
        transform: translateX(-52px);
        width: 99px;
        height: 43px;
        margin: 0 auto;
        opacity: 1;
        image{
              width: 99px;
              height: 43px;
        }
    }
    //抽奖失败模态框
    .cant-draw {
        position: fixed;
        z-index: 999;
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 100;
        .main {
            // width:375px;
            // height:812px;
            // background:rgba(0,0,0,1);
            // opacity:0.7;
            width: 305px;
            height: 222px;
            box-sizing: border-box;
            padding: 28px 0 25px;
            background-color: #fff;
            margin: 50% auto 0;
            text-align: center;
            background: rgba(0, 0, 0, 1);
            // background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191030/d9482f7dd6ca4ce08ec702126c052d52.png') no-repeat center center;
            // background-size: 100%;
            .img {
                display: block;
                margin: 0 auto;
                width: 82px;
                height: 82px;
                background-color: #f45870;
                border-radius: 50%;
                text-align: center;
                padding-top: 21px;
                box-sizing: border-box;
                span {
                    font-size: 20px;
                    color: #fff;
                    line-height: 20px;
                }
            }
            p {
                max-width: 90%;
                margin: 0 auto;
                font-size: 17px;
                color: #f45870;
                padding-top: 25px;
            }
            .footer-btn {
                height: 45px;
                padding-top: 25px;
                display: flex;
                button {
                    width: 123px;
                    height: 45px;
                    background-image: linear-gradient(#f87191, #e04164);
                    border-radius: 23px;
                    font-size: 16px;
                    line-height: 45px;
                    color: #fff;
                    justify-content: space-between;
                }
                // .back {
                //     line-height: 44px;
                //     color: #e04164;
                //     background-image: linear-gradient(#fff, #fff);
                //     border: 1px solid #e04164;
                // }
            }
        }
    }
}
.cant-draw {
    // 关闭
    .close {
        .line {
            width: 1.5px;
            height: 30px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.4);
        }
        img {
            width: 50px;
            height: 50px;
            margin: 0 auto;
        }
    }
}
</style>
