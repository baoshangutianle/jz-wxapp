<template>
    <div class="game-container">
        <div class="game-title">
            <!-- <img src="/static/images/game_title.png"
                 alt=""> -->
            <h1>
                <span>小手按一按</span>
                <span>开心赢大奖</span>
            </h1>
        </div>
        <div class="game-btn">
            <div class="game-btn-box">
                <LoginGame
                    :gameBtnBoxBg="'rgba(255, 115, 110, 0.18)'"
                    :gameBtnBg="'#ff736e'"
                    :activityId="activityId"
                    @playGame="playGame">
                </LoginGame>
            </div>
        </div>
        <div class="game-logo">
            <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/0927bafad951400abd6008e3edfc00eb.png"
                 alt="">
        </div>
        <GameDialog
            :isShowDialog="isShowDialog"
            :isShowCountDown="isShowCountDown"
            :showGameTime="showGameTime"
            :isWinPrize="isWinPrize"
            :prizeObj="prizeObj"
            :isShowPrize="isShowPrize"
            :isHaveOtherNum="true"
            @reset="reset"
            @checkPrize="checkPrize"
        ></GameDialog>
    </div>

</template>

<script>
import utils from '@/plugins/utils'
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils'
import api from '@/plugins/api'
import { type } from 'os'
import { mapState, mapMutations } from 'vuex'
import bigScreenGame from '@/plugins/bigScreenGame'
import LoginGame from '@/components/LoginGame'
import GameDialog from '@/components/GameDialog'

export default {
    components: {
        LoginGame,GameDialog
    },
    data() {
        return {
            type: null,
            // isGetPhoneNum: null,
            gameTime: null,
            showGameTime: null,
            setInterval: null,
            setIntervalStatus: null,
            isShowDialog: false,
            isShowCountDown: true,
            isShowPrize: false,
            isCloseDialog: false,
            activityId: null,
            isWinPrize: true,
            status:'',
            errMsg:'',
            prizeName:'',
            prizeImageUrl:'',
            roundId: '',
            isHaveOtherNum:'',
            prizeObj:{}
        }
    },
    mounted() {
        this.reset()
        this.roundId = utils.getCurrentPageUrlWithArgs().roundId;

        this.fnGetGameTime();
        this.setIntervalStatus = setInterval(()=>{
            this.updateStatus();
        },1000)

    },
    onUnload(){
        this.reset()
    },
    methods: {
        ...mapMutations(['update']),
        //开始游戏
        playGame(val,msg) {
            if(!val) {
                wx.showModal({
                    title: '提醒',
                    content: msg || '网络开了小差，请重新尝试',
                    showCancel: false,
                    confirmText: '确认',
                    confirmColor: '#4694FA'
                })
                // wx.showToast({
                //     title: '不好意思，没有剩余游戏次数了',
                //     icon: 'none',
                //     duration: 2000
                // })

                return false;

            }else{

                if(this.status === 2){
                    let _this = this;
                    // 只允许从相机扫码
                    wx.scanCode({
                        onlyFromCamera: false,
                        success (res) {
                            // _this.roundId = res.result;  //todo
                            _this.roundId =  res.result.split('?')[1].split('=')[1]; //todo
                            _this.fnStartGame()
                        }
                    })
                }else if(this.status === 1){
                    wx.showToast({
                        title: '不好意思，游戏正在进行中',
                        icon: 'none',
                        duration: 2000
                    })
                }else{
                    this.fnStartGame()
                }
            }

        },
        fnStartGame(){
            if (!this.setIntervalStatus) {
                this.setIntervalStatus = setInterval(() => {
                    this.updateStatus()
                }, 1000)
            }
            let wxUserInfo = wx.getStorageSync('vipInfo')
            bigScreenGame.startGame(this.roundId, wxUserInfo.memberCode, res => {
                if (res.data.data.code === 0) {
                    this.updateRoundMsg();
                    this.isShowDialog = true;
                    this.showGameTime = this.gameTime;
                    this.isCloseDialog = true;
                    this.setInterval = setInterval(() => {
                        if (this.showGameTime <= 1) {
                            this.reset()
                            this.fnEndGame();

                        } else {
                            this.showGameTime--
                        }
                    }, 1000)
                } else if (res.data.data.code === 1000) {
                    wx.showToast({
                        title: '二维码已过期，请至屏幕前重新扫码',
                        icon: 'none',
                        duration: 2000
                    })
                    this.reset()
                }

            })
        },
        fnGetGameTime() {
            bigScreenGame.getGameTime(res => {
                this.gameTime = res.data.data.roundDuration
                this.activityId = res.data.data.activityId
            })
        },
        updateRoundMsg(){
            let obj = {
                sessionId: wx.getStorageSync('sessionId')
            }
            let data = {
                data: JSON.stringify(obj)
            }
            bigScreenGame.updateRoundMsg(this.roundId, data, res => {})
        },
        updateStatus(){
            bigScreenGame.updateStatus(this.roundId, res => {
                this.status = res.data.data.status;
                let data = res.data.data.data ? JSON.parse(res.data.data.data) : '';

                if (this.status === 2 && data && data.isGameOver && this.isCloseDialog) {
                    this.reset()
                    wx.showModal({
                        title: '温馨提示',
                        content: data.msg || `连不上网络，请刷新重试！`,
                        showCancel: false,
                        confirmText: '确认',
                        confirmColor: '#4694FA'
                    })
                    return
                }

                if (this.status === 2 && data && data.isLogin && this.isCloseDialog) {
                    const t = this;
                    this.reset()

                    wx.showModal({
                        title: '温馨提示',
                        content: '用户信息已过期，请重新登录',
                        showCancel: false,
                        confirmText: '确认',
                        confirmColor: '#4694FA',
                        success(res) {
                            let oldIsLogined = t.isLogined
                            wxUtils.clearLoginStorage()
                            t.update({
                                vipInfo: null,
                                sessionId: '',
                                isLogined: oldIsLogined
                            })
                            wx.navigateTo({
                                url: `/pages/auth/index`
                            })
                        }
                    })
                    clearInterval(this.setIntervalStatus)
                    this.setIntervalStatus = null
                    return
                }

                if(data && data.sessionId) return;

                if(data && !data.flag && this.isCloseDialog){
                    this.isShowDialog = true;
                    this.isShowCountDown = false;
                    this.isShowPrize = true;
                    this.isWinPrize = false;
                    this.isCloseDialog = false;
                    this.errMsg = data.errMsg;
                    this.prizeObj = data;

                }else if(data && data.flag && this.isCloseDialog){
                    this.isShowDialog = true;
                    this.isShowCountDown = false;
                    this.isShowPrize = true;
                    this.isWinPrize = true;
                    this.isCloseDialog = false;
                    this.prizeName = data.prizeName;
                    this.prizeImageUrl = data.prizeImageUrl;
                    this.prizeObj = data;
                }

            })
        },
        fnEndGame(){
            bigScreenGame.endGame(this.roundId, res => {})
        },
        reset() {
            this.isShowPrize = false
            this.isShowCountDown = true
            this.isShowDialog = false
            this.isCloseDialog = false
            clearInterval(this.setInterval)
            clearInterval(this.setIntervalStatus)
            this.setIntervalStatus = null

        },
        checkPrize(){
            this.reset();
            wx.navigateTo({
                url: '/pagesMine/card'
            })
        }
    },
    computed: {
        ...mapState(['vipInfo', 'isLogined', 'isVip', 'wxUserInfo'])
    },
    beforeDestory() {
        clearInterval(this.setInterval)
        clearInterval(this.setIntervalStatus)
    }
}
</script>

<style lang="less">
page {
    height: 100%;
    width: 100%;
}
.game-container {
    height: 100%;
    width: 100%;
    background: aqua;
    display: flex;
    flex-direction: column;
    .game-title {
        padding-top: 40px;
        display: flex;
        justify-content: center;
        // img {
        //     width: 256px;
        //     height: 118px;
        // }
        h1{
            width: 100%;
            height: 118px;
            span{
                width: 100%;
                display: block;
                color: #fff;
                font-size: 46px;
                font-weight: 500;
                text-align: center;
                letter-spacing: 4px;
                text-shadow: 0 2px 0 #FF736E;
            }
        }
    }
    > .game-btn {
        padding-top: 62px;
        flex: 1 1 auto;
        display: flex;
        justify-content: center;
    }
    .game-logo {
        padding-bottom: 60px;
        display: flex;
        justify-content: center;
        img {
            width: 97px;
            height: 44px;
        }
    }
}
</style>
