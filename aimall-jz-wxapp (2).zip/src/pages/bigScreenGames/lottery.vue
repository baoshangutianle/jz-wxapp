<template>
    <div class="game-lottery">
        <div class="luck-title"></div>
        <div class="game-btn" v-if="!vipInfo">
            <auth-btn auth="user" @pass="onGotUserInfo" v-if="!isAuth && !vipInfo" />
            <auth-btn auth="phone" v-if="isAuth && !vipInfo" />
        </div>
        <div class="game-btn" v-if="vipInfo" @click="StartLOttery"></div>
        <p class="rules">-{{costIntegral}} 积分抽奖</p>
        <div class="logo"></div>
        <!-- 抽奖提示模态框 -->
        <div class="cant-draw" v-show="isShowDraw">
            <div class="main">
                <!-- 不能抽奖 -->
                <div v-show="prizeStatus === 0">
                    <img
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191030/5a62c9d523c8470d9cd3c84ad8aa6a78.png"
                        alt
                    />
                    <p>{{msg}}</p>
                    <div class="footer-btn">
                        <button @click="closeDraw">知道了</button>
                    </div>
                </div>
                <!-- 300积分抽奖 -->
                <div v-show="prizeStatus===1">
                    <div class="img">
                        <span>{{costIntegral}}</span>
                        <br />
                        <span>积分</span>
                    </div>
                    <p>{{msg}}</p>
                    <div class="footer-btn">
                        <!-- <button class="back" @click="isShowDraw=false">再想想</button> -->
                        <button @click="startPrize">立刻抽奖</button>
                    </div>
                </div>
                <!-- 大屏开始游戏 -->
                <div v-show="prizeStatus===2">
                    <img
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191101/7e678ed0587d4269a59b6cfc89e25ab5.png"
                        alt
                    />
                    <p class="game-start">
                        请关注大屏
                        <br />大屏已经开始游戏哦 !
                    </p>
                </div>
                <!-- 二维码过期 -->
                <div v-show="prizeStatus === 3">
                    <img
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191030/5a62c9d523c8470d9cd3c84ad8aa6a78.png"
                        alt
                    />
                    <p>{{msg}}</p>
                    <div class="footer-btn">
                        <button @click="scanAgain">确定</button>
                    </div>
                </div>
            </div>
            <div class="close" v-show="prizeStatus===1">
                <div class="line"></div>
                <img
                    src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/5ec255d63c534452916ebc09c6b28911.png"
                    @click="isShowDraw = false"
                />
            </div>
        </div>
        <!-- 抽奖结果模态框 -->
        <prize-Page
            :openFalg="openFalg"
            :lotteryStatus="lotteryStatus"
            :lotteryName="lotteryName"
            :lotteryImg="lotteryImg"
            :activityId="activityId"
            :luckyPrizeId="hitPrizeId"
            :sourceFrom="false"
            @close="closePage"
            @resetInfo="resetData"
        />
    </div>
</template>

<script>
import utils from '@/plugins/utils'
import wxUtils from '@/plugins/wxUtils'
import prizePage from '@/components/prizePage'
import request from '@/plugins/request'
import api from '@/plugins/api'
import AuthBtn from '@/components/AuthBtn'
import { mapState, mapMutations } from 'vuex'
import bigScreenGame from '@/plugins/bigScreenGame'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
export default {
    components: { AuthBtn, prizePage },
    data() {
        return {
            activityName: '', //活动名称
            isCanClick: false,
            activityId: null,
            prizeList: [],
            isCloseDialog: false, //是否关闭中奖结果弹框
            isAuth: null,
            // 是否可以抽奖
            isShowDraw: false, // 是否显示
            prizeStatus: 0, // 抽奖状态
            msg: ``, //提示消息
            // 抽奖结果模态框数据
            openFalg: false, // 是否显示
            costIntegral: 0, //消耗积分
            lotteryStatus: false, // 是否中奖
            lotteryName: '', // 中奖商品名称
            lotteryImg: '', // 中奖商品图片src
            setIntervalStatus: null,
            status: null, //此轮游戏状态
            pageStayTime: 0,
            dialogStayTime: 0
        }
    },
    mounted() {
        clearInterval(this.setIntervalStatus)
        this.setIntervalStatus = null
        this.roundId = utils.getCurrentPageUrlWithArgs().roundId
        //刷新session
        wxUtils.getUserSession()
        let userInfo = wxUtils.getUserStorage()
        userInfo ? (this.isAuth = true) : (this.isAuth = false)
        this.fnGetGameTime()
        this.setIntervalStatus = setInterval(() => {
            this.updateStatus()
        }, 1000)
    },
    onShow() {
        this.pageStayTime = new Date().getTime()
    },
    onLoad() {
        buryPoint.setP({
            id: pointCode.BIG_LOTTERY_P
        })
    },
    onUnload() {
        //重置信息
        this.resetData()
        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        this.dialogStayTime = new Date().getTime() - this.dialogStayTime
        buryPoint.setZ({
            id: pointCode.BIG_LOTTERY_Z,
            p_stay_time: this.pageStayTime
        })
        buryPoint.setZ({
            id: pointCode.BIG_LOTTERY_RESULT_Z,
            p_stay_time: this.dialogStayTime
        })
        // 返回跳转爱琴海首页
        // wx.reLaunch({
        //     url: '/pages/home',
        // });
    },
    methods: {
        ...mapMutations(['update']),
        //获取活动id
        fnGetGameTime() {
            bigScreenGame.getActivityId(res => {
                if (res.data.data) {
                    this.activityId = res.data.data.activityId
                    this.getActivityDetail()
                }
            })
        },
        // 根据活动id查详情
        getActivityDetail() {
            let requestOptions = {
                path: api.getActivityDetail + this.activityId
            }
            request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    this.isCanClick = true
                    let data = res.data
                    this.costIntegral = data.costIntegral || 0
                    this.prizeList = data.prizeVos
                    this.rules = data.activityRules.split('\n')
                    this.baseAlign = this.angle
                    this.activityName = data.activityName || 'A+CLUB会员'
                }
            })
        },
        //授权登录
        onGotUserInfo(e) {
            this.isAuth = true
        },
        updateStatus() {
            let t = this
            bigScreenGame.updateStatus(this.roundId, res => {
                if (!res.data.data) {
                    return
                }
                this.status = res.data.data.status
                let data = res.data.data.data ? JSON.parse(res.data.data.data) : ''

                if (this.status === 2 && data && data.isLogin && this.isCloseDialog) {
                    this.isShowDraw = false
                    wx.showModal({
                        title: '温馨提示',
                        content: '用户信息已过期，请重新登录',
                        showCancel: false,
                        confirmText: '确认',
                        confirmColor: '#4694FA',
                        success(res) {
                            let oldIsLogined = t.isLogined
                            wxUtils.clearLoginStorage()
                            t.update({
                                vipInfo: null,
                                sessionId: '',
                                isLogined: oldIsLogined
                            })
                            wx.navigateTo({
                                url: `/pages/auth/index`
                            })
                        }
                    })
                    clearInterval(this.setIntervalStatus)
                    this.setIntervalStatus = null
                    return
                }

                if (this.status === 2 && data && data.isGameOver && this.isCloseDialog) {
                    this.isShowDraw = false
                    clearInterval(this.setIntervalStatus)
                    this.setIntervalStatus = null
                    this.isCloseDialog = false
                    return
                }

                if (data && data.sessionId) return

                if (data && !data.flag && this.isCloseDialog) {
                    this.dialogStayTime = new Date().getTime()
                    buryPoint.setP({
                        id: pointCode.BIG_LOTTERY_RESULT_P
                    })
                    console.log('谢谢参与')
                    // 不中奖
                    // let msg = '谢谢参与~'
                    let msg = data.errMsg
                    this.notHitPrize(msg)
                    this.isCloseDialog = false
                } else if (data && data.flag && this.isCloseDialog) {
                    this.dialogStayTime = new Date().getTime()
                    buryPoint.setP({
                        id: pointCode.BIG_LOTTERY_RESULT_P
                    })
                    console.log('中奖')
                    //中奖
                    this.hitPrizeId = data.prizeId
                    // this.hitPrizeId = this.prizeList[parseInt(Math.random() * this.prizeList.length)].id
                    this.hitPrize()
                    this.isCloseDialog = false
                }
            })
        },
        closeDraw() {
            if (this.msg.indexOf('抽过奖') != -1) {
                buryPoint.setF({
                    id: pointCode.BIG_LOTTERY_ALREADY_F
                })
            } else if (this.msg.indexOf('积分不足') != -1) {
                buryPoint.setF({
                    id: pointCode.BIG_LOTTERY_INTEGRAL_F
                })
            }
            this.isShowDraw = false
        },
        scanAgain(){
            this.isShowDraw = false
            let _this = this
            // 只允许从相机扫码
            wx.scanCode({
                onlyFromCamera: false,
                success(res) {     
                    // _this.roundId = res.result;  //todo
                    _this.roundId = res.result.split('?')[1].split('=')[1] //todo
                    _this.resetData()
                    _this.setIntervalStatus = setInterval(() => {
                        _this.updateStatus()
                    }, 1000)
                }
            })
        },
        // 点击抽奖
        StartLOttery() {
            buryPoint.setF({
                id: pointCode.BIG_LOTTERY_START_F
            })
            // 节流
            if (!this.isCanClick) return
            this.isDisable = false
            // 是否登录
            if (this.vipInfo && wx.getStorageSync('sessionId')) {
                this.query()
            } else {
                // 未登录
                var t = this;
                wx.showModal({
                    title: '温馨提示',
                    content: '用户信息已过期，请重新登录',
                    showCancel: false,
                    confirmText: '确认',
                    confirmColor: '#4694FA',
                    success(res) {
                        let oldIsLogined = t.isLogined
                        wxUtils.clearLoginStorage()
                        t.update({
                            vipInfo: null,
                            sessionId: '',
                            isLogined: oldIsLogined
                        })
                        wx.navigateTo({
                            url: `/pages/auth/index`
                        })
                    }
                })
            }
        },
        // 查询是否可以抽奖
        query() {
            let requestOptions = {
                path: api.checkLuckyDraw + this.activityId
            }
            request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    if (res.ok) {
                        if(this.status == 2){
                            this.prizeStatus = 3
                            // 二维码已过期
                            this.msg = `二维码已过期，请至大屏重新抽奖`
                        }else{
                            this.prizeStatus = 1
                            // 可以抽奖
                            this.msg = `本次抽奖将消耗` +  this.costIntegral + `积分`
                        } 
                    
                    } else {
                        this.prizeStatus = 0
                        // 不能抽奖
                        this.msg = res.message || `连不上网络，请刷新重试！`
                    }
                    this.isShowDraw = true
                }
            })
        },
        // 开始抽奖
        startPrize() {
            if (this.status === 2) {
                let _this = this
                // 只允许从相机扫码
                wx.scanCode({
                    onlyFromCamera: false,
                    success(res) {
                        // _this.roundId = res.result;  //todo
                        _this.roundId = res.result.split('?')[1].split('=')[1] //todo
                        _this.fnStartGame()
                        buryPoint.setF({
                            id: pointCode.BIG_LOTTERY_IMMEDIATELY_F
                        })
                    }
                })
            } else if (this.status === 1) {
                wx.showToast({
                    title: '不好意思，游戏正在进行中',
                    icon: 'none',
                    duration: 2000
                })
                return
            } else {
                this.fnStartGame()
                buryPoint.setF({
                    id: pointCode.BIG_LOTTERY_IMMEDIATELY_F
                })
            }
        },
        //开始游戏
        fnStartGame() {
            if (!this.setIntervalStatus) {
                this.setIntervalStatus = setInterval(() => {
                    this.updateStatus()
                }, 1000)
            }
            let wxUserInfo = wx.getStorageSync('vipInfo')
            bigScreenGame.startGame(this.roundId, wxUserInfo.memberCode, res => {
                if (res.data.data.code === 0) {
                    this.updateRoundMsg()
                    this.prizeStatus = 2
                    this.isCloseDialog = true
                } else if (res.data.data.code === 1000) {
                    wx.showToast({
                        title: '二维码已过期，请至屏幕前重新扫码',
                        icon: 'none',
                        duration: 2000
                    })
                    this.openFalg = false
                    this.isShowDraw = false
                    this.isCloseDialog = false
                }
            })
        },
        //用户信息传给大屏
        updateRoundMsg() {
            let wxUserInfo = wx.getStorageSync('vipInfo')

            let obj = {
                sessionId: wx.getStorageSync('sessionId'),
                avatarUrl: wxUserInfo && wxUserInfo.avatarUrl,
                nickName: wxUserInfo && wxUserInfo.memberName
            }
            let data = {
                data: JSON.stringify(obj)
            }
            bigScreenGame.updateRoundMsg(this.roundId, data, res => {})
        },
        // 中奖执行逻辑
        hitPrize() {
            this.prizeList.forEach(v => {
                if (v.id === this.hitPrizeId) {
                    this.lotteryStatus = true
                    this.lotteryName = v.prizeName
                    this.lotteryImg = v.couponImageUrl
                    this.openFalg = true
                }
            })
            console.log('中奖了,奖品:' + this.lotteryName)
        },
        // 未中奖逻辑
        notHitPrize(msg) {
            console.log('未中奖')
            this.hitPrizeId = ''
            this.lotteryStatus = false
            this.lotteryName = msg || '谢谢参与~'
            this.lotteryImg = ''
            this.openFalg = true
        },
        resetData() {
            clearInterval(this.setIntervalStatus)
            this.setIntervalStatus = null
            this.openFalg = false
            this.isShowDraw = false
            this.isCloseDialog = false
        },
        // 关闭中奖结果模态框
        closePage(status) {
            this.openFalg = status
            this.isCloseDialog = false
        }
    },
    computed: {
        ...mapState(['vipInfo', 'isLogined', 'isVip', 'wxUserInfo'])
    },
    beforeDestroy() {
        clearInterval(this.setIntervalStatus)
        this.setIntervalStatus = null
    },
    onShareAppMessage(options) {
        let title
        if (this.lotteryStatus) {
            title = `我在${this.activityName}中抽中了${this.lotteryName}，你也来试试吧`
        } else {
            title = `${this.activityName}正在火热进行中，快来试试吧`
        }
        return {
            title: title,
            imageUrl: this.lotteryImg,
            path: 'pages/home?pageId=lotteryShare&activityId=' + this.activityId + '&luckyPrizeId=' + this.hitPrizeId,
            success: function(res) {
                this.resetData()
                wx.showToast({
                    title: '转发成功',
                    icon: 'success',
                    duration: 2000
                })
            }
        }
    }
}
</script>

<style lang="less">
.game-lottery {
    position: fixed;
    height: 100%;
    width: 100%;
    padding-top: 70%;
    box-sizing: border-box;
    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/2d05db4210b34b95b3bfa252b059a73c.png') no-repeat top center;
    background-size: 100% auto;
    .luck-title {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        top: 10%;
        width: 320px;
        height: 135px;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/929d15ff5fbe4117a7e8304f4dbe1a6c.png') no-repeat center center;
        background-size: 100% 100%;
    }
    .game-btn {
        width: 163px;
        height: 163px;
        margin: 0 auto;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191119/39a76922f11b4fc985cc5b3c2102b482.png') no-repeat top center;
        background-size: 100% 100%;
        font-size: 32px;
        font-weight: 600;
        color: #fff;
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-wrap: wrap;
        span {
            text-align: center;
            width: 100%;
            padding: 0;
        }
    }
    .rules {
        text-align: center;
        height: 25px;
        margin-top: 40px;
        font-size: 18px;
        color: rgba(226, 70, 103, 1);
        line-height: 25px;
    }
    .game-start {
        margin-top: 20px;
        width: 200px;
        height: 56px;
        font-size: 20px;
        font-family: PingFangHK-Regular, PingFangHK;
        color: rgba(244, 88, 112, 1);
        line-height: 28px;
    }
    .logo {
        position: absolute;
        bottom: 10px;
        left: 50%;
        transform: translateX(-52px);
        width: 104px;
        height: 122px;
        margin: 0 auto;
        // background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/d4f2e8427766489f883049a0885dd435.png') no-repeat center center;
        background: url('https://aimall-jz.oss-cn-shenzhen.aliyuncs.com/as/WechatIMG1220.png') no-repeat center center;
        background-size: 104px 44px;
        opacity: 1;
    }
    //抽奖失败模态框
    .cant-draw {
        position: fixed;
        z-index: 999;
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 100;
        .main {
            width: 302px;
            height: 279px;
            box-sizing: border-box;
            padding: 28px 0 25px;
            background-color: #fff;
            margin: 50% auto 0;
            text-align: center;
            background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191030/d9482f7dd6ca4ce08ec702126c052d52.png') no-repeat center center;
            background-size: 100%;
            .img {
                display: block;
                margin: 0 auto;
                width: 82px;
                height: 82px;
                background-color: #f45870;
                border-radius: 50%;
                text-align: center;
                padding-top: 21px;
                box-sizing: border-box;
                span {
                    font-size: 20px;
                    color: #fff;
                    line-height: 20px;
                }
            }
            p {
                max-width: 90%;
                margin: 0 auto;
                font-size: 17px;
                color: #f45870;
                padding-top: 25px;
            }
            .footer-btn {
                height: 45px;
                padding-top: 25px;
                display: flex;
                button {
                    width: 123px;
                    height: 45px;
                    background-image: linear-gradient(#f87191, #e04164);
                    border-radius: 23px;
                    font-size: 16px;
                    line-height: 45px;
                    color: #fff;
                    justify-content: space-between;
                }
                // .back {
                //     line-height: 44px;
                //     color: #e04164;
                //     background-image: linear-gradient(#fff, #fff);
                //     border: 1px solid #e04164;
                // }
            }
        }
    }
}
.cant-draw {
    // 关闭
    .close {
        .line {
            width: 1.5px;
            height: 30px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.4);
        }
        img {
            width: 50px;
            height: 50px;
            margin: 0 auto;
        }
    }
}
</style>
