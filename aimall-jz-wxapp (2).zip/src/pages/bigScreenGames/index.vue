<template>
    <div />
</template>

<script>
import utils from '@/plugins/utils'
const gestureLottery = 'gesture-lottery'
const ledLottery = 'led-lottery'
const parkour = 'parkour'
const luckyLottery = 'lucky-lottery'
const faceShow = 'face-show'
const shapon = 'shapon'
const sceneTakingPhoto = 'sceneTakingPhoto'
const downloadPhoto = 'downloadPhoto'
export default {
    data() {
        return {}
    },
    mounted() {
        let url = decodeURIComponent(utils.getCurrentPageUrlWithArgs().q)
        let roundId = url.split('?')[1].split('=')[1]
        let pageList = url.split('?')[0].split('/')
        let pageName = pageList[pageList.length - 1]
        switch (pageName) {
            case gestureLottery:
                wx.redirectTo({
                    url: `/pages/bigScreenGames/gesture-draw?roundId=${roundId}`
                })
                break
            case ledLottery:
                wx.redirectTo({
                    url: `/pages/bigScreenGames/led-lottery?roundId=${roundId}`
                })
                break
            case parkour:
                wx.redirectTo({
                    url: `/pages/bigScreenGames/parkour?roundId=${roundId}`
                })
                break
            case luckyLottery:
                wx.redirectTo({
                    url: `/pages/bigScreenGames/lottery?roundId=${roundId}`
                })
                break
            case faceShow:
                wx.redirectTo({
                    url: `/pages/bigScreenGames/face-show?roundId=${roundId}`
                })
                break
            case shapon:
                wx.redirectTo({
                    url: `/pages/bigScreenGames/shapon?roundId=${roundId}`
                })
                break
            case sceneTakingPhoto:
                wx.redirectTo({
                    url: `/pages/bigScreenGames/scene-taking-photo?roundId=${roundId}`
                })
                break
            case downloadPhoto:
                wx.redirectTo({
                    url: `/pages/bigScreenGames/download-photo?roundId=${roundId}`
                })
                break
        }
    }
}
</script>

<style scoped>
</style>
