<template>
    <div id="machine">
        <div class="container">
            <!-- <div class="slot-machine-container" :class="bgCheck?'bg-check-1':'bg-check-2'"> -->
            <div class="slot-machine-container">
                <!-- logo -->
                <div class="gashaponTop">
                    <div class="gashapon_icon">
                        <img
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191218/38143a49d94f4b71a5c13fc603b7b67f.png"
                        />
                    </div>
                </div>
                <!-- 主层 -->
                <div class="machine_bg" :class="bgCheck?'bg-check-1':'bg-check-2'">
                    <!-- 立即抽奖 -->
                    <div class="begin-btn" v-if="!vipInfo">
                        <img
                            v-show="btnCheck"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191222/1d19825d45254c76b35491b07400930c.png"
                            mode="widthFix"
                        />
                        <img
                            v-show="!btnCheck"
                            mode="widthFix"
                            style="top: 340px;"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191222/4aea6feb33604f71a2c7341c4c866a86.png"
                        />
                        <auth-btn auth="user" @pass="onGotUserInfo" v-if="!isAuth && !vipInfo" />
                        <auth-btn auth="phone" v-if="isAuth && !vipInfo" />
                    </div>
                    <div class="begin-btn" v-if="vipInfo" @click="startLOttery">
                        <img
                            v-show="btnCheck"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191222/1d19825d45254c76b35491b07400930c.png"
                            mode="widthFix"
                        />
                        <img
                            v-show="!btnCheck"
                            mode="widthFix"
                            style="top: 340px;"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191222/4aea6feb33604f71a2c7341c4c866a86.png"
                        />
                    </div>
                    <!-- 积分 -->
                    <div class="coupon-text">
                        <p class="cost-inter" v-if="intergNum!='0'">-{{intergNum}} 积分抽奖</p>
                        <p class="cost-inter" v-else>免费抽奖</p>
                    </div>
                </div>
                <!-- 点击立即抽奖弹窗 -->
                <div v-if="beginModal" class="machine_layer">
                    <div class="layer_top">
                        <div class="layer_title">
                            <img
                                v-if="noInterg === 2"
                                mode="widthFix"
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/ebeef624b31a4122885de7df76d7cff0.png"
                                alt
                            />
                            <img
                                v-if="noInterg === 1 || noInterg === 3"
                                mode="widthFix"
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/50c6c3349fd44ff98507c457421852d9.png"
                                alt
                            />
                            <p v-if="noInterg === 2">{{intergNum}}</p>
                            <p v-if="noInterg === 2">积分</p>
                            <p v-if="!noInterg && intergNum =='0'">免费</p>
                            <p v-if="!noInterg && intergNum =='0'">抽奖</p>
                        </div>
                        <div class="layer_container">
                            <p
                                v-if="noInterg === 2"
                                style="padding-top: 90rpx;"
                            >使用 {{intergNum}} 积分抽奖一次</p>
                            <p v-if="noInterg === 2">未完成抽奖积分不退换</p>
                            <p v-if="noInterg === 1  || noInterg === 3" class="layer_container_remark">{{messageText}}</p>
                        </div>
                        <div class="layer_footer">
                            <div class="layer_footer_btn">
                                <p v-if="noInterg === 2" @click="start">立即抽奖</p>
                                <p v-if="noInterg === 3">去首页看看</p>
                                <p v-if="noInterg === 1" @click="beginModal = false">我知道了</p>
                            </div>
                        </div>
                        <div class="layer_close">
                            <img
                                mode="widthFix"
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/4160aa61cfe9430aae0a3d96e95cf648.png"
                                alt
                                @click="beginModal = false"
                            />
                        </div>
                    </div>
                </div>
                <!-- 关注大屏弹窗 -->
                <div v-if="lookScreenModal" class="look_screen">
                    <div class="look_screen_container">
                        <img
                            mode="widthFix"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/148e0a136f3b48bfa9a430aaf10241d3.png"
                        />
                        <p class="show_screen">请关注大屏</p>
                        <p class="screen_game">大屏已经开始游戏哦！</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import AuthBtn from '@/components/AuthBtn'
import { mapState, mapMutations } from 'vuex'
import bigScreenGame from '@/plugins/bigScreenGame'
import wxUtils from '@/plugins/wxUtils'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import GoodLuck from '@/components/GoodLuck'
export default {
    components: { AuthBtn },
    data() {
        return {
            // 闪灯背景切换定时器
            bgCheck: false,
            setIntervalBgStatus: null,
            // 按钮闪烁定时器
            btnCheck: true,
            setIntervalStatus: null,
            intergNum: 0,
            beginModal: false,
            lookScreenModal: false,
            noInterg: 0,
            isAuth: null,
            activityId: 348,
            messageText: '二维码已过期，请至大屏重新扫码'
        }
    },
    mounted() {
        //刷新session
        wxUtils.getUserSession()
        let userInfo = wxUtils.getUserStorage()
        userInfo ? (this.isAuth = true) : (this.isAuth = false) 

        let t = this
        t.btnAnmite()
        t.setIntervalBgStatus = setInterval(() => {
            t.bgCheck = !t.bgCheck
        }, 1000)

        // this.getActivityDetail()

    },
    onUnload() {},
    computed: {
        ...mapState(['vipInfo', 'isLogined', 'isVip', 'wxUserInfo'])
    },
    methods: {
        ...mapMutations(['update']),
        btnAnmite() {
            let t = this
            t.setIntervalStatus = setInterval(() => {
                t.btnCheckFun()
                setTimeout(() => {
                    t.btnCheckFun()
                    setTimeout(() => {
                        t.btnCheckFun()
                        setTimeout(() => {
                            t.btnCheckFun()
                        }, 150)
                    }, 150)
                }, 150)
            }, 2000)
        },
        // 按钮动画
        btnCheckFun() {
            this.btnCheck = !this.btnCheck
        },
        //授权登录
        onGotUserInfo(e) {
            this.isAuth = true
        },
        // 根据活动id查详情
        getActivityDetail() {
            const _this = this
            wx.request({
                url: api.checkMemberLotteryEligible + _this.activityId,
                method: 'GET',
                data: null,
                header: {
                    Authorization: wx.getStorageSync('sessionId'),
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code == 4001 || res.data.code == 4000) {
                         _this.beginModal = false
                        wx.showModal({
                            title: '温馨提示',
                            content: '用户信息已过期，请重新登录',
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = _this.isLogined
                                wxUtils.clearLoginStorage()
                                _this.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        })
                        clearInterval(_this.setIntervalStatus)
                        // _this.setIntervalStatus = null
                    } else if (res.data.code == 200 || res.data.code == 0) {
                       if (res.data.ok) {
                            if (_this.status === 2) {
                                // 二维码已过期
                                _this.noInterg = 0
                            } else {
                                // 可以抽奖
                                _this.noInterg = 2
                            }
                            _this.beginModal = true
                        }
                    } else if(res.data.code === 400003){
                        // 不能抽奖
                        _this.curErrorcode = 400003
                        _this.noInterg = 3
                        _this.msg = res.data.message || `连不上网络，请刷新重试！`
                        _this.beginModal = true
                    } else if(res.data.code === 400008){
                        // 不能抽奖
                        _this.curErrorcode = 400008
                        _this.noInterg = 3
                        _this.msg = res.data.message || `连不上网络，请刷新重试！`
                        _this.beginModal = true
                    }else{
                        wx.showModal({
                            title: '提醒',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA'
                        })
                    }
                }
            })
        },
        //立即抽奖
        startLOttery(){
            // 是否登录
            if (this.vipInfo) {
                this.query()
            } else {
                // 未登录
                console.log('未登录')
            }
        },
        //查询是否有抽奖资格
        query(){
            this.beginModal = true
            // //不能抽奖
            // this.noInterg = 1

            // //可以抽奖
            // this.noInterg = 2

            //已经抽过奖了
            this.noInterg = 3
        }
    }
}
</script>
<style lang="less">
page {
    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191217/b7bb4e805af2441f8ba9925dfc9855da.png') center center no-repeat;
    background-size: cover;
    background-color: rgba(18, 22, 118, 1);
}
</style>
<style lang="less" scoped>
#machine {
    .slot-machine-container {
        // position: relative;
        // margin: 0 auto auto;
        // z-index: 2;
        // width: 750rpx;
        // height: 1110rpx;
        // background-size: cover;
        .gashaponTop {
            height: 60px;
            .gashapon_icon {
                width: 95px;
                height: 41px;
                padding-top: 18px;
                padding-left: 18px;
                float: left;
                img {
                    width: 95px;
                    height: 41px;
                }
            }
        }
        // 老虎机背景切换
        .bg-check-1 {
            background: transparent url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/95921da318f44bdb96e2f9de3ad783a5.png') bottom center no-repeat;
            background-size: cover;
        }
        .bg-check-2 {
            background: transparent url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/936167fe43c6414d88408aa576e74b85.png') bottom center no-repeat;
            background-size: cover;
        }
        .machine_bg {
            position: relative;
            margin: 0 auto auto;
            z-index: 2;
            width: 352px;
            height: 435px;
            // 开始按钮
            .begin-btn {
                img {
                    position: absolute;
                    top: 330px;
                    left: 50%;
                    margin-left: -106.5px;
                    width: 213px;
                }
            }
            .coupon-text {
                position: absolute;
                width: 106px;
                height: 30px;
                left: 50%;
                margin-left: -53px;
                top: 407px;
                font-size: 13px;
                text-align: center;
                p{
                    color: #dc5812;
                }
            }
        }
        // 抽奖二次确认弹窗
        .machine_layer {
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            position: fixed;
            z-index: 199;
            top: 0px;
            left: 0px;
            right: 0px;
            .layer_top {
                width: 85%;
                height: 260px;
                // background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/76d65823e88a4653ac921cb5600d5bab.png') no-repeat;
                background: -moz-linear-gradient(top, #f5ce34 0%, #dda641 100%);
                background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #f5ce34), color-stop(100%, #dda641));
                background: -webkit-linear-gradient(top, #f5ce34 0%, #dda641 100%);
                background: -o-linear-gradient(top, #f5ce34 0%, #dda641 100%);
                background: -ms-linear-gradient(top, #f5ce34 0%, #dda641 100%);
                background: linear-gradient(to bottom, #f5ce34 0%, #dda641 100%);
                border-radius: 8px;
                position: relative;
                margin: 405rpx auto 0;
                .layer_title {
                    height: 83rpx;
                    img {
                        width: 100px;
                        position: absolute;
                        top: -50px;
                        left: 50%;
                        margin-left: -50px;
                        z-index: 1;
                    }
                    p {
                        color: #fff;
                        text-align: center;
                        width: 100%;
                        z-index: 2;
                        position: relative;
                        top: -25px;
                    }
                }
                .layer_container {
                    height: 315rpx;
                    width: 585rpx;
                    margin: 0px auto;
                    position: relative;
                    z-index: 3;
                    top: -15px;
                    text-align: center;
                    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/2943a05be45d43bab84ff75c7e59a544.png') bottom center no-repeat;
                    background-size: cover;
                    p {
                        font-size: 18px;
                        color: #e28502;
                    }
                }
                .layer_container_remark {
                    padding: 50px;
                }
                .layer_footer {
                    .layer_footer_btn {
                        width: 150px;
                        height: 48px;
                        line-height: 48px;
                        text-align: center;
                        background: #ffd932;
                        border-radius: 6px;
                        margin: 0 auto;
                        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/db0269aa563e446ba85f006166df3660.png') center center no-repeat;
                        p {
                            color: #db7c06;
                            font-size: 20px;
                        }
                    }
                }
                .layer_close {
                    img {
                        width: 37px;
                        margin: 13px auto 0;
                    }
                }
            }
        }
        // 请关注大屏弹窗
        .look_screen {
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            position: fixed;
            z-index: 199;
            top: 0px;
            left: 0px;
            right: 0px;
            .look_screen_container {
                position: relative;
                img {
                    width: 323px;
                    position: absolute;
                    top: 150px;
                    left: 50%;
                    margin-left: -162px;
                }
                .show_screen {
                  position: absolute;
                  width: 300px;
                  text-align: center;
                  top: 260px;
                  left: 50%;
                  margin-left: -150px;
                  font-size: 15px;
                  color: #db7c06;
                }
                .screen_game {
                  position: absolute;
                  width: 300px;
                  text-align: center;
                  top: 300px;
                  left: 50%;
                  margin-left: -150px;
                  font-size: 15px;
                  color: #db7c06;
                }
            }
        }
    }
}
</style>
