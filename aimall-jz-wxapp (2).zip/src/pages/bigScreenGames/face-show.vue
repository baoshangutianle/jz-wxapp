<template>
    <div class="page-face">
        <!-- 颜值秀 -->
        <div class="page-title">
            <img :src="titleImg" alt="">
        </div>

        <div class="game-btn-box">
            <div :class="{'game-btn':true,'isAuth-btn': !isAuth && !vipInfo}" v-if="!vipInfo">
                <auth-btn auth="user" @pass="onGotUserInfo" v-if="!isAuth && !vipInfo" />
                <auth-btn auth="phone" @pass="getPhoneNumber" v-if="isAuth && !vipInfo" />
            </div>
            <div class="game-btn" v-if="vipInfo" @click="startGame"></div>
        </div>

        <!-- 抽奖提示模态框 -->
        <div class="cant-draw" v-show="isShowDraw">
            <div class="main">
                <!-- 大屏开始游戏 -->
                <div v-show="prizeStatus === 1">
                    <div class="bigScreen-img">
                        <img
                            :src="bigScreenImg"
                            alt
                        />
                    </div>
                    <p class="game-start">
                        请关注大屏
                        <br />大屏已经开始游戏哦 !
                    </p>
                </div>
            </div>
        </div>

        <!-- 二维码过期提示模态框 -->
        <div class="qrcode-dialog" v-show="isShowDialog">
            <div class="main">
                <div class="qrcode-dialog_close" @click="closeDialog">
                    <image
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/954ca5af8ec64c0d827c6e3e536c2f53.png"
                    />
                </div>
                <p class="game-start">
                    二维码已过期
                        <br />请至屏幕前重新扫码哦 !
                </p>
            </div>
        </div>

    </div>
</template>

<script>
import utils from '@/plugins/utils'
import { mapState, mapMutations } from 'vuex'
import AuthBtn from '@/components/AuthBtn'
import wxUtils from '@/plugins/wxUtils'
import bigScreenGame from '@/plugins/bigScreenGame'
export default {
    data () {
        return {
            isAuth: null, //是否授权
            isShowDraw: false, // 是否显示
            prizeStatus: 0, // 抽奖状态
            titleImg: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/0735265a72714fe49e87c714ca0351ea.png ',
            bigScreenImg: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/adc16b04c5b8493aa2a51026d996a47e.png',
            setIntervalStatus: null,
            roundId:null,
            isShowDialog: false

        }
    },
    components:{
        AuthBtn
    },
    computed: {
        ...mapState(['vipInfo', 'isLogined', 'isVip', 'wxUserInfo'])
    },
    onShow(){
        clearInterval(this.setIntervalStatus)
        this.setIntervalStatus = null
        this.roundId = utils.getCurrentPageUrlWithArgs().roundId
        this.updateStatus()
        //刷新session
        wxUtils.getUserSession()
        let userInfo = wxUtils.getUserStorage()
        userInfo ? (this.isAuth = true) : (this.isAuth = false)
        this.setIntervalStatus = setInterval(() => {
            this.updateStatus()
        }, 1000)
    },
    computed: {
        ...mapState(['vipInfo', 'isLogined', 'isVip', 'wxUserInfo'])
    },
    onUnload() {
        console.log('onUnload')
        clearInterval(this.setIntervalStatus)
        this.setIntervalStatus = null
        this.isShowDialog = false
        this.isShowDraw = false
        this.prizeStatus = 0
    },
    onHide() {
        console.log('onHide')
        clearInterval(this.setIntervalStatus)
        this.setIntervalStatus = null
        this.isShowDialog = false
        this.isShowDraw = false
        this.prizeStatus = 0
        this.fnEndGame()
    },
    methods: {
        ...mapMutations(['update']),
        //授权登录
        onGotUserInfo(e) {
            this.isAuth = true
        },
        //授权手机号
        getPhoneNumber(){
            console.log('phone')
            this.startGame()
        },
        closeDialog(){
            this.isShowDialog = false
        },
        //游戏结束
        fnEndGame(){
            bigScreenGame.endGame(this.roundId, res => {})
        },
        //游戏开始
        startGame(){

            if (this.status === 2) {
                let _this = this
                this.isShowDialog = true
                clearInterval(this.setIntervalStatus)
                this.setIntervalStatus = null

            } else if (this.status === 1) {
                wx.showToast({
                    title: '不好意思，游戏正在进行中',
                    icon: 'none',
                    duration: 2000
                })
                return
            } else {
                this.fnStartGame()
            }

        },
        //开始游戏
        fnStartGame() {
            if (!this.setIntervalStatus) {
                this.setIntervalStatus = setInterval(() => {
                    this.updateStatus()
                }, 1000)
            }
            let wxUserInfo = wx.getStorageSync('vipInfo')
            bigScreenGame.startGame(this.roundId, wxUserInfo.memberCode, res => {
                if (res.data.data.code === 0) {
                    this.isShowDraw = true
                    this.prizeStatus = 1
                } else if (res.data.data.code === 1000) {
                    this.isShowDialog = true
                    // wx.showToast({
                    //     title: '二维码已过期，请至屏幕前重新扫码',
                    //     icon: 'none',
                    //     duration: 2000
                    // })
                }
            })
        },
        //轮询游戏状态
        updateStatus() {
            let t = this
            bigScreenGame.updateStatus(this.roundId, res => {
                if (!res.data.data) {
                    return
                }
                this.status = res.data.data.status
                if(this.status === 2){
                    this.isShowDraw = false
                    this.prizeStatus = 0
                }
               
            })
        },

    },
    beforeDestroy() {
        clearInterval(this.setIntervalStatus)
        this.setIntervalStatus = null
    },


}
</script>

<style lang="less">
page {
    height: 100%;
    width: 100%;
    overflow-y: hidden;
}
.page-face{
    width: 100%;
    height: 100%;
    background:linear-gradient(134deg,rgba(29,203,68,1) 0%,rgba(77,180,179,1) 18%,rgba(76,180,177,1) 64%,rgba(29,203,68,1) 100%);
    .page-title{
        padding: 18% 14px 0;
        img{
            width: 347px;
            height: 121px;
        }
    }
    .game-btn-box{
        width: 227px;
        height: 253px;
        margin: 12% auto;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/18456b0b3cac48ecb438f19b5ba78957.png') no-repeat center center;
        background-size: 100% 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        .game-btn{
            width: 174px;
            height: 172px;
            background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/d078c7e809ea423eb056e14ef618ef5f.png') no-repeat center center;
            background-size: 100% 100%;
            span {
                text-align: center;
                width: 100%;
                padding: 0;
            }
        }
        .isAuth-btn{
            background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191225/02214062b91c4746a364a3c8c622b8ae.png') no-repeat center center;
            background-size: 100% 100%;
        }
    }
    //抽奖失败模态框
    .cant-draw {
        position: fixed;
        z-index: 999;
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 100;
        .main {
            width: 302px;
            height: 279px;
            box-sizing: border-box;
            padding: 45px 0 25px;
            margin: 50% auto 0;
            text-align: center;
            background:linear-gradient(134deg,rgba(29,203,68,1) 0%,rgba(77,180,179,1) 18%,rgba(76,180,177,1) 64%,rgba(29,203,68,1) 100%);
            border-radius:12px;
            .bigScreen-img{
                display: block;
                margin: 0 auto;
                width:101px;
                height:101px;
                background:#B0DEDC;
                border-radius: 50%;
                text-align: center;
                box-sizing: border-box;
                padding-top: 14px;
                img{
                    width: 45px;
                    height: 74px;
                }
            }
            p {
                max-width: 90%;
                margin: 0 auto;
                font-size: 17px;
                color: #fff;
                padding-top: 38px;
            }
        }
    }
    .qrcode-dialog{
        position: fixed;
        z-index: 999;
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 100;
        .main{
            width: 302px;
            height: 279px;
            box-sizing: border-box;
            padding: 45px 0 25px;
            margin: 50% auto 0;
            text-align: center;
            background:linear-gradient(134deg,rgba(29,203,68,1) 0%,rgba(77,180,179,1) 18%,rgba(76,180,177,1) 64%,rgba(29,203,68,1) 100%);
            border-radius:12px;
            color: #fff;
            p{
                text-align: center;
                margin-top: 65px;
            }
            .qrcode-dialog_close{
                position: absolute;
                z-index: 99;
                top: 134px;
                right: 34px;
                width: 38px;
                height: 38px;
                image {
                    width: 38px;
                    height: 38px;
                }
            }
        }
    }

}
</style>