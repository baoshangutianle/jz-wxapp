<template>
    <div class="scene-taking-photo">
        <div class="slogan" />
        <div class="game-btn-box">
            <div v-if="!vipInfo"
                 class="game-btn">
                <auth-btn v-if="!isAuth && !vipInfo"
                          auth="user"
                          @pass="onGotUserInfo" />
                <auth-btn v-if="isAuth && !vipInfo"
                          auth="phone"
                          @pass="getPhoneNumber" />
                <div v-if="vipInfo"
                     class="game-btn" />
            </div>
        </div>
        <div class="logo" />
        <div v-if="showMask"
             class="mask" />
        <div v-if="showMask"
             class="alert">
            <div class="alert-img" />
            <div class="alert-title">已经授权成功哦！请关注大屏</div>
        </div>
    </div>
</template>

<script>
import utils from '@/plugins/utils'
import { mapState, mapMutations } from 'vuex'
import AuthBtn from '@/components/AuthBtn'
import wxUtils from '@/plugins/wxUtils'
import bigScreenGame from '@/plugins/bigScreenGame'
export default {
    components: {
        AuthBtn
    },
    data() {
        return {
            showMask: false,
            isAuth: null, //是否授权
            roundId: null
        }
    },
    computed: {
        ...mapState(['vipInfo', 'wxUserInfo'])
    },
    mounted() {
        this.roundId = utils.getCurrentPageUrlWithArgs().roundId //1291
        let userInfo = wxUtils.getUserStorage()
        userInfo ? (this.isAuth = true) : (this.isAuth = false)
        this.updateRound()
    },
    methods: {
        onGotUserInfo(e) {
            this.isAuth = true
        },
        getPhoneNumber() {
            this.updateRound()
        },
        updateRound() {
            if (this.vipInfo && this.vipInfo.id) {
                bigScreenGame.updateRoundMsg(
                    this.roundId,
                    {
                        data: JSON.stringify({
                            id: this.vipInfo.id,
                            avatarUrl: this.vipInfo.avatarUrl,
                            nickName: this.wxUserInfo.userInfo.nickName
                        })
                    },
                    () => {
                        this.showMask = true
                        setTimeout(() => {
                            wx.switchTab({ url: '/pages/home' })
                        }, 10000)
                    }
                )
            }
        }
    }
}
</script>

<style lang="less">
page {
    height: 100%;
    width: 100%;
    overflow-y: hidden;
}
.scene-taking-photo {
    width: 100%;
    height: 100%;
    background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/766b4cb6016d4369ba83ea7f85080c36.png');
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    .game-btn-box {
        width: 185px;
        height: 72px;
        background-size: cover;
        position: absolute;
        bottom: 200px;
        .game-btn {
            width: 100%;
            height: 100%;
            background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/71a5dc9e65a54e66856b0dfdffe5c8c6.png');
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
    }
    .slogan {
        width: 360px;
        height: 150px;
        background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/9e9c906fb13047b39e28df2e67e91732.png');
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        position: absolute;
        bottom: 500px;
    }
    .logo {
        width: 120px;
        height: 54px;
        background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/1d5df097635a49deb4e698fcdccc93ef.png');
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        position: absolute;
        bottom: 66px;
    }
    .mask {
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 1);
        opacity: 0.7798999999999999;
    }
    .alert {
        width: 302px;
        height: 279px;
        background: linear-gradient(134deg, rgba(61, 79, 166, 1) 0%, rgba(61, 84, 193, 1) 28%, rgba(47, 76, 212, 1) 65%, rgba(29, 203, 68, 1) 100%);
        border-radius: 12px;
        position: absolute;
        z-index: 2;
        .alert-img {
            width: 100px;
            height: 100px;
            position: absolute;
            left: 50%;
            margin-left: -50px;
            top: 45px;
            background-image: url(https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/1c003d8b64084d44bd8eacacfd66c5f1.png);
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
        .alert-title {
            bottom: 40px;
            position: absolute;
            left: 50%;
            margin-left: -100px;
            text-align: center;
            width: 200px;
            height: 56px;
            font-size: 20px;
            font-weight: 400;
            color: rgba(255, 255, 255, 1);
        }
    }
}
</style>
