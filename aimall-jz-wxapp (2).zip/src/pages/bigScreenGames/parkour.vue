<template>
    <div class="game-container">
        <div class="game-title">
            <h1>真人酷跑</h1>
        </div>
        <div class="game-description">
            <h1>全民运动跑赢人生得大奖</h1>
        </div>
        <div class="game-btn">
            <div class="game-btn-box">
                <LoginGame :type="type"
                           :is-get-phone-num="isGetPhoneNum"
                           :activity-id="activityId"
                           :is-parkour="true"
                           @updateIsGetPhone="updateIsGetPhone"
                           @updateType="updateType"
                           @playGame="playGame" />
            </div>
        </div>
        <div class="game-logo">
            <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/0927bafad951400abd6008e3edfc00eb.png"
                 alt="">
        </div>
        <div :class="{'show-result':showResult}"
             class="result-mask">
            <div v-if="isShowPrize"
                 class="result-dialog">
                <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/navigation/wxapp/result-dialog-bg.jpg">
                <div v-if="prizeObj.flag"
                     class="coin win">
                    <img :src="prizeObj.prizeImageUrl"
                         alt="">
                </div>
                <div v-if="!prizeObj.flag"
                     class="coin lose" />
                <div class="coin-result">

                    <div class="get-coin">恭喜 ！赢取
                        <span>{{ coinCount }}</span> 个金币
                    </div>
                </div>
                <div :class="{'show-cousel':prizeObj.flag}"
                     class="win-cousel">送你一张{{ prizeName }}
                </div>
                <div :class="{'win-description':prizeObj.flag,'lose-description':!prizeObj.flag}"
                     class="result-text">{{ resultTextDescription }}
                </div>
                <div class="return-home"
                     @click="goHome">返回首页
                </div>
                <div class="game-again"
                     @click="reset">再玩一次
                </div>
                <div class="coin-description">金币仅限娱乐，单次游戏有效！
                </div>
            </div>
            <div v-if="isShowCountDown"
                 class="game-countDown">
                <p class="game-countDown-tips">请在大屏玩游戏</p>
            </div>
        </div>
    </div>

</template>

<script>
import utils from '@/plugins/utils'
import request from '@/plugins/request'
import api from '@/plugins/api'
import wxUtils from '@/plugins/wxUtils'
import { type } from 'os'
import bigScreenGame from '@/plugins/bigScreenGame'
import LoginGame from '@/components/LoginGame'

export default {
    components: {
        LoginGame
    },
    data() {
        return {
            type: null,
            isGetPhoneNum: null,
            gameTime: '',
            showGameTime: '',
            setInterval: null,
            setIntervalStatus: null,
            isShowDialog: false,
            isShowCountDown: true,
            isShowPrize: false,
            isCloseDialog: true,
            isWinPrize: true,
            status: '',
            errMsg: '',
            prizeName: '',
            prizeImageUrl: '',
            roundId: '',
            isHaveOtherNum: '',
            prizeObj: {},
            activityId: null,
            showResult: false,
            winPrize: true,
            resultText: '你是全跑道最帅的仔',
            resultTextDescription: '再接再厉哦～',
            coinCount: 0
        }
    },
    mounted() {
        clearInterval(this.setIntervalStatus)
        //this.roundId = utils.getCurrentPageUrlWithArgs().roundId
        this.roundId = 862
        this.fnGetGameTime()
    },
    onUnload() {
        clearInterval(this.setIntervalStatus)
        // 返回跳转爱琴海首页
        wx.reLaunch({
            url: '/pages/home'
        })
    },
    methods: {
        updateIsGetPhone(val) {
            this.isGetPhoneNum = val
        },
        updateType(val) {
            this.type = val
        },
        goHome() {
            clearInterval(this.setIntervalStatus)
            // 返回跳转爱琴海首页
            wx.reLaunch({
                url: '/pages/home'
            })
        },
        //开始游戏
        playGame(val) {
            this.isHaveOtherNum = val
            // if (!this.isHaveOtherNum) {
            //     wx.showToast({
            //         title: '不好意思，没有剩余游戏次数了',
            //         icon: 'none',
            //         duration: 2000
            //     })

            //     return false
            // } else {
            if (this.status === 1) {
                wx.showToast({
                    title: '当前游戏已经开始',
                    icon: 'none',
                    duration: 2000
                })
                return false
            }
            let _this = this
            if (this.status === 2) {
                // 只允许从相机扫码
                wx.scanCode({
                    onlyFromCamera: false,
                    success(res) {
                        // _this.roundId = res.result //todo
                        _this.roundId = res.result.split('?')[1].split('=')[1] //todo
                        _this.fnStartGame()
                        _this.setIntervalStatus = setInterval(() => {
                            _this.updateStatus()
                        }, 1000)
                    }
                })
            } else {
                _this.fnStartGame()
                _this.setIntervalStatus = setInterval(() => {
                    _this.updateStatus()
                }, 1000)
            }

            // }
        },
        fnStartGame() {
            bigScreenGame.startGame(this.roundId, res => {
                this.updateRoundMsg()
                this.showResult = true
                this.isCloseDialog = true
            })
        },
        fnGetGameTime() {
            bigScreenGame.getParkOurGameTime(res => {
                this.gameTime = res.data.data.roundDuration
                this.activityId = res.data.data.activityId
            })
        },
        fnEndGame() {
            bigScreenGame.endGame(this.roundId, res => {})
        },
        updateStatus() {
            let sessionId = wx.getStorageSync('sessionId')
            bigScreenGame.updateStatus(this.roundId, res => {
                this.status = res.data.data.status
                let data = res.data.data.data ? JSON.parse(res.data.data.data) : ''
                if (data && data.sessionId) return
                if (data && !data.flag && this.isCloseDialog) {
                    this.showResult = true
                    this.isShowCountDown = false
                    this.isShowPrize = true
                    this.isCloseDialog = false
                    this.coinCount = data.coinCount
                    this.prizeObj = data
                } else if (data && data.flag && this.isCloseDialog) {
                    this.fnGetDrawsNum()
                    this.showResult = true
                    this.isShowCountDown = false
                    this.isShowPrize = true
                    this.isCloseDialog = false
                    this.prizeName = data.prizeName
                    this.prizeImageUrl = data.prizeImageUrl
                    this.coinCount = data.coinCount
                    this.resultTextDescription = '请去南海嘉洲广场小程序-我的-我的优惠券查找使用'
                    this.prizeObj = data
                }
            })
        },
        updateRoundMsg() {
            let wxUserInfo = wxUtils.getUserStorage()
            let obj = {
                sessionId: wx.getStorageSync('sessionId'),
                avatarUrl: wxUserInfo && wxUserInfo.userInfo.avatarUrl,
                nickName: wxUserInfo && wxUserInfo.userInfo.nickName,
                remainNum: this.isHaveOtherNum
            }

            let data = {
                data: JSON.stringify(obj)
            }
            bigScreenGame.updateRoundMsg(this.roundId, data, res => {})
        },
        fnGetDrawsNum() {
            const sessionId = wx.getStorageSync('sessionId')

            bigScreenGame.fnGetDrawsNum(this.activityId, sessionId, res => {
                this.isHaveOtherNum = res.data.data
            })
        },
        reset() {
            this.isShowPrize = false
            this.showResult = false
            this.isShowCountDown = true
            this.isCloseDialog = false
            clearInterval(this.setInterval)
            this.roundId++
            this.status = 0
            this.playGame()
        },
        checkPrize() {
            this.reset()
            wx.navigateTo({
                url: '/pagesMine/card'
            })
        }
    },
    beforeDestory() {
        // clearInterval(this.setInterval)
        clearInterval(this.setIntervalStatus)
    }
}
</script>

<style lang="less">
page {
    height: 100%;
    width: 100%;
}
.game-container {
    height: 100%;
    width: 100%;
    background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/navigation/wxapp/parkour-bg.png');
    background-size: 100%, 100%;
    position: relative;
    display: flex;
    flex-direction: column;
    .game-title {
        position: absolute;
        left: 61px;
        top: 42px;
        width: 260px;
        height: 91px;
        text-align: center;
        h1 {
            font-family: PingFangSC-Semibold;
            font-size: 64.8px;
            color: #ffffff;
        }
    }
    .game-description {
        position: absolute;
        left: 30px;
        top: 131px;
        width: 321px;
        height: 41px;
        text-align: center;
        h1 {
            font-family: PingFangSC-Light;
            font-size: 29.16px;
            color: #ffffff;
        }
    }
    // .start-game {

    // }
    > .game-btn {
        flex: 1 1 auto;
        display: flex;
        justify-content: center;
        z-index: 99;
    }
    .game-logo {
        padding-bottom: 60px;
        display: flex;
        justify-content: center;
        z-index: 2;
        img {
            width: 97px;
            height: 44px;
        }
    }
    .game-dialog {
        z-index: 999;
    }
    .result-mask {
        background: rgba(0, 0, 0, 0.8);
        display: none;
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        z-index: 9999;
        &.show-result {
            display: block;
        }
        .result-dialog {
            z-index: 9999;
            position: absolute;
            top: 80px;
            left: 43px;
            width: 289px;
            height: 432px;
            opacity: 1;
            img {
                width: 100%;
                height: 100%;
            }
            .circle-jinbi(@n, @percent, @i) when (@i < @n) {
                @a: @n - 1;
                @b: 1 / @a * @percent;
                @c: @b * @i;
                @x: round(@c, 2);
                @selector: e('@{x}%');
                @j: @i + 1;
                @{selector} {
                    background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/navigation/wxapp/jinbi/@{j}.png');
                    transform: scale(2, 2);
                }
                .circle-jinbi(@n, @percent, (@i + 1));
            }
            @keyframes coin-roate {
                .circle-jinbi(90, 100, 0);
            }
            .coin {
                display: none;
                &.lose {
                    display: block;
                    position: absolute;
                    top: 154px;
                    left: 99px;
                    width: 92px;
                    height: 92px;
                    background-size: 100% 100%;
                    animation: coin-roate 3.5s linear 0s infinite;
                }
                &.win {
                    position: absolute;
                    display: block;
                    top: 130px;
                    left: 109px;
                    width: 71px;
                    height: 71px;
                    img {
                        width: 100%;
                        height: 100%;
                    }
                }
            }
            .coin-result {
                position: absolute;
                top: 50px;
                width: 100%;
                height: 38px;
                .get-coin {
                    span {
                        color: #f3c56d;
                    }
                    font-family: PingFangHK-Medium;
                    color: #ffffff;
                    text-align: center;
                    height: 100%;
                    font-size: 17px;
                }
            }
            .win-cousel {
                position: absolute;
                width: 100%;
                height: 22px;
                font-family: PingFangHK-Medium;
                font-size: 16px;
                color: #ffffff;
                text-align: center;
                top: 225px;
                display: none;
                &.show-cousel {
                    display: block;
                }
            }
            .result-text {
                position: absolute;
                width: 100%;
                height: 22px;
                font-family: PingFangHK-Medium;
                font-size: 16px;
                color: #ffffff;
                text-align: center;
                line-height: 22px;
                top: 250px;
                &.win-description {
                    font-size: 12px;
                    color: #ffffff;
                    opacity: 0.6;
                }
                &.lose-description {
                    top: 74px;
                }
            }
            .return-home {
                position: absolute;
                width: 112px;
                height: 47px;
                left: 22px;
                display: flex;
                align-items: center;
                justify-content: center;
                background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/navigation/wxapp/return-home.png');
                font-family: PingFangHK-Medium;
                font-size: 14.4px;
                color: #cccfd8;
                background-size: 100%, 100%;
                top: 347px;
            }
            .game-again {
                position: absolute;
                width: 112px;
                height: 47px;
                left: 155px;
                display: flex;
                align-items: center;
                justify-content: center;
                background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/navigation/wxapp/return-home.png');
                font-family: PingFangHK-Medium;
                font-size: 14.4px;
                color: #cccfd8;
                background-size: 100%, 100%;
                top: 347px;
            }
        }
    }
    .game-countDown {
        text-align: center;
        color: #ffffff;
        position: relative;
        .game-countDown-tips {
            padding: 100px 36px 38px 36px;
            font-family: PingFangHK-Semibold;
            font-size: 40px;
            letter-spacing: 3.18px;
        }
        .game-countDown-distanceEnd {
            font-family: PingFangHK-Regular;
            font-size: 18px;
            letter-spacing: 1.43px;
            margin-bottom: 32px;
        }
        // .game-countDown-bg {
        //     width: 176.7px;
        //     height: 176.7px;
        //     background-image: url('../../static/images/cutDown.png');
        //     background-size: 100%,100%;
        //     top:256px;
        //     border-radius: 50%;
        //     position: absolute;
        //     left: 0;
        //     right: 0;
        //     margin: 0 auto;
        //     display: flex;
        //     justify-content: center;
        //     align-items: center;
        //     .game-countDown-second{
        //         position: relative;
        //         span {
        //             display: inline-block;
        //             color: #ffffff;
        //             letter-spacing: 2.38px;
        //         }
        //         span:nth-child(1) {
        //             font-size: 50px;
        //         }
        //         span:nth-child(2) {
        //             position: absolute;
        //             right: -12px;
        //             top: 0;
        //             font-size: 30px;
        //         }
        //     }
        // }
    }
}
</style>
