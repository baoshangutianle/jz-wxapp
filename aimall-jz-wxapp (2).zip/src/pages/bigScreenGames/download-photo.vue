<template>
    <div class="download-photo">
        <img :src="imgURL"
             class="photo">
        <div class="download"
             @click="saveImageToLocal">下载照片</div>
        <div class="logo" />
    </div>
    </div>
</template>
<script>
import utils from '@/plugins/utils'
const BASE_URL_AIGAME = process.env.BASE_URL_AIGAME
export default {
    data() {
        return {
            imgURL: '',
            roundId: ''
        }
    },
    mounted() {
        this.roundId = utils.getCurrentPageUrlWithArgs().roundId //1291
        // this.roundId = 1416
        this.getImage()
    },
    methods: {
        //拿到图片的临时路径
        getImageInfo(url) {
            var cache = {}
            return new Promise((resolve, reject) => {
                /* 获得要在画布上绘制的图片 */
                if (cache[url]) {
                    resolve(cache[url])
                } else {
                    const objExp = new RegExp(/^http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w- .\/?%&=]*)?/)
                    if (objExp.test(url)) {
                        wx.getImageInfo({
                            src: url,
                            complete: res => {
                                if (res.errMsg === 'getImageInfo:ok') {
                                    cache[url] = res.path
                                    resolve(res.path)
                                } else {
                                    reject(new Error('getImageInfo fail'))
                                }
                            }
                        })
                    } else {
                        this.cache[url] = url
                        resolve(url)
                    }
                }
            })
        },
        saveImageToLocal() {
            //保存临时图片到本地
            this.getImageInfo(this.imgURL).then(path => {
                wx.saveImageToPhotosAlbum({
                    filePath: path,
                    success(res) {
                        wx.showToast({
                            icon: 'success',
                            title: '保存成功'
                        })
                    },
                    fail(res) {
                        wx.showToast({
                            icon: 'fail',
                            title: '保存失败'
                        })
                    }
                })
            })
        },
        async getImage() {
            const that = this
            const BASE_URL_AIGAME = 'https://aegeanpark-stg.aimall.cloud/api-aifun'
            wx.request({
                url: `${BASE_URL_AIGAME}/round/${this.roundId}`,
                method: 'get',
                success(res) {
                    const result = res.data.data.data
                    const imageKey = result && JSON.parse(result) && JSON.parse(result).imageKey
                    that.imgURL = 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/aifun/' + imageKey
                }
            })
        }
    }
}
</script>

<style lang="less">
page {
    height: 100%;
    width: 100%;
    overflow-y: hidden;
}
.download-photo {
    width: 100%;
    height: 100%;
    background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/766b4cb6016d4369ba83ea7f85080c36.png');
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    .photo {
        width: 250px;
        height: 434px;
        border: 8px solid rgba(248, 216, 0, 1);
        position: absolute;
        bottom: 250px;
    }
    .download {
        position: absolute;
        left: 50%;
        margin-left: -72px;
        bottom: 158px;
        width: 145px;
        height: 55px;
        background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/7b0157869eb94efd86abcb6ddbd79d48.png');
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        text-align: center;
        font-size: 18px;
        font-weight: 600;
        color: rgba(61, 79, 166, 1);
        line-height: 50px;
    }
    .logo {
        width: 120px;
        height: 54px;
        background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/1d5df097635a49deb4e698fcdccc93ef.png');
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        position: absolute;
        left: 50%;
        margin-left: -60px;
        bottom: 66px;
    }
}
</style>
