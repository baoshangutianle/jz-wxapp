<template>
    <div class="game-container">
        <img
            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/1914d4f244b84b0fb8fa0ce188d7c872.png"
            class="citybg">
        <div class="game-title">
            <h1>一起来玩游戏吧</h1>
        </div>
        <div class="game-btn">
            <div class="game-btn-box">
                <LoginGame
                    :type="type"
                    :isGetPhoneNum="isGetPhoneNum"
                    :gameBtnBoxBg="'rgba(211,71,70,.18)'"
                    :gameBtnBg="'#D34746'"
                    :activityId="activityId"
                    @updateIsGetPhone="updateIsGetPhone"
                    @updateType="updateType"
                    @playGame="playGame">
                </LoginGame>
            </div>
        </div>
        <div class="game-logo">
            <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/0927bafad951400abd6008e3edfc00eb.png"
                 alt="">
        </div>
        <GameDialog
            :isShowDialog="isShowDialog"
            :isShowCountDown="isShowCountDown"
            :showGameTime="showGameTime"
            :isWinPrize="isWinPrize"
            :prizeObj="prizeObj"
            :isShowPrize="isShowPrize"
            :isHaveOtherNum="isHaveOtherNum"
            @reset="reset"
            @checkPrize="checkPrize"
        ></GameDialog>

    </div>

</template>

<script>
import utils from '@/plugins/utils'
import request from '@/plugins/request'
import api from '@/plugins/api'
import wxUtils from '@/plugins/wxUtils'
import { type } from 'os'
import bigScreenGame from '@/plugins/bigScreenGame'
import LoginGame from '@/components/LoginGame'
import GameDialog from '@/components/GameDialog'


export default {
    components: {
        LoginGame,GameDialog
    },
    data() {
        return {
            type: null,
            isGetPhoneNum: null,
            gameTime: '',
            showGameTime: '',
            setInterval: null,
            setIntervalStatus: null,
            isShowDialog: false,
            isShowCountDown: true,
            isShowPrize: false,
            isCloseDialog: true,
            isWinPrize: true,
            status:'',
            errMsg:'',
            prizeName:'',
            prizeImageUrl:'',
            roundId: '',
            isHaveOtherNum:'',
            prizeObj:{},
            activityId: null,
        }
    },
    mounted() {
        clearInterval(this.setInterval)
        this.roundId = utils.getCurrentPageUrlWithArgs().roundId;
        this.fnGetGameTime();

    },
    onUnload(){
        clearInterval(this.setInterval)
        clearInterval(this.setIntervalStatus)
        // 返回跳转南海嘉洲广场首页
        wx.reLaunch({
            url: '/pages/home',
        });
    },
    methods: {
        updateIsGetPhone(val){
            this.isGetPhoneNum = val
        },
        updateType(val){
            this.type = val
        },
        //开始游戏
        playGame(val) {
            this.isHaveOtherNum = val;
            if(!this.isHaveOtherNum) {
                wx.showToast({
                    title: '不好意思，没有剩余游戏次数了',
                    icon: 'none',
                    duration: 2000
                })

                return false;

            }else{
                let _this = this;
                // 只允许从相机扫码
                wx.scanCode({
                    onlyFromCamera: false,
                    success (res) {
                        // _this.roundId = res.result;  //todo
                        _this.roundId =  res.result.split('?')[1].split('=')[1]; //todo
                        // console.log('scanCode', res)
                        _this.fnStartGame()
                        _this.setIntervalStatus = setInterval(()=>{
                            _this.getLedRoundMsg();
                        },1000)
                    }
                })

            }



        },
        fnStartGame(){
            bigScreenGame.startGame(this.roundId, res => {
                this.updateLedRoundMsg();
                this.isShowDialog = true;
                this.showGameTime = this.gameTime;
                this.isCloseDialog = true;
                this.setInterval = setInterval(() => {
                    if (this.showGameTime === 1) {
                        clearInterval(this.setInterval)

                        this.isShowPrize = false;
                        this.isShowCountDown = true;
                        this.isShowDialog = false;
                        this.isCloseDialog = false;

                    } else {
                        this.showGameTime--
                    }
                }, 1000)
            })
        },
        fnGetGameTime() {
            bigScreenGame.getLedGameTime(res => {
                this.gameTime = res.data.data.roundDuration
                this.activityId = res.data.data.activityId
            })
        },
        getLedRoundMsg(){
            let sessionId = wx.getStorageSync('sessionId');

            bigScreenGame.getLedRoundMsg(this.roundId, sessionId, res => {

                let data = res.data.data ? JSON.parse(res.data.data) : '';
                if(data && data.sessionId) return;

                if(data && !data.flag && this.isCloseDialog){
                    this.isShowDialog = true;
                    this.isShowCountDown = false;
                    this.isShowPrize = true;
                    this.isWinPrize = false;
                    this.isCloseDialog = false;
                    this.errMsg = data.errMsg;
                    this.prizeObj = data;

                }else if(data && data.flag && this.isCloseDialog){
                    this.fnGetDrawsNum();
                    this.isShowDialog = true;
                    this.isShowCountDown = false;
                    this.isShowPrize = true;
                    this.isWinPrize = true;
                    this.isCloseDialog = false;
                    this.prizeName = data.prizeName;
                    this.prizeImageUrl = data.prizeImageUrl;
                    this.prizeObj = data;
                }
            })
        },
        updateLedRoundMsg(){
            let wxUserInfo = wxUtils.getUserStorage();
            let obj = {
                sessionId: wx.getStorageSync('sessionId'),
                avatarUrl: wxUserInfo && wxUserInfo.userInfo.avatarUrl,
                nickName: wxUserInfo && wxUserInfo.userInfo.nickName
            }

            let data = {
                data: JSON.stringify(obj)
            }
            bigScreenGame.updateLedRoundMsg(this.roundId, data, res => {})
        },
        fnGetDrawsNum(){
            const sessionId = wx.getStorageSync('sessionId');

            bigScreenGame.fnGetDrawsNum(this.activityId, sessionId, res => {
               this.isHaveOtherNum = res.data.data;
            })


        },
        reset() {
            this.isShowPrize = false
            this.isShowCountDown = true
            this.isShowDialog = false
            this.isCloseDialog = false
            clearInterval(this.setInterval)
        },
        checkPrize(){
            this.reset();
            wx.navigateTo({
                url: '/pagesMine/card'
            })
        }
    },
    beforeDestory() {
        clearInterval(this.setInterval)
        clearInterval(this.setIntervalStatus)
    }
}
</script>

<style lang="less">
page {
    height: 100%;
    width: 100%;
}
.game-container {
    height: 100%;
    width: 100%;
    background: #99D5DA;
    position: relative;
    display: flex;
    flex-direction: column;
    .citybg{
        width: 100%;
        height: 248px;
        bottom: 0;
        left: 0;
        position: absolute;
        z-index: 1;
    }
    .game-title {
        padding-top: 120px;
        padding: 120px 0 58px;
        text-align: center;
        h1{
            font-family: PingFangHK-Semibold;
            font-size: 30px;
            color: #D34746;
            letter-spacing: 2.38px;
        }
    }
    > .game-btn {
        flex: 1 1 auto;
        display: flex;
        justify-content: center;
        z-index: 99;
    }
    .game-logo {
        padding-bottom: 60px;
        display: flex;
        justify-content: center;
        z-index: 2;
        img {
            width: 97px;
            height: 44px;
        }
    }
    .game-dialog{
        z-index: 999;
    }
}
</style>
