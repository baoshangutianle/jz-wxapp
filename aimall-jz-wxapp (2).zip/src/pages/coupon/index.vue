<template>
    <div class="coupon-container">
        <!-- <div class="search-btn">
            <div class="search-btn-wrap">
                <img
                    class="icon-search"
                    src="/static/images/icon-common-search@2x.png"
                >
                <input
                    id="search"
                    v-model="ipt"
                    class="search-input"
                    type="text"
                    placeholder="搜索"
                    @confirm="searchPopConfrim"
                >
                <img
                    v-show="ipt"
                    class="btn-clear"
                    src="/static/images/icon-common-clear@2x.png"
                    @tap="clearSearch"
                >
            </div>

        </div> -->
        <div class="coupon-con">
            <ul>
                <li
                    v-for="(item,index) in list"
                    :key="index"
                    class="flex-wrp coupon-item"
                >
                    <coupon-item :data="item" />
                </li>
            </ul>
            <load-more v-if="reachFinish" />
            <blank-page
                :show-blank-page="hasFetchData&&list.length===0"
                :blank-page-content="`“${ipt}…”`"
            />
        </div>
    </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import utils from '@/plugins/utils'
import ConditionFiltr from '@/components/ConditionFiltr'
import CouponItem from '@/components/CouponItem'
import SearchComp from '@/components/SearchComp'
import AuthBtn from '@/components/AuthBtn'
import BlankPage from '@/components/blankPage'
import { getCouponNormalBatchPage, getCouponBatchPage } from '@/service/mine'
import wxUtils from '@/plugins/wxUtils'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import loadMore from '@/components/loadMore'
export default {
    components: {
        ConditionFiltr,
        CouponItem,
        SearchComp,
        AuthBtn,
        BlankPage,
        loadMore
    },
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            loaderMore: false,
            isDataFinish: false, // 数据加载完成状态
            ipt: '',
            isSearchFocus: false,
            isClear: false,
            isShowModal: false,
            reachFinish: false,
            filterData: [
                {
                    title: '智能排序',
                    data: [
                        {
                            name: '最新',
                            value: ''
                        },
                        {
                            name: '最热',
                            value: 'time'
                        }
                    ]
                },
                {
                    title: '筛选',
                    data: [
                        {
                            name: '商场发布',
                            value: '1'
                        },
                        {
                            name: '门店发布',
                            value: '2'
                        }
                    ]
                }
            ],
            updateIsShow(val) {
                this.isShowModal = val
            },
            page: {
                pageNum: 1,
                pageSize: 10,
                total: 0
            },
            list: [],
            hasFetchData: false //拉取数据状态
        }
    },
    computed: {
        ...mapState(['mallCode', 'sessionId'])
    },
    mounted() {
        this.resetRefresh()
    },
    methods: {
        goDetail(data) {
            let { couponId, couponBatchId, chargeOffStatus } = data
            wx.navigateTo({
                url: `/pages/coupon/details?couponId=${couponId}&couponBatchId=${couponBatchId}&chargeOffStatus=${chargeOffStatus}`
            })
        },
        clearSearch() {
            this.list = []
            this.ipt = ""
            this.resetRefresh()
        },
        searchPopConfrim(val) {
            //埋点
            buryPoint.setF({
                id: pointCode.COUPON_F_SEARCH,
                p_action_id: this.ipt,
                p_action: this.ipt
            })
            this.resetRefresh()
        },
        resetRefresh() {
            //重置刷新
            this.list = []
            this.ipt = ""
            this.page.pageNum = 1
            this.getData()
        },
        getData(times) {
            this.hasFetchData = false
            return new Promise(async resolve => {
                let params = Object.assign({}, this.page, {
                    mallCode: this.mallCode,
                    sourtRule: 1,
                    keyWord: this.ipt
                })
                delete params.total
                this.reachFinish = false
                let res
                if (this.sessionId) {
                    res = await getCouponNormalBatchPage(params)
                } else {
                    res = await getCouponBatchPage(params)
                }
                this.hasFetchData = true
                let { list, total } = res
                list = list || []
                this.page.total = total
                list.map(item => {
                    if (!this.sessionId) {
                        item.chargeOffStatus = 0
                    }
                    item.chargedOffBeginTime = item.chargedOffBeginTime.substr(0, 10).replace(/-/g, '.')
                    item.chargedOffEndTime = item.chargedOffEndTime.substr(0, 10).replace(/-/g, '.')
                })
                if (times == 1) {
                    this.list = list
                } else {
                    this.list = this.list.concat(list)
                }
                //数据加载结束
                if (0 <= list.length && list.length < this.page.pageSize) {
                    this.isDataFinish = true
                } else {
                    this.isDataFinish = false
                }
                this.loaderMore = false
            })
        }
    },
    onShow() {
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.COUPON_P
        })
    },
    onUnload() {
        this.ipt = ''
        this.list = []
        this.hasFetchData = false

        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.COUPON_Z,
            p_stay_time: this.pageStayTime
        })
    },
    onPullDownRefresh() {
        this.loaderMore = true
        this.resetRefresh()
        wx.stopPullDownRefresh()

    },
    // 页面滚动到底部
    onReachBottom() {
        if (!this.isDataFinish && !this.loaderMore) {
            this.page.pageNum++
            this.getData()
        } else {
            if (this.list.length > 10) {
                this.reachFinish = true
            } else {
                this.reachFinish = false
            }
        }
    }
}
</script>

<style lang="less">
@import '../../assets/styles/vars';
.coupon-container {
    color: @black-color;
    .coupon-con {
        padding: 0 15px;
        padding-bottom: 15px;
        .coupon-item-navigator {
            width: 100%;
        }
        li {
            position: relative;
            margin-bottom: 20px;
            &:first-child {
                margin-top: 20px;
            }
            &:last-child {
                padding-bottom: 0px;
                margin-bottom: 0px;
            }
        }
    }
    .coupon-item {
        position: relative;
    }
    .btn-clear {
        z-index: 10;
        width: 15px;
        height: 16px;
        padding: 9.5px;
        position: absolute;
        top: 50%;
        right: 15px;
        transform: translateY(-50%);
        font-size: 15px;
    }
    .search-btn {
        .search-btn-wrap {
            background-color: #ffffff;
            border-radius: 4px;
        }
        text-align: left;
        line-height: 50%;
        .icon-search {
            position: absolute;
            top: 50%;
            left: 15%;
        }
        .search-input {
            height: 38px;
            line-height: 28px;
            width: 90%;
            background: #ffffff;
            display: inline-block;
            padding-left: 30px;
            background-color: #ffffff;
        }
    }
}
</style>
