<template>
    <div class="coupon-detail-container">
        <div class="coupon-detail-content">
            <div class="coupon-img">
                 <image
                    :src="couponUrlList[0]"
                    class="slide-image"
                    mode="aspectFill"
                />
            </div>
            <div class="coupon-cons">
                <p class="coupon-title">{{ data.couponName||'' }}</p>
                <p class="coupon-price">{{ data.couponType?(data.couponType !='3'?data.couponWorth+'元':data.discount+'折'):'' }}</p>
                <!-- <p class="coupon-date time"></p> -->
                <p class="coupon-date">有效期：{{ data.chargedOffBeginTime||'' }} 至 {{ data.chargedOffEndTime||'' }}</p>
                <p class="coupon-bg"></p>
                <coupon-rule :data="data" />
            </div>
            <div class="fix-btn">
                <button
                    v-if="data.chargeOffStatus==1"
                    class="btn-operate btn-get"
                    @tap="goDetail(data)"
                >
                    去使用
                </button>
                <button
                    v-else
                    :disabled="data.chargeOffStatus==1"
                    class="btn-operate btn-get"
                >
                    <auth-btn @pass="buy(data)" />
                    领 取
                </button>
            </div>

        </div>

    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import utils from '@/plugins/utils'
import wxUtils from '@/plugins/wxUtils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import CouponRule from '@/components/CouponRule'
import { getCouponDetail, buyCoupon, getCouponDetailNormal, getCouponStatus } from '@/service/mine'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import AuthBtn from '@/components/AuthBtn'

export default {
    components: {
        CouponRule,
        AuthBtn
    },
    data() {
        return {
            pageStayTime: 0,//页面停留时间
            data: {
            },
            status: 1,
            couponId: '',
            couponBatchId: '',
            couponCode: '',
            chargeOffStatus: null,
            couponUrlList: []
        }
    },
    computed: {
        ...mapState(['mallCode', 'sessionId'])
    },
    methods: {
        goDetail() {
            let { couponId, batchId,couponCode } = this.data
            wx.navigateTo({
                // url: `/pages/mine/cardDetail?couponId=${couponId}&couponBatchId=${batchId}`
                url: `/pagesMine/cardDetail?couponCode=${couponCode}`
            })
        },
        promotionShow(id, type) {
            let shopNo = wx.getStorageSync('accountInfo').shopVo.shopCode
            let requestOptions = {
                path: api.promotionShow,
                method: 'post',
                data: {
                    promotionId: id,
                    promotionType: type,
                    shopNo: shopNo
                }
            }
            request(requestOptions).then(res => {
                this.promotionShowResponse = res.data
            })
        },
        async getCouponDetail() {
            let params = {
                mallCode: this.mallCode,
                couponId: this.couponId,
                couponBatchId: this.couponBatchId
            }
            let data = {}
            let chargeOffStatus
            if (this.sessionId) {
                let res = await getCouponStatus(params)
                chargeOffStatus = res.chargeOffStatus
            }
            let detailData = await getCouponDetail(params)
            Object.assign(data, detailData, {
                chargeOffStatus: chargeOffStatus
            })
            data.chargedOffBeginTime = data.chargedOffBeginTime ? data.chargedOffBeginTime.substr(0, 10) : ''
            data.chargedOffEndTime = data.chargedOffEndTime ? data.chargedOffEndTime.substr(0, 10) : ''
            data.couponDesc = data.couponDesc ? data.couponDesc.replace(/\n/g, '<br>') : ''
            data.useRuleDesc = data.useRuleDesc ? data.useRuleDesc.replace(/\n/g, '<br>') : ''
            this.data = data
            this.couponUrlList = data.couponUrlList
        },
        async buy() {
            let params = {
                mallCode: this.mallCode,
                couponId: this.couponId,
                couponBatchId: this.couponBatchId,
                buyAmount: 1
            }

            await buyCoupon(params)
            utils.setPageLoadingStatus("isCouponLoading", false)
            wx.showToast({
                title: "领取成功，请到我的-卡券查看",
                icon: "none"
            })
            this.data.chargeOffStatus = 1
            this.getCouponDetail()
        }
    },
    onLoad(options) {
        this.couponId = options.couponId
        this.couponBatchId = options.couponBatchId
        this.couponCode = options.couponCode
        this.data = {}
    },
    onShow() {
    // 埋点 P
        this.data = {}
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.COUPON_DETAIL_P,
            p_id: this.couponId,
        })
        this.getCouponDetail()
    },
    onUnload() {
    //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.COUPON_DETAIL_Z,
            p_stay_time: this.pageStayTime,
            p_id: this.couponId
        })
    },
}
</script>

<style lang="less">
@import '../../assets/styles/vars';
.coupon-detail-container {
    .coupon-img {
        width: 100%;
        height: 211px;
        border-radius: 4px;
        swiper {
            height: 100%;
        }
        image {
            width: 100%;
            height: 211px;
        }
    }
    .coupon-title {
        font-size: 18px;
        padding: 13px;
        color: #333333;
    }
    .coupon-price {
        font-size: 18px;
        color: @black-color;
        padding-left: 13px;
    }
    .coupon-date {
        margin: 10px 0 15px;
        font-weight: 200;
        font-size: 15px;
        line-height: 21px;
        color: @dark-color;
        padding-left: 13px;
    }
    .coupon-bg{
        width: 100%;
        height: 12px;
        background: #F4F4F4;
    }
    .time.coupon-date {
        margin: 10px 0 0 0;
    }
    .fix-btn{
        position: fixed;
        bottom: 0px;
        width: 100%;
        height: 84px;
        background: #ffffff;
        box-shadow:0px 4px 15px 5px rgba(0,0,0,0.09);
    }
    .btn-get {
        margin-top: 10px;
    }
}
</style>
