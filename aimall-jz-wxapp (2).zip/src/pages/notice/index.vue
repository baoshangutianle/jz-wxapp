<template>
    <div id="notice">
        <div v-if="noticeResponse.length == 0"
             class="blank">
            <div class="pic">
                <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191028/19b3706b6f4b45279b7b5cef15f4e105.png">
            </div>
            <span>你还没有公告</span>
        </div>
        <div v-else>
            <div v-for="(item,index) in noticeResponse"
                 :key="index"
                 class="noticeItem"
                 @click="goToRouter(item.id)">
                <div class="left">
                    <h5>{{ item.noticeTitle }}</h5>
                    <p>{{ item.releaseTime }}</p>
                </div>
                <div class="md">
                    <div v-if="!item.readStatus"
                         class="sign">&nbsp;</div>
                </div>
                <div class="right">
                    <img src="/static/images/arrow_right.png">
                </div>
            </div>
            <loaderMore :loadermore="loaderMore">&nbsp;</loaderMore>
        </div>
    </div>
</template>

<script>
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import loaderMore from '../../components/loaderMore'

export default {
    components: {
        loaderMore
    },
    data() {
        return {
            loaderMore: true,
            findShopNoticeRequest: {
                shopId: '',
                pageNum: 1,
                pageSize: 20
            },
            noticeResponse: []
        }
    },
    onShow() {
        this.loaderMore = true
        this.noticeResponse = []
        this.findShopNoticeRequest.pageNum = 1
        this.findShopNotice(0)
    },
    methods: {
        // 获取列表
        findShopNotice(times) {
            this.findShopNoticeRequest.shopId = wx.getStorageSync('shopId')
            let requestOptions = {
                path: api.findShopNotice,
                method: 'post',
                data: this.findShopNoticeRequest
            }
            request(requestOptions).then(res => {
                if (res.data.list.length == 0) {
                    this.loaderMore = false
                    return
                }
                if (res.data.list.length < 20) this.loaderMore = false
                if (times == 1) {
                    this.noticeResponse = this.noticeResponse.concat(res.data.list)
                } else {
                    this.noticeResponse = res.data.list
                }
            })
        },
        // 查看详情
        goToRouter(id) {
            wx.navigateTo({
                url: `/pages/notice/details?id=${id}`
            })
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        this.loaderMore = true
        this.findShopNoticeRequest.pageNum = 1
        this.findShopNotice(0)
        wx.stopPullDownRefresh()
    },
    // 页面滚动到底部
    onReachBottom() {
        if (this.loaderMore) {
            this.findShopNoticeRequest.pageNum++
            this.findShopNotice(1)
        }
    }
}
</script>

<style lang="less">
#notice {
    width: 100vw;
    overflow: hidden;
    .blank {
        width: 100vw;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        align-content: center;
        flex-wrap: wrap;
        text-align: center;
        font-size: 14px;
        color: #666666;
        .pic {
            width: 100%;
            img {
                width: 190px;
                height: 150px;
                margin: 0 auto 20px;
            }
        }
    }
    .noticeItem {
        width: 100%;
        height: 80px;
        padding-left: 20px;
        padding-right: 20px;
        display: flex;
        align-items: center;
        background-color: #fff;
        border-bottom: 1px solid #e4e4e4;
        .left {
            width: 310px;
            h5 {
                width: 100%;
                font-size: 16px;
                color: #333333;
                margin-bottom: 5px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            p {
                width: 100%;
                font-size: 13px;
                color: #999999;
            }
        }
        .md {
            width: 8px;
            height: 8px;
            margin-right: 10px;
            .sign {
                width: 100%;
                height: 100%;
                border-radius: 50%;
                background-color: red;
            }
        }
        .right {
            width: 10px;
            height: 16px;
            img {
                width: 100%;
                height: 100%;
            }
        }
    }
}
</style>
