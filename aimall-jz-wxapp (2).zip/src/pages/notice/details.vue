<template>
    <div id="noticeDetails">
        <div class="details">
            <h3>{{ getNoticeResponse.noticeTitle }}</h3>
            <h5>{{ getNoticeResponse.releaseTime }}</h5>
            <div v-html="getNoticeResponse.noticeText">&nbsp;</div>
        </div>
        <div v-if="getNoticeResponse.fileList.length"
             class="enclosure">
            <h4>附件</h4>
            <p v-for="(item,index) in getNoticeResponse.fileList"
               :key="index"
               @click="downloadFile(item.fileUrl)">{{ item.fileName + item.documentType }}</p>
        </div>
    </div>
</template>

<script>
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'

export default {
    data() {
        return {
            getNoticeRequest: {
                noticeId: 0
            },
            getNoticeResponse: {
                fileList: []
            }
        }
    },
    onLoad(options) {
        this.getNoticeRequest.noticeId = options.id
        this.getNotice()
    },
    methods: {
        // 获取详细
        getNotice() {
            let requestOptions = {
                path: api.getNotice,
                method: 'get',
                data: this.getNoticeRequest
            }
            request(requestOptions).then(res => {
                this.getNoticeResponse = res.data
            })
        },
        // 附件预览
        downloadFile(url) {
            let sessionId = wx.getStorageSync('sessionId')
            let previewUrl = url + '?token=' + sessionId
            if (url.substring(url.length - 3) == 'pdf' || url.substring(url.length - 3) == 'PDF') {
                wx.downloadFile({
                    url: previewUrl, //.pdf文件地址或者可以在浏览器直接下载pdf的地址
                    success: function(res) {
                        let Path = res.tempFilePath //返回的文件临时地址，用于后面打开本地预览所用
                        wx.openDocument({
                            filePath: Path,
                            success: function(res) {
                            }
                        })
                    },
                    fail: function(res) {
                        console.log(res)
                    }
                })
            } else {
                wx.previewImage({
                    urls: [previewUrl]
                })
            }
        }
    }
}
</script>

<style lang="less">
#noticeDetails {
    padding: 30px 0;
    .details {
        padding: 0 15px 20px;
        h3 {
            font-size: 20px;
            color: #333333;
            margin-bottom: 5px;
        }
        h5 {
            font-size: 13px;
            color: #999999;
            margin-bottom: 20px;
        }
        p {
            padding: 30px 0;
            font-size: 15px;
            color: #333333;
        }
    }
    .enclosure {
        border-top: 10px solid #f5f5f5;
        padding: 15px;
        h4 {
            font-size: 16px;
            color: #444444;
        }
        p {
            font-size: 15px;
            color: #25b5c6;
        }
    }
}
</style>
