<template>
    <div class="goodsDetails">
        <swiper class="swiper" indicator-dots="true" indicator-color="#EFEFEF" indicator-active-color="#B374F8" autoplay="true" interval="3000" duration="1000">
            <block v-for="(item, index) in movies" :index="index" :key="index">
                <swiper-item>
                    <image :src="item" class="slide-image" mode="aspectFill"/>
                </swiper-item>
            </block>
        </swiper>
        <div class="count-down" v-if="isCountDown">
            <div class="left">
                <div class="top">
                    <div class="sales"><span class="icon">￥</span>{{salePrice}}</div>
                    <div class="stock">剩余{{stock}}件</div>
                </div>
                <div class="orig">原价 ¥{{goodsPrice}}</div>
            </div>
            <div class="right">
                <div class="remain">距结束剩余</div>
                <count-down :timer='timer' :colorFul='false'/>
            </div>
        </div>
        <div class="goods-info">
            <div class="goods-name">{{prodName}}</div>
            <div class="left-num" v-if="!isCountDown">库存 <span>{{stock}}</span> 件</div>
            <div class="goods-price-container" :class="{'flex-end': isCountDown}">
                <div class="goods-price" v-if="buyWay == 2 && !isCountDown">
                    <p class="goods-reality-price">
                        <span>¥</span>
                        {{salePrice}}
                    </p>
                    <p class="origin-price">原价 ¥{{totalPrice}}</p>
                </div>
                <div class="goods-price" v-if="(buyWay == 1 || buyWay == 3) && !isCountDown">
                    <p class="interal-buy">
                        <span>{{integral}}</span>
                        积分
                        <block v-if="buyWay == 3">
                            +
                            <span>{{salePrice}}</span>
                            元
                        </block>
                    </p>
                    <p class="origin-price">原价 ¥{{totalPrice}}</p>
                </div>
                <div :class="['btn-border']" >
                    <button open-type="share"><image src="../../static/images/share-icon.png" /> 分享</button>
                </div>
            </div>
        </div>
        <div class="goods-extra-info" v-if="goodType===1 || isCountDown">
            <div class="formLine1" :class="{'withComponent':pageData.specsType == 2 && isCanBuy && saveNumber&&pageData.goodsStatus!=5 }">
                <p  @click="showSku">商品规格：
                    <span >{{specsValue}}</span>
                </p>
            </div>
            <p>
                配送方式：
                <span v-if="distributeWay == 1">商场自提</span>
                <span v-if="distributeWay == 2">快递送货</span>
                <span v-if="distributeWay == 0">商场自提或快递送货</span>
            </p>
        </div>
        <div class="processBox" v-if="groupBuyingStatus==1&&!showJoinGroup">
            <Process :options="successNumber"></Process>
        </div>
        <div class="processBox" v-if="groupBuyingStatus==1&&showJoinGroup">
            <Process-list
                :options="pageData.groupSkuDetailVo.groupInfoDetailVos"
                :successNumber="needNumber"
                @goGroup="goGroup($event)"
            />
        </div>
        <div class="goods-details-container" v-if="!isCountDown">
            <p class="goods-details-title">使用须知：</p>
            <div class="goods-details-usageRule">
                <wxParse
                    v-if="usageRule"
                    :content="usageRule"
                    :image-prop="imageProp"
                />
            </div>

        </div>
        <div class="goods-details-container">
            <p class="goods-details-title">商品详情：</p>
            <div class="goods-details-remark">
                <wxParse
                    v-if="remark"
                    :content="remark"
                    :image-prop="imageProp"
                />
            </div>
        </div>
        <div :class="['bottomAdaptor',{'iphoneX': isIphoneX}]" v-if="!isCountDown">
            <div class="orderHandeler">
                <div class="price">
                    <block v-if="buyWay == 2">
                        <span>
                            <span class="dollar">￥</span>{{salePrice}}
                        </span>
                    </block>
                    <block v-if="buyWay == 1 || buyWay == 3">
                        <span>{{integral}}</span>
                        积分
                        <block v-if="buyWay == 3">
                            +
                            <span>{{salePrice}}</span>
                            元
                        </block>
                        <p>现有积分: {{availableIntegral}}积分</p>
                    </block>
                </div>
                <div v-if="isCanBuy && saveNumber &&pageData.goodsStatus!=5">
                    <div class="btnBorder" v-if='goodType==1 && !isGroupBuying && !isCountDown'>
                        <button class="addShopCar" @click="toCart">
                                加入购物车</button>
                        <button class="payNow">
                                <auth-btn @pass="jumpTo" />
                                购买</button>
                    </div>
                    <button class="singlePayNow" v-else>
                            <auth-btn @pass="jumpTo" />
                            购买</button>
                </div>
                <button class="payFail" v-if="!isCanBuy">积分不足</button>
                <button class="payFail" v-if="!saveNumber">已售罄</button>
                <button class="payFail lessGrade" v-if="pageData.goodsStatus==5">亲亲更高卡等可购哦~</button>
                <button
                class="payNow_left"
                :class="{grey: !pageData.stock}"
                v-if="isGroupBuying && groupBuyingStatus==1"
                @click="jumpTo1(1)"
                >
                <span>
                    <span class="dollarT">￥</span>
                    <span class="priceNumber" style="opacity:0.8">
                    {{aloneSalePrice}}
                    <span class="price_text">{{"单独购买"}}</span>
                    </span>
                </span>
                </button>
                <button
                class="payNow_right"
                :class="{grey: pageData.groupSkuDetailVo.groupInfoDetailVos && !pageData.groupSkuDetailVo.groupInfoDetailVos[0].currentNumber}"
                v-if="isGroupBuying && groupBuyingStatus==1"
                @click="jumpTo1(3)"
                >
                <span>
                    <span class="dollarT">￥</span>
                    <span class="priceNumber">
                    {{groupPrice}}
                    <span class="price_text" v-if="groupBuyingStatus==1">拼团购买</span>
                    </span>
                </span>
                </button>
            <!-- <button class="payNow" @click='jumpTo'>购买</button>  -->
            </div>
        </div>
        <div :class="['bottomAdaptor',{'iphoneX': isIphoneX}]" v-if="isCountDown">
            <div class="countDownBuy">
                <span class="countPrice">￥{{salePrice}}</span>
                <span class="countText"><auth-btn @pass="jumpTo" />立即购买</span>
            </div>
        </div>
        <spec-window  ref="specWindow" @toDetail='toDetail' :product='pageData'/>
    </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import wxUtils from '@/plugins/wxUtils'
import request from '@/plugins/request'
import wxParse from 'mpvue-wxparse'
import api from '@/plugins/api'
import AuthBtn from '../../components/AuthBtn'
import specWindow from '../../components/specWindow'
import countDown from '@/components/countDown'
export default {
    name: 'goodsDetails',
    components: {
        wxParse,
        AuthBtn,
        specWindow,
        countDown
    },
    data() {
        return{
            isIphoneX: wxUtils.getSystemInfo().model.indexOf('iPhone X')>=0,
            movies:[
            ],
            imageProp: {
                mode: 'widthFix'
            },
            pageData: {},
            skuData: {},
            prodName: '',
            buyWay:'',
            stock:'',
            sku: false,
            salePrice:'',
            totalPrice:'',
            //拼团购买标识
            groupBuyingStatus: "",  
            showJoinGroup: false,
            integral:'',
            specsValue:'',
            distributeWay:'',
            remark:'',
            availableIntegral:'',
            usageRule:'',
            goodType:'',
            isCanBuy: true,
            saveNumber:true,
            timer: 86400,
            isCountDown: false,
            isGroupBuying: false,
            goodsPrice: 0
        }
    },
    onShow () {
        const t = this;
        const query = t.$mp.query;
        wx.removeStorageSync('sku')
        t.skuData = '';
        if (query.roundId) {
            t.isCountDown = true;
            t.getSeckillDetails()
        } else {
            t.isCountDown = false;
            t.getGoodsDetails()
        }
    },
    onLoad (params) {
        wx.removeStorageSync('shareCode')
        if (params.shareCode) {
            wx.setStorageSync('shareCode',params.shareCode);
        }
    },
    onHide(){
        this.isCanBuy = true
        this.$refs.specWindow.hideModal()
    },
    onUnload(){
        this.$refs.specWindow.hideModal()
        this.init()
    },
    async onShareAppMessage(){
        let res = await this.getShareCode(),shareCode;
        shareCode = res.data ? res.data.shareCode : '';
        let bseUrl = 'pages/goodsDetails/index?prodId=' + this.$mp.query.prodId;
        if (shareCode) {
            bseUrl += `&shareCode=${shareCode}`
        }
        return {
            title: this.prodName,
            desc: '',
            path: bseUrl,
            success: function(res) {
                console.log(res)
            },
            fail: function(err) {
                console.log(err)
            }
        }

    },
    computed: {
        ...mapState(['vipInfo', 'isLogined', 'isVip', 'wxUserInfo']),
        showCart () {
            const t = this;
            return t.isCanBuy && t.saveNumber && t.pageData.goodsStatus!=5 && t.goodType==1 && !t.isGroupBuying && !t.isCountDown
        }
    },
    methods: {
        ...mapMutations(['update']),
        init () {
            const t = this;
            t.movies = [];
            t.prodName = '';
            t.stock = '';
            t.salePrice = '';
            t.totalPrice = '';
            t.integral='';
            t.specsValue='';
            t.distributeWay='';
            t.remark='';
            t.availableIntegral='';
            t.usageRule='';
            t.goodType='';
            t.isCanBuy=true;
            t.saveNumber=true;
        },
        getGoodsDetails () {
            let t = this
            wx.request({
                url: api.goodsDtails + t.$mp.query.prodId,
                method: 'get',
                data: null,
                header: {
                    Authorization: wx.getStorageSync('sessionId')
                },
                success(res) {
                    if (res.data.code == 200 && res.data.data) {
                        t.pageData = res.data.data
                        t.movies = res.data.data.thumbnail.split(',')
                        t.prodName = res.data.data.prodName
                        t.buyWay = res.data.data.buyWay
                        t.stock = res.data.data.stock
                        t.integral = res.data.data.integral
                        t.distributeWay = res.data.data.distributeWay
                        t.remark = res.data.data.remark
                        t.usageRule = res.data.data.usageRule
                        t.availableIntegral = res.data.data.availableIntegral
                        t.specsValue = res.data.data.specsValue
                        t.goodType = res.data.data.goodsType
                        t.salePrice = res.data.data.price ? (res.data.data.price / 100).toFixed(2) : 0
                        t.totalPrice = res.data.data.originalPrice ? (res.data.data.originalPrice / 100).toFixed(2) : 0
                        //拼团字段对接
                        t.isGroupBuying = res.data.data.isGroupBuying;
                        if (t.pageData.groupSkuDetailVo) {
                            t.groupBuyingStatus = res.data.groupSkuDetailVo.groupStatus;
                            t.groupPrice =
                            (t.pageData.groupSkuDetailVo.groupBottomPrice / 100).toFixed(
                                2
                            ) || 0;
                            t.successNumber = t.pageData.groupSkuDetailVo.openNumber;
                            if (
                            t.pageData.groupSkuDetailVo.groupInfoDetailVos &&
                            t.pageData.groupSkuDetailVo.groupInfoDetailVos.length
                            ) {
                            t.needNumber = t.pageData.groupSkuDetailVo.groupInfoDetailVos[0].needNumber;

                            t.residueTime = t.dateformat(
                                t.pageData.groupSkuDetailVo.groupInfoDetailVos[0].validTime
                            );
                            t.countDownTime = t.pageData.groupSkuDetailVo.groupInfoDetailVos[0].validTime;

                            let groupList = t.pageData.groupSkuDetailVo.groupInfoDetailVos;
                            groupList.forEach((v, idx) => {
                                if (v.buyingUserVos && v.buyingUserVos.length) {
                                t.showJoinGroup = true;
                                }
                            });
                            }
                        }

                        if (t.stock == 0 || !t.stock) {
                            t.saveNumber = false
                        } else {
                            t.saveNumber = true
                            if (t.buyWay === 1 || t.buyWay === 3) {
                                if (t.availableIntegral < t.integral) {
                                    t.isCanBuy = false
                                } else {
                                    t.isCanBuy = true
                                }
                            } else {
                                t.isCanBuy = true
                            }
                        }

                        //console.log('this.pageData', this.pageData)
                    } else if (res.data.code === 4001) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = t.isLogined
                                wxUtils.clearLoginStorage()
                                t.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        })
                    } else {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                wx.navigateBack({
                                    delta: 1, // 返回上一级页面。
                                    success: function() {
                                        console.log('成功！')
                                    }
                                })
                            }
                        })
                    }
                }
            })
        },
        getShareCode() {
            const t = this;
            let position = { 
                path: api.getShareCode, 
                hideLoading: true, 
                data: {
                    mallCode: t.pageData.mallCode,
                    memberCode: wx.getStorageSync('vipInfo') ? wx.getStorageSync('vipInfo').memberCode : '',
                    goodsId: t.pageData.id,
                    type: 1
                } 
            }
            return request(position)
        },
        getSeckillDetails () {
            let t = this;
            let position = { 
                path: api.querySeckillGoodsDetail, 
                hideLoading: true, 
                data: {
                    roundId: t.$mp.query.roundId,
                    goodsId: t.$mp.query.goodsId
                } 
            }
            request(position).then(res => {
                if (res.code == 200 && res.data) {
                    t.pageData = res.data
                    t.movies = res.data.thumbnail.split(',')
                    t.prodName = res.data.prodName
                    t.buyWay = res.data.distributeWay
                    t.stock = res.data.seckillNum
                    t.integral = res.data.integral
                    t.distributeWay = res.data.distributeWay
                    t.remark = res.data.remark
                    t.usageRule = res.data.usageRule
                    t.availableIntegral = res.data.availableIntegral
                    t.specsValue = res.data.specsValue
                    t.goodType = res.data.goodsType
                    t.goodsPrice = res.data.goodsPrice ? (res.data.goodsPrice / 100).toFixed(2) : 0
                    t.salePrice = res.data.seckillPrice ? (res.data.seckillPrice / 100).toFixed(2) : 0
                    t.totalPrice = res.data.originalPrice ? (res.data.originalPrice / 100).toFixed(2) : 0
                    if (t.stock == 0 || !t.stock) {
                        t.saveNumber = false
                    } else {
                        t.saveNumber = true
                        if (t.buyWay === 1 || t.buyWay === 3) {
                            if (t.availableIntegral < t.integral) {
                                t.isCanBuy = false
                            } else {
                                t.isCanBuy = true
                            }
                        } else {
                            t.isCanBuy = true
                        }
                    }
                } else if (res.code === 4001) {
                    wx.showModal({
                        title: '温馨提示',
                        content: res.message,
                        showCancel: false,
                        confirmText: '确认',
                        confirmColor: '#4694FA',
                        success(res) {
                            let oldIsLogined = t.isLogined
                            wxUtils.clearLoginStorage()
                            t.update({
                                vipInfo: null,
                                sessionId: '',
                                isLogined: oldIsLogined
                            })
                            wx.navigateTo({
                                url: `/pages/auth/index`
                            })
                        }
                    })
                } else {
                    wx.showModal({
                        title: '温馨提示',
                        content: res.message,
                        showCancel: false,
                        confirmText: '确认',
                        confirmColor: '#4694FA',
                        success(res) {
                            wx.navigateBack({
                                delta: 1, // 返回上一级页面。
                                success: function() {
                                    console.log('成功！')
                                }
                            })
                        }
                    })
                }
            })
        },
        showSku () {
            if (this.pageData.specsType == 2 && this.isCanBuy && this.saveNumber&&this.pageData.goodsStatus!=5) {
                this.$refs.specWindow.showModal()
                // this.$refs.specWindow.isShow = true
            }
        },
        toDetail (data) {
            this.$refs.specWindow.hideModal()
            this.skuData = data
            if (this.showCart) {
                this.saveCart(data.skuCode[0],data.buyCount)
            } else {
                let wxUserCode = wx.getStorageSync('wxUserCode')
                let productId = this.isCountDown ? this.$mp.query.goodsId : this.$mp.query.prodId
                let str = `/confirmOrder/index?productId=${productId}&membercode=${wxUserCode}`
                if (this.skuData) {
                    str +=`&skuData=${JSON.stringify(this.skuData)}`
                }
                wx.navigateTo({
                    url: str
                })
            }
        },
        jumpTo() {
            const t = this;
            if (t.pageData.specsType == 2) {
                t.$refs.specWindow.showModal()
                // this.$refs.specWindow.isShow = true
                return
            }
            if(this.buyWay === 1){
                wx.showModal({
                    title: '温馨提示',
                    content: `您将使用${this.integral}积分兑换${this.prodName}`,
                    confirmText: '确认',
                    confirmColor: '#4694FA',
                    success (res) {
                        if (res.confirm) {
                            t.goDetail()
                        }
                    },
                    fail(res){
                        console.log('quxiao')
                    }
                })
            }else{
                this.goDetail()
            }
        },
        saveCart (skuCode,count) {
            const t = this;
            let position = {
                path: api.saveCart, 
                method: 'post',
                hideLoading: true, 
                data: {
                    memberCode: wx.getStorageSync('vipInfo').memberCode,
                    goodsId: t.pageData.id,
                    goodsSku: skuCode,
                    goodsNum: count
                } 
            }
            request(position).then(res=> {
                if (res.code == 200) {
                    wx.showToast({
                        title: '添加成功'
                    })
                }
            }).catch(err=>{
            })
        },
        toCart () {
            const t = this;
            if (this.pageData.specsType == 2 && this.isCanBuy && this.saveNumber&&this.pageData.goodsStatus!=5) {
                this.$refs.specWindow.showModal()
            } else {
                t.saveCart(t.pageData.skuList[0].skuCode,1)
            }
        },
        goDetail(){
            const t = this;
            let wxUserCode = wx.getStorageSync('wxUserCode')
            if(wxUserCode){
                this._fetchProdDetail(wxUserCode)
                // wx.navigateTo({
                //     // 会员号字段后端没返回，需要带给下一页面
                //     url: `/pages/confirmOrder?productId=${this.$mp.query.prodId}&membercode=${wxUserCode}`
                // })
            }else{
                 wx.showModal({
                    title: '温馨提示',
                    content: '请先登录',
                    showCancel: false,
                    confirmText: '确认',
                    confirmColor: '#4694FA',
                    success(res) {
                        let oldIsLogined = t.isLogined
                        wxUtils.clearLoginStorage()
                        t.update({
                            vipInfo: null,
                            sessionId: '',
                            isLogined: oldIsLogined
                        })
                        wx.navigateTo({
                            url: `/pages/auth/index`
                        })
                    }
                })
            }
        },
        _fetchProdDetail(wxUserCode) {
            let id = this.isCountDown ? this.$mp.query.goodsId : this.$mp.query.prodId
            let opsiton = {
                path: api.prodctDetail + id,
                method: 'get',
                data: null,
                hideLoading: true
            }
            request(opsiton).then(res => {
                if (res.data) {
                    wx.navigateTo({
                        // 会员号字段后端没返回，需要带给下一页面
                        url: `/confirmOrder/index?productId=${id}&membercode=${wxUserCode}`
                    })
                }else{
                    wx.showModal({
                        title: '温馨提示',
                        content: message || "网络开了小差，请重新尝试",
                        showCancel: false,
                        confirmText: '确认',
                        confirmColor: '#4694FA',
                    })
                }
            })
        },
    }
}
</script>

<style lang="less">
page {
    padding-bottom: 70px;
}
</style>
<style lang="less" scoped>
@import url('~mpvue-wxparse/src/wxParse.css');
.goodsDetails {
    position: relative;
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background-color: #f7f7f7;
    swiper{
        width: 100%;
        height: 375px!important;
        image{
            height: 100%;
            width: 100%;
        }
    }
    .count-down {
        background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
        display: flex;
        padding: 24rpx;
        justify-content: space-between;
        .left {
            .top {
                display: flex;
                align-items: center;
                margin-bottom: 4px;
                .sales {
                    font-size: 20px;
                    font-weight:500;
                    color:rgba(255,255,255,1);
                    margin-right: 14px;
                    .icon {
                        font-size: 12px;
                        font-weight:400;
                    }
                }
                .stock {
                    font-size:12px;
                    font-family:PingFangSC-Regular,PingFang SC;
                    font-weight:400;
                    color:rgba(255,255,255,.8);
                }
            }
            .orig {
                font-size: 12px;
                color:rgba(255,255,255,.9);
                text-decoration: line-through;
            }
        }
        .right {

            .remain {
                font-size:12px;
                font-family:PingFangSC-Regular,PingFang SC;
                font-weight:400;
                color:rgba(255,255,255,1);
                letter-spacing: 0.5px;
                margin-bottom: 8px;
                text-align: right;
            }
        }
    }
    .goods-info{
        width: 100%;
        background: #fff;
        display: flex;
        flex-direction: column;
        padding: 12px;
        box-sizing: border-box;
        .goods-name{
            font-size: 18px;
            color: #333333;
        }
        .button {
            width:72px;
            height:28px;
            background:rgba(204,204,204,1);
            border-radius:15px 0px 0px 15px;
            opacity:0.17;
        }
        .left-num{
            font-size: 15px;
            color: #666666;
            margin-top: 6px;
            span{
                color: #FF4747;
            }
        }
        .goods-price-container{
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            // margin-top: 6px;
            .goods-price{
                display: flex;
                height: 100%;
                box-sizing: border-box;
                align-items: center;
                .goods-reality-price{
                    display: flex;
                    align-items: flex-end;
                    font-size: 18px;
                    color: #FF4747;
                    span{
                        font-size: 12px;
                        margin-right: 4px;
                        padding-bottom: 2px;
                    }
                }
                .origin-price{
                    font-size: 12px;
                    color: #999999;
                    text-decoration: line-through;
                    padding-top: 2px;
                    margin-left: 6px;
                }
            }
            .interal-buy{
                font-size: 15px;
                color: #333;
                span{
                    font-size: 18px;
                    color: #FF4747;
                }
            }
            button{
                width: 64px;
                height: 32px;;
                padding: 4px 0 0;
                margin: 0;
                font-size: 15px;
                box-sizing: border-box;
                color: #333333;
                display: flex;
                align-items: center;
            }
            image{
                width: 16px;
                height: 16px;
                margin-right: 4px;
            }
        }
        .flex-end {
            justify-content: flex-end;
        }
        .btn-border {
            margin-right: -24px;
            width:94px;
            line-height:28px;
            border-radius:15px;
            background:rgba(204,204,204,0.17);
            button {
                image {
                    margin: 0 4px 0 12px;
                }
                background:none;
            }
        }
        .bg-reward {
            background:rgba(206,171,114,0.23);
        }
    }
    .goods-extra-info{
        width: 100%;
        background: #fff;
        margin-top: 12px;
        padding: 16px 12px;
        box-sizing: border-box;
        p{
            font-size: 15px;
            color: #999999;
            span{
                color: #333;
            }
        }
        .formLine1 {
            position: relative;
            display: flex;
            width: 100%;
            align-items: center;
            font-size: 15px;
            color: #333;
            line-height: 54px;
            p {
                min-width: 93%;
            }
            &:not(:first-child):before {
                content: '';
                display: block;
                position: absolute;
                top: 0;
                right: 12px;
                left: 12px;
                border-top: 1px solid #efefef;
            }
            &.withComponent:after {
                content: '';
                width: 6px;
                height: 6px;
                margin-left: 10px;
                border-style: solid;
                border-color: transparent #cbcbcb #cbcbcb transparent;
                border-width: 1px;
                transform: rotate(-45deg);
            }
        }
    }
    .goods-details-container{
        width: 100%;
        background: #fff;
        margin-top: 12px;
        padding: 16px 12px;
        box-sizing: border-box;
        .goods-details-title{
            font-size: 15px;
            color: #333333;
        }
        /deep/ .wxParse .img{
            max-width:351px;
        }
        .goods-details-usageRule,.goods-details-remark{
            padding: 20px 0 0;
            font-size: 15px;
            color: #333333;
            .wxParse {
                text-align: center;
                image {
                    display: block;
                    width: 100% !important;
                }
            }
        }
    }
    .bottomAdaptor {
        width: 100%;
        position: fixed;
        bottom: 0;
        padding-bottom: 0;
        background-color: #fff;
        &.iphoneX{
          padding-bottom: 20px;
        }
        .countDownBuy {
            width:90%;
            margin: 0 auto;
            height:44px;
            background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
            border-radius:22px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size:15px;
            font-family:PingFangSC-Medium,PingFang SC;
            font-weight:500;
            color:rgba(255,255,255,1);
            .countPrice {
                margin-right:10px
            }
        }
    }
    .orderHandeler {
        height: 70px;
        padding-right: 12px;
        padding-left: 12px;
        display: flex;
        align-items: center;
        font-size: 18px;
        .price {
            flex: 1;
            overflow: hidden;
            font-size: 18px;
            color: #333;
            > span {
                font-size: 22px;
                color: #FF4747;
                .dollar {
                    font-size: 15px;
                }
            }
            p{
                font-size: 12px;
                color: #999999;
            }
        }
        .addShopCar {
            flex: 1;
            text-align: center;
            line-height:44px;
            font-size: 15px;
            color: #fff;
            background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
            border-radius:22px 0px 0px 22px;
            padding: 0;
        }
        .btnBorder {
            width: 200px;
            display: flex;
            align-items: center;
        }
        .payNow {
            width: 80px;
            line-height: 44px;
            text-align: center;
            font-size: 15px;
            color: #fff;
            background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
            border-radius:0 22px 22px 0px;
            // border-radius: 22px;
        }
        .singlePayNow {
            width: 160px;
            line-height: 44px;
            text-align: center;
            color: #fff;
            background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
            border-radius: 22px;
        }
        .payFail{
            width: 100px;
            line-height: 44px;
            text-align: center;
            color: #fff;
            background-color: #C1C1C1;
            border-radius: 22px;
        }
        .lessGrade {
            font-size: 26rpx;
        }
    }
    .wxParse {
        view {
            word-break: break-all;
            image {
                width: 100% !important;
            }
        }
    }
}
</style>
