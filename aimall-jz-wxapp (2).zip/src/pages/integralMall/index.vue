<template>
    <div class="restaurant-container">
        <div class="brand-top">
            <!-- <div class="search-btn">
                <div v-if="!vipInfo"
                     class="unLogin">
                    <div class="fl">
                        <span class="green"
                              @click="loginPage">
                            登录
                        </span>
                        <span class="view">后可查看当前积分</span>
                    </div>
                    <div class="record">
                        <auth-btn @pass="toRecord"/>
                        <img src="/static/images/exchange-icon.png">
                        订单管理
                    </div>
                </div>
                <div v-if="vipInfo">
                    <div class="status now">
                        <span class="now">当前积分</span>
                        <span class="green">{{ integral }}</span>
                    </div>
                    <div class="record"
                         @click="toRecord">
                        <img src="/static/images/exchange-icon.png">
                        订单管理
                    </div>
                </div>
            </div>-->
            <div>
                <sel-integral
                    :type-data="navList"
                    :building-data="buildingList"
                    :category-data="floorList"
                    :category-id="currCategoryId"
                    @change="selectData"
                    @changeFirstCategory="selectFirstCategory"
                    @changeSecondCategory="selectSecondCategory"
                />
            </div>
        </div>
        <div class="brand_main">
            <scroll-view
                :scroll-y="true"
                :style="{'height': '100%'}"
                class="brand_list"
                lower-threshold="100"
                @scrolltolower="onReachBottom"
            >
                <div class="new-wrap">
                    <ul class="fir-ul">
                        <li
                            v-for="(item,index) in firArr"
                            :key="index"
                            class="tap-active restaurant-item"
                        >
                            <integral-comp :data="item" />
                        </li>
                    </ul>
                    <ul class="sec-ul">
                        <li
                            v-for="(item,index) in SecArr"
                            :key="index"
                            class="tap-active restaurant-item"
                        >
                            <integral-comp :data="item" />
                        </li>
                    </ul>
                </div>

                <load-more v-if="reachFinish" />
            </scroll-view>
            <blank-page :show-blank-page="isblank" :blank-page-content="`“${ipt}…”`" />
        </div>
    </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import GradeStar from '@/components/GradeStar'
import ConditionFiltr from '../../components/ConditionFiltr'
import SearchComp from '@/components/SearchComp'
import FoodComp from '@/components/FoodComp'
import integralComp from '@/components/integralComp'
import selIntegral from '@/components/SelEnumIntegral'
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import wxUtils from '@/plugins/wxUtils'
import { INTELSORT, ALLSORT, ISFOOD, BUILDINGID } from '../../plugins/constants'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import BlankPage from '@/components/blankPage'
import loadMore from '@/components/loadMore'
import AuthBtn from '@/components/AuthBtn'
import moment from 'moment'

export default {
    components: {
        GradeStar,
        ConditionFiltr,
        SearchComp,
        FoodComp,
        integralComp,
        selIntegral,
        BlankPage,
        loadMore,
        AuthBtn
    },
    data() {
        return {
            vipCode: null,
            total: 0,
            loginInfo: '',
            integral: 0,
            pageStayTime: 0, //页面停留时间
            isTypePopShow: false,
            loadMore: true,
            data: [],
            navList: [],
            buildingList: [],
            floorList: [],
            category: [],
            isShowModal: {
                floor: false,
                price: false
            },
            currModal: 'floor',
            ipt: '',
            integralFrom: {
                pageNo: 1,
                pageSize: 20,
                sortRule: 0,
                defaultSortRule: 0,
                condition: 0,
                categoryParentId: null,
                categoryId: null
            },
            promtionPage: [],
            reachFinish: false,
            isblank: false,
            format: 'YYYY-MM-DD',
            currCategoryId: '',
            firArr: [],
            SecArr: []
        }
    },
    computed: {
        ...mapState(['sessionId', 'mallCode', 'vipInfo', 'isLogined'])
    },
    watch: {
        mallCode(newVal) {
            if (typeof newVal != 'undefined') {
                this.integralFrom.mallId = this.mallCode
            }
        }
    },
    onLoad() {
        this.getNavList()
        this.init()
        var categoryId = getApp().globalData.categoryId
        if (categoryId) {
            this.currCategoryId = categoryId
            this.integralFrom.categoryParentId = categoryId
            this.floorList.map(item => {
                if (item.id === categoryId) {
                    this.integralFrom.categoryId = item.children && item.children.length ? item.children[0].id : ''
                }
            })
        } else {
            this.currCategoryId = ''
            this.integralFrom.categoryParentId = null
            this.integralFrom.categoryId = null
        }
        this.resetRefresh() //重置数据
        if (this.vipInfo) {
            this.getIntergral()
        }
    },
    mounted() {},
    onShow() {
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: 66
        })
    },
    onHide() {
        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: 67,
            p_stay_time: this.pageStayTime
        })
        getApp().globalData.categoryId = ''
    },
    onTabItemTap(item) {
        //埋点
        buryPoint.setF({
            id: 8
        })
    },
    methods: {
        ...mapMutations(['update']),
        init () {
            this.ipt = ''
            this.integralFrom.pageNo = 1
            this.navList = [{ id: 0, name: '不限', showName: '不限' }, { id: 2, name: '销量' }, { id: 1, name: '最新' }]
            this.buildingList = [{ id: 0, name: '默认排序', showName: '默认排序' }, { id: 1, name: '价格升序' }, { id: 2, name: '价格降序' }]
        },
        //获取积分
        getIntergral() {
            let params = Object.assign(
                {},
                {
                    pageNum: 1,
                    pageSize: 10
                },
                {
                    memberId: this.vipInfo.id,
                    startTime: moment().format(this.format) + ' 00:00:00',
                    endTime: moment().format(this.format) + ' 23:59:59'
                }
            )
            let requestOptions = {
                path: api.getIntegralDetail,
                method: 'get',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                let { totalPoints } = res.data
                this.integral = totalPoints
            })
        },
        //订单管理
        toOrderControl() {
            const t = this
            //调用接口确定用户是否过期
            wx.request({
                url: api.tokenIsExpired,
                method: 'GET',
                data: null,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code == 4001 || res.data.code == 4000 || res.data.code == 216001) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = t.isLogined
                                wxUtils.clearLoginStorage()
                                t.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                // t.floorList = [{ id: 0, name: '全部' }, { id: 1, name: '可兑换',loginFalg:true}]
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        })
                    } else {
                        wx.navigateTo({
                            url: '/pages/ordermanage/orderlist'
                            // url:'/pages/mine/exchangeRecord'
                        })
                    }
                }
            })
        },
        //筛选一级分类
        selectFirstCategory(operate, data) {
            this.integralFrom.categoryParentId = data.id
            this.integralFrom.categoryId = ''
            this.resetRefresh()
        },
        //筛选二级分类
        selectSecondCategory(operate, data) {
            this.integralFrom.categoryId = data.id
            this.resetRefresh()
        },
        //筛选条件筛选
        selectData(operate, data) {
            const t = this
            if (operate == 'type') {
                this.integralFrom.sortRule = data.id
            } else if (operate == 'building') {
                this.integralFrom.defaultSortRule = data.id
            } else if (operate == 'category') {
                // this.integralFrom.defaultSortRule = data.id
            } else if (operate == 'floor') {
                //当选择可兑换时调用接口
                if (data.id == 1 && data.name == '可兑换') {
                    //调用接口确定用户是否过期
                    wx.request({
                        url: api.tokenIsExpired,
                        method: 'GET',
                        data: null,
                        header: {
                            Authorization: t.sessionId,
                            'L-A-Platform': 'mini-program' //后端日志埋点渠道
                        },
                        success(res) {
                            if (res.data.code == 4001 || res.data.code == 4000 || res.data.code == 216001) {
                                wx.showModal({
                                    title: '温馨提示',
                                    content: res.data.message,
                                    showCancel: false,
                                    confirmText: '确认',
                                    confirmColor: '#4694FA',
                                    success(res) {
                                        t.floorList = [{ id: 0, name: '全部' }, { id: 1, name: '可兑换', loginFalg: true }]
                                        let oldIsLogined = t.isLogined
                                        wxUtils.clearLoginStorage()
                                        t.update({
                                            vipInfo: null,
                                            sessionId: '',
                                            isLogined: oldIsLogined
                                        })
                                        wx.navigateTo({
                                            url: `/pages/auth/index`
                                        })
                                    }
                                })
                            } else {
                                t.integralFrom.condition = data.id
                                if (data.id == 1) {
                                    if (!t.vipInfo) {
                                        return
                                    }
                                }
                                t.resetRefresh()
                            }
                        }
                    })
                } else {
                    t.integralFrom.condition = data.id
                    if (data.id == 1) {
                        if (!t.vipInfo) {
                            return
                        }
                    }
                }
            }

            t.resetRefresh()
        },
        resetRefresh() {
            this.reachFinish = false
            this.integralFrom.pageNo = 1
            this.getStoreList(1)
        },
        goDetail(item) {
            let type = item.isFood === true ? 1 : 2
            this.checkMemberCode(item)
        },
        checkMemberCode(item) {
            const t = this
            let wxUserCode = wx.getStorageSync('wxUserCode')
            if (wxUserCode) {
                //校验会员信息
                utils.getVipInfo().then(vipInfo => {
                    if (vipInfo.status) {
                        wx.navigateTo({
                            url: `/pages/goodsDetails/index?prodId=${item}`
                        })
                    } else {
                        // 用户已被冻结，请联系服务台
                        wx.showModal({
                            title: '温馨提示',
                            content: '用户已被冻结，请联系服务台',
                            showCancel: false,
                            confirmText: '知道了'
                        })
                    }
                })
            } else {
                wx.showModal({
                    title: '温馨提示',
                    content: '请先登录',
                    showCancel: false,
                    confirmText: '确认',
                    confirmColor: '#4694FA',
                    success(res) {
                        let oldIsLogined = t.isLogined
                        wxUtils.clearLoginStorage()
                        t.update({
                            vipInfo: null,
                            sessionId: '',
                            isLogined: oldIsLogined
                        })
                        wx.navigateTo({
                            url: `/pages/auth/index`
                        })
                    }
                })
            }
        },
        getNavList() {
            let params = {
                mallCode: this.mallCode ? this.mallCode : wx.getStorageSync('mallCode')
            }
            let opsiton = {
                path: api.getStoreNav,
                method: 'get',
                data: params,
                hideLoading: true
            }
            request(opsiton).then(res => {
                if (res.code == 200) {
                    let data = res.data
                    data = data.map(item => {
                        return {
                            ...item,
                            name: item.categoryName,
                            isShowSecondMenu: true
                        }
                        // item.name = item.categoryName
                    })
                    data.unshift({
                        id: '',
                        name: '全部',
                        isShowSecondMenu: true,
                        children: []
                    })
                    this.floorList = data
                    this.category = data
                    console.log(data)
                }
            })
        },
        getStoreList(status) {
            let params = this.integralFrom
            if (wx.getStorageSync('vipInfo')) {
                params.memberCode = this.vipInfo.memberCode
            } else {
                if (params.memberCode) {
                    delete params.memberCode
                }
            }
            let requestOptions = {
                path: api.onlineMallList,
                method: 'post',
                data: params
            }
            request(requestOptions).then(res => {
                this.total = res.data.totalRecords
                if (res.data.records && res.data.records.length != 0) {
                    this.isblank = false
                    let data = res.data.records.map(item => {
                        let thumbnail
                        if (item.thumbnail && item.thumbnail.indexOf(',') !== -1) {
                            thumbnail = item.thumbnail.split(',')[0]
                        } else {
                            thumbnail = item.thumbnail
                        }
                        return {
                            ...item,
                            originalPrice: item.originalPrice ? (item.originalPrice / 100).toFixed(2) : 0,
                            listPrice: item.listPrice ? (item.listPrice / 100).toFixed(2) : 0,
                            thumbnail: thumbnail
                        }
                    })
                    if (status) {
                        this.promtionPage = data
                    } else {
                        this.promtionPage = this.promtionPage.concat(data)
                    }
                    this.firArr = this.promtionPage.filter((item, ind) => {
                        return ind % 2 == 0
                    })
                    this.SecArr = this.promtionPage.filter((item, ind) => {
                        return ind % 2 == 1
                    })
                } else {
                    if (status) {
                        this.promtionPage = []
                        this.firArr = []
                        this.SecArr = []
                    }
                }
            })
        },
        updateIsShow(val) {
            this.isShowModal[this.currModal] = !this.isShowModal[this.currModal]
            this.isTypePopShow = false
        },
        loginPage() {
            wx.navigateTo({
                url: '/pages/auth/index'
            })
        }
    },
    watch: {
        promtionPage(newVal) {
            if (newVal.length == 0) {
                this.isblank = true
            } else {
                this.isblank = false
            }
        },
        vipInfo(newVal) {
            if (this.vipInfo) {
                this.vipCode = this.vipInfo.memberCode
            } else {
                this.vipCode = null
            }
        },
        vipCode(newVal) {
            if (newVal) {
                this.getIntergral()
                this.resetRefresh() //重置数据
            } else {
                this.integralFrom.condition = 0
            }
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        this.resetRefresh()
        wx.stopPullDownRefresh()
    },
    // 页面滚动到底部
    onReachBottom() {
        if (this.integralFrom.pageNo * this.integralFrom.pageSize <= this.total) {
            this.integralFrom.pageNo++
            this.getStoreList()
        } else {
            this.reachFinish = true
        }
    }
}
</script>

<style lang="less">
@import '../../assets/styles/vars';
page {
    height: 100%;
}
.fl {
    float: left;
}
.fr {
    float: right;
}
.restaurant-container {
    width: 100%;
    height: 100%;
    .filter-title-text-wrap {
        overflow: hidden;
        font-size: 15px;
        color: #333;
        line-height: 50px;
        text-align: center;
        position: relative;
        display: flex;
        padding: 0 15px;
        justify-content: center;
        align-items: center;
        & > div {
            position: relative;
            display: inline-block;
            padding-right: 23px;
            height: 100%;
            overflow: hidden;
        }
        .filter-title-text {
            box-sizing: border-box;
            display: inline-block;
            width: 100%;
        }
        .filter-title-img {
            position: absolute;
            top: 50%;
            display: inline-block;
            right: 6px;
            transform: translateY(-50%);
            img {
                width: 8px;
                height: 5px;
            }
        }
    }

    .brand-top {
        flex: 0 1 auto;
        z-index: 999;
        position: relative;
    }
    .brand_main {
        flex: 1;
        overflow: hidden;
    }
    .brand_box {
        position: fixed;
        left: 0;
        top: 0;
        flex: 1;
        display: flex;
        overflow: hidden;
        height: 50px;
        border-bottom: 1px solid @border-color;
        .brand_nav {
            overflow: hidden;
            flex: 1;
            height: 100%;
            color: #000;
            font-size: 12px;
            // overflow-y: auto;
            // overflow-x: hidden;
            .brand_sel {
                position: relative;
                height: 100%;
                line-height: 50px;
                background: #fff;
                text-align: center;
                font-size: 15px;
                color: @black-color;
                border-bottom: 1px solid #ddd;
                padding: 0 15px;
                &:after {
                    display: inline-block;
                    content: '';
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    right: 0;
                    height: 20px;
                    width: 1px;
                    background: #ddd;
                }
                .brand_sel_text_wrap {
                    width: 100%;
                    height: 100%;
                    display: inline-block;
                    .brand_sel_text {
                        position: relative;
                        box-sizing: border-box;
                        width: 100%;
                        height: 100%;
                        padding-right: 16px;
                        box-sizing: none;
                        display: inline-block;
                        .brand_sel_text_2 {
                            display: inline-block;
                        }
                    }
                }
                .brand_sel_arrow {
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    display: inline-block;
                    right: 6px;
                    display: inline-block;
                    width: 8px;
                    height: 5px;
                    img {
                        display: inline-block;
                        width: 100%;
                        height: 100%;
                    }
                }
            }
        }
        .brand_content {
            overflow: hidden;
            flex: 2;
            display: flex;
            flex-direction: column;
            .brand_type {
                height: 50px;
            }
            .brand_list {
                flex: 1;
                // overflow-y: auto;
                z-index: 9;
                .noMore {
                    text-align: center;
                    color: #999;
                    padding-bottom: 10px;
                }
            }
        }
    }
    .restaurant-item {
        //float: left;
        //border-bottom: 1px solid @border-color;
        display: inline-block;
        background: rgba(255, 255, 255, 1);
        box-shadow: 0px 0px 5px 0px rgba(188, 188, 188, 0.3);
        width: 172px;
        margin-bottom: 10.5px;
        border-radius: 6px;
        overflow: hidden;
        position: relative;
        z-index: 4;
        &:last-child {
            border: 0;
        }
    }
    .btn-clear {
        z-index: 10;
        width: 15px;
        height: 16px;
        padding: 9.5px;
        position: absolute;
        top: 50%;
        right: 15px;
        transform: translateY(-50%);
        font-size: 15px;
    }
    .search-btn {
        text-align: left;
        line-height: 50%;
        overflow: hidden;
        padding: 20px;
        background: #fff;
        border-top: 1px solid #f0f0f0;
        border-bottom: 1px solid #f0f0f0;
        .unLogin {
            font-size: 14px;
            color: #999999;
            line-height: 20px;
            .green {
                margin: 0 5px;
                font-size: 16px;
                border-bottom: 1px solid #9975F3;
                display: inline-block;
                font-weight: bold;
            }
            .view {
            }
        }

        .login {
            width: 10px;
            height: 13px;
            float: left;
            margin-top: 5px;
        }
        .green {
            color: #9975F3;
        }
        .status {
            float: left;
        }
        .status.now {
            color: #333333;
            font-size: 16px;
            line-height: 18px;
            .now {
                font-weight: bold;
                margin-right: 10px;
            }
        }
        .record {
            float: right;
            font-size: 14px;
            line-height: 20px;
            color: #333333;
            position: relative;
            img {
                width: 16px;
                height: 12.5px;
                display: inline-block;
                position: relative;
                top: 2px;
            }
        }
    }
    .loginBox {
        height: 100px;
        width: 100px;
    }
    .new-wrap {
        width: 353px;
        // padding: 11px 11px 0 11px;
        padding: 12px 14px 0 14px;
        overflow: hidden;
        background: #f4f4f4;

        .fir-ul {
            width: 172px;
            float: left;
        }
        .sec-ul {
            width: 172px;
            float: right;
        }
    }
}
</style>

