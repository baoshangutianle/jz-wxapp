<template>
    <div class="ponitsMall_Detail">
        <div class="pointsMall_img">
            <img :src="detailData.thumbnail"/>
        </div>
        <div class="pointsMall_title">
            <p class="title">
                {{detailData.prodName}}
            </p>
            <div class="tltle_flex">
                <div class="stock">库存
                    <span class="stock_num">{{detailData.stock}}</span> 件
                </div>
                <div class="share share-btn-container">
                    <div class="share_div btn-share-wrap">
                        <img class="share_icon" src="../../static/images/icon_share.png"/>
                        <span class="share_title">分享</span>
                        <button class="active-icon" open-type="share"></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="pointsMall_bg"></div>
        <div class="instructions_use">
            <p class="instructions_title">
                <span class="instructions_line"></span>
                <span class="instructions_pl">使用须知</span>
            </p>
            <div class="instructions_con">
                <span v-html="detailData.usageRule"></span>
            </div>
        </div>
        <div class="pointsMall_bg"></div>
        <div class="goods_detail">
            <p class="instructions_title">
                <span class="instructions_line"></span>
                <span class="instructions_pl">商品详情</span>
            </p>
            <div class="goods_con" v-if="integralProdDetail !=''">
                <wxParse :content="integralProdDetail" :image-prop="imageProp" />
            </div>
        </div>
        <div class="pointsMall_bottom">
            <div class="bottom_btn">
                <div class="bottom_integral">
                     <div class="integral1" v-if="detailData.integral == '0' || !detailData.integral"><span class="integral_num1">免费兑换</span></div>
                     <div class="integral1" v-else>消耗<span class="integral_num"> {{detailData.integral ? detailData.integral :''}}</span> 积分</div>
                    <div class="integral2">价值 {{detailData.salePrice ? detailData.salePrice :''}} 元</div>
                </div>
                <div class="integral_btn">
                    <div v-show="!vipInfo || vipInfo == ''">
                        <button class="exchange">
                            <auth-btn @pass="getDeatilInfo" />
                            立即兑换
                        </button>
                    </div>
                    <div v-show="!(!vipInfo || vipInfo == '')">
                        <button class="exchange exchange1" value="" v-if="detailData.stock == '0'">
                            已售罄
                        </button>
                        <button class="exchange exchange1" value="" v-else-if="!available">
                            积分不足
                        </button>
                        <form @submit="goExchange" report-submit="true"  v-else>
                            <button formType="submit" class="exchange" value="">
                                立即兑换
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import { mapState, mapMutations } from "vuex"
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import wxParse from 'mpvue-wxparse'
import AuthBtn from '../../components/AuthBtn'
import wxUtils from '@/plugins/wxUtils'

export default {
     components: {
         wxParse,
         AuthBtn
    },
    data() {
        return {
            id: '',
            detailData: [],
            integralProdDetail: '',
            cardName: '',
            available: true,
            imageProp: {
                mode: 'widthFix'
            },
            prodLabelId: ''
        }
    },
    computed: {
        ...mapState(['wxUserInfo','vipInfo','sessionId','isLogined'])
    },
    onLoad(){
        this.detailData = '',
        this.integralProdDetail =  ''
        this.cardName = ''
        this.available = true
        this.prodLabelId =  ''
        this.id = this.$root.$mp.query.id
        this.getDeatilInfo()
    },
    methods: {
        ...mapMutations(['update']),
        getDeatilInfo() {
            const t = this
            if(t.id){
                let opsiton
                if(t.vipInfo){
                     opsiton = api.getIntegralProdNew +"?id=" + t.id + "&memberCode=" + t.vipInfo.memberCode
                }else{
                     opsiton = api.getIntegralProdNew +"?id=" + t.id
                }
                wx.request({
                    url: opsiton,
                    method: 'GET',
                    data: null,
                    header: {
                        Authorization: t.sessionId,
                        'L-A-Platform': 'mini-program' //后端日志埋点渠道
                    },
                    success(res) {
                        if (res.data.code === 200) {
                            res.data.usageRule = res.data.data.usageRule ? res.data.data.usageRule.replace(/\n/g, '<br>') : ''
                            t.integralProdDetail = res.data.data.integralProdDetailVO ? res.data.data.integralProdDetailVO.detail :''
                            //判断是否授权登录
                            if(t.vipInfo && t.vipInfo != ''){
                                t.cardName = res.data.data.integralGradeName ? res.data.data.integralGradeName :'尊享普卡'
                                //判断用户是否可以兑换
                                if(res.data.data.availableIntegral){
                                    if(res.data.data.availableIntegral >= res.data.data.integral){
                                        t.available = true
                                    }else if(res.data.data.integral == '0' || !res.data.data.integral){ //当为免费兑换时
                                        t.available = true
                                    }else{
                                        t.available = false
                                    }
                                }else{
                                    //当为免费兑换时
                                    if(res.data.data.integral == '0' || !res.data.data.integral){
                                        t.available = true
                                    }else {
                                        t.available = false
                                    }
                                }
                            }else {
                                t.cardName = '尊享普卡'
                            }
                            t.detailData = res.data.data
                            t.prodLabelId = res.data.data.prodLabelId
                        } else if (res.data.code === 4001) {
                            wx.showModal({
                                title: '温馨提示',
                                content: res.data.message,
                                showCancel: false,
                                confirmText: '确认',
                                confirmColor: '#4694FA',
                                success(res) {
                                    let oldIsLogined = t.isLogined
                                    wxUtils.clearLoginStorage()
                                    t.update({
                                        vipInfo: null,
                                        sessionId: '',
                                        isLogined: oldIsLogined
                                    })
                                    wx.navigateTo({
                                        url: `/pages/auth/index`
                                    })
                                }
                            })
                        }else{
                            wx.showModal({
                                title: '温馨提示',
                                content: res.data.message,
                                showCancel: false,
                                confirmText: '确认',
                                confirmColor: '#4694FA',
                                success(res) {
                                    wx.switchTab({
                                        url: `/pages/integralMall/index`
                                    })
                                }
                            })
                        }
                    }
                })
            }
        },
        goExchange(e) {
            const t = this
            wx.showModal({
                title: '积分兑换',
                confirmText: '立即兑换',
                cancelText: '我再想想',
                confirmColor:'#007AFF',
                cancelColor:'#666666',
                content: `您正在使用${this.detailData.integral}积分兑换${this.detailData.prodName},兑换后不可退换`,
                success (res) {
                    if (res.confirm) {
                        let formId = e.mp.detail.formId
                        let opsiton = { path: api.exchange +"?prodId=" + t.id + "&fomId=" + formId}
                        request(opsiton).then(res => {
                            if (res.code == 200) {
                                wx.showToast({
                                    title: '兑换成功',
                                    icon: 'success',
                                    duration: 2000
                                })
                                setTimeout(() => {
                                    wx.navigateTo({
                                        url:'/pagesMine/exchangeRecord'
                                    })
                                }, 2000)
                            }else{
                                let success = {
                                    title: res.message,
                                    icon: 'none'
                                }
                                wx.showToast(success)
                            }
                        })
                    } else if (res.cancel) {
                    }
                }
            })
        }
    },
    // 分享
    onShareAppMessage() {
        return {
            title: this.detailData.prodName,
            //path: 'pages/home?pageId=integralMall&id=' + this.id,
            path: 'pages/integralMall/detail?id=' + this.id,
            success: function(res) {
                console.log(res)
            },
            fail: function(err) {
                console.log(err)
            }
        }
    }
}
</script>
<style lang="less">
@import url('~mpvue-wxparse/src/wxParse.css');
.ponitsMall_Detail{
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
   .pointsMall_img{
       width: 100%;
       height: 376px;
       img{
           width: 100%;
           height: 376px;
       }
    }
    .pointsMall_title{
        padding: 0px 20px;
        .title{
            padding-top: 12px;
            color: #333333;
            font-size: 18px;
            overflow:hidden;
            text-overflow:ellipsis;
            display:-webkit-box;
            -webkit-line-clamp:2;
            -webkit-box-orient:vertical;
        }
        .tltle_flex{
            display: flex;
            padding-top: 13px;
            padding-bottom: 20px;
        }
        .stock{
            flex: 1;
            color: #333333;
            font-size: 16px;
            font-weight: 200;
        }
        .stock_num{
            color: #9975F3;
            font-weight: 200;
        }
        .share{
            flex: 1;
            text-align: right;
            color: #333333;
            font-size: 16px;
        }
        .share_div{
            display: inline-block;
            position: relative;
        }
        .share_icon{
            width: 20px;
            height: 20px;
            display: inline-block;
            vertical-align: bottom;
        }
        .share_title{
            padding-left: 6px;
        }
        .active-icon{
            z-index: 2;
            opacity: 0;
            display: inline-block;
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100% !important;
            height: 100% !important;
            margin: 0 !important;
            padding: 0 !important;

        }
    }
    .pointsMall_bg{
        width: 100%;
        height: 12px;
        background: #F4F4F4;
    }
    .instructions_use{
        padding: 0px 20px;
    }
    .instructions_title{
        padding-top: 16*2px;
        color: #333333;
        font-size: 15px;
    }
    .instructions_line{
        width: 2px;
        height: 10px;
        border-radius:2px;
        background: #9975F3;
        display: inline-block;
    }
    .instructions_pl{
        padding-left: 6px;
    }
    .instructions_con{
        color: #666;
        font-size: 14px;
        padding-top: 10px;
        padding-left: 10px;
        padding-bottom: 9px;
        font-weight: 200;
        span{
            font-weight: 200
        }
    }
    .goods_detail{
        padding: 0px 20px;
    }
    .goods_con{
        padding-left: 10px;
        // font-size: 14px;
        // padding-top: 15px;
        // color: #666;
        padding-bottom: 100px;
    }
    .pointsMall_bottom{
        position: fixed;
        bottom: 0px;
        width: 100%;
        height: 84px;
        background: #ffffff;
        box-shadow:0px 4px 15px 5px rgba(0,0,0,0.09);
    }
    .bottom_btn{
        display: flex;
        padding-left: 25px;
        padding-top: 8px;
    }
    .bottom_integral{
        flex: 1;
        .integral1{
            color: #333333;
            font-size: 16px;

        }
        .integral_num1{
            color: #EA7979;
            font-size: 20px;
        }
        .integral_num{
            color: #9975F3;
            font-size: 20px;
        }
        .integral2{
            color: #999;
            font-size: 12px;
        }
    }
    .integral_btn{
        flex: 1;
        text-align: right;
        padding-right: 8px;
        .exchange{
            width:130px;
            height: 44px;
            background: #9975F3;
            color: #ffffff;
            font-size: 18px;
            border-radius:22px;
        }
        .exchange1{
            background: #bbbbbb;
            color: #ffffff;
        }
    }
    .wxParse {
        view {
            word-break: break-all;
            image {
                width: 100% !important;
            }
        }
    }
}
</style>
