<template>
    <div id="mermberShip">
        <img mode="widthFix" src="https://img-cdn.aimall.cloud/as/20200528/32cd95a997be4b268e154c01f50550b7.png" style="width:100%"/>
        <!-- 轮播 -->
        <!-- <div class="swiper">
            <div class="right-title">
                <h2>为您开启 爱琴海会员特权</h2>
            </div>
            <swiper
                :duration="1000"
                :circular="true"
                previous-margin="54px"
                next-margin="54px"
                @change="swiperChange"
            >
                <block
                    v-for="(item, index) in imgUrls"
                    :key="index"
                >
                    <swiper-item>
                        <image
                            :src="item"
                            :class="{leactive:swiperIndex!=index}"
                            class="slide-image le-img"
                        />
                    </swiper-item>
                </block>
            </swiper>
        </div>
        <div class="line">
            <div class="changxiang">{{ memberInfo.title }}</div>
        </div>
        <div class="infos">
            <div
                v-for="(item,index) in memberInfo.info"
                :key="index"
                :class="{info:true, index1:swiperIndex ==0,index2:swiperIndex ==1,index3:swiperIndex ==2,index4:swiperIndex ==3}"
            >
                <h3>{{ item.infoTitle }}</h3>
            </div>
        </div> -->
    </div>
</template>
<script>
export default {
    data() {
        return {
            // 会卡卡等对象
            memberInfo: {},
            // 轮播序号
            swiperIndex: 0,
            // 轮播图列表
            imgUrls: [
                'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190907/067fec2b1e674e9893112e411f9c160c.png',
                'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190911/e662a8a3c6784535ae03293b83bb5211.png',
                'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190911/747fddc8ed364f84b6c711503e6374ec.png',
                'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190907/e83893f3225d436fbfdf004376241f23.png'
            ],
            // 卡等信息列表
            memberList: [
                {
                    title: '畅享普卡',
                    info: [
                        {
                            infoTitle: '签到有礼',
                            desc: ''
                        },
                        {
                            infoTitle: '信息获知',
                            desc: ''
                        },
                        {
                            infoTitle: '积分累积',
                            desc: ''
                        }
                    ],

                },
                {
                    title: '乐享银卡',
                    info: [
                        {
                            infoTitle: '签到有礼',
                            desc: ''
                        },
                        {
                            infoTitle: '信息获知',
                            desc: ''
                        },
                        {
                            infoTitle: '积分累积',
                            desc: ''
                        },
                        {
                            infoTitle: '积分换礼',
                            desc: ''
                        },
                        {
                            infoTitle: '积分换活动',
                            desc: ''
                        },
                        {
                            infoTitle: '积分换服务',
                            desc: ''
                        },
                        {
                            infoTitle: '会员停车',
                            desc: ''
                        },
                    ],

                },
                {
                    title: '优享金卡',
                    info: [
                        {
                            infoTitle: '签到有礼',
                            desc: ''
                        },
                        {
                            infoTitle: '信息获知',
                            desc: ''
                        },
                        {
                            infoTitle: '积分累积',
                            desc: ''
                        },
                        {
                            infoTitle: '积分换礼',
                            desc: ''
                        },
                        {
                            infoTitle: '积分换活动',
                            desc: ''
                        },
                        {
                            infoTitle: '积分换服务',
                            desc: ''
                        },
                        {
                            infoTitle: '会员停车',
                            desc: ''
                        },
                        {
                            infoTitle: '专享生日礼',
                            desc: ''
                        },
                        {
                            infoTitle: '会员日',
                            desc: ''
                        }
                    ],

                },
                {
                    title: '尊享黑卡',
                    info: [
                        {
                            infoTitle: '签到有礼',
                            desc: ''
                        },
                        {
                            infoTitle: '信息获知',
                            desc: ''
                        },
                        {
                            infoTitle: '积分累积',
                            desc: ''
                        },
                        {
                            infoTitle: '积分换礼',
                            desc: ''
                        },
                        {
                            infoTitle: '积分换活动',
                            desc: ''
                        },
                        {
                            infoTitle: '积分换服务',
                            desc: ''
                        },
                        {
                            infoTitle: '会员停车',
                            desc: ''
                        },
                        {
                            infoTitle: '专享生日礼',
                            desc: ''
                        },
                        {
                            infoTitle: '会员日',
                            desc: ''
                        }
                    ],
                    nextShipe: {
                        next: '',
                        conditions: ['', '']
                    }
                },
            ]
        }
    },
    methods: {
        swiperChange: function(e) {
            // 根据轮播序号显示不同卡等信息
            this.swiperIndex = e.target.current
            this.memberInfo = this.memberList[this.swiperIndex]
        }
    },
    onLoad() {
        this.swiperIndex = 0
        this.memberInfo = this.memberList[this.swiperIndex]
    }
}
</script>

<style lang="less" scoped>
@import url('../../assets/styles/vars');
#mermberShip {
    width: 100%;
    /* --轮播-- */
    .swiper {
        height: 243px;
        max-width: 100%;
        overflow: hidden;
        box-sizing: border-box;
        position: relative;
        margin-bottom: 35px;
        .right-title {
            height: 180px;
            width: 100%;
            padding-top: 30px;
            background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190907/f203454efcde48119708e3ba0aa7aaf0.png') no-repeat top center;
            background-size: 375px 180px;
            border-radius: 0 0 30px 30px;
            h2 {
                height: 30px;
                font-size: 22px;
                font-family: PingFangHK;
                font-weight: 300;
                color: #d6b17c;
                line-height: 30px;
                text-align: center;
            }
        }
        swiper {
            position: absolute;
            z-index: 99;
            width: 100%;
            height: 143px;
            bottom: 10px;
            .leactive {
                transform: scaleY(0.8);
                transform-origin: center;
            }
            swiper-item {
                margin: 0 auto;
                width: 268px;
                height: 143px;
                opacity: 1;
                box-sizing: border-box;
            }
            image {
                display: block;
                width: 252px;
                height: 143px;
                transition: all 0.5s;
                transform-origin: center;
                opacity: 1;
                margin: 0 auto;
            }
        }
    }
    /*-----line----*/
    .line {
        width: 310px;
        height: 1px;
        margin: 20px auto;
        background-color: #9975F3;
        position: relative;
        .changxiang {
            width: 116px;
            height: 33px;
            font-size: 24px;
            font-family: PingFangSC;
            font-weight: 500;
            text-align: center;
            color: #9975F3;
            line-height: 33px;
            position: absolute;
            top: -16px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #fff;
        }
    }
    /*-----items----*/
    .infos {
        padding-top: 35px;
        padding-bottom: 70px;
        .info {
            width: 252px;
            height: 44px;
            margin: 0 auto 20px;
            background-origin: center;
            background-repeat: no-repeat;
            background-size: 252px 44px;
            h3 {
                height: 44px;
                line-height: 44px;
                text-align: center;
                font-size: 18px;
            }
        }
    }
    /*-----会员升级----*/

    // 普卡
    .index1 {
        color: #ffffff;
        background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191107/66b1ffdd650748c29ce0048aab312d71.png');
    }
    // 银卡
    .index2 {
        color: #ffffff;
        background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191107/05017611f16b4fb5ac8c472069cb6ea6.png');
    }
    // 金卡
    .index3 {
        color: #ffffff;
        background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191107/d247666548d74615b2387c53abf3192b.png');
    }
    // 黑卡
    .index4 {
        color: #ffffff;
        background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191107/e29019b210984bd18051081d45e41b20.png');
    }
}
</style>
