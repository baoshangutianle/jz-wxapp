<template name="liveBroadcast">
    <div class="liveBroadcast">
        <scroll-view
            :scroll-y="true"
            :style="{'height': '100%'}"
            class="brand_list"
            lower-threshold="100"
            @scrolltolower="onReachBottom"
        >
            <div
                class="liveList"
                v-for="(item,index) in liveList"
                :key="index"
                @click="goLive(item.roomId,item.liveStatus,item.anchorImg)"
            >
                <img class="live-img" :src="item.anchorImg" />
                <!-- <div class="live-img" :style="{backgroundImage:'url('+ item.anchorImg +')'}"></div> -->
                <div class="live-type" v-if="item.liveStatus == 102">
                    <img
                        class="live-type-img"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200320/f6fcf8074aed47a6888a14858bc66ba3.png"
                    />
                    <p class="live-info">
                        <span class="live-type-text">预告</span>
                    </p>
                    <span class="live-time">{{item.startTime}}</span>
                </div>
                <div class="live-type" v-else-if="item.liveStatus == 101">
                    <img
                        class="live-type-img"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200320/87b4dea15b2c4066bedea13cbc895044.png"
                    />
                    <p class="live-info">
                        <span class="live-type-text">•直播中</span>
                    </p>
                    <span class="live-time">{{item.startTime}}</span>
                </div>
                <div class="live-type" v-else>
                    <img
                        class="live-type-img"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200320/2a0785d3abd04639b6d34fc24401ade5.png"
                    />
                    <p class="live-info">
                        <span class="live-type-text">回放</span>
                    </p>
                    <span class="live-time">{{item.startTime}}</span>
                </div>
                <div class="liveList-info">
                    <p class="title">{{item.name}}</p>
                    <div class="liveList-ul">
                        <div class="liveList-div" v-if="item.goodsList && item.goodsList[0]">
                            <img class="goods-img" :src="item.goodsList[0].coverImg" />
                            <!-- priceType:2区间价格，priceType：1单价格，priceType：3划线价格 -->
                            <span
                                class="goods-price"
                                v-if="item.goodsList[0].priceType == 3"
                            >¥{{item.goodsList[0].price2 / 100 }}</span>
                            <span
                                class="goods-price"
                                v-else-if="item.goodsList[0].priceType == 2"
                            >¥{{item.goodsList[0].price / 100 }} - {{item.goodsList[0].price2 / 100 }}</span>
                            <span class="goods-price" v-else>¥{{item.goodsList[0].price / 100 }}</span>
                        </div>
                        <div class="liveList-div" v-if="item.goodsList && item.goodsList[1]">
                            <img class="goods-img" :src="item.goodsList[1].coverImg" />
                            <div class="cover-bg">
                                <span>+{{item.goodsListLength}}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="noLive" v-if="noLive">暂无直播，敬请期待</div>
            <div class="loadmore-show" v-if="reach">
                <div class="reachText">
                    <span class="reach-text">直播让你更快乐</span>
                </div>
            </div>
        </scroll-view>
    </div>
</template>

<script>
import api from '../../plugins/api'
import moment from 'moment'
export default {
    props: {
        // eslint-disable-next-line vue/require-default-prop
        url: ''
    },
    data() {
        return {
            liveList: [],
            goodsList: [],
            pageNum: 1,
            pageSize: 10,
            total: 0,
            reach: false,
            noLive: false,
            goodsListLength: 0
        }
    },
    onShow() {
        this.getRefresh()
    },
    methods: {
        getRefresh() {
            this.liveList = []
            this.goodsList = []
            this.pageNum = 1
            this.pageSize = 10
            this.reach = false
            this.goodsListLength = 0
            this.getLiveList()
            wx.stopPullDownRefresh()
        },
        getLiveList() {
            let t = this
            wx.request({
                url: api.getRoomList + '?page=' + this.pageNum + '&pageSize=' + this.pageSize,
                method: 'get',
                data: null,
                header: {
                    Authorization: wx.getStorageSync('sessionId')
                },
                success(res) {
                    if (res.data.code === 200) {
                        t.total = res.data.data.total
                        if (res.data.data.room_info && res.data.data.room_info.length > 0) {
                            res.data.data.room_info.map(item => {
                                item.startTime = moment.unix(item.startTime).format('MM-DD HH:mm')
                                if(item.goodsList){
                                    t.$set(item, 'goodsListLength', item.goodsList.length - 1)
                                }
                            })
                            if (t.pageNum > 1) {
                                t.liveList = t.liveList.concat(res.data.data.room_info)
                            } else {
                                t.liveList = res.data.data.room_info
                            }
                            t.reach = true
                            t.noLive = false
                        } else {
                            if (t.pageNum > 1) {
                                t.noLive = false
                            } else {
                                t.noLive = true
                            }
                        }
                    }
                }
            })
        },
        goLive(roomid, status, img) {
            // let t = this
            // let customParams = { type: 9 }
            // wx.redirectTo({
            //     url: `plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=${roomid}&custom_params=${encodeURIComponent(JSON.stringify(customParams))}`
            // })
            if (status == 102 || status == 101) {
                wx.navigateTo({
                    url: `/pages/stayTuned/index?roomId=${roomid}`
                })
            } else {
                wx.navigateTo({
                    url: `/pages/liveBroadcast/replay?roomId=${roomid}&liveImg=${img}`
                })
            }
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        this.liveList = []
        this.pageNum = 1
        this.pageSize = 10
        this.reach = false
        this.getLiveList()
        wx.stopPullDownRefresh()
    },
    // 页面滚动到底部
    onReachBottom() {
        if (this.pageNum * this.pageSize <= this.total) {
            this.pageNum++
            this.getLiveList()
        } else {
            //this.reachFinish = true
        }
    }
}
</script>


<style lang="less" scoped>
@import url(../../assets/styles/vars);
.liveBroadcast {
    width: 100%;
    height: 100%;
    min-height: 100vh;
    background: #f5f6fa;
    padding-top: 15px;
    .liveList {
        background: #ffffff;
        height: 150px;
        margin: 15px;
        margin-top: 0px;
        overflow: hidden;
        position: relative;
        box-shadow: 0px 0px 7px 0px rgba(0, 0, 0, 0.05);
        border-radius: 5px;
        .live-type {
            position: absolute;
            z-index: 99;
            top: 18px;
            left: 0px;
            width: 122px;
            height: 19px;
            background: linear-gradient(270deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 1) 100%);
            border-radius: 0px 13px 13px 0px;
            .live-type-img {
                width: 52px;
                height: 19px;
                display: inline-block;
            }
            .live-info {
                position: absolute;
                z-index: 99;
                top: -1px;
                left: 7px;
                height: 19px;
                line-height: 18px;
            }
            .live-type-text {
                font-size: 12px;
                color: rgba(255, 255, 255, 1);
            }
            .live-time {
                font-size: 10px;
                font-weight: 400;
                color: rgba(255, 255, 255, 1);
                vertical-align: top;
                height: 19px;
                line-height: 19px;
                display: inline-block;
            }
        }
        .live-img {
            width: 150px;
            height: 150px;
            float: left;
            // background-repeat: no-repeat;
            // background-size: cover;
        }
        .liveList-info {
            display: inline-block;
            //padding: 15px;
            width: 195px;
        }
        .title {
            font-size: 16px;
            font-weight: 500;
            color: rgba(51, 51, 51, 1);
            padding: 10px 15px 20px 15px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .liveList-ul {
            list-style: none;
            margin-left: 15px;
            padding: 0px;
            //overflow-x: auto;
            white-space: nowrap;
            //overflow-y: hidden;
            overflow: none;
        }
        .liveList-ul::-webkit-scrollbar {
            display: none;
        }
        .liveList-ul .liveList-div {
            display: inline-block;
            margin: 0px 10px 10px 0px;
            text-align: center;
            position: relative;
        }
        .goods-img {
            width: 80px;
            height: 80px;
            border-radius: 4px;
        }
        .goods-price {
            display: inline-block;
            font-size: 12px;
            font-weight: 400;
            //color: rgba(102, 102, 102, 1);
            padding: 3px 0px 3px 0px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            width: 80px;
            position: absolute;
            z-index: 99;
            bottom: 0px;
            background: rgba(0, 0, 0, 0.5);
            left: 0px;
            color: #fff;
            border-bottom-left-radius: 4px;
            border-bottom-right-radius: 4px;
        }
        .cover-bg {
            width: 80px;
            height: 80px;
            position: absolute;
            z-index: 99;
            bottom: 0px;
            background: rgba(0, 0, 0, 0.5);
            left: 0px;
            color: #fff;
            text-align: center;
            line-height: 80px;
            border-radius: 4px;
            span {
                //font-size: 20px;
            }
        }
    }
    .loadmore-show {
        .reachText {
            color: #d5d5d5;
            text-align: center;
            padding: 15px;
            font-size: 12px;
            padding-top: 30px;
            letter-spacing: 1px;
            position: relative;
            padding-bottom: 50px;
        }
        .reach-text {
            display: block;
            position: relative;
            text-align: center;
        }
        .reach-text:before,
        .reach-text:after {
            content: '';
            position: absolute;
            top: 50%;
            background: #e2e2e2;
            width: 32%;
            height: 1px;
        }
        .reach-text:before {
            left: 2%;
        }
        .reach-text:after {
            right: 2%;
        }
    }
    .noLive {
        color: #d5d5d5;
        font-size: 15px;
        padding-top: 150px;
        text-align: center;
    }
}
</style>
