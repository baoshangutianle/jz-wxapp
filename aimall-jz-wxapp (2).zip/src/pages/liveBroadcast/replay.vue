<template name="liveBroadcast">
    <div class="liveBroadcast">
        <!-- <live-player src="http://1258344707.vod2.myqcloud.com/1b87576bvodcq1258344707/f07f0ef55285890799978995919/playlist_eof.m3u8" mode="RTC" autoplay bindstatechange="statechange" binderror="error" style="width: 300px; height: 225px;" /> -->
        <video
            id="myVideo"
            autoplay="true"
            object-fit="cover"
            :controls="controls"
            :show-fullscreen-btn="showfullScreen"
            :src="videoUrl"
            @fullscreenchange="screenChange"
            @ended="ended"
            :class="fullScreen ? 'fullScreenVideo' : ''"
        ></video>
        <div class="replayLst" v-if="!fullScreen">
            <div class="replay-info">
                <p class="replay-title">
                    <span
                        class="replay-span"
                        :class="replayActive ?'replay-active':'' "
                        @click="goActive('replayActive')"
                    >回放章节</span>
                    <span class="replay-line"></span>
                    <span
                        class="replay-span"
                        :class="replayGoods ?'replay-active':'' "
                        @click="goActive('replayGoods')"
                    >商品信息</span>
                </p>
                <div class="liveList-info" v-if="replayActive">
                    <div class="liveList-ul">
                        <div
                            class="liveList-div"
                            v-for="(item,i) in replayList"
                            :key="i"
                            @click="changeVideo(item,i)"
                        >
                            <!-- <div class="live-img" :style="{backgroundImage:'url('+ liveImg +')'}"></div> -->
                            <img class="goods-img" :src="liveImg" />
                            <p
                                class="title"
                                :class="activeClass == i ? 'activeTitle' : ''"
                            >第{{i + 1}}章节</p>
                        </div>
                    </div>
                    <span class="noReplay" v-if="noReplay">暂无回放章节</span>
                </div>
                <div class="liveList-info" v-else>
                    <div class="liveList-ul">
                        <div
                            class="liveList-div"
                            v-for="(item,index) in goodsList"
                            :key="index"
                            @click="goGoodsDetail(item)"
                        >
                            <img class="goods-img" :src="item.coverImg" />
                            <p class="title">{{item.name}}</p>
                        </div>
                    </div>
                    <span class="noReplay" v-if="noReplayGoods">暂无回放商品</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import api from '../../plugins/api'
import moment from 'moment'
export default {
    props: {
        // eslint-disable-next-line vue/require-default-prop
        url: ''
    },
    data() {
        return {
            replayList: [],
            roomId: '',
            liveImg: '',
            videoUrl: '',
            activeClass: 0,
            replayActive: true,
            replayGoods: false,
            controls: true,
            noReplay: false,
            fullScreen: false,
            showfullScreen: false,
            noReplayGoods: false,
            goodsList: []
        }
    },
    onShow() {
        this.replayList = []
        this.videoUrl = ''
        this.activeClass = 0
        this.replayActive = true
        this.replayGoods = false
        this.noReplay = true
        this.fullScreen = false
        this.showfullScreen = false
        this.controls = true
        this.liveImg = this.$root.$mp.query.liveImg
        this.noReplayGoods = false
        this.goodsList = []
        this.getReplay()
        this.getGoodsList()
    },
    methods: {
        goActive(type) {
            if (type == 'replayActive') {
                this.replayActive = true
                this.replayGoods = false
            } else {
                this.replayActive = false
                this.replayGoods = true
            }
        },
        getReplay() {
            let t = this
            t.roomId = this.$root.$mp.query.roomId
            wx.request({
                url: api.getReplay + '?roomId=' + t.roomId,
                method: 'get',
                data: null,
                header: {
                    Authorization: wx.getStorageSync('sessionId')
                },
                success(res) {
                    if (res.data.code === 200) {
                        if (res.data.data && res.data.data.length > 0) {
                            //先取第一个视频
                            t.videoUrl = res.data.data[0].mediaurl
                            t.replayList = res.data.data
                            t.noReplay = false
                        } else {
                            t.noReplay = true
                        }
                    }
                }
            })
        },
        getGoodsList() {
            let t = this
            t.roomId = this.$root.$mp.query.roomId
            wx.request({
                url: api.getRoomInfo + '?roomId=' + t.roomId,
                method: 'get',
                data: null,
                header: {
                    Authorization: wx.getStorageSync('sessionId')
                },
                success(res) {
                    if (res.data.code === 200) {
                        if (res.data.data.goodsList && res.data.data.goodsList.length > 0) {
                            t.goodsList = res.data.data.goodsList
                            t.noReplayGoods = false
                        } else {
                            t.noReplayGoods = true
                        }
                    }
                }
            })
        },
        goGoodsDetail(item) {
            const id = item.url.split('?')[1]
            wx.navigateTo({
                url: `/pages/goodsDetails/index?${id}`
            })
        },
        changeVideo(data, index) {
            this.activeClass = index
            this.videoUrl = data.mediaurl
        },
        screenChange(e) {
            let fullScreen = e.mp.detail.fullScreen //值true为进入全屏，false为退出全屏

            if (!fullScreen) {
                //退出全屏
                this.fullScreen = true
                this.controls = true
            } else {
                //进入全屏
                this.fullScreen = false
                this.controls = true
            }
        },
        ended() {
            //退出全屏
            console.log('end')
            this.fullScreen = false
            this.controls = true
        }
    }
}
</script>


<style lang="less" scoped>
@import url(../../assets/styles/vars);
.liveBroadcast {
    width: 100%;
    height: 100%;
    min-height: 100vh;
    background: #f5f6fa;
    #myVideo {
        width: 100%;
        height: calc(100vh - 170px);
    }
    .fullScreenVideo {
        height: 100vh !important;
    }
    .replayLst {
        position: absolute;
        z-index: 999;
        width: 100%;
        height: 170px;
        bottom: 0px;
        left: 0px;
        background: rgba(17, 17, 70, 0.7);
    }
    .replay-info {
        margin: 15px;
        position: relative;
        z-index: 2;
        background-color: rgba(0, 0, 0, 0.25);
        border-radius: 8px;
        min-height: 140px;
    }
    .replay-title {
        color: #999999;
        font-size: 15px;
        width: 100%;
        text-align: center;
        height: 40px;
        line-height: 40px;
        padding: 5px 0px 5px 0px;
    }
    .replay-active {
        color: #ffffff;
    }
    .replay-span {
        display: inline-block;
        width: 49%;
        text-align: center;
    }
    .replay-line {
        width: 1px;
        height: 18px;
        display: inline-block;
        background: #fff;
        vertical-align: middle;
    }
    .liveList-info {
        display: inline-block;
        //padding: 15px;
        width: 100%;
    }
    .title {
        font-size: 12px;
        color: #999999;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        width: 60px;
        padding-top: 5px;
    }
    .activeTitle {
        color: #fff;
    }
    .liveList-ul {
        list-style: none;
        margin-left: 15px;
        margin-right: 15px;
        padding: 0px;
        overflow-x: auto;
        white-space: nowrap;
        overflow-y: hidden;
    }
    .liveList-ul::-webkit-scrollbar {
        display: none;
    }
    .liveList-ul .liveList-div {
        display: inline-block;
        margin: 0px 10px 0px 0px;
        text-align: center;
    }
    .live-img {
        width: 60px;
        height: 60px;
        background-repeat: no-repeat;
        background-size: cover;
    }
    .goods-img {
        width: 60px;
        height: 60px;
        border-radius: 2px;
    }
    .noReplay {
        width: 100%;
        text-align: center;
        display: inline-block;
        color: #fff;
        padding-top: 20px;
    }
}
</style>
