<template name="stayTuned">
    <div class="stayTunedcontainer">
        <span class="go_live">敬请期待....</span>
    </div>
</template>

<script>
export default {
    props: {
    // eslint-disable-next-line vue/require-default-prop
        url: ''
    },
    data() {
        return {
            roomId: ''
        }
    },
    onShow(){

    },
    methods: {

    }
}
</script>


<style lang="less" scoped>
@import url(../../assets/styles/vars);
.stayTunedcontainer {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    text-align: center;
    width: 100%;
    height: 100%;
    min-height: 100vh;
    background: #f5f6fa;
    text-align: center;
    .go_live{
        color: #d5d5d5;
        font-size: 15px;
        padding-top: 150px;
        display: inline-block;
    }
    .stay_img {
        display: inline-block;
        width: 175px;
        height: 174px;
        margin-top: 90px;
    }
    .stay_text {
        margin-top: 30px;
        text-align: center;
        color: #999999;
        font-size: 18px;
    }
    .stay_tile {
        text-align: center;
        font-size: 30px;
        font-weight: 500;
        color: rgba(114, 197, 193, 1);
        padding-top: 5px;
        padding-left: 20px;
    }
}
</style>
