<template>
    <div class="restaurant-container"
         @tap="clickBody">
        <div class="brand-top">
            <div class="search-btn">
                <div class="search-btn-wrap">
                    <img class="icon-search"
                         src="/static/images/icon-common-search@2x.png">
                    <input v-model="ipt"
                           class="search-input"
                           type="text"
                           placeholder="搜索"
                           @confirm="searchPopConfrim">
                    <img v-show="ipt"
                         class="btn-clear"
                         src="/static/images/icon-common-clear@2x.png"
                         @tap="clearSearch()">
                </div>
            </div>
            <div>
                <sel-enum :type-data="navList"
                          :building-data="buildingList"
                          :floor-data="floorList"
                          :money-data="moneyList"
                          @change="selectData" />
            </div>
        </div>
        <div class="brand_main">
            <scroll-view :scroll-y="true"
                         :style="{'height': '100%'}"
                         class="brand_list"
                         lower-threshold="100"
                         @scrolltolower="scrollToLower">
                <ul>
                    <li v-for="(item,index) in promtionPage"
                        :key="index"
                        class="tap-active restaurant-item"
                        @click="goDetail(item)">
                        <!-- <div v-if="isFoodName">
                            <food-comp :data="item"/>
                        </div>
                        <div v-else>
                            <brand-comp :data="item"/>
                        </div> -->
                        <!-- 不再区分是否是美食 -->
                        <div>
                            <brand-comp :data="item" />
                        </div>
                    </li>
                </ul>

                <load-more v-if="reachFinish" />
            </scroll-view>
            <blank-page :show-blank-page="isblank"
                        :blank-page-content="`“${ipt}…”`" />
            <!-- <blank-page :show-blank-page="promtionPage.length===0"
                        :blank-page-content="`“${ipt}…”`" /> -->
        </div>
    <!-- <search-comp :is-show="isSearchPopShow"
                     :focus="focus"
                     @cancel="myEvent"
                     @confirm="searchPopConfrim" /> -->
    </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import GradeStar from '@/components/GradeStar'
import ConditionFiltr from '../../components/ConditionFiltr'
import SearchComp from '@/components/SearchComp'
import FoodComp from '@/components/FoodComp'
import BrandComp from '@/components/BrandComp'
import SelEnum from '@/components/SelEnum'
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import wxUtils from '@/plugins/wxUtils'
import { INTELSORT, ALLSORT, ISFOOD, BUILDINGID } from '../../plugins/constants'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import moneyData from './moneyData'
import BlankPage from '@/components/blankPage'
import loadMore from '@/components/loadMore'

export default {
    components: {
        GradeStar,
        ConditionFiltr,
        SearchComp,
        FoodComp,
        BrandComp,
        SelEnum,
        BlankPage,
        loadMore
    },
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            page: {
                pageNo: 1,
                pageSize: 20
            },
            isTypePopShow: false,
            isFloorPopShow: false,
            isMoneyPopShow: false,
            currType: {},
            currFloor: {},
            currMoney: {},
            data: [],
            navList: [],
            floorList: [],
            moneyList: [],
            buildingList: [],
            totalPages: null,
            curNav: {},
            isFoodName: null,
            loaderMore: true,
            isShowModal: {
                floor: false,
                price: false
            },
            currModal: 'floor',
            ipt: '',
            filterWidth: '80%',
            getPromtionPageRequest: {
                pageNo: 1,
                pageSize: 20,
                storeName: '',
                mallId: '',
                floorNo: null,
                floorId: null,
                categoryId: null,
                sort: null,
                averageFrom: null,
                averageTo: null
            },
            promtionPage: [],
            isFoodFilterData: [
                // {
                //     name:'智能排序',
                //     value:{
                //         sort:'',
                //     },
                // },
                {
                    name: '全部',
                    value: {
                        sort: ''
                    }
                },
                {
                    name: '口味优先',
                    value: {
                        sort: 'taste'
                    }
                },
                {
                    name: '服务优先',
                    value: {
                        sort: 'service'
                    }
                },
                {
                    name: '环境优先',
                    value: {
                        sort: 'surroundings'
                    }
                }
            ],
            isNotFoodFilterData: [],
            selectCondCache: {},
            filterData: [
                {
                    title: '楼层',
                    group: 'floor',
                    data: []
                },
                {
                    title: '金额',
                    group: 'price',
                    data: []
                }
            ],
            isSearchPopShow: false,
            isClear: false,
            serachVal: false,
            focus: false,
            query: {},
            reachFinish: false,
            constFloorData: [],
            isblank:false
        }
    },
    computed: {
        ...mapState(['mallCode'])
    },
    onLoad(options) {
        this.isSearchPopShow = false
        this.ipt = ''
        this.getPromtionPageRequest.storeName = this.ipt
        this.serachVal = false

        this.getPromtionPageRequest.pageNo = 1
        this.getStoreList(0)
    },
    onHide() {
        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.BRAND_Z,
            p_stay_time: this.pageStayTime
        })
    },
    watch: {
        mallCode(newVal) {
            if (typeof newVal != 'undefined') {
                this.getPromtionPageRequest.mallId = this.mallCode
            }
        }
    },
    onShow() {
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.BRAND_P
        })
        this.isSearchPopShow = false
        this.ipt = ''
        this.getPromtionPageRequest.storeName = this.ipt
        this.getPromtionPageRequest.pageNo = 1
        this.loaderMore = true
        this.serachVal = false
        this.isblank = false
        this.promtionPage = []
        this.resetRefresh()


        this.getPromtionPageRequest.pageNo = 1
    },
    mounted() {
        this.isSearchPopShow = false
        this.ipt = ''
        this.getPromtionPageRequest.storeName = this.ipt
        this.getPromtionPageRequest.pageNo = 1
        this.loaderMore = true
        this.serachVal = false
        this.promtionPage = []
        this.resetRefresh()


        this.getPromtionPageRequest.pageNo = 1
        this.getStoreFloor()
        this.getNavList()

        //保留筛选中的人均，虽然不知道为什么
        this.moneyList = moneyData
    },
    methods: {
        selectData(operate, data) {
            if (operate == 'type') {
                this.query.categoryId = data.id
            } else if (operate == 'building') {
                this.query.buildingId = data.id
                this.query.floorId = ''
                let constFloorData = this.constFloorData
                let busArray = []
                constFloorData.forEach(item => {
                    if (data.id == '') {
                        let obj = {
                            id: item.id,
                            name: item.floorNo
                        }
                        busArray.push(obj)
                    }
                    if (item.building == data.id) {
                        let obj = {
                            id: item.id,
                            name: item.floorNo
                        }
                        busArray.push(obj)
                    }
                })
                busArray.unshift({
                    id: '',
                    name: '全部',
                    showName: '楼层'
                })
                this.floorList = busArray
            } else if (operate == 'floor') {
                this.query.floorId = data.id
            } else if (operate == 'money') {
                this.query.averageFrom = data.averageFrom
                this.query.averageTo = data.averageTo
            }
            if (operate == 'type') {
                this.query = {
                    categoryId: data.id
                }
            }
            this.selectNav()
        },
        myEvent(val) {
            this.isClear = val.clear
            this.getPromtionPageRequest.pageNo = 1
            this.ipt = ''
            this.getPromtionPageRequest.storeName = this.ipt
            this.isSearchPopShow = false
            this.focus = false
            this.getStoreList(0)
        },
        clearSearch() {
            this.getPromtionPageRequest.pageNo = 1
            this.ipt = ''
            this.getPromtionPageRequest.storeName = this.ipt
            this.isSearchPopShow = false
            this.isblank = false
            // this.serachVal = falseSearch
            this.loaderMore = true
            this.getStoreList(0)
        },
        searchPopCancel() {
            this.isSearchPopShow = false
        },
        searchPopConfrim(val) {
            this.promtionPage = []
            // this.ipt = val
            this.isSearchPopShow = false
            this.serachVal = true
            this.focus = false
            //埋点
            buryPoint.setF({
                id: pointCode.BRAND_F_SEARCH,
                p_action_id: this.ipt,
                p_action: this.ipt
            })
            this.getStoreList(3)//3代表搜索
            //this.resetRefresh()
        },
        resetRefresh() {
            //重置刷新
            this.getPromtionPageRequest.pageNo = 1
            this.getPromtionPageRequest.storeName = this.ipt

            this.getStoreList(0)
        },
        toSearch() {
            this.focus = true
            this.isSearchPopShow = true
        },
        //到达底部
        scrollToLower(e) {
            if (this.loaderMore) {
                this.getPromtionPageRequest.pageNo++
                this.getStoreList(1)
            } else {
                if (this.promtionPage.length > 20) {
                    this.reachFinish = true
                } else {
                    this.reachFinish = false
                }
            }
        },
        goDetail(item) {
            let type = item.isFood === true ? 1 : 2
            //埋点
            buryPoint.setF({
                id: pointCode.BRAND_F_DETAIL,
                p_action_id: item.shopId,
                p_action: item.storeName
            })
            wx.navigateTo({
                url: `/pages/restaurant/detail?id=${item.id}&type=${type}&shopId=${item.shopId}`
            })
        },
        openTypePop() {
            this.isTypePopShow = !this.isTypePopShow
            this.isShowModal[this.currModal] = false
        },
        selectNav(data) {
            this.getPromtionPageRequest.pageNo = 1
            this.promtionPage = []
            this.getStoreList(4)//4代表切换tab
        },
        getFilterParams(val) {
            // console.log(val)
            let orderBy = val['楼层']
            let ownerType = val['金额']

            let orderByObj = {
                floorId: null,
                floorNo: null
            }
            let ownerTypeObj = {
                averageFrom: null,
                averageTo: null
            }

            this.ipt = ''
            this.getPromtionPageRequest.storeName = this.ipt

            if (orderBy) {
                this.getPromtionPageRequest = Object.assign(this.getPromtionPageRequest, orderBy)
            } else {
                if (this.curNav.name === ISFOOD) {
                    this.getPromtionPageRequest.sort = null
                } else {
                    this.getPromtionPageRequest = Object.assign(this.getPromtionPageRequest, orderByObj)
                }
            }
            if (ownerType) this.getPromtionPageRequest = Object.assign(this.getPromtionPageRequest, ownerType)
            if (!ownerType) this.getPromtionPageRequest = Object.assign(this.getPromtionPageRequest, ownerTypeObj)
        },
        getFilter(val, data) {
            this.currModal = data.group
            this.getFilterParams(val)
            this.getPromtionPageRequest.pageNo = 1
            this.getStoreList(0)
        },
        getNavList() {
            let params = {
                mallCode: this.mallCode
            }
            let opsiton = {
                path: api.getStoreNav,
                method: 'get',
                data: params,
                hideLoading: true
            }
            request(opsiton).then(res => {
                console.log(res)
                if (res.code == 200) {
                    let data = res.data
                    data.map(item => {
                        item.name = item.categoryName
                    })
                    data.unshift({
                        id: '',
                        name: '全部',
                        showName: '分类'
                    })
                    this.navList = res.data
                }
            })
        },
        getStoreFloor() {
            let params = {
                mallCode: this.mallCode
            }
            let opsiton = {
                path: api.getStoreFloor,
                method: 'get',
                data: params,
                hideLoading: true
            }
            request(opsiton).then(res => {
                if (res.code == 200) {
                    if (res.data) {
                        let data = res.data
                        let busArray = []
                        let buildingData = []
                        let floorData = []
                        data.forEach(item => {
                            let busObj = {}
                            let busObjFloor = {}
                            if (busArray.length == 0) {
                                busArray.push(item.building)
                                busObj.id = item.building
                                busObj.name = item.buildingCode
                                buildingData.push(busObj)
                            } else {
                                if (busArray.indexOf(item.building) == -1) {
                                    busArray.push(item.building)
                                    busObj.id = item.building
                                    busObj.name = item.buildingCode
                                    buildingData.push(busObj)
                                }
                            }

                            busObjFloor.id = item.id
                            busObjFloor.name = item.floorNo
                            floorData.push(busObjFloor)
                        })
                        buildingData.unshift({
                            id: '',
                            name: '全部',
                            showName: '楼栋'
                        })
                        // data.map(item => {
                        //     ;(item.id = item.floorNo), (item.name = item.floorNo)
                        // })
                        floorData.unshift({
                            id: '',
                            name: '全部',
                            showName: '楼层'
                        })
                        this.constFloorData = data
                        this.buildingList = buildingData
                        this.floorList = floorData
                    }
                }
            })
        },
        getStoreList(times) {
            // delete this.getPromtionPageRequest.floorId
            let { pageNo, pageSize } = this.getPromtionPageRequest
            let params = {
                storeName: this.ipt,
                mallId: this.mallCode
            }
            Object.assign(
                params,
                {
                    pageNo,
                    pageSize
                },
                this.query
            )
            // debugger
            let requestOptions = {
                path: api.getStoreList,
                method: 'post',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                // if (!res.data.records) {
                //     this.promtionPage = []
                //     this.loaderMore = false
                //     return
                // }
                // if (res.data.records.length < 20) {
                //     this.loaderMore = false
                // }
                //判断是否有下一页
                if(!res.data.hasNextPage){
                    this.loaderMore = false
                }else{
                    this.loaderMore = true
                }
                let list = res.data.records
                this.isFoodName = this.curNav.name === ISFOOD ? true : false

                if (times == 1) {
                    let newList = list.map(item => {
                        return {
                            ...item,
                            userTag: item.userTag ? item.userTag.split(',') : []
                        }
                    })
                    this.promtionPage = this.promtionPage.concat(newList)
                    if (0 <= res.data.records.length && res.data.records.length < this.getPromtionPageRequest.pageSize) {
                        this.reachFinish = true
                    }

                } else if(times == 3){
                    if(list.length === 0){
                        this.isblank = true;
                        this.reachFinish = false;
                    }else{
                        this.isblank = false;

                        let newList = list.map(item => {
                        return {
                            ...item,
                            userTag: item.userTag ? item.userTag.split(',') : []
                        }
                        })
                        this.promtionPage = this.promtionPage.concat(newList)
                    }
                } else if(times == 4){
                    if(list.length === 0){
                        this.isblank = true;
                        this.reachFinish = false;
                    }else{
                        this.isblank = false;

                        let newList = list.map(item => {
                        return {
                            ...item,
                            userTag: item.userTag ? item.userTag.split(',') : []
                        }
                        })
                        this.promtionPage = this.promtionPage.concat(newList)
                    }
                }  else {
                    this.reachFinish = false
                    if (list.length === 0) {
                        this.promtionPage = []
                        this.isblank = true
                    } else {
                        this.promtionPage = list.map(item => {
                            return {
                                ...item,
                                userTag: item.userTag ? item.userTag.split(',') : []
                            }
                        })
                    }
                }
            })
        },
        updateIsShow(val) {
            this.isShowModal[this.currModal] = !this.isShowModal[this.currModal]
            this.isTypePopShow = false
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        console.log('shag')
        this.loaderMore = true
        this.resetRefresh()
        wx.stopPullDownRefresh()
    },
    onTabItemTap(item) {
        //埋点
        buryPoint.setF({
            id: pointCode.TABBAR_F_BRAND
        })
    },
    // // 页面滚动到底部
    onReachBottom() {
        if (this.loaderMore) {
            this.getPromtionPageRequest.pageNo++
            this.getStoreList(1)
        } else {
            if (this.promtionPage.length > 20) {
                // wx.showToast({
                //     title: '我是有底线的',
                //     icon: 'none',
                //     duration: 2500
                // })
            }
        }
    }
}
</script>

<style lang="less">
@import '../../assets/styles/vars';
page {
    height: 100%;
}
.restaurant-container {
    display: flex;
    flex-direction: column;
    height: 100%;

    .filter-title-text-wrap {
        overflow: hidden;
        font-size: 15px;
        color: #333;
        line-height: 50px;
        text-align: center;
        position: relative;
        display: flex;
        padding: 0 15px;
        justify-content: center;
        align-items: center;
        & > div {
            position: relative;
            display: inline-block;
            padding-right: 23px;
            height: 100%;
            overflow: hidden;
        }
        .filter-title-text {
            box-sizing: border-box;
            display: inline-block;
            width: 100%;
        }
        .filter-title-img {
            position: absolute;
            top: 50%;
            display: inline-block;
            right: 6px;
            transform: translateY(-50%);
            img {
                width: 8px;
                height: 5px;
            }
        }
    }

    .brand-top {
        flex: 0 1 auto;
    }
    .brand_main {
        flex: 1;
        overflow: hidden;
    }
    .brand_box {
        flex: 1;
        display: flex;
        overflow: hidden;
        height: 50px;
        border-bottom: 1px solid @border-color;
        .brand_nav {
            overflow: hidden;
            flex: 1;
            height: 100%;
            color: #000;
            font-size: 12px;
            // overflow-y: auto;
            // overflow-x: hidden;
            .brand_sel {
                position: relative;
                height: 100%;
                line-height: 50px;
                background: #fff;
                text-align: center;
                font-size: 15px;
                color: @black-color;
                border-bottom: 1px solid #ddd;
                padding: 0 15px;
                &:after {
                    display: inline-block;
                    content: '';
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    right: 0;
                    height: 20px;
                    width: 1px;
                    background: #ddd;
                }
                .brand_sel_text_wrap {
                    width: 100%;
                    height: 100%;
                    display: inline-block;
                    .brand_sel_text {
                        position: relative;
                        box-sizing: border-box;
                        width: 100%;
                        height: 100%;
                        padding-right: 16px;
                        box-sizing: none;
                        display: inline-block;
                        .brand_sel_text_2 {
                            display: inline-block;
                        }
                    }
                }
                .brand_sel_arrow {
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    display: inline-block;
                    right: 6px;
                    display: inline-block;
                    width: 8px;
                    height: 5px;
                    img {
                        display: inline-block;
                        width: 100%;
                        height: 100%;
                    }
                }
            }
        }
        .brand_content {
            overflow: hidden;
            flex: 2;
            display: flex;
            flex-direction: column;
            .brand_type {
                height: 50px;
            }
            .brand_list {
                flex: 1;
                // overflow-y: auto;
                z-index: 9;
                .noMore {
                    text-align: center;
                    color: #999;
                    padding-bottom: 10px;
                }
            }
        }
    }
    .restaurant-item {
        //border-bottom: 1px solid @border-color;
        background: rgba(255, 255, 255, 1);
        box-shadow: 0px 0px 5px 0px rgba(188, 188, 188, 0.3);
        border-radius: 4px;
        margin: 20px;
        height: 96px;
        overflow: hidden;
        &:last-child {
            border: 0;
        }
    }
    .btn-clear {
        z-index: 10;
        width: 15px;
        height: 16px;
        padding: 9.5px;
        position: absolute;
        top: 50%;
        right: 15px;
        transform: translateY(-50%);
        font-size: 15px;
    }
    .search-btn {
        text-align: left;
        line-height: 50%;
        .search-btn-wrap {
            background-color: #ffffff;
            border-radius: 4px;
        }
        .icon-search {
            position: absolute;
            top: 50%;
            left: 15%;
        }
        .search-input {
            height: 38px;
            line-height: 28px;
            width: 90%;
            background: #ffffff;
            display: inline-block;
            padding-left: 30px;
            background-color: #ffffff;
        }
    }
}
</style>
