export default [{
    id: '',
    name: '全部',
    averageFrom: null,
    averageTo: null,
    showName: '人均'
},
{
    id: 1,
    name: '100元以下',
    averageFrom: null,
    averageTo: 99
},
{
    id: 2,
    name:'100-300元',
    averageFrom: 100,
    averageTo: 300,
},
{
    id: 3,
    name:'300-500元',
    averageFrom: 300,
    averageTo: 500,
},
{
    id: 4,
    name:'500元以上',
    averageFrom: 500,
    averageTo: null,
},]
