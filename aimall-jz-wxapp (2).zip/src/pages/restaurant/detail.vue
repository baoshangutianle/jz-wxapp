<template>
    <div class="restaurant-detail-box">
        <view class="aqh-swiper">
            <swiper
                :circular="true"
                :indicator-dots="true"
                :autoplay="true"
                indicator-active-color="#f9f8f8"
            >
                <block
                    v-for="(item,index) in imgUrls"
                    :key="index"
                >
                    <swiper-item>
                        <image
                            :src="item"
                            class="slide-image"
                        />
                    </swiper-item>
                </block>
            </swiper>
        </view>
        <div class="list-box">
            <div class="list-item">
                <div class="restaurant-basic">
                    <p class="flex-wrp restaurant-name-operate">
                        <span class="flex-item restaurant-name">{{ storeName }}</span>
                    </p>
                    <p
                        v-if="type === '1'"
                        class="restaurant-price-grade"
                    >
                        <span class="restaurant-grade">
                        <grade-star :value="grade" /></span>
                        <span
                            v-show="average"
                            class="restaurant-price"
                        >¥{{ average }}/人</span>
                    </p>
                    <p class="flex-wrp restaurant-feature">
                        <span
                            v-if="type === '1'"
                            class="flex-item restaurant-grade-detail"
                        >
                            口味:{{ tasteGrade }} 环境:{{ surroundingsGrade }} 服务:{{ serviceGrade }}
                        </span>
                        <span
                            v-if="type === '1'"
                            class="flex-item restaurant-price txt-right"
                        >{{ categoryName }}</span>
                        <span
                            v-if="type === '2'"
                            class="flex-item restaurant-price txt-left"
                        >{{ categoryName }}</span>
                    </p>
                </div>
            </div>
            <div
                v-if="type === '1'"
                class="list-item restaurant-other-box"
            >
                <div class="restaurant-other">
                    <div class="flex-wrp restaurant-time">
                        <div class="flex-item">
                            <span class="restaurant-time-img">
                                <img
                                    src="/static/images/time-icon.png"
                                    alt=""
                                >
                            </span>
                            <span class="restaurant-time-name">
                                营业时间
                            </span>
                            <span class="restaurant-times">
                                {{ openingHours }}
                            </span>
                            <ul class="restaurant-tags">
                                <li
                                    v-for="(item,index) in userTag"
                                    :key="index"
                                >{{ item }}</li>
                            </ul>
                        </div>
                        <div
                            v-show="mobile"
                            class="flex-item restaurant-call"
                        >
                            <img
                                class="icon"
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/2c19b5c9304d4d51a5f8bd7fb63a3da3.png"
                                alt="电话"
                                @tap="call"
                            >
                        </div>
                    </div>
                </div>
            </div>
            <div class="list-item">
                <div class="restaurant-contact">
                    <div class="flex-wrp restaurant-phone">
                        <div class="flex-item">
                            <span class="restaurant-phone-img">
                                <img src="/static/images/location.png">
                            </span>
                            <span class="flex-item restaurant-phone-name">{{ buildingCode }}-{{ floorNo }}-{{ positionNo }}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="list-item">
                <div class="restaurant-detail">
                    <p>
                        <span class="restaurant-merchant-img">
                            <img src="/static/images/merchant-icon.png">
                        </span>
                        商户详情</p>
                    <div class="restaurant-detail-txt">{{ storeDesc }}</div>
                </div>
            </div>
        </div>
        <!-- 吸底 -->
        <div class="restaurant-footer">
            <div>
                <span>
                    <share />
                </span>
                <!-- <span>分享</span> -->
                <span class="collect-icon">
                    <collect-comp
                        :content-id="contentId"
                        :content-type="contentType"
                        :collectState="collectState"
                        @getCollectNum="getshareNum"
                    />
                </span>
                <!-- <span>收藏</span> -->
            </div>

        </div>
    </div>
</template>

<script>
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import wxUtils from '@/plugins/wxUtils'
import GradeStar from '@/components/GradeStar'
import collectComp from '@/components/CollectComp'
import share from '@/components/ShareBtn'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
export default {
    components: {
        GradeStar,
        collectComp,
        share
    },
    data() {
        return {
            pageStayTime: 0,//页面停留时间
            contentId: '',
            contentType: 1,
            type: '',
            storeName: '',
            grade: '',
            average: '',
            tasteGrade: '',
            surroundingsGrade: '',
            serviceGrade: '',
            categoryName: '',
            openingHours: '',
            userTag: [],
            mobile: '',
            buildingCode: '',
            floorNo: '',
            positionNo: '',
            storeDesc: '',
            showIcon: '',
            imgUrls: [],
            collectState: false
        };
    },
    onLoad() {
        this.getDetailById()
        this.getshareNum()
    },
    onShow() {
    // 埋点 P
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.BRAND_DETAIL_P,
            p_id: this.$root.$mp.query.shopId
        })
    },
    onUnload() {
    //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.BRAND_DETAIL_Z,
            p_id: this.$root.$mp.query.shopId,
            p_stay_time: this.pageStayTime
        })
    },

    methods: {
        call() {
            wx.makePhoneCall({
                phoneNumber: this.mobile
            })
        },
        fnCallStore() {
            if (this.mobile) {
                wx.makePhoneCall({
                    phoneNumber: this.mobile,
                })
            }
        },
        getDetailById() {
            this.type = this.$root.$mp.query.type;
            let id = this.$root.$mp.query.id;
            this.contentId = id;
            let opsiton = { path: api.getStoreListDetail + id }
            request(opsiton).then(res => {
                if (res.code == 200) {
                    // debugger
                    let data = res.data;
                    this.imgUrls = data.shopDetailPictures;
                    this.storeName = data.storeName;
                    this.grade = data.grade;
                    this.average = data.average;
                    this.tasteGrade = data.tasteGrade;
                    this.surroundingsGrade = data.surroundingsGrade;
                    this.serviceGrade = data.serviceGrade;
                    this.categoryName = data.categoryName;
                    // this.openingHours = data.openingHours;
                    this.userTag = data.userTag ? data.userTag.split(',') : [];
                    this.mobile = data.mobile;
                    this.buildingCode = data.buildingCode;
                    this.floorNo = data.floorNo;
                    this.positionNo = data.positionNo;
                    this.storeDesc = data.storeDesc;
                    this.showIcon = data.showIcon;
                    let timeArr = JSON.parse(data.openingHours);
                    this.openingHours = this.getTimeRangeStr(timeArr)
                    this.isFood = data.isFood || false
                }
            })
        },
        getTimeRangeStr(data) {
            var timeResult = []
            data.forEach(item => {
                var temp = [];
                if (item.start) {
                    temp.push(item.start)
                }
                if (item.end) {
                    temp.push(item.end)
                }

                timeResult.push(temp.join(' — '))
            })
            return timeResult.join("，")
        },
        //获取转发、收藏个数
        getshareNum(item){
            //证明是从操作收藏取消收藏过来的
            let collectFlag
            if(item == 'collectFlag'){
                collectFlag = true
            }else {
                collectFlag = false
            }
            let wxUserCode = wx.getStorageSync('wxUserCode') ? wx.getStorageSync('wxUserCode') :''
            let requestOptions = {
                    path: api.creatCollect,
                    method: 'post',
                    data: {
                        "contentId": this.contentId,
                        "contentType": '1',
                        "userCode": wxUserCode,
                        "collectFlag": collectFlag
                    }
                }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    if(collectFlag){
                        var msg = this.collectState ? '取消收藏' : '已收藏'
                        wx.showToast({
                            icon: 'success',
                            title: msg
                        })
                    }
                    this.collectState = res.data.collectState ? res.data.collectState : false
                    // this.shareNum = res.data.relayNum ? res.data.relayNum :''
                    // this.collectNum = res.data.collectNum ? res.data.collectNum :''
                }
            })
        }
    },
    // 分享
    onShareAppMessage() {
        return {
            title: this.storeName,
            desc: '',
            path: 'pages/home?pageId=restaurant&id=' + this.$root.$mp.query.id + '&type=' + this.$root.$mp.query.type,
            success: function(res) {
                console.log(res)
            },
            fail: function(err) {
                console.log(err)
            }
        }
    }
}

</script>

<style lang='less' scoped>
@import '../../assets/styles/vars';
@import '../../assets/styles/common';
.restaurant-detail-box {
    padding-bottom: 100px;
    color: @black-color;
    .restaurant-img {
        display: block;
        width: 100%;
        height: 215px;
        background: gray;
    }
    .aqh-swiper {
        width: 100%;
        height: 272px;
        swiper {
            height: 100%;
        }
        image {
            width: 100%;
            height: 272px;
        }
    }
    .list-box {
        padding: 0 20px 0 20px;
        .restaurant-call,
        .restaurant-navigate {
            position: relative;
            flex: 0 1 auto;
            align-items: center;
            .icon {
                display: inline-block;
                width: 16px;
                height: 22px;
                margin-right: 10px;
                &:before {
                    position: absolute;
                    top: 50%;
                    left: -15px;
                    transform: translateY(-50%);
                    display: inline-block;
                    content: '';
                    height: 40px;
                    width: 1px;
                    background: #e7e7e7;
                }
                &.icon-navigate {
                    width: 18px;
                    height: 18px;
                }
            }
        }
        .restaurant-basic {
            padding: 0 0 15px 0;
            font-size: 15px;
            color: @gray-color;
            border-bottom: 1px solid @line-color;
            font-weight: 200;
            .restaurant-feature {
                margin-top: 10px;
            }
            p {
                margin-top: 15px;
                justify-content: space-between;
                color: @black-color;
                &.restaurant-name-operate {
                    margin-top: 15px;
                    align-items: center;
                    .restaurant-name {
                        font-size: 20px;
                        font-weight: bold;
                        line-height: 28px;
                    }
                }
                &.restaurant-price-grade {
                    .restaurant-grade {
                        display: inline-block;
                    }
                    .restaurant-price {
                        margin-left: 20px;
                        vertical-align: middle;
                    }
                }
                &.flex-wrp {
                    .txt-right {
                        text-align: right;
                    }
                    .txt-left {
                        text-align: left;
                    }
                }
            }
        }
        .restaurant-other-box {
            display: flex;
            .restaurant-phone-icon-wrap {
                flex: 0 1 auto;
                align-self: center;
                .restaurant-phone-icon {
                    position: relative;
                    display: inline-block;
                    width: 19px;
                    height: 19px;
                    background: gray;
                    &:before {
                        position: absolute;
                        top: 50%;
                        transform: translateY(-50%);
                        left: -13px;
                        display: inline-block;
                        content: '';
                        width: 1px;
                        height: 20px;
                        background: #d8d8d8;
                        vertical-align: middle;
                    }
                }
            }
        }
        .restaurant-other {
            flex: 1;
            padding: 15px 0;
            border-bottom: 1px solid @line-color;
            .restaurant-time {
                font-size: 12px;
                color: @black-color;
                display: flex;
                align-items: center;
                .restaurant-time-img {
                    display: inline-block;
                    margin-right: 4px;
                    vertical-align: middle;
                    margin-top: -5px;
                    img {
                        width: 20px;
                        height: 20px;
                    }
                }
                .restaurant-time-name {
                    font-size: 18px;
                    font-weight: bold;
                    margin-right: 6px;
                }
            }
            .restaurant-tags {
                margin-top: 4px;
                li {
                    display: inline-block;
                    padding: 2px 6px;
                    border: 1px solid @theme-color;
                    font-size: 12px;
                    color: @theme-color;
                    & + li {
                        margin-left: 5px;
                    }
                }
            }
        }
        .restaurant-contact {
            justify-content: space-between;
            padding: 15px 0;
            border-bottom: 1px solid #e7e7e7;
            .restaurant-phone {
                display: flex;
                align-items: center;
                .restaurant-phone-name {
                    font-size: 18px;
                    font-weight: bold;
                    line-height: 20px;
                    color: #333;
                }
                .restaurant-phone-img {
                    display: inline-block;
                    margin-right: 4px;
                    vertical-align: middle;
                    margin-top: -2px;
                    img {
                        width: 20px !important;
                        height: 20px !important;
                    }
                }
                .restaurant-phone-icon-wrap {
                    flex: 0 1 auto;
                    .restaurant-phone-icon {
                        position: relative;
                        display: inline-block;
                        width: 19px;
                        height: 19px;
                        background: gray;
                        &:before {
                            position: absolute;
                            top: 50%;
                            transform: translateY(-50%);
                            left: -13px;
                            display: inline-block;
                            content: '';
                            width: 1px;
                            height: 20px;
                            background: #d8d8d8;
                            vertical-align: middle;
                        }
                    }
                }
            }
        }
        .restaurant-detail {
            padding: 15px 0;
            color: #333;
            > p {
                font-size: 18px;
                font-weight: bold;
                padding-bottom: 10px;
            }
            .restaurant-detail-txt {
                font-size: 15px;
                line-height: 22px;
                color: #666;
                font-weight: 200;
            }
        }
    }
    .btn-operate-receive {
        margin: 69px 50px 0;
    }

    .restaurant-times {
        color: #666;
        font-size: 15px;
        display: block;
        padding-top: 10px;
    }
    .restaurant-merchant-img {
        display: inline-block;
        margin-right: 4px;
        vertical-align: middle;
        margin-top: -3px;
        img {
            width: 20px;
            height: 20px;
        }
    }
}
</style>
