<template>
    <div class="vr">
        <img
            class="stay_img"
            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191107/321e8d2b74e742ba82afed1721506b62.png"
        >
        <p class="stay_text">功能紧张开发中...</p>
    </div>
</template>

<script>

export default {
    data() {
        return {
            webViewUrl: ''
        }
    },
    onShow() {

    },
    mounted() {
        this.webViewUrl = 'http://aegeanpark.uat1.rs.com/map/#/temp-m-map' + new Date().getTime()
    }
}
</script>


<style lang="less" scoped>
.vr {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    text-align: center;
    .stay_img {
        display: inline-block;
        width: 193px;
        height: 175px;
        margin-top: 99px;
    }
    .stay_text {
        margin-top: 30px;
        text-align: center;
        color: #999;
        font-size: 18px;
    }
    .stay_tile {
        text-align: center;
        font-size: 15px;
        color: #999;
        padding-top: 5px;
    }
}
</style>
