<template>
    <div class="checkDetail">
        <div class="check-title">
            <span class="check-text">签到明细</span>
            <span class="check-useIn">当前可用<span class="chenk-jifen">{{integral}}</span>分</span>
        </div>
        <div class="check-list">
             <scroll-view
                    :scroll-y="true"
                    class="check-list-ul"
                    @scrollToLower="onReachBottom"
                    @scroll-top="scrollTop"
                >
                <ul v-if="checkList">
                    <li v-for="(item,index) in checkList" :key="index">
                        <div class="check-left">
                            <p class="check-name">{{item.signRewardType}}</p>
                            <p class="check-time">{{item.createTime}}</p>
                        </div>
                        <div class="check-right">
                            <span class="check-prize">{{item.attendanceAward}}</span>
                        </div>
                    </li>
                </ul>
                <div v-if="checkList.length===0">
                    <block-page :type="checkInText" />
                </div>
                <load-more v-if="reachFinish" />
             </scroll-view>
        </div>
    </div>
</template>
<script>
import { mapState, mapMutations } from 'vuex'
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import blockPage from '@/components/blockPage'
import loadMore from '@/components/loadMore'
export default {
    components: {
        blockPage,
        loadMore
    },
    data() {
        return {
            checkInText:'签到',
            reachFinish: false,
            loadingMore: false,
            checkList: [],
            pageNum: 1,
            pageSize: 10,
            mallCode: '',
            integral: '',
            isDataFinish: false,
            activityId: '',
            scrollTop: 100

        }
    },
    onShow(){
        this.mallCode = wx.getStorageSync('mallCode')
        this.activityId = this.$root.$mp.query.activityId
        this.getIntergral()
        this.resetRefresh()
    },
    computed: {
        ...mapState(['sessionId','mallCode', 'vipInfo','isLogined'])
    },
    methods: {
        resetRefresh(){
            this.checkList = []
            this.pageNum = 1
            this.pageSize = 10
            this.reachFinish = false
            this.loadingMore = false
            this.isDataFinish = false
            this.getList(1)
        },
        //获取积分
        getIntergral() {
            let params = Object.assign(
                {
                    pageNum: 1,
                    pageSize: 10,
                     memberId: this.vipInfo.id
                }
            )
            let requestOptions = {
                path: api.getIntegralDetail,
                method: 'get',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                let { totalPoints } = res.data
                this.integral = totalPoints
            })
        },
        getList(times){
            const t = this
            let requestOptions = {
                 path: api.signDetails +"?pageNum="+t.pageNum+"&pageSize="+ t.pageSize +"&mallCode="+t.mallCode +"&activityId="+t.activityId,
                method: 'get',
                data: {}
            }
            request(requestOptions).then(res => {
                if(res.code == 200){
                    if(times == 1){
                        t.checkList = res.data.list
                    }else{
                        t.checkList =t.checkList.concat(res.data.list)
                    }
                    //数据加载结束
                    if (0 <= res.data.list.length && res.data.list.length < t.pageSize) {
                        t.isDataFinish = true
                    } else {
                        t.isDataFinish = false
                    }
                }
            })
            t.loadMore = false
        },
    },
    // 页面滚动到底部
    onReachBottom() {
        if (!this.isDataFinish) {
            this.pageNum++
            this.getList()
            if(this.checkList.length > 10){
                this.reachFinish = true
            } else {
                this.reachFinish = false
            }
        }else{
            if(this.checkList.length > 10){
                this.reachFinish = true
            } else {
                this.reachFinish = false
            }
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
        this.loadMore = true
        this.resetRefresh()
    },
}
</script>
<style lang="less" scoped>
.checkDetail{
    width: 100%;
    .check-title{
        padding: 16px;
        border-bottom: solid 1px #e7e7e7;
    }
    .check-text{
        color: #999999;
        font-size: 15px;
        font-weight: 400;
    }
    .check-useIn{
        color: #999999;
        font-size: 15px;
        font-weight: 400;
        float: right;
    }
    .chenk-jifen{
        color: #333333;
        font-size: 15px;
        padding-left: 15px;
        padding-right: 15px;
    }
    .check-list{
        .check-list-ul{
            min-height: 100vh;
        }
        padding: 0px 16px;
        overflow: hidden;
        ul li{
            padding: 10px 0px;
            border-bottom: solid 1px #E7E7E7;
        }
        .check-left,.check-right{
            display: inline-block;
        }
        .check-right{
            float: right;
        }
        .check-name{
            color: #333333;
            font-size: 15px;
            font-weight: 400;
        }
        .check-time{
            padding-top: 7px;
            color: #999999;
            font-size: 13px;
            font-weight: 400;
        }
        .check-prize{
            font-size: 15px;
            color: #333333;
            padding-top: 10px;
            display: inline-block;
        }
    }
}
</style>
