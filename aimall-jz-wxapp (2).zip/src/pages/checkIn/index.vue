<template>
    <div class="signActivity">
        <div class="signin">
            <img class="signin-bg"
                     src="https://img-cdn.aimall.cloud/as/20200601/bfa4dbf546d14ef8b55c2be43b3135c5.png"
                     alt="">
            <p class="sign-p">
                <span  class="signTitle">签到日历</span>
                <span  class="signDay">您已签到{{signDays}}天</span>
            </p>
        </div>
        <div id="calendar">
            <div class="calendar-head">
                <p class="calendar-head-p">
                    <span class="calendar-head-span calendar-head-span1" @click="changeMonth('prev')"> <img src="https://img-cdn.aimall.cloud/as/20200601/333209eb59d44fd99bea01ac1ead138b.png"/> </span>
                    <span class="calendar-head-span calendar-head-span2">{{calendarDay}}</span>
                    <span class="calendar-head-span calendar-head-span1" @click="changeMonth('next')"> <img src="https://img-cdn.aimall.cloud/as/20200601/18c80d02a5c54cf8bbb6e784a0fa50e0.png"/> </span>
                </p>
            </div>
            <table>
                <tbody>
                    <tr class="week">
                        <th v-for="(d,idx) in week" :key="idx">{{ d }}</th>
                    </tr>
                    <tr class="days">
                        <div v-if="firstDay !=0">
                            <th v-for="(dd,idx) in firstDay" :key="idx" class="color9">&nbsp;</th>
                        </div>
                        <th v-for="(item,index) in dayArr" :key="index" :class="{isDay : item.isDay,isCheckIn : item.sign}">
                            <span :class="[item.selected ? 'selected' : '',!item.range ? 'rangedate' : '']" class="daile-span">{{ item.daily }}</span>
                            <span :class="[item.selected ? 'selected' : '',!item.range ? 'rangedate' : '']" class="month-span">{{ item.month ?item.month+'月':'' }}</span>
                            <!-- <span :class="item.selected ? 'selected' : ''" class="daile-span">{{ item.daily }}</span>
                            <span :class="item.selected ? 'selected' : ''" class="month-span">{{ item.month ?item.month+'月':'' }}</span> -->
                            <span class="check-icon" v-if="!item.isDay && item.sign">
                                <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191114/23776c6fec084805a917b5ab40f50f83.png"/>
                            </span>
                            <span class="check-icon" v-else-if="item.isDay && item.sign">
                                <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191114/1f2c98634b5e4a5cb3852e3f289c6380.png"/>
                            </span>
                        </th>
                    </tr>
                </tbody>
            </table>
            <div class="chenkIn-status">
            <p v-if="isSignDay">已连续签到{{continuousSum}}天,继续保持哦</p>
            <p v-else>今天还没有签到哦</p>
        </div>

        <div class="checkIn-btn">
            <button class="checkIn-detail">
                <auth-btn @pass="goDetail" />
                签到明细
            </button>
            <button class="checkIn-day" v-if="!isSignDay  && !isSaveSign">
                <auth-btn @pass="signClick" />
                今日签到
            </button>
            <button class="checkIn-day isCkeckDay" v-if="isSaveSign">暂无签到</button>
            <button class="checkIn-day isCkeckDay" v-if="isSignDay && !isSaveSign">已签到</button>
        </div>
        <div class="checkIn-rule">
            <p class="rule-title">
                <span class="rule-span"></span>
                <span class="rule-text">签到规则</span>
            </p>
            <div class="card-rule-use">
                <span v-html="rule" />
            </div>
        </div>
    </div>
    </div>
</template>
<script>
import moment from 'moment'
import utils from '@/plugins/utils'
import { mapState, mapMutations } from 'vuex'
import wxUtils from '@/plugins/wxUtils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import AuthBtn from '@/components/AuthBtn'
export default {
    data() {
        return {
            firstDay: 0,
            week: ['日', '一', '二', '三', '四', '五', '六'],
            signDays: '0',
            isSignDay: false,
            dayArr: [],
            rule: '',
            mallCode: '',
            continuousSum: '',
            activityId: '',
            isSaveSign: false,
            monthNum: 0,
            clickNum: 0,
            calendarDay: '',
            currentDay: '',
            targetMonth: ''
        }
    },
    components: {
        AuthBtn
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo', 'isLogined'])
    },
    onShow() {
        this.isSaveSign = false
        this.isSignDay = false
        this.calendarDay = ''
        this.monthNum = 0
        this.clickNum = 0
        this.currentDay = ''
        this.targetMonth = ''
        this.getAcitivitySign()
    },
    methods: {
        ...mapMutations(['update']),
        //判断是否可以签到，有无签到活动
        getAcitivitySign() {
            let mallCode = wx.getStorageSync('mallCode')
            let requestOptions = {
                path: api.getActivitySign + '?mallCode=' + mallCode,
                method: 'get',
                data: {}
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    if (res.data) {
                        this.getSignInfo()
                    } else {
                        this.isSaveSign = true //无签到活动
                        this.getSignInfo()
                    }
                } else {
                    this.getSignInfo()
                }
            })
        },
        changeMonth(type){
            //只能点击前后两个月
            if(type == 'prev'){
                if(this.clickNum <=-2){
                    return
                }
                this.monthNum--
            }else if (type == 'next'){
                if(this.clickNum >= 2){
                    return
                }
                this.monthNum++
            }

            this.getSignInfo()
        },
        getSignInfo() {
            const t = this
            let mallCode = wx.getStorageSync('mallCode')
            let wxUserCode = wx.getStorageSync('wxUserCode') ? wx.getStorageSync('wxUserCode') : ''
            let requestOptions = {
                path: api.getSignCalendar + '?mallCode=' + mallCode + '&userCode=' + wxUserCode + '&monthIndex=' +this.monthNum,
                method: 'get',
                data: {}
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    t.signDays = res.data.totalSum
                    t.rule = res.data.introduction ? res.data.introduction.replace(/\n/g, '<br>') : ''
                    t.continuousSum = res.data.continuousSum ? res.data.continuousSum : ''
                    t.activityId = res.data.activityId ? res.data.activityId : ''
                    t.calendarDay = res.data.targetMonth ? moment(res.data.targetMonth).format('YYYY年MM月') : ''
                    t.targetMonth = res.data.targetMonth ? res.data.targetMonth : ''
                    t.currentDay = res.data.currentMonth ? res.data.currentMonth : ''
                    t.clickNum = moment(this.targetMonth).diff(moment(this.currentDay),'months')
                    if (res.data.signRecord) {
                        //判断返回的第一条数据是周几
                        t.firstDay = t.getWeekByDay(res.data.signRecord[0].calendarDay)
                        res.data.signRecord.map((item, index) => {
                            //判断是否是今天,且是否签到
                            if (item.today) {
                                item.isDay = true
                                if (item.sign) {
                                    t.isSignDay = true
                                } else t.isSignDay = false
                            } else {
                                item.isDay = false
                            }
                        })
                        t.dayArr = res.data.signRecord
                    }
                }
            })
        },
        //签到
        signClick() {
            const t = this
            //二次授权手机号
            if(!t.vipInfo){
                return
            }
            let data = {
                activityId: t.activityId
            }
            wx.request({
                url: api.signIn,
                method: 'POST',
                data: data,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code == 200) {
                        wx.showToast({
                            title: res.data.message,
                            icon: 'none'
                        })
                    } else if (res.data.code === 4001 || res.data.code === 4000) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = t.isLogined
                                wxUtils.clearLoginStorage()
                                t.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        })
                    } else {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '知道了',
                            success: function(res) {}
                        })
                    }
                    t.getSignInfo()
                }
            })
        },
        //跳转签到明细
        goDetail() {
            //二次授权手机号
            if(!this.vipInfo){
                return
            }
            wx.navigateTo({
                url: `/pages/checkIn/detail?activityId=${this.activityId}`
            })
        },
        getWeekByDay(dayValue) {
            //dayValue=“2014-01-01”
            var day = new Date(Date.parse(dayValue.replace(/-/g, '/'))) //将日期值格式化
            var today = new Array(0, 1, 2, 3, 4, 5, 6) //创建星期数组
            return today[day.getDay()] //返一个星期中的某一天，其中0为星期日
        }
    }
}
</script>
<style lang="less" scoped>
.signActivity {
    font-family: PingFangSC-Regular;
    font-size: 30rpx;
    color: #ffffff;
    letter-spacing: 0.79px;
    width: 100%;
    position: relative;
    .signin {
        width: 100%;
        height: 207px;
    }
    .signin-bg {
        position: absolute;
        top: 0;
        right: 0;
        width: 100%;
        height: 207px;
    }
    .sign-p {
        padding: 20px 18px;
        overflow: hidden;
        position: absolute;
        z-index: 199;
        left: 0px;
        right: 0px;
    }
    .signTitle {
        color: #fff;
        font-size: 24px;
    }
    .signDay {
        display: inline-block;
        float: right;
        padding-top: 8px;
    }
    .color9 {
        color: #999999;
        display: inline-block;
    }
    // .color3 {
    //     color: #333333 !important;
    // }
}
#calendar {
    padding: 0 18px;
    z-index: 10;
    position: absolute;
    top: 73px;
    left: 0;
    .calendar-head{
        width:100%;
        height:48px;
        background:#9975F3;
        border-radius:8px 8px 0px 0px;
    }
    .calendar-head-p{
        text-align: center;
        padding-top: 10px;
    }
    .calendar-head-span{
        font-size:15px;
        font-weight: 400;
        color: #ffffff;
        display: inline-block;
        vertical-align: middle;
        img{
            width: 10px;
            height: 16px;
        }
    }
    .calendar-head-span1{
        //padding: 0px 6px 0px 6px;
        padding: 6px
    }
    .calendar-head-span2{
        padding-left: 48px;
        padding-right: 48px
    }
    .calendar_title {
        height: 142rpx;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        font-size: 36rpx;
        color: #2f80ed;
        background: #fff;
        border-top-left-radius: 20rpx;
        border-top-right-radius: 20rpx;
    }
    .hr_class {
        width: 332rpx;
        height: 2rpx;
        background: #979797;
        margin-top: 26rpx;
    }
    .ruleItem {
        color: #000;
    }
    .rule_body {
        background: #fff;
        height: 610rpx;
        padding: 0 38rpx;
        width: calc(100% - 20rpx);
        font-size: 30rpx;
        color: rgba(0, 0, 0, 0.5);
        letter-spacing: 0.79px;
        line-height: 42rpx;
        border-bottom-left-radius: 20rpx;
        border-bottom-right-radius: 20rpx;
    }
    table {
        tbody {
            background: #fff;
            border-bottom-left-radius: 20rpx;
            border-bottom-right-radius: 20rpx;
            box-shadow: 0px 2px 9px 4px rgba(0, 0, 0, 0.05);
            padding-bottom: 10px;
            min-height: 281px;
            tr {
                display: flex;
                align-items: center;
                flex-wrap: wrap;
                padding-left: 16rpx;
                th {
                    width: 84rpx;
                    height: 84rpx;
                    line-height: 84rpx;
                    text-align: center;
                    font-size: 15px;
                    //color: #767676;
                    margin-right: 3px;
                    margin-bottom: 5px;
                    position: relative;
                    font-weight: 400;
                    border-radius: 23px;
                    border: 1px solid #ffffff;
                    span {
                        display: block;
                        width: 100%;
                        height: 100%;
                    }
                    .selected {
                        border-radius: 50%;
                        background-color: #2f80ed;
                        color: #fff;
                    }
                    .rangedate{
                        color: #999999 !important
                    }
                }
                // th:nth-child(1),th:nth-child(2),th:nth-child(1) .month-span,th:nth-child(2) .month-span{
                //     color: #999999 !important;
                // }
                th:nth-child(7n) {
                    //margin-right: 0;
                }
                .month-span {
                    position: absolute;
                    z-index: 99;
                    font-size: 9px;
                    color: #333333;
                    top: 1px;
                    width: 25px !important;
                    height: 13px !important;
                    display: inline-block !important;
                    line-height: 13px !important;
                    left: 9px;
                }
                .check-icon {
                    width: 18px !important;
                    height: 18px !important;
                    position: absolute;
                    z-index: 99;
                    display: inline-block;
                    top: -3px;
                    right: -5px;
                    img {
                        width: 18px;
                        height: 18px;
                    }
                }
            }
        }
        .week {
            th {
                width: 45px;
                margin-right: 0px;
                color: #767676;
            }
        }
        .days {
            .month-span,
            .daile-span {
                color: #333333;
            }
        }
        .isCheckIn {
            border-radius: 23px;
            border: 1px solid #9975F3 !important;
        }
        .isDay {
            color: #fff !important;
            background: #9975F3 !important;
            border-radius: 23px;
            .month-span {
                color: #ffffff !important;
            }
        }
    }
}
.chenkIn-status {
    width: 100%;
    text-align: center;
    //padding-top: 200px;
    padding-top: 30px;
    p {
        width: 293px;
        height: 30px;
        background: linear-gradient(90deg, rgba(153,117,243,0) 0%, rgba(153,117,243,0.3) 53%, rgba(153,117,243,0) 100%);
        //opacity:0.2206;
        //background-color:rgba(255,255,255,0.2);
        color: #9975F3;
        font-size: 15px;
        margin: 0 auto;
        line-height: 30px;
    }
}
.checkIn-btn {
    padding-top: 30px;
    text-align: center;
    .checkIn-detail {
        width: 141px;
        height: 45px;
        border-radius: 23px;
        border: 1px solid #9975F3;
        color: #9975F3;
        font-size: 18px;
        display: inline-block;
        background: #ffffff;
    }
    .checkIn-day {
        width: 141px;
        height: 45px;
        background: #9975F3;
        border-radius: 23px;
        color: #ffffff;
        font-size: 18px;
        display: inline-block;
        margin-left: 20px;
    }
}
.checkIn-rule {
    width: 100%;
    border-top: solid 1px #f2f2f2;
    margin-top: 30px;
}
.rule-title {
    // padding: 30px 17px;
    padding-top: 30px;
    padding-bottom: 0px;
}
.rule-span {
    width: 2px;
    height: 10px;
    background: #9975F3;
    border-radius: 1px;
    display: inline-block;
}
.rule-text {
    font-size: 15px;
    font-weight: 400;
    color: rgba(51, 51, 51, 1);
    line-height: 21px;
    padding-left: 5px;
}
.card-rule-use {
    // padding: 10px 25px;
    padding-top: 10px;
    color: #666666;
    font-size: 14px;
    font-weight: 300;
    line-height: 24px;
    padding-bottom: 30px;
}
.isCkeckDay {
    background:linear-gradient(147deg,rgba(180,117,249,1) 0%,rgba(116,121,239,1) 100%) !important;
}
// .isRange {
//     .month-span,
//     .daile-span {
//         color: #999999 !important;
//     }
// }
.isDay {
    .month-span,
    .daile-span {
        color: #ffffff !important;
    }
}
</style>
