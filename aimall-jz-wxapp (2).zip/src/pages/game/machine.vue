<template>
    <div id="machine">
        <div class="container">
            <div class="slot-machine-container" :class="bgCheck?'bg-check-1':'bg-check-2'">
                <div class="gashaponTop">
                    <div class="gashapon_icon">
                        <!-- <img
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191218/38143a49d94f4b71a5c13fc603b7b67f.png"
                        /> -->
                        <image src="https://aimall-jz.oss-cn-shenzhen.aliyuncs.com/as/WechatIMG1220.png" mode="widthFix" style="width:150rpx"></image> 
                    </div>
                    <div class="gashapon_record">
                        <auth-btn @pass="openRecord" />
                        <img
                            mode="widthFix"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/95c0c7156f5e4f72a517104226803562.png"
                        />
                    </div>
                </div>
                <div class="reel-container">
                    <!-- <div v-for="(item,index) in reels" :key="index" :class="['reel', 'reel'+index, item.css]" :animation="item.animation"  :style="{top:item.top+'rpx'}"> -->
                    <div
                        v-for="(item,index) in reels"
                        :key="index"
                        :class="['reel', 'reel'+index, item.css]"
                        :animation="item.animation"
                        :style="{'background-position-y':item.top+'rpx'}"
                    ></div>
                    <div class="reel-overlay"></div>
                </div>
                <div class="arrow">
                    <img
                        class
                        mode="widthFix"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/8c86f89b0bc343bc899742c937a4573e.png"
                    />
                </div>
                <!-- 闪灯 -->
                <div class="bottom_lamp_box">
                    <div class="bottom_lamp">
                        <img v-if="bottomLampCheck1" mode="widthFix" :src="bottomLampBright" alt />
                        <img v-if="!bottomLampCheck1" mode="widthFix" :src="bottomLampDark" alt />
                    </div>
                    <div class="bottom_lamp">
                        <img v-if="bottomLampCheck2" mode="widthFix" :src="bottomLampBright" alt />
                        <img v-if="!bottomLampCheck2" mode="widthFix" :src="bottomLampDark" alt />
                    </div>
                    <div class="bottom_lamp">
                        <img v-if="bottomLampCheck3" mode="widthFix" :src="bottomLampBright" alt />
                        <img v-if="!bottomLampCheck3" mode="widthFix" :src="bottomLampDark" alt />
                    </div>
                </div>
                <!-- 立即抽奖 -->
                <div class="begin-btn" :style="btnCheck ? '' : 'margin-top:8px'">
                    <auth-btn @pass="startClick" />
                    <img
                        v-show="btnCheck"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191217/b6817e9231634bc6b8c0f1069cbb81ef.png"
                        mode="widthFix"
                    />
                    <img
                        v-show="!btnCheck"
                        mode="widthFix"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/1880aa74e78a4d60966a6f033f0a7505.png"
                    />
                </div>
                <div class="coupon-text">
                    <p class="cost-inter" v-if="intergNum!='0'">-{{intergNum}} 积分抽奖</p>
                    <p class="cost-inter" v-else>免费抽奖</p>
                </div>
            </div>
            <!-- 活动规则 -->
            <div class="machine_rule">
                <div class="machine_title">
                    <img
                        mode="widthFix"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191218/57ee5a8e070e4eabb7ca62190112f1fc.png"
                    />
                </div>
                <div class="machine_text">
                    <ul class="rule_text_ul">
                        <li v-for="(item,index) in rules" :key="index">{{item}}</li>
                    </ul>
                </div>
            </div>
            <!-- 点击立即抽奖弹窗 -->
            <div v-if="beginModal" class="machine_layer">
                <div class="layer_top">
                    <div class="layer_title">
                        <img
                            v-if="!noInterg"
                            mode="widthFix"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/ebeef624b31a4122885de7df76d7cff0.png"
                            alt
                        />
                        <img
                            v-if="noInterg"
                            mode="widthFix"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/50c6c3349fd44ff98507c457421852d9.png"
                            alt
                        />
                        <p v-if="!noInterg && intergNum !='0'">{{intergNum}}</p>
                        <p v-if="!noInterg && intergNum !='0'">积分</p>
                        <p v-if="!noInterg && intergNum =='0'">免费</p>
                        <p v-if="!noInterg && intergNum =='0'">抽奖</p>
                    </div>
                    <div class="layer_container">
                        <img class="layer_container_img" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/2943a05be45d43bab84ff75c7e59a544.png">
                        <div class="layer_container_div">
                            <p
                            v-if="!noInterg && intergNum != '0'"
                            >使用 {{intergNum}} 积分抽奖一次</p>
                            <p v-if="!noInterg && intergNum != '0'">未完成抽奖积分不退换</p>
                        </div>
                        <p v-if="noInterg" class="layer_container_remark">{{messageText}}</p>

                    </div>
                    <div class="layer_footer">
                        <div class="layer_footer_btn">
                            <p v-if="!noInterg" @click="start">立即抽奖</p>
                            <!-- <p v-if="false">去首页看看</p> -->
                            <p v-if="noInterg" @click="closeLayer('beginModal')">我知道了</p>
                        </div>
                    </div>
                    <div class="layer_close">
                        <img
                            mode="widthFix"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/4160aa61cfe9430aae0a3d96e95cf648.png"
                            alt
                            @click="closeLayer('beginModal')"
                        />
                    </div>
                </div>
            </div>
            <!-- 获奖记录弹窗 -->
            <div v-if="recordModal" class="machine_record">
                <div class="record_box">
                    <p class="record_title">获奖记录</p>
                    <div class="record_list">
                        <scroll-view
                            :style="{'height': '295px'}"
                            @scrolltolower="scrolltolower"
                            class="record_list_con"
                            :scroll-y="true"
                        >
                            <div class="record_list_con">
                                <ul v-if="!noRecord">
                                    <li v-for="(item,index) in recordList" :key="index">
                                         <p class="record_p1">
                                            获得奖品：
                                            <span class="record_span">{{item.prizeName}}</span>
                                        </p>
                                        <p class="record_p2">抽奖日期：{{item.createTime}}</p>

                                    </li>
                                </ul>
                                <div class="noRecord" v-if="noRecord">
                                    <img
                                        mode="widthFix"
                                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/3a164a3f875440d594522ddc2080e557.png"
                                    />
                                    <p>暂时还没有中奖纪录呦~</p>
                                </div>
                            </div>
                        </scroll-view>
                        <div class="record_close" @click="closeLayer('recordModal')">
                            <img
                                mode="widthFix"
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/4160aa61cfe9430aae0a3d96e95cf648.png"
                                alt
                            />
                        </div>
                    </div>
                </div>
            </div>
            <!-- 中奖未中奖弹窗 dazzle_light_bg 炫光背景切换-->
            <div
                v-if="winningPrizeModal"
                class="machine_winning_prize"
                :class="isWinningPrize ? 'dazzle_light_bg' : ''"
            >
                <!-- 中奖 -->
                <div class="winning_prize_box" v-if="drawn">
                    <div class="winning_prize_msg">
                        <img
                            class="winning_prize_box_bg"
                            v-show="winningPrizeBgCheck"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/a235ce48063044949b303596fbc64d7e.png"
                        />
                        <img
                            class="winning_prize_box_bg"
                            v-show="!winningPrizeBgCheck"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/50646bc379b746faadc29f30869baae3.png"
                        />
                        <p class="winning_prize_title">我抽中了</p>
                        <p class="winning_prize_name">{{prizeName}}</p>
                        <img class="winning_prize_img" :src="prizeImageUrl" />
                        <p class="winning_prize_show">可在 我的 - 卡包 查看</p>
                        <div class="winning_prize_footer">
                            <div class="winning_prize_footer_btn" @click="openShare">
                                <p>晒好运</p>
                            </div>
                        </div>
                        <div class="winning_prize_close" @click="closeLayer('winningPrizeModal')">
                            <img
                                mode="widthFix"
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/4160aa61cfe9430aae0a3d96e95cf648.png"
                                alt
                            />
                        </div>
                    </div>
                </div>
                <div class="no_winning_prize_box" v-if="!drawn">
                    <img
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/eb9ed5a6817a4d55a51224e8f2a4bc2d.png"
                        alt
                    />
                    <p class="winning_prize_title">好可惜</p>
                    <p class="winning_prize_name">未中奖呦</p>
                    <p class="winning_prize_show">{{messageText}}</p>
                    <div class="winning_prize_footer">
                        <div class="winning_prize_footer_btn" @click="openShare">
                            <p>去首页看看</p>
                        </div>
                    </div>
                    <div class="winning_prize_close" @click="closeLayer('winningPrizeModal')">
                        <img
                            mode="widthFix"
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/4160aa61cfe9430aae0a3d96e95cf648.png"
                            alt
                        />
                    </div>
                </div>
            </div>
        </div>
        <!-- 晒好运 -->
        <good-luck :hAnimate="hAnimate" :prizeVos="templateBill" @changeHeight="changeHeight"></good-luck>
    </div>
</template>
<script>
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import AuthBtn from '@/components/AuthBtn'
import { mapState, mapMutations } from 'vuex'
import wxUtils from '@/plugins/wxUtils'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import GoodLuck from '@/components/GoodLuck'
export default {
    components: {
        AuthBtn,
        GoodLuck
    },
    data() {
        return {
            spinDisabled: false,
            result: [], // 中奖池
            credits: 50, //积分
            curBet: 1, // 每局消耗积分
            stripHeight: 851, // 总高度
            alignmentOffset: 120, // 结果位置偏移量
            reelSpeed1Delta: 100, // 间隔位移
            positioningTime: 200, // 停止前动画时间
            bounceHeight: -200, // 结束弹射动画高度
            firstReelStopTime: 3667, // 第一个动画延迟停止时间
            secondReelStopTime: 575, // 第二个动画延迟停止时间
            thirdReelStopTime: 568, // 第三个动画延迟停止时间
            payoutStopTime: 1500, // 触发结束延迟时间
            numIconsPerReel: 6, // 每个轮子几个格子
            timer: [],
            reels: [
                // 轮子动画属性
                {
                    top: -860, // 初始位置
                    animation: '', // 结束滚动动画
                    css: '' // 反弹动画css
                },
                {
                    top: -860,
                    animation: '',
                    css: ''
                },
                {
                    top: -860,
                    animation: '',
                    css: ''
                }
            ],
            // 按钮闪烁定时器
            btnCheck: true,
            setIntervalStatus: null,
            // 闪灯背景切换定时器
            bgCheck: false,
            setIntervalBgStatus: null,
            // 立即抽奖弹窗
            beginModal: false,
            // 获奖记录弹窗
            recordModal: false,
            // 是否中奖
            isWinningPrize: true,
            // 获奖纪录数据
            recordList: [],
            // 抽奖结果弹窗
            winningPrizeModal: false,
            // 抽奖弹层背景切换
            winningPrizeBgCheck: true,
            // 底灯闪烁亮灯暗灯
            bottomLampBright: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/957b35568a0e4824bb5edd1f856b84d9.png',
            bottomLampDark: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/f36518c1d8e34bb9bc4b81a287f41099.png',
            bottomLampCheck1: true,
            bottomLampCheck2: false,
            bottomLampCheck3: false,
            setIntervalBottomLampCheck: null,
            activityId: '',
            templateData: {},
            templateBill: {},
            //生成海报默认图片
            templateDefaultImg: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png',
            shareImg: '',
            intergNum: '',
            prizeVos: [],
            rules: [],
            activityName: '',
            messageText: '',
            noInterg: false, //积分不够
            drawn: false, //是否中奖
            prizeId: '',
            prizeName: '',
            prizeImageUrl: '',
            hAnimate: false,
            isData: false,
            repeatClick: false, //防止重复点击
            pageSize: 10,
            pageNum: 1,
            firstTop: '',
            noRecord: false
        }
    },
    onLoad() {
        let t = this
        t.resetData()
        // 按钮定时抖动
        t.btnAnmite()
        t.setIntervalBgStatus = setInterval(() => {
            t.bgCheck = !t.bgCheck
            t.winningPrizeBgCheck = !t.winningPrizeBgCheck
        }, 1000)
        t.setIntervalBottomLampCheckFunc()
        t.setIntervalBottomLampCheck = setInterval(() => {
            t.setIntervalBottomLampCheckFunc()
        }, 4000)
        t.activityId = this.$root.$mp.query.activityId
        //t.activityId = '212'
        t.getActivityDetail()

    },
    onUnload() {
        let t = this
        //先清除按钮动画
        clearInterval(t.setIntervalStatus)
        clearInterval(t.setIntervalBottomLampCheck)
        clearInterval(t.setIntervalBgStatus)
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo', 'isLogined'])
    },
    methods: {
        ...mapMutations(['update']),
         //重置
        resetData() {
            this.activityId = ''
            this.templateData = {}
            this.templateBill = {}
            this.shareImg =  ''
            this.intergNum = ''
            this.prizeVos = []
            this.rules = []
            this.activityName = ''
            this.messageText = ''
            this.noInterg = false //积分不够
            this.drawn = false //是否中奖
            this.prizeId = ''
            this.prizeName = ''
            this.prizeImageUrl = ''
            this.hAnimate = false
            this.isData = false
            this.repeatClick = false //防止重复点击
            this.pageSize = 10
            this.pageNum = 1
        },
        // 根据活动id查详情
        async getActivityDetail() {
            let requestOptions = {
                path: api.getActivityDetail + this.activityId
            }
            await request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    let data = res.data || []
                    this.intergNum = data.costIntegral ? data.costIntegral : 0
                    this.prizeVos = data.prizeVos ? data.prizeVos : []
                    if (data.activityRules) {
                        this.rules = data.activityRules.split('\n')
                    } else {
                        this.rules = []
                    }
                    this.activityName = data.activityName ? data.activityName : ''
                }
            })
        },
        scrolltolower() {
            if (!this.noDataList) {
                this.pageNum++
                this.openRecord()
            }
        },
        //晒好运
        openShare() {
            const t = this
            if (t.drawn) {
                t.hAnimate = true
            } else {
                wx.reLaunch({
                    url: '/pages/home'
                })
            }
        },
        changeHeight() {
            wx.hideLoading()
            this.isData = false
            this.hAnimate = false
        },
        createBill() {
            const t = this
            // wx.getSavedFileList({  // 获取文件列表
            //     success (res) {
            //     res.fileList.forEach((val, key) => { // 遍历文件列表里的数据
            //         // 删除存储的垃圾数据
            //         wx.removeSavedFile({
            //             filePath: val.filePath
            //         });
            //     })
            //     }
            // })
            let templateData = {}
            templateData = {
                background: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/91d130a6689a4262a62c092977b9e10d.png',
                width: '375px',
                height: '812px',
                views: [
                    {
                        type: 'image',
                        url: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/56544c269ca24fa197017812c8a167cf.png',
                        css: {
                            top: '21px',
                            left: '26px',
                            width: '88px',
                            height: '39px'
                        }
                    },
                    {
                        type: 'image',
                        url: t.prizeImageUrl,
                        css: {
                            top: '218px',
                            left: '55px',
                            width: '233px',
                            height: '228px'
                        }
                    },
                    {
                        type: 'text',
                        text: t.prizeName,
                        css: {
                            top: '148px',
                            width: '375px',
                            height: '36px',
                            textAlign: 'center',
                            fontSize: '25px',
                            color: '#fff'
                        }
                    },
                    {
                        type: 'text',
                        text: '丰富好礼等你来拿',
                        css: {
                            top: '505px',
                            width: '375px',
                            height: '36px',
                            textAlign: 'center',
                            fontSize: '20px',
                            color: '#D17F28'
                        }
                    },
                    //中奖图片背景色1
                    {
                        type: 'rect',
                        css: {
                            top: '550px',
                            left: '30px',
                            width: '72px',
                            height: '72px',
                            color: '#fff',
                            borderRadius: '4px'
                        }
                    },
                    //中奖图片背景色2
                    {
                        type: 'rect',
                        css: {
                            top: '550px',
                            left: '110px',
                            width: '72px',
                            height: '72px',
                            color: '#fff',
                            borderRadius: '4px'
                        }
                    },
                    //中奖图片背景色3
                    {
                        type: 'rect',
                        css: {
                            top: '550px',
                            left: '190px',
                            width: '72px',
                            height: '72px',
                            color: '#fff',
                            borderRadius: '4px'
                        }
                    },
                    //中奖图片背景色1
                    {
                        type: 'rect',
                        css: {
                            top: '550px',
                            left: '271px',
                            width: '72px',
                            height: '72px',
                            color: '#fff',
                            borderRadius: '4px'
                        }
                    },
                    //中奖图片1
                    {
                        type: 'image',
                        url: t.templateData[0].couponImageUrl != '' ? t.templateData[0].couponImageUrl : t.templateDefaultImg,
                        css: {
                            top: '553px',
                            left: '35px',
                            width: '66px',
                            height: '63px'
                        }
                    },
                    //中奖图片2
                    {
                        type: 'image',
                        url: t.templateData[1].couponImageUrl != '' ? t.templateData[1].couponImageUrl : t.templateDefaultImg,
                        css: {
                            top: '553px',
                            left: '115px',
                            width: '66px',
                            height: '63px'
                        }
                    },
                    //中奖图片3
                    {
                        type: 'image',
                        url: t.templateData[2].couponImageUrl != '' ? t.templateData[2].couponImageUrl : t.templateDefaultImg,
                        css: {
                            top: '553px',
                            left: '195px',
                            width: '66px',
                            height: '63px'
                        }
                    },
                    //中奖图片4
                    {
                        type: 'image',
                        url: t.templateData[3].couponImageUrl != '' ? t.templateData[3].couponImageUrl : t.templateDefaultImg,
                        css: {
                            top: '553px',
                            left: '276px',
                            width: '66px',
                            height: '63px'
                        }
                    },
                    //中奖奖品名字1
                    {
                        type: 'text',
                        text: t.templateData[0].prizeName,
                        css: {
                            top: '630px',
                            left: '37px',
                            width: '72px',
                            height: '30px',
                            textAlign: 'center',
                            fontSize: '12px',
                            color: '#DA852B'
                        }
                    },
                    //中奖奖品名字2
                    {
                        type: 'text',
                        text: t.templateData[1].prizeName,
                        css: {
                            top: '630px',
                            left: '110px',
                            width: '72px',
                            height: '30px',
                            textAlign: 'center',
                            fontSize: '12px',
                            color: '#DA852B'
                        }
                    },
                    //中奖奖品名字3
                    {
                        type: 'text',
                        text: t.templateData[2].prizeName,
                        css: {
                            top: '630px',
                            left: '190px',
                            width: '72px',
                            height: '30px',
                            textAlign: 'center',
                            fontSize: '12px',
                            color: '#DA852B'
                        }
                    },
                    //中奖奖品名字4
                    {
                        type: 'text',
                        text: t.templateData[3].prizeName,
                        css: {
                            top: '630px',
                            left: '271px',
                            width: '72px',
                            height: '30px',
                            textAlign: 'center',
                            fontSize: '12px',
                            color: '#DA852B'
                        }
                    },
                    {
                        type: 'text', //18
                        text: '长按识别或者扫码',
                        css: {
                            left: '174px',
                            top: '737px',
                            fontSize: '15px',
                            color: '#A4761D'
                        }
                    },
                    {
                        type: 'text', //19
                        text: '进入小程序参与活动',
                        css: {
                            left: '174px',
                            top: '759px',
                            fontSize: '15px',
                            color: '#A4761D'
                        }
                    },
                    {
                        type: 'rect',
                        css: {
                            top: '720px',
                            left: '76px',
                            width: '72px',
                            height: '72px',
                            color: '#fff'
                        }
                    },
                    {
                        //11
                        type: 'image',
                        url: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191207/5b6142b017a94307a300dbcb5f5cbb50.png',
                        css: {
                            left: '85px',
                            top: '728px',
                            width: '55px',
                            height: '56px'
                        }
                    }
                ]
            }
            t.templateBill = templateData
            console.log(t.templateBill, 88889)
        },
        btnAnmite() {
            let t = this
            t.setIntervalStatus = setInterval(() => {
                t.btnCheckFun()
                setTimeout(() => {
                    t.btnCheckFun()
                    setTimeout(() => {
                        t.btnCheckFun()
                        setTimeout(() => {
                            t.btnCheckFun()
                        }, 150)
                    }, 150)
                }, 150)
            }, 2000)
        },
        setIntervalBottomLampCheckFunc() {
            let t = this
            setTimeout(() => {
                t.bottomLampCheck1 = !t.bottomLampCheck1
                t.bottomLampCheck2 = !t.bottomLampCheck2
                setTimeout(() => {
                    t.bottomLampCheck2 = !t.bottomLampCheck2
                    t.bottomLampCheck3 = !t.bottomLampCheck3
                    setTimeout(() => {
                        t.bottomLampCheck1 = !t.bottomLampCheck1
                        t.bottomLampCheck3 = !t.bottomLampCheck3
                    }, 800)
                }, 800)
            }, 800)
        },
        // 点击立即抽奖触发二次确认弹窗
        startClick() {
            //查询是否有抽奖资格
            let _this = this
            if (_this.repeatClick) {
                return
            }
            //先清除按钮动画
            clearInterval(_this.setIntervalStatus)

            _this.repeatClick = true
            _this.noInterg = false
            wx.request({
                url: api.checkMemberLotteryEligible + _this.activityId,
                method: 'GET',
                data: null,
                header: {
                    Authorization: _this.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code == 4001 || res.data.code == 4000) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = _this.isLogined
                                wxUtils.clearLoginStorage()
                                _this.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index?form=machineGame&formId=${_this.activityId}`
                                })
                            }
                        })
                    } else if (res.data.code == 200 || res.data.code == 0) {
                        //当为免费抽奖时显示弹窗，直接进行抽奖
                        _this.repeatClick = true
                        if (_this.intergNum != '0' || _this.intergNum != '') {
                            _this.beginModal = true
                        } else {
                            _this.beginModal = false
                            _this.start()
                        }
                    } else {
                        if (res.data.code != 500 && _this.intergNum != '0') {
                            _this.repeatClick = true
                            _this.noInterg = true
                            _this.messageText = res.data.message
                            _this.beginModal = true
                            if (res.data.code == 400003 || res.data.code == 400002) {
                                // buryPoint.setF({
                                //     id: pointCode.GASHAPON_Index_Finish_F,
                                //     p_action_id: pointCode.GASHAPON_Index_Finish_F,
                                //     p_action: _this.p_action,
                                //     p_id: _this.activityId,
                                //     p_v1: 0
                                // })
                            } else if (res.data.code == 400008) {
                                // buryPoint.setF({
                                //     id: pointCode.GASHAPON_Index_KNOW_F,
                                //     p_action_id: pointCode.GASHAPON_Index_KNOW_F,
                                //     p_action: _this.p_action,
                                //     p_id: _this.activityId,
                                //     p_v1: 0
                                // })
                            }
                        } else {
                            _this.noInterg = false
                            _this.repeatClick = false
                            wx.showModal({
                                title: '提醒',
                                content: res.data.message,
                                showCancel: false,
                                confirmText: '确认',
                                confirmColor: '#4694FA'
                            })
                        }
                    }
                    clearInterval(_this.setIntervalStatus)
                    _this.setIntervalStatus = null
                    _this.btnCheck = false
                    setTimeout(() => {
                        _this.btnCheck = true
                    }, 100)
                    _this.btnAnmite()
                }
            })
        },
        start() {
            const _this = this
            clearInterval(_this.setIntervalStatus)
            const { spinDisabled } = _this._data
            _this.beginModal = false
            // 点击开始后不可点击
            if (spinDisabled) return false
            // 随机设置奖项 该数据应该从后台接口获取
            let result = []
            for (var i = 0; i < 3; i++) {
                result.push(Math.floor(Math.random() * 6 + 1))
            }
            _this.spinDisabled = true
            _this.result = result

            //查询抽奖结果
            let requestOptions = {
                path: api.luckyTry,
                method: 'post',
                hideLoading: true,
                data: {
                    raffleActivityId: _this.activityId,
                    source: 1 //小程序入口标识
                }
            }
            request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    if (res.data) {
                        // 中奖了 获取中奖商品id
                        _this.prizeImageUrl = res.data.prizeImageUrl ? res.data.prizeImageUrl : _this.templateDefaultImg
                        _this.prizeName = res.data.prizeName ? res.data.prizeName : ''
                        _this.prizeId = res.data.prizeId ? res.data.prizeId : ''
                        _this.drawn = true
                        _this.templateData = _this.prizeVos
                        //开始绘制海报
                        _this.createBill()
                    } else {
                        // 未中奖 获取文案
                        _this.drawn = false
                        _this.messageText = res.message
                    }
                }
            })

            // 触发组件开始方法
            this.goStart()
        },
        // 结束
        doFinish() {
            console.log('当前项=', this.result)
            // wx.showToast({
            //     title: '恭喜你获奖了',
            //     icon: 'none'
            // })
            this.spinDisabled = false
            this.winningPrizeModal = true
        },
        goStart() {
            const { firstReelStopTime, secondReelStopTime, thirdReelStopTime, result, payoutStopTime } = this._data
            // 开始滚动
            this.start_reel_spin(0)
            this.start_reel_spin(1)
            this.start_reel_spin(2)
            // 结束
            utils
                .runAsync(firstReelStopTime)
                .then(() => {
                    this.stop_reel_spin(0, result[0])
                    return utils.runAsync(secondReelStopTime)
                })
                .then(() => {
                    this.stop_reel_spin(1, result[1])
                    return utils.runAsync(thirdReelStopTime)
                })
                .then(() => {
                    this.stop_reel_spin(2, result[2])
                    return utils.runAsync(payoutStopTime)
                })
                .then(() => {
                    // 完成
                    // 重置
                    this.reset_reel_spin(0)
                    this.reset_reel_spin(1)
                    this.reset_reel_spin(2)
                    this.doFinish()
                    //this.triggerEvent('finish')
                })
        },
        // 开始动画
        start_reel_spin(index) {
            const { stripHeight, reelSpeed1Delta } = this._data
            const position = parseInt(-(Math.random() * stripHeight * 2))

            this.reels[`${index}`].top = position

            // 循环动画
            this.timer[index] = setInterval(() => {
                this.reels[`${index}`].top = this.reels[index].top + reelSpeed1Delta
                if (this.reels[index].top > 0) {
                    this.reels[`${index}`].top = 2 * -stripHeight
                }
            }, 20)
        },
        // 停止动画
        stop_reel_spin(index, lottery) {
            const { stripHeight, numIconsPerReel, alignmentOffset, positioningTime, bounceHeight } = this._data
            const cellHeight = stripHeight / numIconsPerReel
            const position = -stripHeight - (lottery - 1) * cellHeight + alignmentOffset
            // 清除滚动timer
            clearInterval(this.timer[index])
            // 最终位置
            let busNumber = this.result[index] > 2 ? 2 : this.result[index] > 4 ? 3 : 1
            //中奖则三个一样，取第一个的位置
            if(this.drawn){
                if(index == 0){
                    this.firstTop = position - stripHeight - busNumber
                }
                this.reels[`${index}`].top = this.firstTop
            }else{
                this.reels[`${index}`].top = position - stripHeight - busNumber
            }

            console.log(index,position - stripHeight - busNumber)
            // this.reels[`${index}`].top = '-970'
            // 到最终位置之前的动画
            var animation = wx.createAnimation({
                transformOrigin: '-50% -50%',
                duration: positioningTime,
                timingFunction: 'linear',
                delay: 0
            })
            animation.translateY(bounceHeight).step()
            this.reels[`${index}`].animation = animation.export()
            // 弹射动画
            utils.runAsync(positioningTime).then(() => {
                // translateY重置成0为下次做准备
                animation.translateY(0).step({ duration: 0 })
                ;(this.reels[`${index}`].animation = animation.export()), (this.reels[`${index}`].css = 'bounce')
            })
        },
        // 重置动画
        reset_reel_spin(index) {
            this.reels[`${index}`].css = ''
        },
        // 按钮动画
        btnCheckFun() {
            this.btnCheck = !this.btnCheck
        },
        // 获奖记录点击
        openRecord() {
            this.recordModal = true
            //查询中奖纪录
            let requestOptions = {
                path: api.listOfPrizes,
                method: 'post',
                data: {
                    memberCode: this.vipInfo ? this.vipInfo.memberCode : '',
                    pageNum: this.pageNum,
                    pageSize: this.pageSize,
                    activityId: this.activityId
                }
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    if (res.data.total == 0 && this.pageNum == 1) {
                        this.noRecord = true
                    } else {
                        this.noRecord = false
                        if (this.pageNum != 1) {
                            this.recordList = this.recordList.concat(res.data.list)
                        } else {
                            this.recordList = res.data.list
                        }
                        //数据加载结束
                        if (0 <= res.data.list.length && res.data.list.length < this.pageSize) {
                            this.noDataList = true
                        } else {
                            this.noDataList = false
                        }
                    }
                }
            })
        },
        closeLayer(type) {
            //先清除按钮动画
            clearInterval(this.setIntervalStatus)
            if (type == 'beginModal') {
                this.beginModal = false
            } else if( type == 'recordModal'){
                this.recordModal = false
                this.pageNum = 1
                this.noDataList = false
            } else if(type == 'winningPrizeModal'){
                this.winningPrizeModal = false
            }
            // 按钮定时抖动
            this.btnAnmite()
            this.repeatClick = false
        }
    },
    onShareAppMessage(options) {
        // buryPoint.setF({
        //     id: pointCode.GASHAPON_RESULT_INVITE_F,
        //     p_action_id: pointCode.GASHAPON_RESULT_INVITE_F,
        //     p_action: this.p_action,
        //     p_id: this.activityId,
        //     p_v1: 0
        // })
        let title
        if (this.drawn) {
            title = `我在${this.activityName}中抽中了${this.prizeName}，你也来试试吧`
        } else {
            title = `${this.activityName}正在火热进行中，快来试试吧`
        }
        return {
            title: title,
            imageUrl: this.prizeImageUrl,
            path: 'pages/home?pageId=machineShare&activityId=' + this.activityId + '&prizeId=' + this.prizeId,
            success: function(res) {
                console.log('zhuanfa')
                wx.showToast({
                    title: '转发成功',
                    icon: 'success',
                    duration: 2000
                })
            }
        }
    }
}
</script>
<style lang="less">
page {
    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191217/b7bb4e805af2441f8ba9925dfc9855da.png') center center no-repeat;
    background-size: cover;
    background-color: rgba(18, 22, 118, 1);
}
</style>
<style lang="less" scoped>
#machine {
    .container {
        // display: flex;
        // flex-direction: column;
        // justify-content: center;
        // align-items: center;
    }
    // 活动规则
    .machine_rule {
        background: #a101c3;
        width: 90%;
        margin: 30rpx auto;
        color: #fff;
        .machine_title {
            width: 100%;
            padding-top: 5px;
            img {
                width: 155px;
                margin: 10px auto;
            }
        }
        .machine_text {
            max-width: 613rpx;
            padding: 15px;
            height: 400rpx;
            overflow: scroll;
            font-size: 13px;
            li {
                max-width: 613rpx;
                padding-bottom: 15px;
            }
        }
    }

    .gashaponTop {
        height: 60px;
    }
    .gashaponTopBg {
        padding: 0 5px 0px 20px;

        image {
            width: 100%;
            height: 160px;
        }
    }
    .gashapon_icon {
        width: 95px;
        height: 41px;
        padding-top: 18px;
        padding-left: 18px;
        float: left;
        img {
            width: 95px;
            height: 41px;
        }
    }
    .gashapon_record {
        width: 95px;
        height: 55px;
        float: right;
        padding-right: 35rpx;
        position: relative;
        img {
            width: 95px;
        }
    }
    .gashapon_record_span {
        position: absolute;
        z-index: 99;
        color: #ffffff;
        font-size: 18px;
        font-weight: 400;
        top: 26px;
        left: 12px;
    }
    .sol-button {
        width: 100px;
    }

    .btn-group {
        margin-top: 40rpx;
        display: flex;
        align-items: center;
    }

    .sol-button {
        margin-right: 20rpx;
    }
    // 老虎机背景切换
    .bg-check-1 {
        background: transparent url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/510b73b09b134d598749f800c95a3ec8.png') bottom center no-repeat;
    }
    .bg-check-2 {
        background: transparent url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/0d424c4f72ba4343825319e375695fbc.png') bottom center no-repeat;
    }
    .slot-machine-container {
        position: relative;
        margin: 0 auto auto;
        z-index: 2;
        width: 750rpx;
        height: 1110rpx;
        background-size: cover;
        .reel-container {
            position: absolute;
            left: 149rpx;
            top: 405rpx;
            width: 456rpx;
            height: 433rpx;
            overflow: hidden;
            .reel {
                position: absolute;
                width: 144rpx;
                height: 4104rpx;
                // margin-top: 1px;
                background: transparent url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/fb568e455520467aa1d313aa576c79b1.png') 0 0 repeat-y;
                background-size: contain;
            }

            .reel0 {
                left: 7rpx;
            }

            .reel1 {
                left: 157rpx;
            }

            .reel2 {
                left: 307rpx;
            }

            .reel-overlay {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                z-index: 2;
                background: transparent url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191217/20011c85b1944c529086db62ad82af89.png') 0 0 repeat-y;
                background-size: 100% 100%;
            }
        }
        .begin-btn {
            position: absolute;
            left: 50%;
            margin-left: -76px;
            margin-top: 1px;
            z-index: 33;
            img {
                width: 307rpx;
                height: 45px;
                margin: 0 auto;
            }
        }
    }
    // 两个箭头
    .arrow {
        width: 509rpx;
        margin: 415rpx auto 0;
        position: relative;
        z-index: 3;
        img {
            width: 509rpx;
        }
    }
    .coupon-text {
        width: 100%;
        text-align: center;
        p {
            margin-top: 130rpx;
            color: #dc5812;
        }
    }

    @keyframes bounce {
        40%,
        43% {
            animation-timing-function: cubic-bezier(0.645, 0.045, 0.355, 1);
            transform: translate3d(0, -20px, 0);
        }

        70% {
            animation-timing-function: cubic-bezier(0.645, 0.045, 0.355, 1);
            transform: translate3d(0, 10px, 0);
        }

        to {
            animation-timing-function: cubic-bezier(0.645, 0.045, 0.355, 1);
            transform: translate3d(0, 0px, 0);
        }
    }

    .bounce {
        -webkit-animation-duration: 1s;
        animation-duration: 1s;
        -webkit-animation-fill-mode: both;
        animation-fill-mode: both;
        -webkit-animation-name: bounce;
        animation-name: bounce;
        -webkit-transform-origin: center bottom;
        transform-origin: center bottom;
    }

    // 抽奖二次确认弹窗
    .machine_layer {
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        position: fixed;
        z-index: 199;
        top: 0px;
        left: 0px;
        right: 0px;
        .layer_top {
            width: 85%;
            height: 260px;
            // background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/76d65823e88a4653ac921cb5600d5bab.png') no-repeat;
            background: -moz-linear-gradient(top, #f5ce34 0%, #dda641 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #f5ce34), color-stop(100%, #dda641));
            background: -webkit-linear-gradient(top, #f5ce34 0%, #dda641 100%);
            background: -o-linear-gradient(top, #f5ce34 0%, #dda641 100%);
            background: -ms-linear-gradient(top, #f5ce34 0%, #dda641 100%);
            background: linear-gradient(to bottom, #f5ce34 0%, #dda641 100%);
            border-radius: 8px;
            position: relative;
            margin: 405rpx auto 0;
            .layer_title {
                height: 83rpx;
                img {
                    width: 100px;
                    position: absolute;
                    top: -50px;
                    left: 50%;
                    margin-left: -50px;
                    z-index: 1;
                }
                p {
                    color: #fff;
                    text-align: center;
                    width: 100%;
                    z-index: 2;
                    position: relative;
                    top: -25px;
                }
            }
            .layer_container {
                height: 285rpx;
                width: 585rpx;
                margin: 0px auto;
                position: relative;
                z-index: 3;
                top: -15px;
                text-align: center;
                // background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/2943a05be45d43bab84ff75c7e59a544.png') bottom center no-repeat;
                // background-size: cover;
                p {
                    font-size: 18px;
                    color: #e28502;
                }
            }
            .layer_container_img{
                height: 315rpx;
                width: 585rpx;
            }
            .layer_container_div{
                position: absolute;
                z-index: 99;
                top: 45px;
                width: 100%;
            }
            .layer_container_remark {
                position: absolute;
                z-index: 99;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
            }
            .layer_footer {
                .layer_footer_btn {
                    width: 150px;
                    height: 48px;
                    line-height: 48px;
                    text-align: center;
                    background: #ffd932;
                    border-radius: 6px;
                    margin: 0 auto;
                    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/db0269aa563e446ba85f006166df3660.png') center center no-repeat;
                    p {
                        color: #db7c06;
                        font-size: 20px;
                    }
                }
            }
            .layer_close {
                img {
                    width: 37px;
                    margin: 13px auto 0;
                }
            }
        }
    }
    // 获奖记录弹窗
    .machine_record {
        height: 100%;
        position: fixed;
        z-index: 199;
        top: 0px;
        left: 0px;
        right: 0px;
        background-color: rgba(0, 0, 0, 0.7);
        .record_box {
            background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/d70fcd8504e64d2fb72aa676327e1c43.png') center center no-repeat;
            background-size: cover;
            width: 359px;
            height: 447px;
            margin: 75px auto 0;
            .record_title {
                font-size: 22.31px;
                color: #fff;
                text-align: center;
                padding-top: 47px;
            }
            .record_list {
                width: 260px;
                margin: 0 auto;
                margin-top: 40px;
                height: 330px;
                position: relative;
            }
            .record_list_con {
                //height: 328px;
                ul li {
                    border-bottom: solid 1px #e6e6e6;
                    margin-left: 19px;
                    margin-right: 19px;
                }
                .record_p1,
                .record_p2 {
                    font-size: 15px;
                    font-weight: 400;
                    color: rgba(102, 102, 102, 1);
                    line-height: 21px;
                    padding-bottom: 5px;
                }
                .record_p1 {
                    padding-top: 15px;
                }
                .record_p2 {
                    padding-bottom: 16px;
                    color: #999999;
                }
                .record_span1 {
                    font-size: 17px;
                    font-weight: 400;
                    color: #666666;
                }
            }
            .record_close {
                width: 100%;
                right: 33px;
                margin-top: 25px;
                image {
                    width: 35px;
                    height: 100%;
                    margin: 0 auto;
                }
            }
            .noRecord {
                text-align: center;
                image {
                    width: 150px;
                    height: 150px;
                    padding-top: 48px;
                    margin: 0 auto;
                }
                p {
                    font-size: 15px;
                    color: #999999;
                    font-weight: 400;
                    padding-top: 30px;
                }
            }
        }
    }
    // 抽奖结果弹窗
    .machine_winning_prize {
        height: 100%;
        position: fixed;
        z-index: 199;
        top: 0px;
        left: 0px;
        right: 0px;
        background-color: rgba(0, 0, 0, 0.7);
        // .winning_prize_box_bg_check1 {
        //     height: 528px;
        //     background-size: cover;
        //     background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191221/5b492e7415614ca38d5dbd7d5031c033.png') center center no-repeat;
        // }
        // .winning_prize_box_bg_check2 {
        //     background-size: cover;
        //     background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191221/64d3073174504a49bf4223109dffa8b4.png') center center no-repeat;
        // }
        .winning_prize_box {
            height: 600px;
            position: relative;
            margin: 3% auto;
            .winning_prize_box_bg {
                width: 375px;
                height: 528px;
            }
            .winning_prize_msg {
                .winning_prize_title {
                    color: #fff2e3;
                    text-align: center;
                    position: absolute;
                    top: 49px;
                    left: 50%;
                    transform: translate(-50%);
                    -webkit-transform: translate(-50%);
                    -moz-transform: translate(-50%);
                }
                .winning_prize_name {
                    font-size: 25px;
                    color: #fff;
                    text-align: center;
                    top: 76px;
                    position: absolute;
                    left: 50%;
                    transform: translate(-50%);
                    -webkit-transform: translate(-50%);
                    -moz-transform: translate(-50%);
                }
                .winning_prize_img {
                    width: 160px;
                    height: 160px;
                    margin: 0 auto;
                    position: absolute;
                    top: 200px;
                    left: 50%;
                    transform: translate(-50%);
                    -webkit-transform: translate(-50%);
                    -moz-transform: translate(-50%);
                }
                .winning_prize_show {
                    color: #fff;
                    text-align: center;
                    position: absolute;
                    left: 50%;
                    top: 420px;
                    transform: translate(-50%);
                    -webkit-transform: translate(-50%);
                    -moz-transform: translate(-50%);
                }
                .winning_prize_footer {
                    position: absolute;
                    left: 50%;
                    transform: translate(-50%);
                    -webkit-transform: translate(-50%);
                    -moz-transform: translate(-50%);
                    margin: -150rpx auto;
                    .winning_prize_footer_btn {
                        width: 150px;
                        height: 48px;
                        line-height: 48px;
                        text-align: center;
                        background: #ffd932;
                        border-radius: 6px;
                        margin: 0 auto;
                        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/db0269aa563e446ba85f006166df3660.png') center center no-repeat;
                        p {
                            color: #db7c06;
                            font-size: 20px;
                        }
                    }
                }
                .winning_prize_close {
                    margin-top: 70px;
                    img {
                        width: 37px;
                        margin: -83px auto;
                    }
                }
            }
        }
        .no_winning_prize_box {
            position: relative;
            width: 375px;
            height: 600px;
            margin: 3% auto;
            img {
                width: 370px;
                height: 528px;
            }
            // background-size: cover;
            // background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/b7aeed452c1f4eb085fe36456a8a82db.png') center center no-repeat;
            .winning_prize_title,
            .winning_prize_name,
            .winning_prize_show,
            .winning_prize_footer,
            .winning_prize_close {
                position: absolute;
                left: 50%;
                transform: translate(-50%);
                -webkit-transform: translate(-50%);
                -moz-transform: translate(-50%);
            }
            .winning_prize_title {
                color: #fff2e3;
                top: 48px;
            }
            .winning_prize_name {
                font-size: 25px;
                color: #fff;
                top: 75px;
            }
            .winning_prize_show {
                color: #fff;
                top: 415px;
            }
            .winning_prize_footer {
                top: 460px;
                .winning_prize_footer_btn {
                    width: 150px;
                    height: 48px;
                    line-height: 48px;
                    text-align: center;
                    background: #ffd932;
                    border-radius: 6px;
                    margin: 0 auto;
                    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/db0269aa563e446ba85f006166df3660.png') center center no-repeat;
                    p {
                        color: #db7c06;
                        font-size: 20px;
                    }
                }
            }
            .winning_prize_close {
                top: 600px;
                img {
                    width: 37px;
                    margin: -83px auto;
                }
            }
        }
        .winning_prize_close {
            img {
                width: 37px;
                margin: -83px auto;
            }
        }
    }
    // 底灯
    .bottom_lamp_box {
        width: 226px;
        margin: 71px auto 0;
        height: 30px;
        position: relative;
        z-index: 3;
        .bottom_lamp {
            float: left;
            width: 33.33%;
            border: 1xp solid #333;
            height: 30px;
            img {
                width: 46px;
                height: 16px;
                margin: 0 auto;
            }
        }
    }
    // 炫光背景
    .dazzle_light_bg {
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/d29dd6926cd145fead02773158e5a91a.png') center center no-repeat;
        background-size: cover;
        background-color: rgba(0, 0, 0, 0.7);
    }
    .painterImg {
        //
    }
}
</style>
