<template>
    <div id="machine">
        <div class="container">
            <div class="slot-machine-container" :class="bgCheck?'bg-check-1':'bg-check-2'">
                <div class="gashaponTop">
                    <div class="gashapon_icon">
                        <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191218/38143a49d94f4b71a5c13fc603b7b67f.png"/>
                    </div>
                </div>
                <div class="reel-container">
                    <ul class="reel-container-ul">
                        <li class="reel-container-li">
                            <img mode='widthFix' src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191221/ecd87b0fd1de43b8b4782a9b7a9cdeab.png">
                        </li>
                        <li class="reel-container-li">
                            <img mode='widthFix' src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191221/ecd87b0fd1de43b8b4782a9b7a9cdeab.png">
                        </li>
                        <li class="reel-container-li">
                            <img mode='widthFix' src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191221/ecd87b0fd1de43b8b4782a9b7a9cdeab.png">
                        </li>
                    </ul>
                    <div class="reel-container-time">
                        <div v-for="(item,index) in tigerVos"  :key="index"  :class="['reel-container-time'+index,'reel-container-bg',item.polystatus != '1'?'reel-container-bg1':'reel-container-bg2']">
                            <p class="reel-container-p1">{{item.startTimeStr}}</p>
                            <p class="reel-container-p2" v-if="item.polystatus == '0'">未开始</p>
                            <p class="reel-container-p2" v-if="item.polystatus == '1'">进行中</p>
                            <p class="reel-container-p2" v-if="item.polystatus == '2'">已结束</p>
                            <p class="reel-container-p2" v-if="item.polystatus == '3'">敬请期待</p>
                        </div>

                    </div>
                    <div class="reel-container-bottom">
                        <!-- <img class="reel-container-bottom-bg" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191221/f97dd5a44fa64b4095d2f6f82a3c0413.png"/> -->
                        <img class="reel-container-bottom-bg" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191221/3d82d5d1152e49b4ab1aaa2472019819.png"/>
                        <p class="reel-container-bottom-time">{{raffleTigerVO.startTimeStr}}</p>
                        <p class="reel-container-bottom-text">点击下方进行抽奖</p>
                    </div>
                </div>
                <!-- 闪灯 -->
                <div class="bottom_lamp_box">
                    <div class="bottom_lamp">
                        <img v-if="bottomLampCheck1" mode='widthFix' :src="bottomLampBright" alt="">
                        <img v-if="!bottomLampCheck1" mode='widthFix' :src="bottomLampDark" alt="">
                    </div>
                    <div class="bottom_lamp">
                        <img v-if="bottomLampCheck2" mode='widthFix' :src="bottomLampBright" alt="">
                        <img v-if="!bottomLampCheck2" mode='widthFix' :src="bottomLampDark" alt="">
                    </div>
                    <div class="bottom_lamp">
                        <img v-if="bottomLampCheck3" mode='widthFix' :src="bottomLampBright" alt="">
                        <img v-if="!bottomLampCheck3" mode='widthFix' :src="bottomLampDark" alt="">
                    </div>
                </div>
                <!-- 立即抽奖 -->
                <div class="begin-btn" :style="btnCheck ? '' : 'margin-top:8px'">
                    <img
                        v-show="btnCheck"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191217/b6817e9231634bc6b8c0f1069cbb81ef.png"
                        mode="widthFix"
                        @click="startClick"
                    />
                    <img
                        v-show="!btnCheck"
                        mode="widthFix"
                        @click="startClick"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/1880aa74e78a4d60966a6f033f0a7505.png"
                    />
                </div>
                <div class="coupon-text">
                    <p class="cost-inter" v-if="raffleTigerVO.costIntegral !='0' && raffleTigerVO.costIntegral">-{{raffleTigerVO.costIntegral}} 积分抽奖</p>
                    <p class="cost-inter" v-else>免费抽奖</p>
                </div>
            </div>
            <!-- 活动规则 -->
            <div class="machine_rule">
                <div class="machine_title">
                    <img mode="widthFix" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191218/57ee5a8e070e4eabb7ca62190112f1fc.png">
                </div>
                <div class="machine_text">
                    <p>
                        <ul class="rule_text_ul">
                            <li v-for="(item,index) in rules" :key="index">{{item}}</li>
                        </ul>
                    </p>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import utils from '../../plugins/utils'
import AuthBtn from '@/components/AuthBtn'
import api from '../../plugins/api'
import request from '../../plugins/request'
export default {
    components: {
        AuthBtn
    },
    data() {
        return {
            spinDisabled: false,
            // 按钮闪烁定时器
            btnCheck: true,
            setIntervalStatus: null,
            // 闪灯背景切换定时器
            bgCheck: false,
            setIntervalBgStatus: null,
            // 底灯闪烁亮灯暗灯
            bottomLampBright: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/957b35568a0e4824bb5edd1f856b84d9.png',
            bottomLampDark: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/f36518c1d8e34bb9bc4b81a287f41099.png',
            bottomLampCheck1: true,
            bottomLampCheck2: false,
            bottomLampCheck3: false,
            setIntervalBottomLampCheck: null,
            tigerVos: [],
            raffleTigerVO: {},
            rules: [],
        }
    },
    onLoad() {
        let t = this
        // 按钮定时抖动
        t.btnAnmite();
        t.setIntervalBgStatus = setInterval(() => {
            t.bgCheck = !t.bgCheck
            t.winningPrizeBgCheck = !t.winningPrizeBgCheck
        }, 1000)
        t.setIntervalBottomLampCheckFunc();
        t.setIntervalBottomLampCheck = setInterval(() => {
            t.setIntervalBottomLampCheckFunc();
        },4000)
        t.rules = []
        t.getList()
    },
    onHide(){
        let t = this
        //先清除按钮动画
        clearInterval(t.setIntervalStatus)
        clearInterval(t.setIntervalBottomLampCheck)
        clearInterval(t.setIntervalBgStatus)
    },
    methods: {
        //获取聚合列表
        getList(){
            let requestOptions = {
                path: api.polymerization + '?source=1'
            }
            request(requestOptions).then(res => {
                if(res.code == 200){
                    this.tigerVos = res.data.tigerVOs ? res.data.tigerVOs.slice(0,6): [],
                    this.raffleTigerVO = res.data.raffleTigerVO ? res.data.raffleTigerVO : {}
                    this.rules = res.data.raffleTigerVO.activityRules ? res.data.raffleTigerVO.activityRules.split('\n') : []
                }
            })
        },
        btnAnmite(){
            let t = this
            t.setIntervalStatus = setInterval(() => {
                t.btnCheckFun()
                setTimeout(() => {
                    t.btnCheckFun()
                    setTimeout(() => {
                        t.btnCheckFun()
                        setTimeout(() => {
                            t.btnCheckFun()
                        }, 150)
                    }, 150)
                }, 150)
            }, 2000)
        },
        setIntervalBottomLampCheckFunc(){
            let t = this;
            setTimeout(() => {
                t.bottomLampCheck1 = !t.bottomLampCheck1;
                t.bottomLampCheck2 = !t.bottomLampCheck2;
                setTimeout(() => {
                    t.bottomLampCheck2 = !t.bottomLampCheck2;
                    t.bottomLampCheck3 = !t.bottomLampCheck3;
                    setTimeout(() => {
                        t.bottomLampCheck1 = !t.bottomLampCheck1;
                        t.bottomLampCheck3 = !t.bottomLampCheck3;
                    },800)
                },800)
            },800)
        },

        startClick() {
            if(this.raffleTigerVO.polystatus !='1'){
                let msg
                if(this.raffleTigerVO.polystatus == '0'){
                    msg ='活动未开始，请继续关注！'
                }else if(this.raffleTigerVO.polystatus == '2'){
                    msg ='活动已结束，请继续关注！'
                }else if(this.raffleTigerVO.polystatus == '3'){
                    msg ='活动即将开始，请继续关注！'
                }
                 wx.showModal({
                    title: '温馨提示',
                    content: msg,
                    showCancel: false,
                    confirmText: '确认',
                    confirmColor: '#4694FA',
                    success(res) {}
                 })
            }else{
                wx.navigateTo({
                    url: `/pages/game/machine?activityId=${this.raffleTigerVO.activityId}`
                })
            }
        },
        // 按钮动画
        btnCheckFun() {
            this.btnCheck = !this.btnCheck
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
        this.getList()
    },
}
</script>
<style lang="less">
page {
    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191217/b7bb4e805af2441f8ba9925dfc9855da.png') center center no-repeat;
    background-size: cover;
    background-color: rgba(18, 22, 118, 1);
}
</style>
<style lang="less" scoped>
#machine {
    .container {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    // 活动规则
    .machine_rule{
        background: #A101C3;
        width: 90%;
        margin: 30rpx auto;
        color: #fff;
        .machine_title{
            width: 100%;
            img{
                width: 155px;
                margin: 15px auto;
            }
        }
        .machine_text{
            max-width: 613rpx;
            padding: 15px;
            height: 400rpx;
            overflow: scroll;
            font-size: 13px;
            li{
                max-width: 613rpx;
                padding-bottom: 15px;
            }
        }
    }

    .gashaponTop {
        height: 60px;
    }
    .gashaponTopBg {
        padding: 0 5px 0px 20px;

        image {
            width: 100%;
            height: 160px;
        }
    }
    .gashapon_icon {
        width: 95px;
        height: 41px;
        padding-top: 18px;
        padding-left: 18px;
        float: left;
        img {
            width: 95px;
            height: 41px;
        }
    }
    .gashapon_record {
        width: 95px;
        height: 55px;
        float: right;
        padding-right: 35rpx;
        position: relative;
        img {
            width: 95px;
        }
    }
    .gashapon_record_span {
        position: absolute;
        z-index: 99;
        color: #ffffff;
        font-size: 18px;
        font-weight: 400;
        top: 26px;
        left: 12px;
    }
    .sol-button {
        width: 100px;
    }

    .btn-group {
        margin-top: 40rpx;
        display: flex;
        align-items: center;
    }

    .sol-button {
        margin-right: 20rpx;
    }
    // 老虎机背景切换
    .bg-check-1 {
        background: transparent url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/510b73b09b134d598749f800c95a3ec8.png') bottom center no-repeat;
    }
    .bg-check-2 {
        background: transparent url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191224/0d424c4f72ba4343825319e375695fbc.png') bottom center no-repeat;
    }
    .slot-machine-container {
        position: relative;
        margin: 0 auto auto;
        z-index: 2;
        width: 750rpx;
        height: 1110rpx;
        background-size: cover;
        .reel-container {
            position: absolute;
            left: 149rpx;
            top: 405rpx;
            width: 456rpx;
            height: 433rpx;
            overflow: hidden;
            .reel {
                position: absolute;
                width: 144rpx;
                height: 4104rpx;
                // margin-top: 1px;
                background: transparent url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/fb568e455520467aa1d313aa576c79b1.png') 0 0 repeat-y;
                background-size: contain;
            }

            .reel0 {
                left: 7rpx;
            }

            .reel1 {
                left: 157rpx;
            }

            .reel2 {
                left: 307rpx;
            }

            .reel-overlay {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                z-index: 2;
                background: transparent url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191217/20011c85b1944c529086db62ad82af89.png') 0 0 repeat-y;
                background-size: 100% 100%;
            }
            .reel-container{
                position: relative;
            }
            .reel-container-ul{
                width: 100%;
                height: 145px;
            }
            .reel-container-li{
                width: 73.8px;
                height: 145px;
                display: inline-block;
                padding-left: 2px;
                position: relative;
                img{
                    width: 100%;
                    height: 145px;
                }
            }
            .reel-container-time{
                width: 100%;
                height: 145px;
                position: absolute;
                z-index: 99;
                top: 0px;
                left: 0px;
            }
            .reel-container-time0{
               position: absolute;
               z-index: 99;
               top: 13px;
               left: 15px;
            }
            .reel-container-time1{
               position: absolute;
               z-index: 99;
               top: 13px;
               left: 90px;
            }
            .reel-container-time2{
               position: absolute;
               z-index: 99;
               top: 13px;
               left: 164px;
            }
            .reel-container-time3{
               position: absolute;
               z-index: 99;
               top: 85px;
               left: 15px;
            }
            .reel-container-time4{
               position: absolute;
               z-index: 99;
               top: 85px;
               left: 90px;
            }
            .reel-container-time5{
               position: absolute;
               z-index: 99;
               top: 85px;
               left: 164px;
            }
            .reel-container-p1{
                font-size: 15px;
                font-weight: 400;
                text-align: center;
                padding-top: 2px;
            }
            .reel-container-p2{
                font-size: 10px;
                font-weight: 400;
                padding-top: 4px;
                text-align: center;
            }
            .reel-container-bg{
                width: 50px;
                height: 50px;
            }
            .reel-container-bg1{
                background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191221/09112a2dfb2f46bba9244236dabc4ddf.png') no-repeat;
                background-size: cover;
                color: #B6B6B6;
            }
            .reel-container-bg2{
                background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191221/785e84223f2e4cbd9d95a8354b792366.png') no-repeat;
                background-size: cover;
                color: #FDA211;
            }
            .reel-container-bottom{
                padding: 3px 2px 0px 2px;
                height: 68px;
                padding-top: 3px;
                position: relative;
                .reel-container-bottom-bg{
                    width: 100%;
                    height: 68px;
                }
                .reel-container-bottom-time{
                    width: 100%;
                    text-align: center;
                    font-size: 22px;
                    color: #FEFFDD;
                    position: absolute;
                    z-index: 99;
                    top: 12px;
                }
                .reel-container-bottom-text{
                    width: 100%;
                    text-align: center;
                    font-size: 16px;
                    color: #FEFFDD;
                    position: absolute;
                    z-index: 99;
                    top: 40px;
                }
            }
        }
        .begin-btn {
            position: absolute;
            left: 50%;
            margin-left: -76px;
            margin-top:1px;
            img {
                width: 307rpx;
                margin: 0 auto;
                height: 35px;
            }
        }
    }
    .coupon-text{
        width: 100%;
        text-align: center;
        p{
            margin-top: 142rpx;
            color: #DC5812;
        }
    }
    // 底灯
    .bottom_lamp_box{
        width: 226px;
        margin: 365.5px auto 0;
        height: 30px;
        position: relative;
        z-index: 3;
        .bottom_lamp{
            float: left;
            width: 33.33%;
            height: 30px;
            img{
                width: 46px;
                height: 16px;
                margin: 0 auto;
            }
        }
    }
    // 炫光背景
    .dazzle_light_bg{
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/d29dd6926cd145fead02773158e5a91a.png') center center no-repeat;
        background-size: cover;
        background-color: rgba(0, 0, 0, 0.7);
    }
}
</style>
