export default class LastMayday {
    cardInfo = {}

    do(cardInfo) {
        this.cardInfo = JSON.parse(JSON.stringify(cardInfo))
        return this._template()
    }

    TEXT_SMALL = {
        fontSize: '24rpx'
    }

    _template() {
        return ({
            background: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/acb7ef3d44c2482e947340474e49af14.png",
            width: '375px',
            height: '862px',
            views: [{
                //0
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/57c8a32b5ae041e3883609c10f2353f8.png",
                    css: {
                        top: '18px',
                        left: '18px',
                        width: '95px',
                        height: '41px',
                    }
                },
                {
                    //1
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191204/ce0b76c6d4384eb28c5cb16b02b0b731.png",
                    css: {
                        top: '215px',
                        left: '38px',
                        width: '307px',
                        height: '345px',
                    }
                },
                { //中奖图片 //2
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/95016418126d4ae2a3c00b86192844c9.png",
                    css: {
                        top: '260px',
                        left: '115px',
                        width: '150px',
                        height: '142px',
                    }
                }, {
                    //图片列表背景1 //3
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191203/705a6248f30944aca3e4be551b21536d.png",
                    css: {
                        width: '80px',
                        height: '108px',
                        color: '#DEBC64',
                        left: '20px',
                        top: '609px'
                    }
                },
                {
                    //图片列表背景2 //4
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191203/705a6248f30944aca3e4be551b21536d.png",
                    css: {
                        width: '80px',
                        height: '108px',
                        color: '#DEBC64',
                        left: '105px',
                        top: '609px'
                    }
                },
                {
                    //图片列表背景3 //5
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191203/705a6248f30944aca3e4be551b21536d.png",
                    css: {
                        width: '80px',
                        height: '108px',
                        color: '#DEBC64',
                        left: '190px',
                        top: '609px'
                    }
                },
                {
                    //图片列表背景4 //6
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191203/705a6248f30944aca3e4be551b21536d.png",
                    css: {
                        width: '80px',
                        height: '108px',
                        color: '#DEBC64',
                        left: '275px',
                        top: '609px'
                    }
                },
                { //图片列表1 //7
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/95016418126d4ae2a3c00b86192844c9.png",
                    css: {
                        top: '618px',
                        left: '27px',
                        width: '66px',
                        height: '63px'
                    }
                },
                { //图片列表2 //8
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/95016418126d4ae2a3c00b86192844c9.png",
                    css: {
                        top: '618px',
                        left: '112px',
                        width: '66px',
                        height: '63px',
                    }
                },
                { //图片列表3 //9
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/95016418126d4ae2a3c00b86192844c9.png",
                    css: {
                        top: '618px',
                        left: '197px',
                        width: '66px',
                        height: '63px',
                    }
                },
                { //图片列表4 //10
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/95016418126d4ae2a3c00b86192844c9.png",
                    css: {
                        top: '618px',
                        left: '282px',
                        width: '66px',
                        height: '63px',
                    }
                },
                { //11
                    type: 'image',
                    url: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191207/5b6142b017a94307a300dbcb5f5cbb50.png',
                    css: {
                        left: '58px',
                        top: '760px',
                        width: '130rpx',
                        height: '130rpx'
                    }
                },
                { //12
                    type: 'text',
                    text: '我获得了',
                    css: {
                        left: '160px',
                        top: '220px',
                        fontSize: '15px',
                        color: '#fff'

                    }
                },
                { //中奖奖品名称 //13
                    type: 'text',
                    text: '我获得了',
                    css: {
                        left: '35px',
                        width: '305px',
                        top: '510px',
                        fontSize: '24px',
                        color: '#fff',
                        textAlign: 'center'
                    }
                },
                { //奖品列表文字1 //14
                    type: 'text',
                    text: 'skG按摩仪',
                    css: {
                        left: '20px',
                        top: '693px',
                        width: '80px',
                        fontSize: '12px',
                        color: '#fff',
                        textAlign: 'center'
                    }
                },
                { //奖品列表文字2 //15
                    type: 'text',
                    text: '洁面仪',
                    css: {
                        left: '105px',
                        top: '693px',
                        fontSize: '12px',
                        color: '#fff',
                        width: '80px',
                        textAlign: 'center'
                    }
                },
                { //奖品列表文字3 //16
                    type: 'text',
                    text: '我获得了11',
                    css: {
                        left: '192px',
                        top: '693px',
                        fontSize: '12px',
                        color: '#fff',
                        width: '80px',
                        textAlign: 'center'
                    }
                },
                { //奖品列表文字4 //17
                    type: 'text',
                    text: '我获得了11',
                    css: {
                        left: '277px',
                        top: '693px',
                        fontSize: '12px',
                        color: '#fff',
                        width: '80px',
                        textAlign: 'center'
                    }
                },
                {
                    type: 'text', //18
                    text: '长按识别或者扫码',
                    css: {
                        left: '174px',
                        top: '775px',
                        fontSize: '15px',
                        color: '#A4761D',

                    }
                },
                {
                    type: 'text', //19
                    text: '进入小程序参与活动',
                    css: {
                        left: '174px',
                        top: '795px',
                        fontSize: '15px',
                        color: '#A4761D',

                    }
                },
                { //横线
                    type: 'rect', //20
                    css: {
                        left: '15px',
                        top: '586px',
                        color: '#A4761D',
                        width: '96px',
                        height: '1px'
                    }
                },
                { //横线 //21
                    type: 'rect',
                    css: {
                        right: '15px',
                        top: '586px',
                        color: '#A4761D',
                        width: '96px',
                        height: '1px'
                    }
                },
                {
                    type: 'text', //22
                    text: '丰富好礼等你来拿',
                    css: {
                        left: '120px',
                        top: '574px',
                        fontSize: '18px',
                        color: '#DD933A',

                    }
                },
                { //背景图 //23
                    type: 'image',
                    url: "https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191203/fe031c1966ef454698a88f090a17afb0.png",
                    css: {
                        top: '740px',
                        left: '0px',
                        width: '375px',
                        height: '121px',
                    }
                }
            ]
        })
    }
}
