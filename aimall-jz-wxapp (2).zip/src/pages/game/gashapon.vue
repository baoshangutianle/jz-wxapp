<template>
    <div id="gashapon" :class="record || ballLayer || layer ?'rootView' :''">
        <div class="gashaponView">
            <div class="gashaponTop">
                <div class="gashapon_icon">

                    <!-- <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/57c8a32b5ae041e3883609c10f2353f8.png"/> -->
                    <!-- <img src="https://aimall-jz.oss-cn-shenzhen.aliyuncs.com/as/WechatIMG1220.png"/> -->
                    <image src="https://aimall-jz.oss-cn-shenzhen.aliyuncs.com/as/WechatIMG1220.png" mode="widthFix" style="width:150rpx"></image> 
                </div>
                <div class="gashapon_record">
                    <!-- <span class="gashapon_record_span">
                        <auth-btn @pass="openRecord" />
                    </span> -->
                    <auth-btn @pass="openRecord" />
                    <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191209/bef6b7ab6a8642b292ae6edf0efe8047.png">

                    <!-- <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/d6bc3804f18a4ba58e274035d9bed6f1.png"/> -->
                </div>
            </div>
            <div class="gashaponTopBg">
                <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191204/b67e586538a44c47b9862483c8db7444.png"/>
            </div>
            <div class="egg">
                <div class="egg_con">
                    <image class="egg_con_img" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191205/930b33ec971743c081d1f2887962ada1.png" mode="widthFix"/>
                    <image class="ball ball_1" :class="start?'weiyi_1':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/187acf2b8b3444daae596ff0d028e61d.png" mode="widthFix"/>
                    <image class="ball ball_2" :class="start?'weiyi_2':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/b6694a61034f4f1fa1f4d523aba3bf71.png" mode="widthFix"/>
                    <image class="ball ball_3" :class="start?'weiyi_3':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/11eb19fcab0348b3ba0ec5bd9bd1c6f9.png" mode="widthFix"/>
                    <image class="ball ball_4" :class="start?'weiyi_4':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/59c80435956045bf8ade40c9416efcf3.png" mode="widthFix"/>
                    <image class="ball ball_5" :class="start?'weiyi_5':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/fff35ea9f8cb49b3b309c79a414eaa16.png" mode="widthFix"/>
                    <image class="ball ball_6" :class="start?'weiyi_6':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/f0ee680d780946b3af530ecdc3c86b67.png" mode="widthFix"/>
                    <image class="ball ball_7" :class="start?'weiyi_7':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/7ade45c25d9240dfb5964c9b41a5085f.png" mode="widthFix"/>
                    <image class="ball ball_8" :class="start?'weiyi_8':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/4e75f21244b243fd9d6739f20b3d57e7.png" mode="widthFix"/>
                    <image class="ball ball_9" :class="start?'weiyi_9':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191209/29d049f22bd542d88948eb1687156748.png" mode="widthFix"/>
                    <image class="ball ball_10" :class="start?'weiyi_10':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/54cee1e79a174c4883546c80ca11886c.png" mode="widthFix"/>

                    <image v-if="vipInfo" class="egg_play" @click="eggPlay" :class="start?'go':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191207/027fb66b4cf841b4841c3e8ccc28869a.png" mode="widthFix">
                    </image>
                    <image v-if="!vipInfo" class="egg_play" :class="start?'go':''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191207/027fb66b4cf841b4841c3e8ccc28869a.png" mode="widthFix">
                        <auth-btn @pass="eggPlay" />
                    </image>

                    <!-- <image :hidden="qiu" :animation="ani" class="ball ball_end" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191205/c3670789c6894b9786115caee644b0a8.png"></image> -->
                    <image v-if="!qiu" class="ball ball_end" :class="{'clearAnimation':clearAnimation}" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191205/c3670789c6894b9786115caee644b0a8.png"></image>
                    <image v-if="spread" class="ball_border spread" :class="{'clearAnimation':clearAnimation}" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/a865fd53e78348fcbc2d4c3759ed30d1.png"></image>
                    <p class="cost-inter" v-if="intergNum !='0' && intergNum !=''">-{{intergNum}} 积分抽奖</p>
                    <p class="cost-inter" v-if="intergNum !='0' && intergNum ==''">积分抽奖</p>
                    <p class="cost-inter" v-if="intergNum =='0'">免费抽奖</p>
                </div>
            </div>
            <div class="gashapon_rule">
                <div class="gashapon_rule_bg">
                    <p class="rule-img">
                        <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/2d47f0eeb9eb45d1aab1d2297978e164.png"/>
                    </p>
                    <p class="rule_text">活动规则</p>
                    <p>
                        <ul class="rule_text_ul">
                            <li v-for="(item,index) in rules" :key="index">{{item}}</li>
                        </ul>
                    </p>
                </div>
            </div>

            <!--弹幕文字-->
            <barrage-page :dmData="dmData" v-if="barrage"></barrage-page>
        </div>
        <!-- 中奖球的弾层 -->
        <div class="ball_layer" v-if="ballLayer" :class="{'clearAnimation':clearAnimation}">
            <!-- <div class="ball_layer"> -->
            <div class="dot">
                <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/c87d27d3df634a18ac26360dccd0b440.png"/>
            </div>
            <image class="pulse" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/b9d904e38a7f43f680f2c00d8d872c9e.png"/>
        </div>
        <!-- 抽奖确认弹框 -->
        <div class="gash_layer" v-if="layer">
            <div class="gash_prize_close" @click="closeLayer('layer')">
                <!-- <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/954ca5af8ec64c0d827c6e3e536c2f53.png"/> -->
                <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191209/cc0ea015e52c4ccaa536f93b0d4493e6.png"/>
            </div>
            <div class="gash_layer_con">
                <div class="gash_layer_top">
                    <div class="layer_interg">
                        <image  v-if="!noInterg" class="layer_interg_img" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191209/f959fc5ac1e94131a5944444bd3e13b6.png"/>
                        <image  v-if="noInterg" class="layer_interg_img" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/f98375f440d844eabe852574e3e14b38.png"/>
                        <div class="layer_interg_div" v-if="!noInterg && intergNum !='0'">
                            <p class="layer_interg_text">{{intergNum}}</p>
                            <p class="layer_interg_text">积分</p>
                        </div>
                        <div class="layer_interg_div" v-if="!noInterg && intergNum =='0'">
                            <p class="layer_interg_text">免费</p>
                            <p class="layer_interg_text">抽奖</p>
                        </div>

                    </div>
                    <div class="layer_interg_con">
                        <p class="layer_interg_remark pt38" v-if="!noInterg && intergNum == '0'">免费抽奖</p>
                        <p class="layer_interg_remark pt38" v-if="!noInterg && intergNum != '0'">使用 {{intergNum}} 积分抽奖一次</p>
                        <p class="layer_interg_remark" v-if="!noInterg">{{intergNum !='0' ?'未完成抽奖积分不退还':'此次抽奖免费'}} </p>
                        <p class="layer_interg_remark layer_interg_remark2" v-if="noInterg">{{messageText}}</p>
                    </div>
                </div>
                <div class="gash_layer_bottom">
                    <image class="layer_bottom_bg" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191126/e2a7d4f3e3434850b8dbd3fedec6ad0e.png"/>

                    <span class="layer_btn" v-if="noInterg" @click="closeLayer('layer')">我知道了</span>
                    <span class="layer_btn" v-if="!noInterg" @click="goPlay">立即抽奖</span>
                </div>
            </div>
        </div>
        <!-- 中奖/未中奖弹出框 -->
        <div class="gash_prize" v-if="prizeLayer" :class="{'clearAnimation':clearAnimation}">
            <div class="record_close" @click="closeLayer('prize')">
                <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191209/cc0ea015e52c4ccaa536f93b0d4493e6.png"/>
            </div>
            <div class="gash_prize_con">
                <div class="gash_prize_top">
                    <p class="gash_prize_title" v-if="drawn">恭喜您抽中</p>
                    <p class="gash_prize_title" v-if="!drawn">送你个小心心</p>
                    <image class="gash_prize_img" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/b9b75c75d53240f388d1d8ab9e450f01.png"/>
                    <div class="gash_prize_goods">
                        <image v-if="drawn" :src="prizeImageUrl"/>
                        <image v-else src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png"/>
                    </div>
                    <div class="gash_prize_name">
                        <p class="prize_name" v-if="drawn">{{prizeName}}</p>
                        <p class="prize_name2" v-if="drawn">可在<span class="prize_span">我的卡包</span>查看</p>
                        <p class="prize_name" v-if="!drawn">好可惜，没抽中</p>
                        <p class="prize_name2" v-if="!drawn">{{messageText}}</p>
                    </div>
                </div>
                <div class="gash_prize_bottom">
                    <image class="layer_bottom_bg" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191126/e2a7d4f3e3434850b8dbd3fedec6ad0e.png"/>
                    <span class="layer_go" @click="openShare">{{drawn?'晒好运':'去首页看看'}}</span>
                </div>
            </div>
        </div>
        <!-- 中奖纪录 -->
        <div class="record" touchmove="preventTouchMove" v-if="record">
            <div class="record_close" @click="closeLayer('record')">
                <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191209/cc0ea015e52c4ccaa536f93b0d4493e6.png"/>
            </div>
            <div class="record_con">
                <div class="record_title">
                    <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/8ea7d00dc2d64026843665b446329bc0.png"/>
                    <span class="record_text">获奖记录</span>
                </div>
                <div class="record_list">
                    <scroll-view
                        :style="{'height': '328px'}"
                        @scrolltolower="scrolltolower"
                        class="record_list_con"
                        :scroll-y="true"
                        >
                        <div class="record_list_con">
                            <ul v-if="!noRecord">
                                <li v-for="(item,index) in recordList" :key="index">
                                    <p class="record_p1">参与日期：{{item.createTime}}</p>
                                    <p class="record_p2">恭喜，获得<span class="record_span">{{item.prizeName}}</span></p>
                                </li>

                            </ul>
                            <div class="noRecord" v-else>
                                <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191129/417222e0737c4aa2a66d5dccd08ccdc0.png"/>
                                <p>暂时还没有中奖纪录呦~</p>
                            </div>
                    </div>
                    </scroll-view>

                </div>
            </div>
        </div>
        <!-- 晒好运 -->
        <good-luck :hAnimate="hAnimate" :prizeVos="template" @changeHeight="changeHeight" :isData="isData"></good-luck>
        <!-- 生成海报 -->
        <!-- <posters-share></posters-share> -->
    </div>
</template>
<script>
import barragePage from '@/components/barragePage'
import GoodLuck from '@/components/GoodLuck'
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import AuthBtn from '@/components/AuthBtn'
import { mapState, mapMutations } from 'vuex'
import wxUtils from '@/plugins/wxUtils'
import Card from './card'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
// import { stringify } from 'querystring'
const card = new Card()
const templateL = card._template()
// import postersShare from './postersShare'
export default {
    components: {
        GoodLuck,
        AuthBtn,
        barragePage
        // postersShare
    },
    data() {
        return {
            imgUrl: '',
            start: false,
            qiu: true,
            repeatClick: false, //防止重复点击
            dmData: [],
            layer: false,
            spread: false, //扩散效果
            ballLayer: false, //球的弾层
            prizeLayer: false,
            record: false, //中奖纪录
            drawn: false, //是否中奖
            beDrawn: false, //控制好运框是否出现
            noInterg: false, //积分不够
            hAnimate: false,
            activityId: '',
            intergNum: '',
            rules: [],
            recordList: [],
            prizeImageUrl: '',
            prizeName: '',
            pageSize: 10,
            pageNum: 1,
            noRecord: false,
            postershare: false,
            barrage: true,
            noDataList: false,
            prizeVos: [],
            prizeId: '',
            activityName: '',
            hasAcitivity: true,
            messageContent: templateL,
            template: {},
            messageText: '',
            clearAnimation : false,
            isData: false,
            pageStayTime: 0,
            stayTime: 0,
            p_action: '扭蛋游戏'
        }
    },
    onLoad() {
        this.activityId = this.$root.$mp.query.activityId
        this.stayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.GASHAPON_Index_P,
            p_id: this.$root.$mp.query.activityId,
            p_v1: 0
        })
        this.resetData()
    },
    onUnload(){
        let newTime
        newTime = new Date().getTime() - this.pageStayTime
        if(Math.floor(newTime/1000) <= 8){
            this.clearAnimation = true
        }else {
            this.clearAnimation = false
        }
         this.stayTime = new Date().getTime() - this.stayTime
        buryPoint.setZ({
            id: pointCode.GASHAPON_Index_Z,
            p_stay_time: this.stayTime,
            p_id: this.activityId,
            p_v1: 0
        })
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo', 'isLogined'])
    },
    methods: {
        ...mapMutations(['update']),
        //重置
        resetData() {
            this.imgUrl = ''
            this.start = false
            this.qiu = true
            this.repeatClick = false
            this.dmData = []
            this.layer = false
            this.spread = false //扩散效果
            this.ballLayer = false //球的弾层
            this.drawn = false
            this.prizeLayer = false
            this.hAnimate = false
            this.record = false
            this.noInterg = false
            this.intergNum = ''
            this.rules = []
            this.prizeVos = []
            this.prizeImageUrl = ''
            this.prizeName = ''
            this.pageSize = 10
            this.pageNum = 1
            this.recordList = []
            this.noRecord = false
            this.barrage = true
            this.noDataList = false
            this.prizeId = ''
            this.activityName = ''
            this.hasAcitivity = true
            this.isData = false
            this.setDM()
            this.getActivityDetail()
        },
        // 根据活动id查详情
        async getActivityDetail() {
            let requestOptions = {
                path: api.getActivityDetail + this.$root.$mp.query.activityId
            }
            await request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    let data = res.data || []
                    this.intergNum = data.costIntegral ? data.costIntegral : 0
                    this.prizeVos = data.prizeVos ? data.prizeVos : []
                    if (data.activityRules) {
                        this.rules = data.activityRules.split('\n')
                    } else {
                        this.rules = []
                    }

                    this.beDrawn = true
                    this.activityName = data.activityName ? data.activityName : ''
                } else {
                    this.beDrawn = false
                }
            })
        },
        eggPlay() {
            buryPoint.setF({
                id: pointCode.GASHAPON_Index_START_F,
                p_action_id: pointCode.GASHAPON_Index_START_F,
                p_action: this.p_action,
                p_id: this.activityId,
                p_v1: 0
            })
            //查询是否有抽奖资格
            let _this = this
            //清除在动画没完成退出页面导致的动画已经存在
            _this.pageStayTime = new Date().getTime()
            _this.clearAnimation = false
            _this.prizeLayer = false
            _this.ballLayer = false
            _this.qiu = true
            _this.spread = false

            if (_this.repeatClick) {
                return
            }
            _this.barrage = false
            _this.noInterg = false
            _this.hasAcitivity = true
            wx.request({
                url: api.checkMemberLotteryEligible + _this.activityId,
                method: 'GET',
                data: null,
                header: {
                    Authorization: _this.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code == 4001 || res.data.code == 4000) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = _this.isLogined
                                wxUtils.clearLoginStorage()
                                _this.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index?form=gashaponGame&formId=${_this.activityId}`
                                })
                            }
                        })
                    } else if (res.data.code == 200 || res.data.code == 0) {
                        _this.repeatClick = true
                        if (_this.intergNum == '0') {
                            _this.goPlay()
                        } else {
                            _this.layer = true
                        }
                    } else {
                        if (res.data.code != 500 && _this.intergNum != '0') {
                            _this.layer = true
                            _this.noInterg = true
                            _this.repeatClick = true
                            _this.messageText = res.data.message
                            if(res.data.code == 400003 || res.data.code == 400002){
                                buryPoint.setF({
                                    id: pointCode.GASHAPON_Index_Finish_F,
                                    p_action_id: pointCode.GASHAPON_Index_Finish_F,
                                    p_action: _this.p_action,
                                    p_id: _this.activityId,
                                    p_v1: 0
                                })
                            }else if(res.data.code == 400008){
                                buryPoint.setF({
                                    id: pointCode.GASHAPON_Index_KNOW_F,
                                    p_action_id: pointCode.GASHAPON_Index_KNOW_F,
                                    p_action: _this.p_action,
                                    p_id: _this.activityId,
                                    p_v1: 0
                                })
                            }
                        } else {
                            if(res.data.code == 400003){
                                buryPoint.setF({
                                    id: pointCode.GASHAPON_Index_Finish_F,
                                    p_action_id: pointCode.GASHAPON_Index_Finish_F,
                                    p_action: _this.p_action,
                                    p_id: _this.activityId,
                                    p_v1: 0
                                })
                            }else if(res.data.code == 400008){
                                buryPoint.setF({
                                    id: pointCode.GASHAPON_Index_KNOW_F,
                                    p_action_id: pointCode.GASHAPON_Index_KNOW_F,
                                    p_action: _this.p_action,
                                    p_id: _this.activityId,
                                    p_v1: 0
                                })
                            }
                            _this.noInterg = false
                            _this.repeatClick = false
                            wx.showModal({
                                title: '提醒',
                                content: res.data.message,
                                showCancel: false,
                                confirmText: '确认',
                                confirmColor: '#4694FA'
                            })
                        }
                    }
                }
            })
        },
        goPlay() {
            buryPoint.setF({
                id: pointCode.GASHAPON_Index_GO_F,
                p_action_id: pointCode.GASHAPON_Index_GO_F,
                p_action: this.p_action,
                p_v1: 0
            })
            const _this = this
            _this.prizeImageUrl = ''
            _this.prizeName = ''
            _this.template = {}

            //查询抽奖结果
            let requestOptions = {
                path: api.luckyTry,
                method: 'post',
                hideLoading: true,
                data: {
                    raffleActivityId: _this.activityId,
                    source: 1 //小程序入口标识
                }
            }
            request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    if (res.data) {
                        // 中奖了  获取中奖商品id
                        _this.prizeImageUrl = res.data.prizeImageUrl ? res.data.prizeImageUrl : 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png'
                        _this.prizeName = res.data.prizeName ? res.data.prizeName : ''
                        _this.prizeId = res.data.prizeId ? res.data.prizeId : ''
                        _this.drawn = true
                        let obj = _this.messageContent
                        obj.views[2].url = _this.prizeImageUrl
                        obj.views[13].text = _this.prizeName
                        obj.views[7].url = _this.prizeVos[0].couponImageUrl != '' ? _this.prizeVos[0].couponImageUrl :'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png'
                        obj.views[8].url = _this.prizeVos[1].couponImageUrl!= '' ? _this.prizeVos[1].couponImageUrl :'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png'
                        obj.views[9].url = _this.prizeVos[2].couponImageUrl!= '' ? _this.prizeVos[2].couponImageUrl :'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png'
                        obj.views[10].url = _this.prizeVos[3].couponImageUrl!= '' ? _this.prizeVos[3].couponImageUrl :'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png'
                        obj.views[14].text = _this.prizeVos[0].prizeName
                        obj.views[15].text = _this.prizeVos[1].prizeName
                        obj.views[16].text = _this.prizeVos[2].prizeName
                        obj.views[17].text = _this.prizeVos[3].prizeName

                        _this.template = obj
                    } else {
                        // 未中奖 获取文案
                        _this.drawn = false
                        _this.messageText = res.message
                    }
                }
            })

            _this.barrage = false
            _this.layer = false
            _this.start = true
            _this.spread = false
            setTimeout(() => {
                _this.start = false
                //球落下动画
                // var animation = wx.createAnimation({
                //     duration: 1000,
                //     timingFunction: 'ease'
                // })
                // animation.opacity(1).step()
                // _this.ani = animation.export()
                _this.spread = true
            }, 2500)
            _this.qiu = true
            //将动画返回到开始位置
            // var animation = wx.createAnimation({
            //     duration: 1000,
            //     timingFunction: 'ease'
            // })
            // animation.opacity(0).step()
            // _this.ani = animation.export()
            //六秒钟之后，球掉落显示中奖球弾层
            setTimeout(() => {
                _this.qiu = false
            }, 2000)
            setTimeout(() => {
                _this.spread = false
                _this.ballLayer = true
            }, 3000)
            //六秒钟之后隐藏中奖球扩散弾层，显示白色弾层
            setTimeout(() => {
                _this.ballLayer = false
                _this.prizeLayer = true
            }, 5000)
        },
        // 处理弹幕位置
        setDM: function() {
            // 处理弹幕参数
            const dmArr = []
            this.dmData = []
            this.barrage = true
            let requestOptions = {
                path: api.barrageList,
                method: 'get',
                hideLoading: true,
                data: {
                    source: 1, //小程序入口标识
                    activityId: this.activityId
                }
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    if (res.data.list) {
                        const _b = res.data.list
                        for (let i = 0; i < _b.length; i++) {
                            const time = Math.floor(Math.random() * 10)
                            const _time = time < 6 ? (6 + i) * 3 : time + i
                            const top = Math.floor(Math.random() * 80) + 5
                            const _p = {
                                id: _b[i].id,
                                face: _b[i].memberHeadPortrait,
                                name: _b[i].memberName,
                                prize: _b[i].prizeId,
                                prizeName: _b[i].prizeName,
                                top,
                                time: _time,
                                //dmAnimation: 'dmAnimation ' + _time + 's linear ' + i * 3 + 's infinite'
                                dmAnimation: 'dmAnimation 15s linear ' + i * 3 + 's infinite'
                            }
                            dmArr.push(_p)
                        }
                        this.dmData = dmArr
                    }
                }
            })
        },
        //晒好运
        openShare() {
            const t = this
            buryPoint.setF({
                id: pointCode.GASHAPON_RESULT_LUCK_F,
                p_action_id: pointCode.GASHAPON_RESULT_LUCK_F,
                p_action: this.p_action,
                p_id: this.activityId,
                p_v1: 0
            })
            if (t.drawn) {
                t.barrage = false
                t.hAnimate = true
            } else {
                wx.reLaunch({
                    url: '/pages/home'
                })
            }
        },
        openRecord() {
            this.record = true
            this.barrage = false
            //查询中奖纪录
            let requestOptions = {
                path: api.listOfPrizes,
                method: 'post',
                data: {
                    memberCode: this.vipInfo ? this.vipInfo.memberCode : '',
                    pageNum: this.pageNum,
                    pageSize: this.pageSize,
                    activityId: this.activityId
                }
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    if (res.data.total == 0 && this.pageNum == 1) {
                        this.noRecord = true
                    } else {
                        this.noRecord = false
                        if (this.pageNum != 1) {
                            this.recordList = this.recordList.concat(res.data.list)
                        } else {
                            this.recordList = res.data.list
                        }
                        //数据加载结束
                        if (0 <= res.data.list.length && res.data.list.length < this.pageSize) {
                            this.noDataList = true
                        } else {
                            this.noDataList = false
                        }
                    }
                }
            })
        },
        closeLayer(type) {
            if (type == 'record') {
                this.record = false
                this.pageNum = 1
                this.noDataList = false
            } else if (type == 'layer') {
                this.layer = false
            } else if (type == 'prize') {
                this.prizeLayer = false
                this.hAnimate = false
            }
            if (!this.record && !this.layer && !this.prizeLayer) {
                this.setDM()
            }
            wx.hideLoading()
            this.isData = false
            this.repeatClick = false
            this.qiu = true
        },
        changeHeight() {
            wx.hideLoading()
            this.isData = false
            this.hAnimate = false
        },
        scrolltolower() {
            if (!this.noDataList) {
                this.pageNum++
                this.openRecord()
            }
        },
        //防止底层view滑动
        preventTouchMove(e) {
            return
        }
    },
    onShareAppMessage(options) {
        buryPoint.setF({
            id: pointCode.GASHAPON_RESULT_INVITE_F,
            p_action_id: pointCode.GASHAPON_RESULT_INVITE_F,
            p_action: this.p_action,
            p_id: this.activityId,
            p_v1: 0
        })
        let title
        if (this.drawn) {
            title = `我在${this.activityName}中抽中了${this.prizeName}，你也来试试吧`
        } else {
            title = `${this.activityName}正在火热进行中，快来试试吧`
        }
        return {
            title: title,
            imageUrl: this.prizeImageUrl,
            path: 'pages/home?pageId=gashaponShare&activityId=' + this.activityId + '&prizeId=' + this.prizeId,
            success: function(res) {
                //this.resetData()
                wx.showToast({
                    title: '转发成功',
                    icon: 'success',
                    duration: 2000
                })
            }
        }
    }
}
</script>
<style lang="less" scoped>
.rootView {
    position: fixed !important;
    top: 0px;
    left: 0px;
    right: 0px;
    bottom: 0px;
}
#gashapon {
    .clearAnimation{
        display: none !important
    }
    position: relative;
    .gashaponView {
        // background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/acb7ef3d44c2482e947340474e49af14.png') no-repeat;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191202/40992b5a0ee6490bbcbb4c4fb8ce20df.png') no-repeat;
        background-size: cover;
        width: 100%;
        height: 100%;
        position: relative;
        min-height: 100vh;
    }

    .gashaponTop {
        height: 60px;
    }
    .gashaponTopBg {
        padding: 0 5px 0px 20px;

        image {
            width: 100%;
            height: 160px;
        }
    }
    .gashapon_icon {
        width: 95px;
        height: 41px;
        padding-top: 18px;
        padding-left: 18px;
        float: left;
        img {
            width: 95px;
            height: 41px;
        }
    }
    .gashapon_record {
        width: 95px;
        height: 55px;
        float: right;
        padding-right: 32px;
        position: relative;
        img {
            width: 95px;
            height: 55px;
        }
    }
    .gashapon_record_span {
        position: absolute;
        z-index: 99;
        color: #ffffff;
        font-size: 18px;
        font-weight: 400;
        top: 26px;
        left: 12px;
    }
    // .egg {
    //     width: 100%;
    //     position: absolute;
    //     z-index: 3;
    //     top: 260rpx;
    // }
    .egg {
        width: 281px;
        // padding-top: 160px;
        position: relative;
        margin: 0 auto;
        margin-top: -30px;
    }
    .egg_con {
        width: 100%;
        position: relative;
    }
    .egg_con_img {
        width: 281px;
        height: 268px;
        position: absolute;
        z-index: 99;
        top: 0px;
    }
    .egg .ball {
        position: absolute;
        z-index: 66;
        width: 76px;
        height: 76px;
    }
    .egg .ball_1 {
        top: 165px;
        left: 87px;
    }
    .egg .ball_2 {
        top: 165px;
        left: 147px;
    }
    .egg .ball_3 {
        top: 150px;
        left: 27px;
    }
    .egg .ball_4 {
        top: 145px;
        right: 20px;
        z-index: 44;
    }
    .egg .ball_5 {
        top: 115px;
        left: 125px;
    }
    .egg .ball_6 {
        top: 105px;
        left: 70px;
    }
    .egg .ball_7 {
        top: 95px;
        left: 30px;
        z-index: 22;
    }
    .egg .ball_8 {
        top: 60px;
        left: 100px;
        z-index: 22;
    }
    .egg .ball_9 {
        top: 70px;
        right: 30px;
        z-index: 22;
    }
    .egg .ball_10 {
        top: 105px;
        right: 5px;
        z-index: 33;
    }
    .egg .egg_play {
        width: 50px;
        height: 50px;
        top: 292px;
        right: 71px;
        position: absolute;
        z-index: 99;
    }
    // .egg_play_img{
    //     width: 50px;
    //     height: 50px;
    //     top: 292px;
    //     right: 71px;
    //     position: absolute;
    //     z-index: 199;
    // }
    .egg .ball_end {
        left: 73px;
        z-index: 99;
        width: 35px;
        height: 35px;
        top: 310px;
        animation: ballDown 0.8s linear 1;
    }
    .gashapon_rule {
        width: 100%;
        padding-top: 370px;
    }
    .gashapon_rule_bg {
        margin: 27px;
        background: rgba(167, 167, 167, 0.24);
        border-radius: 4px;
        //opacity:0.24;
        padding: 16px;
        color: #a4761d;
        font-size: 15px;
        font-weight: 400;
        position: relative;
    }
    .rule-img {
        width: 100%;
        height: 36px;
        padding-bottom: 15px;
        position: relative;
        image {
            width: 100%;
            height: 36px;
        }
    }
    .rule_text {
        font-size: 20px;
        color: #ffffff;
        display: inline-block;
        width: 100%;
        position: absolute;
        z-index: 99;
        top: 20px;
        left: 0px;
        text-align: center;
    }
    .rule_text_ul {
        max-height: 200px;
        overflow-y: auto;
    }
    .rule_text_ul li {
        padding-bottom: 12px;
    }
    .gash_layer,
    .gash_prize {
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        position: absolute;
        z-index: 199;
        top: 0px;
        left: 0px;
        right: 0px;
    }
    .gash_prize_close {
        position: absolute;
        z-index: 99;
        top: 71px;
        right: 34px;
        width: 38px;
        height: 38px;
        image {
            width: 38px;
            height: 38px;
        }
    }
    .gash_layer_con {
        padding-top: 171px;
        padding-left: 26px;
        padding-right: 26px;
    }
    .gash_prize {
        padding-left: 35px;
        padding-right: 35px;
        animation: prizeSpread 0.8s linear 1;
    }
    .gash_layer_top {
        width: 100%;
        height: 222px;
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/76d65823e88a4653ac921cb5600d5bab.png') no-repeat;
        background-size: 100%;
        //background: linear-gradient(224deg, rgba(222, 188, 100, 1) 0%, rgba(213, 165, 74, 1) 100%, rgba(248, 216, 136, 1) 100%, rgba(248, 216, 136, 1) 100%);
        border-radius: 8px;
        position: relative;
    }
    .gash_prize_top {
        width: 307px;
        height: 381px;
        position: relative;
        margin: 0 auto;
        padding-top: 128px;
        text-align: center;
    }
    .gash_prize_title {
        width: 129px;
        height: 27px;
        position: absolute;
        z-index: 99;
        top: 132px;
        color: #ffffff;
        font-size: 15px;
        font-weight: 400;
        width: 100%;
    }
    .gash_prize_goods {
        width: 100%;
        height: 142px;
        position: absolute;
        z-index: 99;
        top: 165px;
        image {
            width: 150px;
            height: 142px;
        }
    }
    .gash_prize_name {
        width: 100%;
        position: absolute;
        z-index: 99;
        bottom: 25px;
        text-align: center;
    }
    .prize_name {
        color: #ffffff;
        font-size: 24px;
        font-weight: 600;
    }
    .prize_name2 {
        color: #ffffff;
        font-size: 15px;
        font-weight: 400;
        padding-top: 11px;
    }
    .prize_span {
        font-size: 16px;
        font-weight: 500;
        padding-left: 5px;
        padding-right: 5px;
    }
    .gash_prize_img {
        width: 100%;
        height: 100%;
    }
    .layer_interg {
        position: relative;
        height: 90px;
        width: 90px;
        text-align: center;
        margin: 0 auto;
        top: 15px;
    }
    .layer_interg_img {
        height: 90px;
        width: 90px;
    }
    .layer_interg_div {
        position: absolute;
        z-index: 99;
        top: 15px;
        left: 0px;
        width: 100%;
        text-align: center;
    }
    .gash_layer_bottom,
    .gash_prize_bottom {
        margin: 0 auto;
        position: relative;
        padding-top: 55px;
        text-align: center;
        width: 151px;
        height: 48px;
    }
    .layer_bottom_bg {
        width: 151px;
        height: 48px;
    }
    .layer_btn{
        font-size: 20px;
        color: #ffffff;
        font-weight: 500;
        position: absolute;
        top: 55px;
        width: 100%;
        z-index: 99;
        left: 0px;
        display: inline-block;
        height: 48px;
        line-height: 48px;
    }
    .layer_go {
        font-size: 20px;
        color: #ffffff;
        font-weight: 500;
        position: absolute;
        top: 55px;
        width: 100%;
        z-index: 99;
        left: 0px;
        display: inline-block;
        height: 48px;
        line-height: 48px;
    }
    .layer_interg_text {
        font-size: 18px;
        color: #ffffff;
    }
    .layer_interg_con {
        height: 126px;
        background: rgba(255, 255, 255, 1);
        border-radius: 4px;
        position: absolute;
        z-index: 199;
        top: 85px;
        left: 10px;
        right: 10px;
        bottom: 10px;
        text-align: center;
    }
    .layer_interg_remark {
        font-size: 18px;
        color: #a4761d;
    }
    .layer_interg_remark2{
        height: 100%;
        line-height: 126px;
    }
    .ball_layer {
        width: 100%;
        height: 100%;
        position: absolute;
        z-index: 99;
        top: 0px;
        left: 0px;
        right: 0px;
        background: rgba(0, 0, 0, 0.77);
        text-align: center;
        // animation-name:warnBg;
        // animation-duration: 2s;
        // animation-timing-function:linear;
        // animation-delay:2s;
    }
    /* 保持大小不变的小圆点 */
    .dot {
        position: absolute;
        width: 171px;
        height: 172px;
        //left: 134px;
        // top: 50%;
        top: 331px;
        border-radius: 50%;
        z-index: 22;
        left: 50%;
        transform: translate(-50%, -50%);
        opacity: 0;
        animation-name: bigBall, bigBallHide;
        animation-duration: 1s, 1s;
        animation-timing-function: linear, linear;
        animation-delay: 0, 2.5s;
        animation-iteration-count: 1, 1;
        // animation: around2 1s linear infinite
        image {
            width: 100%;
            height: 100%; /* 50%为自身尺寸的一半 */
        }
    }
    /* 产生动画（向外扩散变大）的圆圈 第一个圆 */
    .pulse {
        width: 220px;
        height: 222px;
        top: 50%;
        border-radius: 50%;
        z-index: 2;
        left: 50%;
        opacity: 0;
        position: absolute;
        animation-name: warn;
        animation-duration: 1.5s;
        animation-timing-function: linear;
        animation-delay: 1s;
        animation-iteration-count: 1;
        //box-shadow: 1px 1px 60px rgba(244,228,171,0.58); /* 阴影效果 */
        left: 50%;
        margin-left: -110px;
        // top: 50%;
        top: 331px;
        margin-top: -30%;
    }
    .spread_layer {
        width: 100%;
        height: 100%;
        position: absolute;
        z-index: 99;
        top: 0px;
        left: 0px;
        right: 0px;
        background: rgba(250, 249, 244, 0.9);
        animation: layerSpread 1s ease-out 1;
    }
    .pt38 {
        padding-top: 38px;
    }
    .weiyi_1 {
        animation: around1 2.5s linear 1;
        //animation: aroundBall 1s linear infinite;
    }
    .weiyi_2 {
        animation: around2 2.5s linear 1;
        //animation: aroundBall2 0.8s linear infinite;
    }
    .weiyi_3 {
        animation: around3 2.5s linear 1;
        // animation: aroundBall 1s linear infinite;
    }
    .weiyi_4 {
        animation: around4 2.5s linear 1;
        // animation: aroundBall 1s linear infinite;
    }
    .weiyi_5 {
        animation: around5 2.5s linear 1;
        // animation: aroundBall 1s linear infinite;
    }
    .weiyi_6 {
        animation: around6 2.5s linear 1;
        // animation: aroundBall 1s linear infinite;
    }
    .weiyi_7 {
        animation: around7 2.5s linear 1;
        // animation: aroundBall 1s linear infinite;
    }
    .weiyi_8 {
        animation: around8 2.5s linear 1;
        // animation: aroundBall 1s linear infinite;
    }
    .weiyi_9 {
        animation: around9 2.5s linear 1;
        // animation: aroundBall 1s linear infinite;
    }
    .weiyi_10 {
        animation: around10 2.5s linear 1;
        // animation: aroundBall 1s linear infinite;
    }
    .go {
        animation: aroundGo 2.5s linear 1;
    }
    .spread {
        animation: aroundSpread 1.5s linear 1;
    }
    .ball_border {
        width: 82px;
        height: 82px;
        top: 275px;
        right: 55px;
        position: absolute;
        z-index: 99;
        display: inline-block;
        border-radius: 50%;
        //background: radial-gradient(to top, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.3) 5%, rgba(255, 255, 255, 0.5) 10%, rgba(255, 255, 255, 1) 50%, rgba(255, 255, 255, 0.8) 65%, rgba(255, 255, 255, 0.6) 70%, rgba(255, 255, 255, 0.4) 85%, rgb(255, 255, 255) 100%);
    }
    .cost-inter {
        position: absolute;
        z-index: 99;
        bottom: 0px;
        left: 0px;
        width: 100%;
        top: 355px;
        text-align: center;
        color: #ffffff;
        font-size: 14px;
    }

    /* 位移 */
    @keyframes around {
        100% {
            -webkit-transform: rotate(-180deg);
        }
    }
    /* 位移 */
    @keyframes aroundGo {
        0% {
            -webkit-transform: rotate(0deg);
        }
        10% {
            -webkit-transform: rotate(120deg);
        }
        20% {
            -webkit-transform: rotate(120deg);
        }
        30% {
            -webkit-transform: rotate(120deg);
        }
        40% {
            -webkit-transform: rotate(120deg);
        }
        50% {
            -webkit-transform: rotate(240deg);
        }
        60% {
            -webkit-transform: rotate(240deg);
        }
        70% {
            -webkit-transform: rotate(240deg);
        }
        80% {
            -webkit-transform: rotate(360deg);
        }
        90% {
            -webkit-transform: rotate(360deg);
        }
        100% {
            -webkit-transform: rotate(360deg);
        }
    }
    @keyframes aroundBall {
        0% {
            -webkit-transform: translate(0px, 0px) rotate(0deg);
        }
        2% {
            -webkit-transform: translate(-2px, 2.5px) rotate(2.5deg);
        }
        4% {
            -webkit-transform: translate(2.3px, 0px) rotate(-0.5deg);
        }
        6% {
            -webkit-transform: translate(2.4px, 2.4px) rotate(-4deg);
        }
        8% {
            -webkit-transform: translate(-2.3px, -2px) rotate(-3.5deg);
        }
        10% {
            -webkit-transform: translate(2.4px, 0px) rotate(-4deg);
        }
        12% {
            -webkit-transform: translate(-2.3px, -2px) rotate(-4deg);
        }
        14% {
            -webkit-transform: translate(2.5px, 2.3px) rotate(3.5deg);
        }
        16% {
            -webkit-transform: translate(2.5px, -2.5px) rotate(-3.5deg);
        }
        18% {
            -webkit-transform: translate(2.3px, -2.3px) rotate(-4deg);
        }
        20% {
            -webkit-transform: translate(2px, 2px) rotate(-2.5deg);
        }
        22% {
            -webkit-transform: translate(2.3px, 2.5px) rotate(-4deg);
        }
        24% {
            -webkit-transform: translate(-2.4px, -2px) rotate(4deg);
        }
        26% {
            -webkit-transform: translate(2.3px, -2.3px) rotate(2.5deg);
        }
        28% {
            -webkit-transform: translate(2.6px, -2.6px) rotate(-4deg);
        }
        30% {
            -webkit-transform: translate(-2.3px, -2.3px) rotate(-3.5deg);
        }
        32% {
            -webkit-transform: translate(-2px, 0px) rotate(4deg);
        }
        34% {
            -webkit-transform: translate(2.3px, 2.3px) rotate(-2.5deg);
        }
        36% {
            -webkit-transform: translate(2.3px, 2.6px) rotate(4.5deg);
        }
        38% {
            -webkit-transform: translate(2.3px, -2.6px) rotate(3.5deg);
        }
        40% {
            -webkit-transform: translate(-2.4px, -2px) rotate(-2.5deg);
        }
        42% {
            -webkit-transform: translate(-2.4px, 2.3px) rotate(-2.5deg);
        }
        44% {
            -webkit-transform: translate(-2.6px, 2.4px) rotate(2.5deg);
        }
        46% {
            -webkit-transform: translate(-2.1px, -2.3px) rotate(-2.5deg);
        }
        48% {
            -webkit-transform: translate(2px, 2.6px) rotate(3.5deg);
        }
        50% {
            -webkit-transform: translate(2.6px, 2.6px) rotate(3.5deg);
        }
        52% {
            -webkit-transform: translate(-2.4px, 2.6px) rotate(2.5deg);
        }
        54% {
            -webkit-transform: translate(2.6px, -2px) rotate(-4deg);
        }
        56% {
            -webkit-transform: translate(2.3px, -2.6px) rotate(-4deg);
        }
        58% {
            -webkit-transform: translate(-2.3px, -2.6px) rotate(2.5deg);
        }
        60% {
            -webkit-transform: translate(2.3px, 2.6px) rotate(-2.5deg);
        }
        62% {
            -webkit-transform: translate(0px, 0px) rotate(-3.5deg);
        }
        64% {
            -webkit-transform: translate(-2.6px, -2.6px) rotate(-4deg);
        }
        66% {
            -webkit-transform: translate(2.6px, -2.6px) rotate(2.5deg);
        }
        68% {
            -webkit-transform: translate(0px, -2.6px) rotate(-4deg);
        }
        70% {
            -webkit-transform: translate(-2.6px, 2px) rotate(3.5deg);
        }
        72% {
            -webkit-transform: translate(-2.6px, 2.6px) rotate(4deg);
        }
        74% {
            -webkit-transform: translate(2.3px, -2.6px) rotate(-2.5deg);
        }
        76% {
            -webkit-transform: translate(2.4px, 2px) rotate(-2.5deg);
        }
        78% {
            -webkit-transform: translate(-2px, 2.4px) rotate(4deg);
        }
        80% {
            -webkit-transform: translate(2.4px, 2.6px) rotate(4deg);
        }
        82% {
            -webkit-transform: translate(-2.6px, -2.6px) rotate(-2.5deg);
        }
        84% {
            -webkit-transform: translate(-2.4px, 2.4px) rotate(-4deg);
        }
        86% {
            -webkit-transform: translate(2px, 2.4px) rotate(-4deg);
        }
        88% {
            -webkit-transform: translate(-2.4px, 2.4px) rotate(-3.5deg);
        }
        90% {
            -webkit-transform: translate(-2.6px, -2.6px) rotate(-4deg);
        }
        92% {
            -webkit-transform: translate(-2.6px, 2.6px) rotate(4deg);
        }
        94% {
            -webkit-transform: translate(-2.6px, -2.6px) rotate(-4deg);
        }
        96% {
            -webkit-transform: translate(-2.4px, 2.3px) rotate(-4deg);
        }
        98% {
            -webkit-transform: translate(2.3px, 2px) rotate(-2.5deg);
        }
    }
    @keyframes aroundBall2 {
        0% {
            -webkit-transform: translate(0px, 0px) rotate(0deg);
        }
        2% {
            -webkit-transform: translate(2px, -2.5px) rotate(-2.5deg);
        }
        4% {
            -webkit-transform: translate(-2.3px, 0px) rotate(0.5deg);
        }
        6% {
            -webkit-transform: translate(-2.4px, -2.4px) rotate(4deg);
        }
        8% {
            -webkit-transform: translate(2.3px, 2px) rotate(3.5deg);
        }
        10% {
            -webkit-transform: translate(-2.4px, 0px) rotate(4deg);
        }
        12% {
            -webkit-transform: translate(2.3px, 2px) rotate(4deg);
        }
        14% {
            -webkit-transform: translate(-2.5px, -2.3px) rotate(-3.5deg);
        }
        16% {
            -webkit-transform: translate(-2.5px, 2.5px) rotate(3.5deg);
        }
        18% {
            -webkit-transform: translate(-2.3px, 2.3px) rotate(4deg);
        }
        20% {
            -webkit-transform: translate(-2px, -2px) rotate(2.5deg);
        }
        22% {
            -webkit-transform: translate(-2.3px, -2.5px) rotate(4deg);
        }
        24% {
            -webkit-transform: translate(2.4px, 2px) rotate(-4deg);
        }
        26% {
            -webkit-transform: translate(-2.3px, 2.3px) rotate(-2.5deg);
        }
        28% {
            -webkit-transform: translate(-2.6px, 2.6px) rotate(4deg);
        }
        30% {
            -webkit-transform: translate(2.3px, 2.3px) rotate(3.5deg);
        }
        32% {
            -webkit-transform: translate(2px, 0px) rotate(-4deg);
        }
        34% {
            -webkit-transform: translate(-2.3px, -2.3px) rotate(2.5deg);
        }
        36% {
            -webkit-transform: translate(-2.3px, -2.6px) rotate(-4.5deg);
        }
        38% {
            -webkit-transform: translate(-2.3px, 2.6px) rotate(-3.5deg);
        }
        40% {
            -webkit-transform: translate(2.4px, 2px) rotate(2.5deg);
        }
        42% {
            -webkit-transform: translate(2.4px, -2.3px) rotate(2.5deg);
        }
        44% {
            -webkit-transform: translate(2.6px, -2.4px) rotate(-2.5deg);
        }
        46% {
            -webkit-transform: translate(2.1px, 2.3px) rotate(2.5deg);
        }
        48% {
            -webkit-transform: translate(-2px, -2.6px) rotate(-3.5deg);
        }
        50% {
            -webkit-transform: translate(-2.6px, -2.6px) rotate(-3.5deg);
        }
        52% {
            -webkit-transform: translate(2.4px, -2.6px) rotate(-2.5deg);
        }
        54% {
            -webkit-transform: translate(-2.6px, 2px) rotate(4deg);
        }
        56% {
            -webkit-transform: translate(-2.3px, 2.6px) rotate(4deg);
        }
        58% {
            -webkit-transform: translate(2.3px, 2.6px) rotate(-2.5deg);
        }
        60% {
            -webkit-transform: translate(-2.3px, -2.6px) rotate(2.5deg);
        }
        62% {
            -webkit-transform: translate(0px, 0px) rotate(3.5deg);
        }
        64% {
            -webkit-transform: translate(2.6px, 2.6px) rotate(4deg);
        }
        66% {
            -webkit-transform: translate(-2.6px, 2.6px) rotate(-2.5deg);
        }
        68% {
            -webkit-transform: translate(0px, 2.6px) rotate(4deg);
        }
        70% {
            -webkit-transform: translate(2.6px, -2px) rotate(-3.5deg);
        }
        72% {
            -webkit-transform: translate(2.6px, -2.6px) rotate(-4deg);
        }
        74% {
            -webkit-transform: translate(-2.3px, 2.6px) rotate(2.5deg);
        }
        76% {
            -webkit-transform: translate(-2.4px, -2px) rotate(2.5deg);
        }
        78% {
            -webkit-transform: translate(2px, -2.4px) rotate(-4deg);
        }
        80% {
            -webkit-transform: translate(-2.4px, -2.6px) rotate(-4deg);
        }
        82% {
            -webkit-transform: translate(2.6px, 2.6px) rotate(2.5deg);
        }
        84% {
            -webkit-transform: translate(2.4px, -2.4px) rotate(4deg);
        }
        86% {
            -webkit-transform: translate(-2px, -2.4px) rotate(4deg);
        }
        88% {
            -webkit-transform: translate(2.4px, -2.4px) rotate(3.5deg);
        }
        90% {
            -webkit-transform: translate(2.6px, 2.6px) rotate(4deg);
        }
        92% {
            -webkit-transform: translate(2.6px, -2.6px) rotate(-4deg);
        }
        94% {
            -webkit-transform: translate(2.6px, 2.6px) rotate(4deg);
        }
        96% {
            -webkit-transform: translate(2.4px, -2.3px) rotate(4deg);
        }
        98% {
            -webkit-transform: translate(-2.3px, -2px) rotate(2.5deg);
        }
    }
    @keyframes ballAAround {
    }
    @keyframes aroundSpread {
        0% {
            opacity: 1;
            transform: scale(1);
        }
        40% {
            opacity: 1;
            transform: scale(1.5);
        }
        80% {
            opacity: 1;
            transform: scale(1.8);
        }
        100% {
            opacity: 0;
            transform: scale(2);
        }
    }
    @keyframes layerSpread {
        0% {
            opacity: 0;
        }
        40% {
            opacity: 0.6;
        }
        100% {
            opacity: 1;
        }
    }
    @keyframes prizeSpread {
        0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }
    @keyframes warnBg {
        0% {
            background: rgba(0, 0, 0, 0.27);
        }
        20% {
            background: rgba(0, 0, 0, 0.27);
        }
        30% {
            background: rgba(0, 0, 0, 0.37);
        }
        40% {
            background: rgba(0, 0, 0, 0.37);
        }
        50% {
            background: rgba(0, 0, 0, 0.47);
        }
        60% {
            background: rgba(0, 0, 0, 0.47);
        }
        70% {
            background: rgba(0, 0, 0, 0.57);
        }
        80% {
            background: rgba(250, 249, 244, 0.77);
        }
        90% {
            background: rgba(250, 249, 244, 0.87);
        }
        100% {
            background: rgba(250, 249, 244, 0.9);
        }
    }
    @keyframes warn {
        0% {
            transform: scale(1);
            -webkit-transform: scale(1);
            opacity: 0;
        }

        25% {
            transform: scale(2);
            -webkit-transform: scale(2);
            opacity: 1;
        }

        50% {
            transform: scale(3);
            -webkit-transform: scale(3);
            opacity: 1;
        }

        75% {
            transform: scale(4);
            -webkit-transform: scale(4);
            opacity: 1;
        }

        100% {
            transform: scale(5);
            -webkit-transform: scale(5);
            opacity: 1;
        }
    }
    @keyframes ballDown {
        0% {
            top: 285px;
        }

        100% {
            top: 310px;
        }
    }
    @keyframes bigBall {
        from {
            width: 40px;
            height: 40px;
            // top: 70%;
            top: 520px;
            left: 37%;
            opacity: 1;
        }
        to {
            width: 171px;
            height: 172px;
            // top: 50%;
            top: 331px;
            left: 50%;
            opacity: 1;
        }
    }
    @keyframes bigBallHide {
        0% {
            opacity: 1;
        }
        10% {
            opacity: 1;
        }
        20% {
            opacity: 1;
        }
        30% {
            opacity: 1;
        }
        40% {
            opacity: 1;
        }
        50% {
            opacity: 0, 8;
        }
        60% {
            opacity: 0.6;
        }
        80% {
            opacity: 0.4;
        }
        100% {
            opacity: 0.4;
        }
    }
    .record {
        width: 100%;
        height: 100%;
        position: absolute;
        z-index: 99;
        top: 0px;
        left: 0px;
        right: 0px;
        background: rgba(0, 0, 0, 0.77);
    }
    .record_con {
        padding-top: 120px;
        margin-left: 27px;
        margin-right: 27px;
    }
    .record_title {
        margin-left: 16px;
        margin-right: 16px;
        height: 34px;
        text-align: center;
        position: relative;
        image {
            width: 100%;
            height: 34px;
        }
    }
    .record_text {
        font-size: 20px;
        color: #ffffff;
        font-weight: 400;
        position: absolute;
        z-index: 99;
        top: 3px;
        left: 0px;
        display: inline-block;
        width: 100%;
    }
    .record_list {
        height: 345px;
        background: linear-gradient(224deg, rgba(222, 188, 100, 1) 0%, rgba(213, 165, 74, 1) 100%, rgba(248, 216, 136, 1) 100%, rgba(248, 216, 136, 1) 100%);
        border-radius: 8px;
        padding: 16px;
        margin-top: 20px;
        padding-bottom: 0px;
    }
    .record_list_con {
        background: #ffffff;
        //height: 328px;
        ul li {
            border-bottom: solid 1px #e6e6e6;
            margin-left: 19px;
            margin-right: 19px;
        }
        .record_p1,
        .record_p2 {
            font-size: 15px;
            font-weight: 400;
            color: rgba(102, 102, 102, 1);
            line-height: 21px;
            padding-bottom: 5px;
        }
        .record_p1 {
            padding-top: 15px;
        }
        .record_p2 {
            padding-bottom: 16px;
        }
        .record_span1 {
            font-size: 16px;
            font-weight: 400;
            color: #666666;
        }
    }
    .record_close {
        width: 38px;
        height: 38px;
        position: absolute;
        z-index: 99;
        top: 55px;
        right: 33px;
        // padding-top: 43px;
        // margin: 0 auto;
        image {
            width: 100%;
            height: 100%;
        }
    }
    .noRecord {
        text-align: center;
        image {
            width: 150px;
            height: 150px;
            padding-top: 48px;
            margin: 0 auto;
        }
        p {
            font-size: 15px;
            color: #999999;
            font-weight: 400;
            padding-top: 30px;
        }
    }

    @keyframes around1 {
        0% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        5% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        10% {
            transform: translate(-100rpx, -100rpx);
            -webkit-transform: translate(-100rpx, -100rpx);
        }
        15% {
            transform: translate(-80rpx, -280rpx);
            -webkit-transform: translate(-80rpx, -280rpx);
        }
        20% {
            transform: translate(50rpx, -160rpx);
            -webkit-transform: translate(50rpx, -160rpx);
        }
        25% {
            transform: translate(180rpx, -160rpx);
            -webkit-transform: translate(180rpx, -160rpx);
        }
        30% {
            transform: translate(180rpx, -160rpx);
            -webkit-transform: translate(180rpx, -160rpx);
        }
        35% {
            transform: translate(-0rpx, 0rpx);
            -webkit-transform: translate(-0rpx, 0rpx);
        }
        40% {
            transform: translate(40rpx, -280rpx);
            -webkit-transform: translate(40rpx, -280rpx);
        }
        45% {
            transform: translate(40rpx, -260rpx);
            -webkit-transform: translate(40rpx, -260rpx);
        }
        50% {
            transform: translate(40rpx, -260rpx);
            -webkit-transform: translate(40rpx, -260rpx);
        }
        55% {
            transform: translate(180rpx, -130rpx);
            -webkit-transform: translate(180rpx, -130rpx);
        }
        60% {
            transform: translate(180rpx, -60rpx);
            -webkit-transform: translate(180rpx, -60rpx);
        }
        65% {
            transform: translate(150rpx, 0rpx);
            -webkit-transform: translate(150rpx, 0rpx);
        }
        70% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        75% {
            transform: translate(0rpx, -50rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        80% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        85% {
            transform: translate(0rpx, -30rpx);
            -webkit-transform: translate(0rpx, -30rpx);
        }
        90% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        95% {
            transform: translate(0rpx, -10rpx);
            -webkit-transform: translate(0rpx, -10rpx);
        }
        100% {
            transform: translate(0, 0);
            -webkit-transform: translate(0, 0);
        }
    }

    @keyframes around2 {
        0% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        5% {
            transform: translate(90rpx, -50rpx);
            -webkit-transform: translate(90rpx, -50rpx);
        }
        10% {
            transform: translate(110rpx, -100rpx);
            -webkit-transform: translate(110rpx, -100rpx);
        }
        15% {
            transform: translate(50rpx, -250rpx);
            -webkit-transform: translate(50rpx, -250rpx);
        }
        20% {
            transform: translate(-100rpx, -300rpx);
            -webkit-transform: translate(-100rpx, -300rpx);
        }
        25% {
            transform: translate(-150rpx, -300rpx);
            -webkit-transform: translate(-150rpx, -300rpx);
        }
        30% {
            transform: translate(-200rpx, -200rpx);
            -webkit-transform: translate(-200rpx, -200rpx);
        }
        35% {
            transform: translate(-250rpx, -200rpx);
            -webkit-transform: translate(-250rpx, -200rpx);
        }
        40% {
            transform: translate(-250rpx, -100rpx);
            -webkit-transform: translate(-250rpx, -100rpx);
        }
        45% {
            transform: translate(-200rpx, -10rpx);
            -webkit-transform: translate(-200rpx, -10rpx);
        }
        50% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        55% {
            transform: translate(-150rpx, -150rpx);
            -webkit-transform: translate(-150rpx, -150rpx);
        }
        60% {
            transform: translate(-200rpx, -260rpx);
            -webkit-transform: translate(-200rpx, -260rpx);
        }
        65% {
            transform: translate(-180rpx, -260rpx);
            -webkit-transform: translate(-180rpx, -260rpx);
        }
        70% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        75% {
            transform: translate(0rpx, -50rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        80% {
            transform: translate(0rpx, -30rpx);
            -webkit-transform: translate(0rpx, -30rpx);
        }
        85% {
            transform: translate(0rpx, -20rpx);
            -webkit-transform: translate(0rpx, -20rpx);
        }
        90% {
            transform: translate(0rpx, -10rpx);
            -webkit-transform: translate(0rpx, -10rpx);
        }
        100% {
            transform: translate(0, 0);
            -webkit-transform: translate(0, 0);
        }
    }

    @keyframes around3 {
        0% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        5% {
            transform: translate(300rpx, 10rpx);
            -webkit-transform: translate(300rpx, 10rpx);
        }
        10% {
            transform: translate(330rpx, -100rpx);
            -webkit-transform: translate(330rpx, -100rpx);
        }
        15% {
            transform: translate(310rpx, -200rpx);
            -webkit-transform: translate(310rpx, -200rpx);
        }
        20% {
            transform: translate(10rpx, -200rpx);
            -webkit-transform: translate(10rpx, -200rpx);
        }
        25% {
            transform: translate(150rpx, -280rpx);
            -webkit-transform: translate(150rpx, -280rpx);
        }
        30% {
            transform: translate(50rpx, -180rpx);
            -webkit-transform: translate(50rpx, -180rpx);
        }
        35% {
            transform: translate(50rpx, -10rpx);
            -webkit-transform: translate(50rpx, -10rpx);
        }
        40% {
            transform: translate(280rpx, -10rpx);
            -webkit-transform: translate(280rpx, -10rpx);
        }
        45% {
            transform: translate(280rpx, -230rpx);
            -webkit-transform: translate(280rpx, -230rpx);
        }
        50% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        55% {
            transform: translate(100rpx, 100rpx);
            -webkit-transform: translate(100rpx, 100rpx);
        }
        60% {
            transform: translate(50rpx, -240rpx);
            -webkit-transform: translate(50rpx, -240rpx);
        }
        65% {
            transform: translate(150rpx, -150rpx);
            -webkit-transform: translate(150rpx, -150rpx);
        }
        70% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        75% {
            transform: translate(0rpx, -50rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        80% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        85% {
            transform: translate(0rpx, -30rpx);
            -webkit-transform: translate(0rpx, -30rpx);
        }
        90% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        95% {
            transform: translate(0rpx, -10rpx);
            -webkit-transform: translate(0rpx, -10rpx);
        }
        100% {
            transform: translate(0, 0);
            -webkit-transform: translate(0, 0);
        }
    }

    @keyframes around4 {
        0% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        5% {
            transform: translate(-320rpx, -10rpx);
            -webkit-transform: translate(-320rpx, -10rpx);
        }
        10% {
            transform: translate(-320rpx, -80rpx);
            -webkit-transform: translate(-320rpx, -80rpx);
        }
        15% {
            transform: translate(-320rpx, -200rpx);
            -webkit-transform: translate(-320rpx, -200rpx);
        }
        20% {
            transform: translate(-250rpx, -250rpx);
            -webkit-transform: translate(-250rpx, -250rpx);
        }
        25% {
            transform: translate(-150rpx, -250rpx);
            -webkit-transform: translate(-150rpx, -250rpx);
        }
        30% {
            transform: translate(-150rpx, -150rpx);
            -webkit-transform: translate(-150rpx, -150rpx);
        }
        35% {
            transform: translate(10rpx, -100rpx);
            -webkit-transform: translate(10rpx, -100rpx);
        }
        40% {
            transform: translate(-30rpx, 50rpx);
            -webkit-transform: translate(-30rpx, 50rpx);
        }
        45% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        50% {
            transform: translate(0rpx, -100rpx);
            -webkit-transform: translate(0rpx, -100rpx);
        }
        55% {
            transform: translate(-100rpx, -180rpx);
            -webkit-transform: translate(-100rpx, -180rpx);
        }
        60% {
            transform: translate(-30rpx, -240rpx);
            -webkit-transform: translate(-30rpx, -240rpx);
        }
        65% {
            transform: translate(-180rpx, -20rpx);
            -webkit-transform: translate(-180rpx, -20rpx);
        }
        70% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        75% {
            transform: translate(0rpx, -50rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        80% {
            transform: translate(0rpx, -40rpx);
            -webkit-transform: translate(0rpx, -40rpx);
        }
        85% {
            transform: translate(0rpx, -30rpx);
            -webkit-transform: translate(0rpx, -30rpx);
        }
        90% {
            transform: translate(0rpx, -20rpx);
            -webkit-transform: translate(0rpx, -20rpx);
        }
        90% {
            transform: translate(0rpx, -10rpx);
            -webkit-transform: translate(0rpx, -10rpx);
        }
        100% {
            transform: translate(0, 0);
            -webkit-transform: translate(0, 0);
        }
    }

    @keyframes around5 {
        0% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        5% {
            transform: translate(-100rpx, 100rpx);
            -webkit-transform: translate(-100rpx, 100rpx);
        }
        10% {
            transform: translate(-100rpx, 70rpx);
            -webkit-transform: translate(-100rpx, 70rpx);
        }
        15% {
            transform: translate(10rpx, -70rpx);
            -webkit-transform: translate(10rpx, -70rpx);
        }
        20% {
            transform: translate(100rpx, 70rpx);
            -webkit-transform: translate(100rpx, 70rpx);
        }
        25% {
            transform: translate(-100rpx, -170rpx);
            -webkit-transform: translate(-100rpx, -170rpx);
        }
        30% {
            transform: translate(-150rpx, -30rpx);
            -webkit-transform: translate(-150rpx, -30rpx);
        }
        35% {
            transform: translate(-180rpx, 30rpx);
            -webkit-transform: translate(-180rpx, 30rpx);
        }
        40% {
            transform: translate(-200rpx, -110rpx);
            -webkit-transform: translate(-200rpx, -110rpx);
        }
        45% {
            transform: translate(-200rpx, 80rpx);
            -webkit-transform: translate(-200rpx, 80rpx);
        }
        50% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        55% {
            transform: translate(-80rpx, 0rpx);
            -webkit-transform: translate(-80rpx, 0rpx);
        }
        60% {
            transform: translate(-110rpx, -180rpx);
            -webkit-transform: translate(-110rpx, -180rpx);
        }
        65% {
            transform: translate(-110rpx, 30rpx);
            -webkit-transform: translate(-110rpx, 30rpx);
        }
        70% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        75% {
            transform: translate(0rpx, -50rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        80% {
            transform: translate(0rpx, -30rpx);
            -webkit-transform: translate(0rpx, -30rpx);
        }
        85% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        95% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, -30rpx);
        }
        95% {
            transform: translate(0rpx, -10rpx);
            -webkit-transform: translate(0rpx, -10rpx);
        }
        100% {
            transform: translate(0, 0);
            -webkit-transform: translate(0, 0);
        }
    }

    @keyframes around6 {
        0% {
            transform: translate(0, 0);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        5% {
            transform: translate(100rpx, 100rpx);
            -webkit-transform: translate(100rpx, 100rpx);
        }
        10% {
            transform: translate(180rpx, 10rpx);
            -webkit-transform: translate(180rpx, 10rpx);
        }
        15% {
            transform: translate(250rpx, -80rpx);
            -webkit-transform: translate(250rpx, -80rpx);
        }
        20% {
            transform: translate(200rpx, -150rpx);
            -webkit-transform: translate(200rpx, -150rpx);
        }
        25% {
            transform: translate(100rpx, -150rpx);
            -webkit-transform: translate(100rpx, -150rpx);
        }
        30% {
            transform: translate(10rpx, -180rpx);
            -webkit-transform: translate(10rpx, -180rpx);
        }
        35% {
            transform: translate(-100rpx, -100rpx);
            -webkit-transform: translate(-100rpx, -100rpx);
        }
        40% {
            transform: translate(-100rpx, -10rpx);
            -webkit-transform: translate(-100rpx, -10rpx);
        }
        45% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        50% {
            transform: translate(-70rpx, 100rpx);
            -webkit-transform: translate(-70rpx, 100rpx);
        }
        55% {
            transform: translate(250rpx, -100rpx);
            -webkit-transform: translate(250rpx, -100rpx);
        }
        60% {
            transform: translate(230rpx, -130rpx);
            -webkit-transform: translate(230rpx, -130rpx);
        }
        65% {
            transform: translate(230rpx, 50rpx);
            -webkit-transform: translate(230rpx, 50rpx);
        }
        70% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        75% {
            transform: translate(0rpx, -50rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        80% {
            transform: translate(0rpx, -40rpx);
            -webkit-transform: translate(0rpx, -40rpx);
        }
        85% {
            transform: translate(0rpx, -30rpx);
            -webkit-transform: translate(0rpx, -30rpx);
        }
        90% {
            transform: translate(0rpx, -20rpx);
            -webkit-transform: translate(0rpx, -20rpx);
        }
        95% {
            transform: translate(0rpx, -10rpx);
            -webkit-transform: translate(0rpx, -10rpx);
        }
        100% {
            transform: translate(0, 0);
            -webkit-transform: translate(0, 0);
        }
    }

    @keyframes around7 {
        0% {
            transform: translate(0, 0);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        5% {
            transform: translate(0rpx, 100rpx);
            -webkit-transform: translate(0rpx, 100rpx);
        }
        10% {
            transform: translate(100rpx, 150rpx);
            -webkit-transform: translate(100rpx, 150rpx);
        }
        15% {
            transform: translate(280rpx, 140rpx);
            -webkit-transform: translate(280rpx, 140rpx);
        }
        20% {
            transform: translate(320rpx, 100rpx);
            -webkit-transform: translate(320rpx, 100rpx);
        }
        25% {
            transform: translate(320rpx, 10rpx);
            -webkit-transform: translate(320rpx, 10rpx);
        }
        30% {
            transform: translate(250rpx, -150rpx);
            -webkit-transform: translate(250rpx, -150rpx);
        }
        35% {
            transform: translate(150rpx, -120rpx);
            -webkit-transform: translate(150rpx, -120rpx);
        }
        40% {
            transform: translate(50rpx, -40rpx);
            -webkit-transform: translate(50rpx, -40rpx);
        }
        45% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        50% {
            transform: translate(150rpx, 100rpx);
            -webkit-transform: translate(150rpx, 100rpx);
        }
        55% {transform: translate(300rpx, -100rpx);
            -webkit-transform: translate(300rpx, -100rpx);
        }
        60% {
            transform: translate(200rpx, -50rpx);
            -webkit-transform: translate(200rpx, -50rpx);
        }
        65% {
            transform: translate(200rpx, -10rpx);
            -webkit-transform: translate(200rpx, -10rpx);
        }
        70% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        75% {
            transform: translate(0rpx, -50rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        80% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        85% {
            transform: translate(-30rpx, -30rpx);
            -webkit-transform: translate(-30rpx, -30rpx);
        }
        90% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        95% {
            transform: translate(0rpx, -10rpx);
            -webkit-transform: translate(0rpx, -10rpx);
        }
        100% {
            transform: translate(0, 0);
            -webkit-transform: translate(0, 0);
        }
    }
    @keyframes around8 {
        0% {
            transform: translate(0, 0);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        5% {
            transform: translate(180rpx, 100rpx);
            -webkit-transform: translate(180rpx, 100rpx);
        }
        10% {
            transform: translate(-100rpx, 180rpx);
            -webkit-transform: translate(-100rpx, 180rpx);
        }
        15% {
            transform: translate(-10rpx, 220rpx);
            -webkit-transform: translate(-10rpx, 220rpx);
        }
        20% {
            transform: translate(100rpx, 120rpx);
            -webkit-transform: translate(100rpx, 120rpx);
        }
        25% {
            transform: translate(180rpx, 60rpx);
            -webkit-transform: translate(180rpx, 60rpx);
        }
        30% {
            transform: translate(80rpx, -100rpx);
            -webkit-transform: translate(80rpx, -100rpx);
        }
        35% {
            transform: translate(-30rpx, -100rpx);
            -webkit-transform: translate(-30rpx, -100rpx);
        }
        40% {
            transform: translate(-100rpx, -60rpx);
            -webkit-transform: translate(-100rpx, -60rpx);
        }
        45% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        50% {
            transform: translate(0rpx, 100rpx);
            -webkit-transform: translate(0rpx, 100rpx);
        }
        55% {
            transform: translate(-100rpx, 150rpx);
            -webkit-transform: translate(-100rpx, 150rpx);
        }
        60% {
            transform: translate(-100rpx, 200rpx);
            -webkit-transform: translate(-100rpx, 200rpx);
        }
        65% {
            transform: translate(80rpx, 200rpx);
            -webkit-transform: translate(80rpx, 200rpx);
        }
        70% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        75% {
            transform: translate(0rpx, -50rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        80% {
            transform: translate(0rpx, -40rpx);
            -webkit-transform: translate(0rpx, -40rpx);
        }
        85% {
            transform: translate(0rpx, -30rpx);
            -webkit-transform: translate(0rpx, -30rpx);
        }
        90% {
            transform: translate(0rpx, -20rpx);
            -webkit-transform: translate(0rpx, -20rpx);
        }
        95% {
            transform: translate(0rpx, -10rpx);
            -webkit-transform: translate(0rpx, -10rpx);
        }
        100% {
            transform: translate(0, 0);
            -webkit-transform: translate(0, 0);
        }
    }
    @keyframes around9 {
        0% {
            transform: translate(0, 0);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        5% {
            transform: translate(50rpx, 50rpx);
            -webkit-transform: translate(50rpx, 50rpx);
        }
        10% {
            transform: translate(-50rpx, 50rpx);
            -webkit-transform: translate(-50rpx, 50rpx);
        }
        15% {
            transform: translate(-50rpx, 200rpx);
            -webkit-transform: translate(-50rpx, 200rpx);
        }
        20% {
            transform: translate(-150rpx, -50rpx);
            -webkit-transform: translate(-150rpx, -50rpx);
        }
        25% {
            transform: translate(-300rpx, -50rpx);
            -webkit-transform: translate(-300rpx, -50rpx);
        }
        30% {
            transform: translate(-200rpx, 150rpx);
            -webkit-transform: translate(-200rpx, 150rpx);
        }
        35% {
            transform: translate(-150rpx, 100rpx);
            -webkit-transform: translate(-150rpx, 100rpx);
        }
        40% {
            transform: translate(-150rpx, -80rpx);
            -webkit-transform: translate(-150rpx, -80rpx);
        }
        45% {
            transform: translate(-70rpx, -80rpx);
            -webkit-transform: translate(-70rpx, -80rpx);
        }
        50% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        55% {
            transform: translate(0rpx, 100rpx);
            -webkit-transform: translate(0rpx, 100rpx);
        }
        60% {
            transform: translate(-110rpx, 120rpx);
            -webkit-transform: translate(-110rpx, 120rpx);
        }
        65% {
            transform: translate(70rpx, 80rpx);
            -webkit-transform: translate(70rpx, 80rpx);
        }
        70% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        75% {
            transform: translate(0rpx, -50rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        80% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        85% {
            transform: translate(0rpx, -30rpx);
            -webkit-transform: translate(0rpx, -30rpx);
        }
        90% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        95% {
            transform: translate(0rpx, -10rpx);
            -webkit-transform: translate(0rpx, -10rpx);
        }
        100% {
            transform: translate(0, 0);
            -webkit-transform: translate(0, 0);
        }
    }
    @keyframes around10 {
        0% {
            transform: translate(0, 0);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        5% {
            transform: translate(-50rpx, 100rpx);
            -webkit-transform: translate(-50rpx, 100rpx);
        }
        10% {
            transform: translate(-200rpx, 120rpx);
            -webkit-transform: translate(-200rpx, 120rpx);
        }
        15% {
            transform: translate(-200rpx, 10rpx);
            -webkit-transform: translate(-200rpx, 10rpx);
        }
        20% {
            transform: translate(-300rpx, 120rpx);
            -webkit-transform: translate(-300rpx, 120rpx);
        }
        25% {
            transform: translate(-350rpx, -120rpx);
            -webkit-transform: translate(-350rpx, -120rpx);
        }
        30% {
            transform: translate(-200rpx, -180rpx);
            -webkit-transform: translate(-200rpx, -180rpx);
        }
        35% {
            transform: translate(-200rpx, -80rpx);
            -webkit-transform: translate(-200rpx, -80rpx);
        }
        40% {
            transform: translate(-150rpx, 100rpx);
            -webkit-transform: translate(-150rpx, 100rpx);
        }
        45% {
            transform: translate(-10rpx, -100rpx);
            -webkit-transform: translate(-10rpx, -100rpx);
        }
        50% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        55% {
            transform: translate(-100rpx, 70rpx);
            -webkit-transform: translate(-100rpx, 70rpx);
        }
        60% {
            transform: translate(-100rpx, 150rpx);
            -webkit-transform: translate(-100rpx, 150rpx);
        }
        65% {
            transform: translate(-100rpx, -150rpx);
            -webkit-transform: translate(-100rpx, -150rpx);
        }
        70% {
            transform: translate(0rpx, 0rpx);
            -webkit-transform: translate(0rpx, 0rpx);
        }
        75% {
            transform: translate(0rpx, -50rpx);
            -webkit-transform: translate(0rpx, -50rpx);
        }
        80% {
            transform: translate(0rpx, -40rpx);
            -webkit-transform: translate(0rpx, -40rpx);
        }
        85% {
            transform: translate(0rpx, -30rpx);
            -webkit-transform: translate(0rpx, -30rpx);
        }
        90% {
            transform: translate(0rpx, -20rpx);
            -webkit-transform: translate(0rpx, -20rpx);
        }
        95% {
            transform: translate(0rpx, -10rpx);
            -webkit-transform: translate(0rpx, -10rpx);
        }
        100% {
            transform: translate(0, 0);
            -webkit-transform: translate(0, 0);
        }
    }
}
</style>
