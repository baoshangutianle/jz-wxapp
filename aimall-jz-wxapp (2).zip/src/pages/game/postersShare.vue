<template>
    <div>
        <painter :customStyle="customStyle" @imgOK="onImgOk" :palette="template" :dirty="false"/>
        <button style="margin-top:40rpx" @click="save">保存</button>
    </div>
</template>

<script>
import Card from './card'
const card = new Card()
const userInfo = {
  avatar: 'https://qhyxpicoss.kujiale.com/r/2017/12/04/L3D123I45VHNYULVSAEYCV3P3X6888_3200x2400.jpg@!70q'
}
const template = card._template()
const customStyle = 'margin-left:40rpx'
export default {
  data () {
    return {
      shareImg: '',
      customStyle: customStyle,
      template: template,
      beShow:false
    }
  },
  methods: {
    save () {
      console.log(this.shareImg)
      console.log('on save click')
               wx.saveImageToPhotosAlbum({
                    filePath: this.shareImg,
                    success: result => {
                        wx.showToast({
                            title: '海报已保存，快去分享给好友吧。',
                            icon: 'none'
                        })
                    },
                    fail: () => {
                        wx.showToast({
                            title: '保存失败',
                            icon: 'fail',
                            duration: 1500
                        })
                    }
                })
        // this.beShow=true
    },
    onImgOk (e) {
        console.log(e)
      this.shareImg = e.mp.detail.path
    }
  }
}
</script>