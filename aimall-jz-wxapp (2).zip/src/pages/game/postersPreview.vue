<template>
    <div class="postersPreview">
        <div class="gashaponTop">
            <div class="gashapon_icon">
                <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/57c8a32b5ae041e3883609c10f2353f8.png"/>
            </div>
        </div>
        <div class="gashaponTopBg">
            <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191204/b67e586538a44c47b9862483c8db7444.png"/>
        </div>
        <div class="gash_prize">
            <div class="gash_prize_con">
                <div class="gash_prize_top">
                    <p class="gash_prize_title">我获得了</p>
                    <image class="gash_top_img" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191203/31d5aa6171de4fe2a056c09f2361182a.png"/>

                    <div class="gash_prize_goods">
                        <image class="gash_prize_img" v-if="prizeId !=''" :src="prizeUrl"/>
                        <image v-if="prizeId ==''" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png"/>
                    </div>
                    <div class="gash_prize_name">
                        <p class="prize_name" v-if="prizeId !=''">{{prizeName }}</p>
                        <p class="prize_name" v-else>送你一颗小心心</p>
                    </div>
                </div>
            </div>
            <div class="prize_list">
                <div class="prize_list_top">
                    <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191203/5331071b559a4ec1ab28012c778b8302.png"/>
                    <span class="prize_list_span">丰富好礼等你来拿</span>
                </div>
                <div class="prize_list_con">
                    <ul>
                        <li v-for="(item,index) in prizeVos" :key="index">
                            <div class="prize_list_div">
                                <div class="prize_list_img">
                                    <image v-if="item.couponImageUrl !=''" :src=item.couponImageUrl />
                                    <image v-else src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png" />
                                </div>
                                <p class="prize_list_text">{{item.prizeName}}</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="gash_layer_bottom">
                    <image class="layer_bottom_bg" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191126/e2a7d4f3e3434850b8dbd3fedec6ad0e.png"/>
                    <span class="layer_go" @click="go">我也去试试</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import api from '../../plugins/api'
import request from '../../plugins/request'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
export default {
    data() {
        return {
            prizeName: '',
            activityId: '',
            prizeUrl: '',
            prizeId:'',
            prizeVos: [],
            pageStayTime: 0,
            p_action: '扭蛋游戏'
        }
    },
    onShow(){
        this.activityId = this.$root.$mp.query.activityId
        this.prizeId = this.$root.$mp.query.prizeId ? this.$root.$mp.query.prizeId :''
        this.pageStayTime = new Date().getTime()
        this.getActivityDetail()
    },
    onUnload(){
         this.pageStayTime = new Date().getTime() - this.pageStayTime
         buryPoint.setZ({
            id: pointCode.GASHAPON_SHARE_Index_Z,
            p_stay_time: this.stayTime,
            p_id: this.activityId
        })
    },
    methods: {
        // 根据活动id查详情
        getActivityDetail() {
            let requestOptions = {
                path: api.getActivityDetail + this.activityId
            }
            request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    let data = res.data || []
                    this.prizeVos = data.prizeVos ? data.prizeVos.slice(0,4) :[]
                    for(let i = 0 ;i<data.prizeVos.length;i++){
                        if(data.prizeVos[i].id == this.prizeId){
                            this.prizeName = data.prizeVos[i].prizeName,
                            this.prizeUrl = data.prizeVos[i].couponImageUrl !='' ? data.prizeVos[i].couponImageUrl :'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png'
                        }
                    }
                }
            })
        },
        go(){
            buryPoint.setF({
                id: pointCode.GASHAPON_Index_Finish_F,
                p_action_id: pointCode.GASHAPON_Index_Finish_F,
                p_action: this.p_action,
                p_id: this.activityId
            })
            // wx.navigateTo({
            //     url: `/pages/game/gashapon?activityId=${this.activityId}`
            // })
        }
    }
}
</script>
<style lang="less" scope>
.postersPreview {
     background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191202/40992b5a0ee6490bbcbb4c4fb8ce20df.png') no-repeat;
    background-size: 100% 100%;
    width: 100%;
    height: 100%;
    position: relative;
    .gashaponTop {
        height: 60px;
    }
    .gashaponTopBg {
        position: relative;

        padding: 0 5px 0px 20px;
        image {
            width: 100%;
            height: 160px;
            margin-top: -15px;
        }
    }
    .gashapon_icon {
        width: 95px;
        height: 41px;
        padding-top: 18px;
        padding-left: 18px;
        float: left;
        img {
            width: 95px;
            height: 41px;
        }
    }
    .gash_prize,.gash_prize_con{
        position: relative;
        margin-top: -20px;
    }
    .gash_prize_top {
        width: 307px;
        height: 345px;
        position: relative;
        margin: 0 auto;
        text-align: center;
    }
    .gash_top_img{
        width: 307px;
        height: 345px;
    }
    .gash_prize_title {
        width: 129px;
        height: 27px;
        position: absolute;
        z-index: 99;
        top: 5px;
        color: #ffffff;
        font-size: 15px;
        font-weight: 400;
        width: 100%;
    }
    .gash_prize_goods {
        width: 100%;
        height: 142px;
        position: absolute;
        z-index: 99;
        top: 40px;
        image {
            width: 150px;
            height: 142px;
        }
    }
    .gash_prize_name {
        width: 100%;
        position: absolute;
        z-index: 99;
        bottom: 25px;
        text-align: center;
    }
    .prize_name {
        color: #ffffff;
        font-size: 24px;
        font-weight: 600;
    }
    .prize_name2 {
        color: #ffffff;
        font-size: 15px;
        font-weight: 400;
        padding-top: 16px;
    }
    .prize_span {
        font-size: 16px;
        font-weight: 500;
        text-decoration: underline;
        padding-left: 5px;
        padding-right: 5px;
    }
    .gash_prize_img {
        width: 100%;
        height: 100%;
    }
    .prize_list{
        padding: 10px 15px 15px 15px;
        position: relative;
    }
    .prize_list_top{
        position: relative;
    }
    .prize_list_top image{
        width: 100%;
        height: 2px;
    }
    .prize_list_span{
        display: inline-block;
        position: absolute;
        z-index: 99;
        font-size: 18px;
        color: #DD933A;
        width: 100%;
        text-align: center;
        top: 3px;
        left: 0px;

    }
    .prize_list_con{
        position: relative;
        ul{
            padding-top: 20px;
        }
        ul li{
            display: inline-block;
            margin-right: 8px;
        }
        ul li:last-child{
            margin-right: 0px;
        }
    }
    .prize_list_div{
        width: 80px;
        height: 108px;
        background:linear-gradient(224deg,rgba(222,188,100,1) 0%,rgba(213,165,74,1) 100%,rgba(248,216,136,1) 100%,rgba(248,216,136,1) 100%);
        border-radius:4px;
        padding-top: 4px;

    }
    .prize_list_img{
        width:72px;
        height:72px;
        background:rgba(255,255,255,1);
        border-radius:2px;
        margin: 0 auto;
        text-align: center;

        image{
            width:66px;
            height:63px;
            padding-top: 4px;
        }
    }
    .prize_list_text{
        color: #ffffff;
        font-size: 12px;
        font-weight: 400;
        width: 100%;
        text-align: center;
        padding-top: 8px;
    }
    .gash_layer_bottom{
        margin: 0 auto;
        position: relative;
        padding-top: 30px;
        text-align: center;
        width: 190px;
        height: 48px;
    }
    .layer_bottom_bg {
        width: 190px;
        height: 48px;
    }
    .layer_go {
        font-size: 20px;
        color: #ffffff;
        font-weight: 500;
        position: absolute;
        top: 40px;
        left: 0px;
        z-index: 99;
        width: 100%;
    }
    .layer_interg_text {
        font-size: 18px;
        color: #ffffff;
    }
}
</style>
