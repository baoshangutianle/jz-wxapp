<template>
    <div class="postersPreview">
        <div class="gashaponTop">
            <div class="gashapon_icon">
                <img
                    src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191218/38143a49d94f4b71a5c13fc603b7b67f.png"
                />
            </div>
        </div>
        <div class="container" :class="bgCheck?'container_bg_1':'container_bg_2'">
            <p class="container_title">我抽中了</p>
            <p class="container_prize">{{prizeName}}</p>
            <image class="gash_prize_img" v-if="prizeId !=''" :src="prizeUrl" />
            <image
                v-if="prizeId ==''"
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png"
            />
        </div>
        <div class="gash_prize">
            <div class="prize_list">
                <div class="prize_list_top">
                    <image
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/3cddbc5d0cb945dfb2b19ce33f3ef1fa.png"
                    />
                    <span class="prize_list_span">丰富好礼等你来拿</span>
                </div>
                <div class="prize_list_con">
                    <ul>
                        <li v-for="(item,index) in prizeVos" :key="index">
                            <div class="prize_list_div">
                                <div class="prize_list_img">
                                    <image
                                        v-if="item.couponImageUrl !=''"
                                        :src="item.couponImageUrl"
                                    />
                                    <image
                                        v-else
                                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png"
                                    />
                                </div>
                                <p class="prize_list_text">{{item.prizeName}}</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="gash_layer_bottom">
                    <image
                        class="layer_bottom_bg"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191219/db0269aa563e446ba85f006166df3660.png"
                    />
                    <span class="layer_go" @click="go">我也去试试</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import api from '../../plugins/api'
import request from '../../plugins/request'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
export default {
    data() {
        return {
            prizeName: '',
            activityId: '',
            prizeUrl: '',
            prizeId: '',
            prizeVos: [],
            pageStayTime: 0,
            p_action: '扭蛋游戏',
            bgCheck: false,
            setIntervalBgStatus: null
        }
    },
    onShow() {
        this.activityId = this.$root.$mp.query.activityId
        this.prizeId = this.$root.$mp.query.prizeId ? this.$root.$mp.query.prizeId : ''
        this.pageStayTime = new Date().getTime()
        this.getActivityDetail()
        let t = this
        t.setIntervalBgStatus = setInterval(() => {
            t.bgCheck = !t.bgCheck
        }, 1000)
    },
    onUnload() {
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.GASHAPON_SHARE_Index_Z,
            p_stay_time: this.stayTime,
            p_id: this.activityId
        })
    },
    methods: {
        // 根据活动id查详情
        getActivityDetail() {
            let requestOptions = {
                path: api.getActivityDetail + this.activityId
            }
            request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    let data = res.data || []
                    this.prizeVos = data.prizeVos ? data.prizeVos.slice(0, 4) : []
                    for (let i = 0; i < data.prizeVos.length; i++) {
                        if (data.prizeVos[i].id == this.prizeId) {
                            ;(this.prizeName = data.prizeVos[i].prizeName), (this.prizeUrl = data.prizeVos[i].couponImageUrl != '' ? data.prizeVos[i].couponImageUrl : 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191128/60a65629761442f0bc339f1af0576419.png')
                        }
                    }
                }
            })
        },
        go() {
            buryPoint.setF({
                id: pointCode.GASHAPON_Index_Finish_F,
                p_action_id: pointCode.GASHAPON_Index_Finish_F,
                p_action: this.p_action,
                p_id: this.activityId
            })
            wx.navigateTo({
                url: `/pages/game/machineList?activityId=${this.activityId}`
            })
        }
    }
}
</script>
<style lang="less" scope>
.postersPreview {
    background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/e01889c015ba4d8986918d62f0d21464.png') center center no-repeat;
    background-size: cover;
    width: 100%;
    // height: 100%;
    position: relative;
    .container_bg_1 {
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/5cbeefc3318c43d8971d30097477bc35.png') center center no-repeat;
        background-size: cover;
    }
    .container_bg_2 {
        background: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191220/4d0a110a6e814f6c892827854ff1d193.png') center center no-repeat;
        background-size: cover;
    }
    .container {
        width: 90%;
        margin: 40px auto 20px;
        height: 400px;
        text-align: center;
        .container_title {
            text-align: center;
            color: #fff;
            font-size: 15px;
            padding-top: 44px;
            padding-bottom: 3px;
        }
        .container_prize {
            text-align: center;
            color: #fff;
            font-size: 25px;
        }
        image{
            width: 150px;
            height: 150px;
            margin: 75px auto 0;
        }
    }
    // position: absolute;
    // z-index: 1;
    // top: 0px;
    // bottom: 0px;
    // left: 0px;
    // right: 0px;
    .gashaponTop {
        height: 60px;
    }
    .gashaponTopBg {
        position: relative;

        padding: 0 5px 0px 20px;
        image {
            width: 100%;
            height: 160px;
            margin-top: -15px;
        }
    }
    .gashapon_icon {
        width: 95px;
        height: 41px;
        padding-top: 18px;
        padding-left: 18px;
        float: left;
        img {
            width: 95px;
            height: 41px;
        }
    }
    .gash_prize,
    .gash_prize_con {
        position: relative;
        margin-top: -20px;
    }
    .gash_prize_top {
        width: 307px;
        height: 345px;
        position: relative;
        margin: 0 auto;
        text-align: center;
    }
    .gash_top_img {
        width: 307px;
        height: 345px;
    }
    .gash_prize_title {
        width: 129px;
        height: 27px;
        position: absolute;
        z-index: 99;
        top: 5px;
        color: #ffffff;
        font-size: 15px;
        font-weight: 400;
        width: 100%;
    }
    .gash_prize_goods {
        width: 100%;
        height: 142px;
        position: absolute;
        z-index: 99;
        top: 40px;
        image {
            width: 150px;
            height: 142px;
        }
    }
    .gash_prize_name {
        width: 100%;
        position: absolute;
        z-index: 99;
        bottom: 25px;
        text-align: center;
    }
    .prize_name {
        color: #ffffff;
        font-size: 24px;
        font-weight: 600;
    }
    .prize_name2 {
        color: #ffffff;
        font-size: 15px;
        font-weight: 400;
        padding-top: 16px;
    }
    .prize_span {
        font-size: 16px;
        font-weight: 500;
        text-decoration: underline;
        padding-left: 5px;
        padding-right: 5px;
    }
    .gash_prize_img {
        width: 100%;
        height: 100%;
    }
    .prize_list {
        padding: 10px 15px 15px 15px;
        position: relative;
    }
    .prize_list_top {
        position: relative;
        text-align: center;
    }
    .prize_list_top image {
        width: 255px;
        height: 12px;
        margin: 10px auto;
    }
    .prize_list_span {
        display: inline-block;
        position: absolute;
        z-index: 99;
        font-size: 18px;
        color: #dd933a;
        width: 100%;
        text-align: center;
        top: 3px;
        left: 0px;
    }
    .prize_list_con {
        position: relative;
        ul {
            width: 322px;
            margin: 0 auto;
        }
        ul li {
            display: inline-block;
        }
        ul li:last-child {
            margin-right: 0px;
        }
    }
    .prize_list_div {
        width: 80px;
        height: 108px;
        border-radius: 4px;
        padding-top: 4px;
    }
    .prize_list_img {
        width: 72px;
        height: 72px;
        background: rgba(255, 255, 255, 1);
        border-radius: 2px;
        margin: 0 auto;
        text-align: center;

        image {
            width: 50px;
            height: 50px;
            padding-top: 11px;
        }
    }
    .prize_list_text {
        color: #db7c06;
        font-size: 12px;
        font-weight: 400;
        width: 100%;
        text-align: center;
        padding-top: 8px;
    }
    .gash_layer_bottom {
        margin: 0 auto 20px;
        position: relative;
        padding-top: 7px;
        text-align: center;
        width: 190px;
        height: 48px;
    }
    .layer_bottom_bg {
        width: 157px;
        height: 54px;
    }
    .layer_go {
        font-size: 20px;
        color: #db7c06;
        font-weight: 500;
        position: absolute;
        top: 20px;
        left: 0px;
        z-index: 99;
        width: 100%;
    }
    .layer_interg_text {
        font-size: 18px;
        color: #ffffff;
    }
}
</style>
