<template name="stayTuned">
    <div class="stayTunedcontainer">
        <!-- <img
            class="stay_img"
            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/e7e5895097554a059bd358b642a6fa3d.png"
        >
        <p class="stay_text">更多精彩进行中</p> -->
        <!-- <p class="stay_tile">敬请期待</p> -->
        <span class="go_live">正在进入直播....</span>
    </div>
</template>

<script>
import api from '../../plugins/api'
export default {
    props: {
    // eslint-disable-next-line vue/require-default-prop
        url: ''
    },
    data() {
        return {
            roomId: ''
        }
    },
    onShow(){
        let t = this
        t.roomId = this.$root.$mp.query.roomId
        let customParams = { type: 9 }
        wx.redirectTo({
            url: `plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=${t.roomId}&custom_params=${encodeURIComponent(JSON.stringify(customParams))}`
        })
        // wx.request({
        //     url: api.getRoomId,
        //     method: 'get',
        //     data: null,
        //     header: {
        //         Authorization: wx.getStorageSync('sessionId')
        //     },
        //     success(res) {
        //         if (res.data.code === 200) {
        //             let customParams = { type: 9 } // 开发者在直播间页面路径上携带自定义参数，后续可以在分享卡片链接和跳转至商详页时获取，详见【获取自定义参数】、【直播间到商详页面携带参数】章节
        //             wx.redirectTo({
        //                 url: `plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=${res.data.data}&custom_params=${encodeURIComponent(JSON.stringify(customParams))}`
        //             })
        //         }
        //     }
        // })
    },
    methods: {

    }
}
</script>


<style lang="less" scoped>
@import url(../../assets/styles/vars);
.stayTunedcontainer {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    text-align: center;
    width: 100%;
    height: 100%;
    min-height: 100vh;
    background: #f5f6fa;
    text-align: center;
    .go_live{
        color: #d5d5d5;
        font-size: 15px;
        padding-top: 150px;
        display: inline-block;
    }
    .stay_img {
        display: inline-block;
        width: 175px;
        height: 174px;
        margin-top: 90px;
    }
    .stay_text {
        margin-top: 30px;
        text-align: center;
        color: #999999;
        font-size: 18px;
    }
    .stay_tile {
        text-align: center;
        font-size: 30px;
        font-weight: 500;
        color: rgba(114, 197, 193, 1);
        padding-top: 5px;
        padding-left: 20px;
    }
}
</style>
