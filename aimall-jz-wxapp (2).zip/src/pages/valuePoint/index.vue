<template>
    <div id="value-point" class="value-point">
        <img
            class="value-point-bg"
            src="https://img-cdn.aimall.cloud/as/20200601/4f17d4dfce264eae88d6882a53a2f355.png"
            mode="widthFix"
            alt="背景"
        />
        <div class="value-point-btns">
            <div>
                <form v-if="sessionId" report-submit="true" @submit="doSubmitForm">
                    <button class="btn btn-operate" formType="submit" @click="doPhoto">
                        <img
                            class="icon"
                            src="/static/images/icon-value-point-photo.png"
                            alt="拍照积分"
                        />
                        <span>拍照积分</span>
                    </button>
                </form>
                <button v-else-if="!sessionId &&isGzhLoginShow == false" class="btn btn-operate">
                    <auth-btn />
                    <img class="icon" src="/static/images/icon-value-point-photo.png" alt="拍照积分" />
                    <span>拍照积分</span>
                </button>
                <button
                    v-else-if="!sessionId &&isGzhLoginShow == true"
                    class="btn btn-operate"
                    @click="goAuth"
                >
                    <img class="icon" src="/static/images/icon-value-point-photo.png" alt="拍照积分" />
                    <span>拍照积分</span>
                </button>
            </div>
            <!-- <div class="btn-scan-wrap">
                <form
                    v-if="sessionId"
                    report-submit="true"
                    @submit="doSubmitForm"
                >
                    <button
                        class="btn btn-operate"
                        formType="submit"
                        @click="doScan"
                    >
                        <img
                            class="icon"
                            src="/static/images/icon-value-point-scan@2x.png"
                            alt="扫码积分"
                        >
                        <span>扫码积分</span>
                    </button>
                </form>
                <button
                    v-else-if="!sessionId &&isGzhLoginShow == false"
                    class="btn btn-operate"
                >
                    <auth-btn />
                    <img
                        class="icon"
                        src="/static/images/icon-value-point-scan@2x.png"
                        alt="扫码积分"
                    >
                    <span>扫码积分</span>
                </button>
                <button
                    v-else-if="!sessionId &&isGzhLoginShow == true"
                    class="btn btn-operate"
                    @click="goAuth"
                >
                    <img
                        class="icon"
                        src="/static/images/icon-value-point-scan@2x.png"
                        alt="扫码积分"
                    >
                    <span>扫码积分</span>
                </button>
            </div>-->
        </div>
        <div class="value-point-main">
            <div class="value-point-tip">
                <h3 class="value-point-tip-name">积分指南</h3>
                <ol class="value-point-tip-text">
                    <li>1. 消费之日起7个自然日内，消费者可单张上传南海嘉洲广场商户内消费凭证获取积分；</li>
                    <li>
                        2. 自助积分凭证仅限商户正规机打结算凭证、门票等；发票、签购单、重打小票、手写票据将视为无效凭证；拍照积分时请确保
                        小票平整清晰，消费信息完整（包含消费商户、消费时间、消费凭证号、消费金额）；通过人工审核后，积分将于72小时内到账。
                    </li>
                    <li>3. 单张消费凭证不可重复累计积分；</li>
                    <li>4. 消费者持同一商户消费小票每日最高不超过3笔；</li>
                    <li>5. 如遇商场会员积分活动，请在活动有效期内上传积分，逾时将按照正常积分策略进行；</li>
                    <li>6. 消费凭证如有异常，商场有权对该账户中的异常积分进行冻结、清零。</li>
                    <!-- <li>7. 如单笔消费超过5000元，请至南海嘉洲广场购物中心1楼服务台进行人工补录。</li> -->
                </ol>
            </div>
        </div>
        <div v-show="isPreviewShow" class="value-point-mask">
            <div class="value-point-mask-con">
                <div class="value-point-mask-close" @click="closePreview()">
                    <img
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/9b2cfa432a604898a3360f665660a4e3.png"
                    />
                </div>
                <div class="value-point-mask-main photo-point-main">
                    <div class="pic-wrap">
                        <img :src="photoPic" class="value-point-mask-pic" mode="aspectFit" alt="图片" />
                    </div>
                    <div class="btn-wrap">
                        <form report-submit="true" @submit="doPhotoForm">
                            <button
                                formType="submit"
                                class="btn btn-operate btn-upload"
                                type="primary"
                            >确定上传</button>
                        </form>
                        <span class="btn-photo" @click="rePhoto">重新拍照</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import AuthBtn from '../../components/AuthBtn'
import wxUtils from '../../plugins/wxUtils'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import { doScan } from '@/service/valuePoint'

export default {
    components: {
        AuthBtn
    },
    data() {
        const BASE_URL = process.env.BASE_URL
        return {
            pageStayTime: 0, //页面停留时间
            isPreviewShow: false,
            photoPic: '',
            formId: '',
            baseUrl: BASE_URL,
            isGzhLoginShow: false
        }
    },
    computed: {
        ...mapState(['sessionId', '', 'scene'])
    },
    methods: {
        goAuth() {
            wx.navigateTo({
                url: `/listOfActivities/shareAuth`
            })
        },
        doPhoto() {
            let vm = this
            buryPoint.setF({
                id: pointCode.POINT_VALUE_Photo
            })
            wx.chooseImage({
                count: 1,
                sizeType: ['compressed'], //上传压缩图
                sourceType: ['album', 'camera'],
                success(res) {
                    var tempFilesSize = res.tempFiles[0].size //获取图片的大小，单位B
                    if (tempFilesSize <= 10000000) {
                        //图片小于或者等于2M时 可以执行获取图片
                        // tempFilePath可以作为img标签的src属性显示图片
                        const tempFilePaths = res.tempFilePaths
                        vm.photoPic = tempFilePaths[0]
                        vm.confirmUpload()
                    } else {
                        //图片大于2M，弹出一个提示框
                        wx.showToast({
                            title: '上传图片不能大于10M!', //标题
                            icon: 'none' //图标 none不使用图标，详情看官方文档
                        })
                    }
                }
            })
        },
        doSubmitForm(e) {
            let vm = this
            let formId = e.mp.detail.formId
            vm.formId = formId
            console.log(formId)
        },
        showErrorScanMsg() {
            wx.showModal({
                title: '温馨提示',
                content: '二维码错误，请重新扫码',
                showCancel: false
            })
        },
        doScan() {
            let vm = this
            // 允许从相机和相册扫码
            wx.scanCode({
                success(res) {
                    console.log('====111')
                    if (res.errMsg == 'scanCode:ok') {
                        let url = res.result
                        let formId = vm.formId
                        let memberCode = wxUtils.getUserCodeStorage()
                        let page = vm.baseUrl + api.getIntegralRecord + `?memberCode=${memberCode}&pageNum=1&pageSize=10`
                        if (!utils.checkURL(url)) {
                            vm.showErrorScanMsg()
                            return
                        }
                        let saleOrder = utils.getUrlParam('n', url)
                        let payAmount = Number(utils.getUrlParam('a', url))
                        let shopCode = utils.getUrlParam('s', url)
                        if (!saleOrder || !payAmount || !shopCode) {
                            vm.showErrorScanMsg()
                            return
                        }
                        let params = {
                            formId,
                            saleOrder: saleOrder,
                            payAmount: payAmount,
                            shopCode: shopCode
                            // page
                        }
                        doScan(params).then(() => {
                            wx.showToast({
                                icon: 'success',
                                title: '积分成功'
                            })
                            setTimeout(() => {
                                wx.navigateTo({
                                    url: '/pagesMine/integral'
                                })
                            }, 1.5 * 1000)
                        })
                    } else {
                        vm.showErrorScanMsg()
                    }
                },
                fail(error) {
                    if (error.errMsg == 'scanCode:fail') {
                        wx.showModal({
                            title: '温馨提示',
                            content: '请扫描二维码',
                            showCancel: false
                        })
                    }
                }
            })
        },
        rePhoto() {
            this.closePreview()
            this.doPhoto()
        },
        confirmUpload() {
            wx.showLoading({
                title: '加载中'
            })
            utils.doUpload(this.photoPic).then(url => {
                let memberCode = wxUtils.getUserCodeStorage()
                let page = this.baseUrl + api.getIntegralRecord + `?memberCode=${memberCode}&pageNum=1&pageSize=10`
                let params = {
                    memberCode: wxUtils.getUserCodeStorage(),
                    integralWay: 1,
                    imgUrl: url,
                    formId: this.formId
                    // page
                }
                let requestOptions = {
                    path: api.doIntegralPhoto,
                    method: 'post',
                    data: params
                }
                request(requestOptions).then(res => {
                    wx.showToast({
                        title: '提交成功',
                        icon: 'success'
                    })
                    this.closePreview()
                })
            })
        },
        closePreview() {
            this.isPreviewShow = false
        },
        doPhotoForm: function(e) {
            let vm = this
            let formId = e.mp.detail.formId
            vm.confirmUpload(formId)
        }
    },
    onUnload() {
        this.isPreviewShow = false

        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.POINT_VALUE_Z,
            p_stay_time: this.pageStayTime
        })
    },
    onLoad() {
        let vm = this
        this.pageStayTime = new Date().getTime()

        buryPoint.setP({
            id: pointCode.POINT_VALUE_P
        })

        if (utils.isFromGzh(this.scene) && !this.sessionId) {
            this.isGzhLoginShow = true //是否从公众号进入
        }
    }
}
</script>

<style lang="less">
@import '../../assets/styles/vars';
.value-point {
    overflow: hidden;
    .value-point-bg {
        display: block;
        width: 290px;
        margin: 17px auto 0px;
    }
    .value-point-main {
        position: relative;
        padding: 0px 23px;
        margin: 50px 0 88px;
        .value-point-tip {
            color: @black-color;
            .value-point-tip-name {
                font-size: 18px;
                line-height: 25px;
            }
            .value-point-tip-text {
                margin-top: 10px;
                font-size: 15px;
                font-weight: 200;
                line-height: 21px;
                color: #666;
            }
        }
    }
    .photo-point-main {
        padding-left: 0px;
    }
    .value-point-btns {
        margin-top: 40px;
        .btn-scan-wrap {
            margin-top: 30px;
        }
        .btn {
            height: 50px;
            line-height: 50px;
            background: linear-gradient(144deg, rgba(179, 116, 248, 1) 0%, rgba(109, 120, 238, 1) 100%);
            border-radius: 25px;
            font-size: 18px;
            font-weight: 400;
            color: @white-color;
            &:active {
                opacity: 0.8;
            }
            &.btn-operate {
                position: relative;
                margin: 0 76px;
                font-size: 0;
                & > span {
                    display: inline-block;
                    vertical-align: middle;
                    margin-left: 10px;
                    font-size: 18px;
                }
                .icon {
                    display: inline-block;
                    width: 28px;
                    height: 28px;
                    vertical-align: middle;
                    padding-top: 2px;
                }
            }
        }
    }
    .value-point-mask {
        box-sizing: border-box;
        z-index: 2;
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: rgba(0, 0, 0, 0.8);
        text-align: center;
        overflow: hidden;
        .value-point-mask-con {
            .value-point-mask-close {
                z-index: 2;
                position: absolute;
                top: 16px;
                right: 16px;
                image {
                    display: inline-block;
                    width: 24px;
                    height: 24px;
                    &:active {
                        opacity: 0.8;
                    }
                }
            }
            .value-point-mask-main {
                box-sizing: border-box;
                display: flex;
                flex-direction: column;
                width: 100vw;
                height: 100vh;
                padding: 0;
                .pic-wrap {
                    padding: 60px 20px 0;
                    flex: 1;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    image {
                        display: inline-block;
                        width: 100%;
                        height: 100%;
                    }
                }
                .btn-wrap {
                    flex: 0 1 auto;
                }
                .btn-upload {
                    height: 44px;
                    line-height: 44px;
                    margin: 35px 50px 0;
                    font-size: 15px;
                }
                .btn-photo {
                    display: inline-block;
                    margin: 30px 0 60px;
                    font-size: 15px;
                    color: @theme-color;
                }
            }
        }
    }
}
</style>
