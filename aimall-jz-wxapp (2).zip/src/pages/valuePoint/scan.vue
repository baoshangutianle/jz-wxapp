<template>
    <div id="scan"
         class="scan">
        <div class="scan-main">
            <div class="scan-info">
                <h1 class="scan-name">南海嘉洲广场 zara店</h1>
                <div class="scan-money">小票可积分金额600元</div>
                <div class="scan-store">
                    可积分：<span class="emphasis scan-point">300积分</span>
                </div>
            </div>
            <div class="scan-date">
                2019-07-01   16:24:00
            </div>
            <button class="btn"
                    @click="confirm">确定积分</button>
        </div>
    </div>
</template>

<script>
import utils from '../../plugins/utils'
import api from '../../plugins/api'
import request from '../../plugins/request'
import loaderMore from '../../components/loaderMore'

export default {
    components: {
        loaderMore
    },
    data() {
        return {

        }
    },
    onShow() {

    },
    methods: {
        confirm(){
            wx.redirectTo({
                url: '/pages/valuePoint/index'
            })
        }
    }
}
</script>

<style lang="less">
@import '../../assets/styles/vars';
@import '../../assets/styles/common';
.scan{
    padding: 0 15px;
    .scan-main{
        color: @black-color;
        .scan-info{
            padding-bottom: 16px;
            font-size: 15px;
            border-bottom: 1px solid @border-color;
            .scan-name{
                margin-top: 20px;
                font-weight: bold;
                line-height: 28px;
            }
            .scan-money{
                margin-top: 15px;
                line-height: 21px;
            }
            .scan-store{
                margin-top: 20px;
                line-height: 21px;
                .scan-point{
                    font-size: 20px;
                    font-weight: bold;
                    line-height: 28px;
                }
            }
        }
        .scan-date{
            margin-top: 10px;
            font-size: 12px;
        }
        .btn{
            height: 44px;
            line-height: 44px;
            margin-top: 130px;
            background: @theme-color;
            font-size: 15px;
            color: @white-color;
            &:active{
                opacity: .8;
            }
        }
    }
}
</style>
