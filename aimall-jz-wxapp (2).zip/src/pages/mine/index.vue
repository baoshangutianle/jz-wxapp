<template>
    <div id="myIndex" :class="{'isMask':isMask}">
        <div class="my-index-con">
            <div class="user-info-con">
                <!-- <img class="user-bg"
                     src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191028/b199988fb1ee4661b2cd6cbb5651abee.png"
                alt="">-->
                <div class="user">
                    <div class="userInfo">
                        <div>
                            <div v-if="!isLogined" class="login-wx login-userInfo">
                                <div class="login-avatar">
                                    <img
                                        v-if="wxUserInfo"
                                        :src="wxUserInfo&&wxUserInfo.userInfo.avatarUrl"
                                        class="user-icon"
                                        mode="scaleToFill"
                                    />
                                    <img
                                        v-else
                                        class="user-icon"
                                        mode="scaleToFill"
                                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/641e6b7d5518485bb393335909347dda.png"
                                        @click="loginByWx"
                                    />
                                </div>
                                <div class="login-user-name">
                                    <div
                                        v-if="wxUserInfo"
                                        class="user-name ecllip"
                                    >{{ wxUserInfo&&wxUserInfo.userInfo.nickName }}</div>
                                    <div v-else class="user-name" @click="loginByWx">登录/注册</div>
                                    <!-- <div v-if="wxUserInfo" class="edit-userInfo">
                                        <span class="edit-userInfo-text">点击编辑个人资料</span>
                                        <span class="edit-arrow">
                                            <img src="/static/images/edit-arrow.png" />
                                        </span>
                                    </div>-->
                                </div>
                            </div>
                            <div v-else class="login-system login-userInfo">
                                <div class="login-avatar">
                                    <img
                                        v-if="vipInfo"
                                        :src="vipInfo&&vipInfo.avatarUrl"
                                        class="user-icon"
                                        mode="scaleToFill"
                                        @click="jump('edit')"
                                    />
                                    <img
                                        v-else
                                        class="user-icon"
                                        mode="scaleToFill"
                                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/641e6b7d5518485bb393335909347dda.png"
                                        @click="loginBySystem"
                                    />
                                </div>
                                <div class="login-user-name">
                                    <div
                                        v-if="vipInfo"
                                        class="user-name ecllip"
                                    >{{ vipInfo&&vipInfo.memberName }}</div>
                                    <div v-else class="user-name" @click="loginBySystem">登录/注册</div>
                                    <div v-if="vipInfo" class="edit-userInfo">
                                        <span
                                            class="edit-userInfo-text"
                                            @click="jump('edit')"
                                        >点击编辑个人资料</span>
                                        <span class="edit-arrow">
                                            <img src="/static/images/edit-arrow.png" />
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex-wrp user-money">
                        <span class="flex-item border-right">
                            <p class="user-money-name">积分</p>
                            <div>
                                <p v-if="vipInfo" class="user-money-value">{{ pointsTotal || 0 }}</p>
                                <p v-else class="user-money-value-default">- -</p>
                            </div>
                            <auth-btn url="/pagesMine/integral" />
                        </span>
                        <span class="flex-item">
                            <auth-btn url="/pagesMine/card" />
                            <p class="user-money-name">卡券</p>
                            <div>
                                <p v-if="vipInfo" class="user-money-value">{{ couponTotal }}</p>
                                <p v-else class="user-money-value-default">- -</p>
                            </div>
                        </span>
                    </div>
                    <div class="user-card">
                        <div class="user-card-con">
                            <div class="vip-title">优享会员</div>
                            <div class="qrcode-wrapper">
                                <span
                                    :style="{visibility:vipInfo&&vipInfo.memberCode?'visible':'hidden'}"
                                    class="user-card-qrcode"
                                >
                                    <div class="user-card-qrcode-con">
                                        <qrcode-comp
                                            :data="qrCode"
                                            width="60"
                                            height="60"
                                            frompage="mimeIndex"
                                            @getimage="getImagePath"
                                        />
                                    </div>
                                </span>
                                <div class="user-card-qrcode-title">专属会员码</div>
                            </div>
                            <div class="user-card-img-con">
                                <!-- <img :src="(vipInfo&&vipInfo.integralGradeId)?'../../static/images/pic_vipCard_0'+vipInfo.integralGradeId+'.png':'../../static/images/pic_vipCard_01.png'"
                                     class="user-card-img"
                                mode="scaleToFill">-->
                                <img
                                    v-if="vipInfo && vipInfo.integralGradeId == 2"
                                    src="https://img-cdn.aimall.cloud/as/20200527/57783f9c0d41420e93a111ed95e8e438.png"
                                    class="user-card-img"
                                    mode="scaleToFill"
                                />
                                <img
                                    v-else-if="vipInfo && vipInfo.integralGradeId == 3"
                                    src="https://img-cdn.aimall.cloud/as/20200527/57783f9c0d41420e93a111ed95e8e438.png"
                                    class="user-card-img"
                                    mode="scaleToFill"
                                />
                                <img
                                    v-else-if="vipInfo && vipInfo.integralGradeId == 4"
                                    src="https://img-cdn.aimall.cloud/as/20200527/57783f9c0d41420e93a111ed95e8e438.png"
                                    class="user-card-img"
                                    mode="scaleToFill"
                                />
                                <img
                                    v-else
                                    src="https://img-cdn.aimall.cloud/as/20200527/57783f9c0d41420e93a111ed95e8e438.png"
                                    class="user-card-img"
                                    mode="scaleToFill"
                                />
                            </div>
                            <span v-if="vipInfo" class="user-card-info">
                                <div class="user-card-name ecllip">{{ vipInfo&&vipInfo.memberName }}</div>
                                <div class="user-card-id">{{ vipInfo&&vipInfo.memberCode }}</div>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <ul class="user-operate">
                <!-- <li class="myApply">
                    <auth-btn @pass="goDetail('exchange','/pages/mine/exchangeRecord')" />
                    <span>兑换记录</span>
                    <span class="flex-item-arrow">
                        <img src="/static/images/arrow_right.png">
                    </span>
                </li>-->
                <li class="myApply">
                    <auth-btn @pass="goDetail('orderList','/pages/ordermanage/orderlist')" />
                    <span>订单管理</span>
                    <span class="flex-item-arrow">
                        <img src="/static/images/arrow_right.png" />
                    </span>
                </li>
                <!-- <li class="myApply">
                    <auth-btn @pass="goDetail('exchangeRecord','/pages/mine/exchangeRecord')" />
                    <span>兑换记录</span>
                    <span class="flex-item-arrow">
                        <img src="/static/images/arrow_right.png">
                    </span>
                </li>-->
                <li class="myApply">
                    <auth-btn @pass="goDetail('collect','/pagesMine/collect')" />
                    <span>我的收藏</span>
                    <span class="flex-item-arrow">
                        <img src="/static/images/arrow_right.png" />
                    </span>
                </li>
                <li class="myApply">
                    <auth-btn @pass="goDetail('activity','/listOfActivities/myActivity')" />
                    <span>我的活动</span>
                    <span class="flex-item-arrow">
                        <img src="/static/images/arrow_right.png" />
                    </span>
                </li>
                <li class="myApply">
                    <auth-btn @pass="goDetail('tickets','/pagesMine/tickets')" />
                    <span>小票上传记录</span>
                    <span class="flex-item-arrow">
                        <img src="/static/images/arrow_right.png" />
                    </span>
                </li>
                <li class="myApply">
                    <auth-btn @pass="goDetail('car','/pages/parkPay/index?from=mine')" />
                    <span>车牌管理</span>
                    <span class="flex-item-arrow">
                        <img src="/static/images/arrow_right.png" />
                    </span>
                </li>
                <!-- <li class="myApply">
                    <span>支付管理</span>
                    <span class="flex-item-arrow">
                        <img src="/static/images/arrow_right.png">
                    </span>
                </li>-->
                <!-- <li class="myApply">
                    <auth-btn @pass="showPhone" />
                    <span>联系客服</span>
                    <span class="flex-item-arrow myApply-phone">
                        021-60906008
                        <img src="/static/images/arrow_right.png">
                    </span>
                </li>-->
                <li class="myApply">
                    <auth-btn @pass="goDetail('setting','/pagesMine/setting')" />
                    <span>设置</span>
                    <span class="flex-item-arrow">
                        <img src="/static/images/arrow_right.png" />
                    </span>
                </li>
            </ul>
            <login-prompt :is-show="isLoginPromptShow" @close="closeLoginPrompt" />
        </div>
        <canvas
            style="margin-top:100px;width: 686rpx;height: 686rpx;background:#f1f1f1;opacity:0;position:absolute;left:-686rpx;"
            canvas-id="mycanvas"
        />
        <!-- 预览 -->
        <div v-if="isShow" class="layer">
            <div class="layer-con">
                <div class="layer-bg">
                    <img
                        v-if="vipInfo.integralGradeId == 2"
                        src="https://img-cdn.aimall.cloud/as/20200601/051c732da45f4a62bd3700be94b4fa45.png"
                    />
                    <img
                        v-else-if="vipInfo.integralGradeId == 3"
                        src="https://img-cdn.aimall.cloud/as/20200601/051c732da45f4a62bd3700be94b4fa45.png"
                    />
                    <img
                        v-else-if="vipInfo.integralGradeId == 4"
                        src="https://img-cdn.aimall.cloud/as/20200601/051c732da45f4a62bd3700be94b4fa45.png"
                    />
                    <img
                        v-else
                        src="https://img-cdn.aimall.cloud/as/20200601/051c732da45f4a62bd3700be94b4fa45.png"
                    />
                </div>
                <div class="layer-face">
                    <img
                        v-if="vipInfo"
                        :src="vipInfo&&vipInfo.avatarUrl"
                        class="face-icon"
                        mode="scaleToFill"
                    />
                    <p class="layer-card">{{vipInfo.integralGradeName}}</p>
                    <p class="layer-text">尊敬的会员，{{timeType}}</p>
                </div>
                <div class="layer-img-div">
                    <div class="layer-img">
                        <img :src="imagePath" mode="aspectFit" />
                    </div>
                    <p class="layer-p layer-pt">购物时出示会员卡</p>
                    <p class="layer-p layer-pb">更多积分可享受更多礼遇哦</p>
                </div>
                <div class="colse_layer-div">
                    <div class="colse_layer" @click="closeImg">
                        <div class="close-line"></div>
                        <img
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191031/410da15b59cb4adf8d10e9e5afe5db74.png"
                        />
                    </div>
                </div>
            </div>
        </div>
        <div class="tipPage" v-if="isMask">
            <img
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191028/d458828dfd244c858e3ccea7a35069bf.png"
                @click="closePage"
                mode="widthFix"
            />
            <img
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191118/5b6e9547f437448ea3f2caae39cd64be.png"
                class="tipTab"
                mode="widthFix"
            />
        </div>
    </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import moment from 'moment'
import request from '../../plugins/request'
import api from '../../plugins/api'
import utils from '../../plugins/utils'
import wxUtils from '../../plugins/wxUtils'
import UserAuth from '../../components/UserAuth'
import PhoneAuth from '../../components/PhoneAuth'
import LoginPrompt from '../../components/loginPrompt'
import AuthBtn from '../../components/AuthBtn'
import QrcodeComp from '../../components/QrcodeComp'
import { getCouponNumForC } from '@/service/mine'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
export default {
    components: {
        UserAuth,
        PhoneAuth,
        LoginPrompt,
        AuthBtn,
        QrcodeComp
    },
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            isWxLogin: true, //是否是微信登录
            wxUserInfo2: wxUtils.getUserStorage(),
            userInfo: {
                avatarUrl: '',
                nickName: ''
            },
            isPhoneShow: false,
            activeStatus: false,
            isLoginPromptShow: false, //登录引导弹框,
            wxUserCode: '',
            qrCode: '',
            couponTotal: 0,
            pointsTotal: 0,
            format: 'YYYY-MM-DD',
            imagePath: '',
            isShow: false,
            timeType: ''
        }
    },
    computed: {
        ...mapState(['vipInfo', 'wxUserInfo', 'isLogined', 'isMask'])
    },
    watch: {
        vipInfo(newVal) {
            if (newVal) {
                this.qrCode = newVal.memberCode
                this.getIntergral()
                //this.getCoupon()
            } else {
                this.qrCode = ''
            }
        }
        // isMask(newVal){
        //     if(newVal){
        //         wx.hideTabBar()
        //     }else{
        //         wx.showTabBar()
        //     }
        // }
    },
    mounted() {},
    onload() {},
    onShow() {
        // 埋点 P
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.MINE_P
        })

        //刷新session
        wxUtils.getUserSession()

        if (this.vipInfo && this.isLogined) {
            //生成二维码
            this.setQrCode()
            this.getCoupon()
            this.getVipBasicInfo()
            this.getMemberNotice()
        }
        //获取时间
        // console.log(moment("13:00", 'HH:mm').format('HH:mm a'));
        if (moment(new Date(), 'HH:mm').format('a') == 'PM' || moment(new Date(), 'HH:mm').format('a') == 'pm') {
            this.timeType = '下午好'
        } else if (moment(new Date(), 'HH:mm').format('a') == 'AM' || moment(new Date(), 'HH:mm').format('a') == 'am') {
            this.timeType = '上午好'
        } else {
            this.timeType = '您好'
        }
    },
    onHide() {
        this.qrCode = ''
        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: pointCode.MINE_Z,
            p_id: wxUtils.getUserCodeStorage(),
            p_stay_time: this.pageStayTime
        })
    },

    methods: {
        ...mapMutations(['update', 'setMaskStatus']),
        closePage() {
            wx.showTabBar()
            this.setMaskStatus(false)
            wx.setStorageSync('maskFalg', false)
            wx.switchTab({
                url: `/pages/home`
            })
        },
        getVipBasicInfo() {
            utils.getVipInfo().then(vipInfo => {
                this.update({
                    vipInfo: vipInfo
                })
            })
        },
        goDetail(type, url) {
            this.doBuryPoint(type)
            // if (type == 'car') {
            //     wx.showToast({
            //         icon: 'none',
            //         title: '敬请期待...'
            //     })
            // } else {
            //     wx.navigateTo({
            //         url: url
            //     })
            // }
            wx.navigateTo({
                url: url
            })
        },
        //会员通知提醒接口
        getMemberNotice() {
            if (wx.getStorageSync('wxUserCode')) {
                let position = {
                    path: api.getMemberNotice,
                    method: 'post',
                    data: {
                        memberCode: wx.getStorageSync('wxUserCode') ? wx.getStorageSync('wxUserCode') : '',
                        mallCode: 'HXSGSH01',
                        noticeType: '10'
                    },
                    isLoading: 'false'
                }
                request(position).then(res => {
                    if (res.code == 200) {
                        if (res.data.noticeBody) {
                            wx.showToast({
                                title: JSON.parse(res.data.noticeBody).couponName,
                                icon: 'none',
                                duration: 5000
                            })
                        }
                    }
                })
            }
        },
        //详情埋点
        doBuryPoint(type, url) {
            let id
            switch (type) {
                case 'collect':
                    id = pointCode.MINE_F_COLLECT
                    break
                case 'tickets':
                    id = pointCode.MINE_F_TICKETS
                    break
                case 'car':
                    id = pointCode.MINE_F_CAR
                    break
                case 'phone':
                    id = pointCode.MINE_F_SERVICE
                    break
                case 'setting':
                    id = pointCode.MINE_F_SETTING
                    break
                default:
                    id = ''
            }
            if (id) {
                buryPoint.setF({
                    id: id
                })
            }
        },
        setQrCode() {
            if (!this.qrCode) {
                this.qrCode = this.vipInfo.memberCode
            }
        },
        async getCoupon() {
            let params = Object.assign(
                {},
                {
                    pageNum: 1,
                    pageSize: 1
                },
                {
                    chargeOffStatus: 1,
                    memberCode: wxUtils.getUserCodeStorage()
                }
            )

            //let res = await getCards(params, true)
            //this.couponTotal = res.total
            let res = await getCouponNumForC(params, true)
            this.couponTotal = res
        },
        async getIntergral() {
            let params = Object.assign(
                {},
                {
                    pageNum: 1,
                    pageSize: 1
                },
                {
                    memberId: this.vipInfo.id,
                    startTime: moment().format(this.format) + ' 00:00:00',
                    endTime: moment().format(this.format) + ' 23:59:59'
                }
            )
            let requestOptions = {
                path: api.getIntegralDetail,
                method: 'get',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                let { totalPoints } = res.data
                this.pointsTotal = totalPoints
            })
        },
        getAllCardTypes() {
            let vm = this
            let params = {}
            let requestOptions = {
                path: api.getAllCardTypes,
                method: 'get',
                data: {}
            }
            request(requestOptions).then(res => {})
        },
        getInitUserInfo() {
            let vm = this
            let wxUserInfo = wxUtils.getUserStorage()
            if (!wxUtils.isStorageEmpty(wxUserInfo)) {
                let { nickName, avatarUrl } = Object.assign({}, wxUtils.getUserStorage().userInfo)
                vm.userInfo.nickName = nickName
                vm.userInfo.avatarUrl = avatarUrl
            } else {
                vm.userInfo = {}
            }
        },
        jump(type) {
            let vm = this
            let url = ''
            if (type == 'edit') {
                url = '/pagesMine/editInfo'
            } else if (type == 'setting') {
                url = '/pagesMine/setting'
            } else if (type == 'collect') {
                url = '/pagesMine/collect'
            }

            wx.navigateTo({
                url: url
            })
        },
        getWxUserInfo() {
            let wxUserInfo = Object.assign(wxUtils.getUserStorage().userInfo)
            let { avatarUrl, nickName } = wxUserInfo
            this.userInfo = {
                avatarUrl,
                nickName
            }
        },
        loginByWx() {
            this.isLoginPromptShow = true
        },
        async loginBySystem() {
            let vm = this
            wx.getSetting({
                success(res) {
                    console.log('myres', res)
                    if (res.authSetting['scope.userInfo']) {
                        wx.navigateTo({
                            url: '/pages/auth/index'
                        })
                    } else {
                        wxUtils.clearLoginStorage()
                        vm.loginByWx()
                        vm.update({
                            wxUserInfo: null,
                            isLogined: false
                        })
                        //刷新session
                        wxUtils.getUserSession()
                    }
                }
            })
        },
        closeLoginPrompt() {
            let vm = this
            vm.isLoginPromptShow = false //关闭弹框
        },
        //刷新基本信息，包括头像、二维码
        refreshBasicInfo() {
            let vm = this
            utils.getAvatar(function(data) {
                vm.update({
                    vipAvatar: data
                })
            })
        },
        closeAuthBtn() {
            this.refreshBasicInfo()
        },
        showPhone() {
            this.doBuryPoint('phone')

            wx.makePhoneCall({
                phoneNumber: '021-60906008'
            })
        },
        closePhone() {
            this.isPhoneShow = false
        },
        // 退出登录
        signOut() {
            wx.showModal({
                title: '',
                content: '确认退出登录？',
                success(res) {
                    if (res.confirm) {
                        wx.removeStorageSync('accountInfo')
                        wx.removeStorageSync('sessionId')
                        wx.removeStorageSync('shopId')
                        wx.reLaunch({
                            url: '/pages/auth/login'
                        })
                    } else if (res.cancel) {
                    }
                }
            })
        },
        closeImg() {
            this.isShow = false
        },
        //防止底层view滑动
        preventTouchMove(e) {
            return
        },
        getImagePath(src) {
            this.imagePath = src
            this.isShow = true
        }
    },

    onTabItemTap(item) {
        //埋点
        buryPoint.setF({
            id: pointCode.TABBAR_F_MINE
        })
    }
}
</script>

<style lang="less">
@import '../../assets/styles/vars';
#myIndex {
    width: 100vw;
    height: 100vh;
    // overflow: hidden;
    background-color: @bg-color;
    .my-index-con {
        height: 100%;
        overflow: auto;
        background: @white-color;
    }
    .user-info-con {
        position: relative;
        background-color: #fff;
        border-bottom: 10px solid #eee;
    }
    .user-bg {
        position: absolute;
        top: 0;
        right: 0;
        width: 100%;
        height: 280px;
    }
    .user {
        position: relative;
        background-color: #fff;
        border-radius: 5px;
        margin: 0 20px;
        padding-bottom: 32px;
        .login-userInfo {
            height: 60px;
            display: flex;
            margin-top: 40px;
            padding-left: 10px;
            .login-avatar {
                width: 60px;
                height: 60px;
            }
            .login-user-name {
                flex: 1;
                height: 60px;
                padding-left: 15px;
            }
            .edit-arrow {
                width: 4px;
                height: 8px;
                display: inline-block;
                vertical-align: top;
                margin-top: 5px;
                img {
                    width: 4px;
                    height: 8px;
                }
            }
        }
        .bottom-arrow {
            display: inline-block;
            position: absolute;
            bottom: -43px;
            border-style: solid;
            border-color: @theme-color transparent transparent transparent;
            border-top-width: 40px;
            border-left-width: 50vw;
            border-right-width: 50vw;
        }
        .backgroundImg {
            width: 100%;
            img {
                width: 100%;
            }
        }
        .userInfo {
            overflow: hidden;
            // margin: 0 30px;
            padding: 0 0 10px;
            text-align: left;
            z-index: 99;
            width: 100%;
            .user-icon {
                width: 60px;
                height: 60px;
                border-radius: 50%;
                background: #e6e6e6;
            }
            .user-name {
                margin-top: 10px;
                font-size: 20px;
                color: #282828;
                font-weight: 500;
                margin-bottom: 5px;
            }
            .edit-userInfo {
                height: 16px;
                color: #282828;
                .edit-userInfo-text {
                    height: 16px;
                    font-size: 12px;
                    vertical-align: top;
                    color: #282828;
                    margin-right: 4px;
                }
            }
            .mall {
                font-size: 12px;
                color: #ffffff;
            }
        }
        .user-money {
            padding: 0 20px;
            padding-top: 10px;
            .border-right::before {
                position: absolute;
                content: '';
                display: block;
                height: 32px;
                width: 1px;
                background: #f0f0f0;
                top: 50%;
                transform: translateY(-50%);
                right: 0px;
            }
            .flex-item {
                position: relative;
                text-align: center;
                // &+.flex-item:before{
                //     position: absolute;
                //     top: 50%;
                //     left: 0;
                //     transform: translateY(-50%);
                //     display: inline-block;
                //     content: '';
                //     width: 1px;
                //     height: 34px;
                //     background: #fff;
                // }
                .user-money-name {
                    color: #5c5c5c;
                    margin-top: 5px;
                    font-size: 13px;
                }
                .user-money-value {
                    margin-top: 4px;
                    font-size: 18px;
                    color: #282828;
                }
                .user-money-value-default {
                    color: #c7c7c7;
                }
            }
        }
        .user-card {
            // position: absolute;
            // left: 50%;
            // bottom: -120px;
            // transform: translateX(-50%);
            margin-top: 20px;
            .vip-title {
                position: absolute;
                left: 25px;
                top: 9px;
                font-weight: 500;
                color: #fff;
                line-height: 25px;
            }
            .user-card-img-con {
                height: 136px;
                width: 336px;
                max-width: 0 auto;
            }
            .user-card-con {
                position: relative;
                width: 100%;
                height: 100%;
                .user-card-img {
                    height: 136px;
                    width: 336px;
                    // background: @theme-color;
                    border-radius: 6px;
                    margin-top: 3px;
                }
                .user-card-info {
                    position: absolute;
                    bottom: 25px;
                    left: 25px;
                    font-size: 15px;
                    color: #fff;
                    .user-card-name {
                        font-size: 15px;
                        width: 140px;
                        font-weight: 300;
                        opacity: 0.8;
                    }
                    .user-card-id {
                        margin-top: 2px;
                        font-size: 15px;
                        font-weight: 300;
                        opacity: 0.8;
                    }
                }
                .qrcode-wrapper {
                    position: absolute;
                    height: 102px;
                    width: 82px;
                    top: 14px;
                    right: 35px;
                }
                .user-card-qrcode-title {
                    color: #fff;
                    font-size: 12px;
                    font-weight: 300;
                    position: absolute;
                    bottom: -0px;
                    left: 0px;
                    text-align: center;
                    width: 100%;
                }
                .user-card-qrcode {
                    position: absolute;
                    left: 0px;
                    top: 0px;
                    border: 5px solid rgba(255, 255, 255, 0.3);
                    border-radius: 4px;

                    .user-card-qrcode-con {
                        box-sizing: border-box;
                        overflow: hidden;
                        width: 72px;
                        height: 72px;
                        canvas {
                            display: inline-block;
                            width: 100%;
                            height: 100%;
                        }
                    }
                }
            }
        }
    }
    .user-operate {
        margin-bottom: 40px;
        background-color: @white-color;
        .myApply {
            position: relative;
            height: 45px;
            box-sizing: border-box;
            margin: 0 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid #f0f0f0;
            .flex-item-arrow {
                position: relative;
                flex: 0 1 60%;
                text-align: right;
                height: 100%;
                display: flex;
                align-items: center;
                justify-content: flex-end;
            }
            span {
                font-size: 15px;
                color: @black-color;
            }
            img {
                display: inline-block;
                margin: 0 0 0 17px;
                width: 12px;
                height: 12px;
            }
            .myApply-phone {
                color: #999;
            }
        }
    }
}
.layer {
    position: relative;
    background: #000000;
    background: rgba(0, 0, 0, 0.7);
    width: 100%;
    height: 100%;
    top: 0px;
    bottom: 0px;
    position: fixed;
    z-index: 999;
    align-items: center;
    overflow-y: auto;
    display: flex;
}
.layer-con {
    position: relative;
    flex: 1;
    margin: 0 30px;
    margin-top: 50px;
    .layer-bg {
        width: 100%;
        height: 116px;
        img {
            width: 100%;
            height: 116px;
        }
    }
}
.layer-face {
    position: absolute;
    z-index: 99;
    width: 100%;
    top: -30px;
    text-align: center;
    .face-icon {
        width: 60px;
        height: 60px;
        margin: 0 auto;
        border-radius: 50%;
    }
    .layer-card {
        padding-top: 12px;
        color: #ffffff;
        font-size: 20px;
    }
    .layer-text {
        padding-top: 5px;
        color: #ffffff;
        font-size: 14px;
        font-weight: 300;
    }
}
.layer-con .layer-img {
    display: inline-block;
    width: 187px;
    height: 187px;
    border-radius: 2px;
    margin-top: 20px;
    background: rgba(235, 235, 235, 1);
}
.layer-img-div {
    background: #ffffff;
    width: 100%;
    margin: 0 auto;
    text-align: center;
}
.layer-img img {
    width: 173px;
    height: 173px;
    padding: 7px;
}
.layer-pt {
    padding-top: 15px;
}
.layer-pb {
    padding-bottom: 22px;
}
.layer-p {
    color: #222222;
    font-size: 14px;
    font-weight: 300;
}
.colse_layer-div {
    position: relative;
    width: 100%;
    height: 100px;
}
.colse_layer {
    position: absolute;
    left: 0;
    right: 0;
    text-align: center;
}
.close-line {
    width: 1px;
    height: 39px;
    background: #ffffff;
    margin: 0 auto;
}
.colse_layer img {
    width: 45px;
    height: 45px;
    margin: 0 auto;
    margin-top: -1px;
}
.tipPage {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.56);
    z-index: 9999;
    img {
        position: absolute;
        bottom: 0;
        width: 100%;
    }
    img.tipTab {
        position: absolute;
        bottom: 0;
    }
}
#myIndex.isMask {
    overflow: hidden;
    background: rgba(0, 0, 0, 0.53);
    .user-operate {
        display: none;
    }
}
</style>
