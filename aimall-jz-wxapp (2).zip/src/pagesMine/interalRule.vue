<template>
    <div class="rulePage">
        <div v-for="(item,index) in data" :key="index" class="main">
            <div class="title"><span class="line"></span>{{item.title}}</div>
            <ul>
                <li v-for="(i,inx) in item.content" class="content" :key="inx">
                    {{i.name}}
                </li>
            </ul>
        </div>
        <div class="ruleTable">
            <table class="table">
                <div class="th">
                    <div class="line w70 bg tleft">消费类别</div>
                    <div class="line w30 bg">兑换比例</div>
                </div>
                <td class="td" v-for="(item,index) in ruleData" :key="index">
                    <div class="line w70">{{item.title}}</div>
                    <div class="line right w30">{{item.name}}</div>
                </td>
            </table>
        </div>
    </div>
</template>

<script>
import { mapState,mapMutations } from "vuex"
import moment from 'moment'
import request from '@/plugins/request'
import api from '@/plugins/api'
import wxUtils from '@/plugins/wxUtils';
import loaderMore from '@/components/loaderMore'
import blockPage from '@/components/blockPage'
export default {
    components:{
        loaderMore,
        blockPage
    },
    data(){
        return{
            data:[
                {title:'如何获取积分',content:[{name:'1.会员可在消费之日起7个自然日内，打开微信小程序，点击“自助积分”专区，拍摄商场内商户消费凭证，获取积分。'},{name:'2.会员可在商场内安装积分设备的商户消费前出示电子会员卡或提供绑定会员卡的手机号，完成消费积分。'},{name:'3.会员可在购物中心1楼服务台，完成积分计入与人工补录。'}]},
                {title:'如何使用积分',content:[{name:'1.可以在停车缴费中抵扣停车费使用。'},{name:'2.可以在热门活动中使用。'},{name:'3.可以在积分商城中使用。'}]},
                {title:'积分规则有哪些',content:[
                    {name:'1.积分可以累积，有效期1年。即从获得开始至次年年底，逾期自动作废（若交易在使用有效期之外发生退款，该部分积分不予退还）。'},
                    {name:'2.用户使用积分时，优先消耗旧积分（如用户积分由去年2月份和今年3月份共同累积，则优先消耗去年2月份的积分）。'},
                    {name:'3.积分不可兑现，不可转让。'},
                    {name:'4.消费类别&兑换比例。'}
                ]}
            ],
            ruleData:[
                {title:'餐饮、儿童零售、服装服饰、化妆品、家具 家用、小家电',name:'1元=1积分'},
                {title:'儿童娱乐、儿童配套、医美、生活配套、培 训、文化娱乐',name:'5元=1积分'},
                {title:'黄金珠宝贵表、手机数码',name:'10元=1积分'},
                {title:'特殊类别（票务、寄存、停车、通讯、特卖、 充值、租借、银行、超市）',name:'不参与积分'},
            ]
        }
    },
    computed: {
        ...mapState(['vipInfo'])
    },
    methods:{
    },
    mounted(){

    }
}
</script>

<style lang="less" scoped>
.rulePage{
    background: #F4F4F4;
    .main{background: #ffffff;margin-bottom:12px;overflow: hidden;padding: 17px;}
    .title{
        .line{display: inline-block;height: 10px;background:#9975F3;width:2px;margin-right:6px;}
        font-size: 15px;padding-bottom:10px;color:#333333;}
    ul{
       .content{font-size: 14px;padding:0 10px 0px 7.5px;color:#999999;line-height: 25px;}
    }
    .ruleTable{
        padding: 17px;
        background: #ffffff;
        margin-top:-30px;
        .table{
            border:1px solid #84C6C4;
            border-bottom: none;
            overflow: hidden;
            .w70{
                width:70%;
            }
            .w30{width:30%;}
            .line{
                border-right:1px solid #84C6C4;
                padding: 17px 7px;
                float: left;
                line-height: 20px;
                box-sizing: border-box;
                color: #666666;
                font-size:12px;
            }
            .tleft{border-right:1px solid #ffffff;}
            .right{
                text-align: center;
                border: none;
                position: absolute;
                right: 0;
                top: 0;
                height: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .bg{background: #84C6C4;font-size: 15px;color: #ffffff;text-align: center;}
            .th{overflow: hidden;}
            .td{overflow: hidden;border-bottom:1px solid #84C6C4;position: relative;}
        }
    }
}
</style>
