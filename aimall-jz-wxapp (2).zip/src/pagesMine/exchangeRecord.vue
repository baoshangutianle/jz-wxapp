<template>
    <div id="listOfActivitiesPopular">
        <view class="section">
            <scroll-view :scroll-y="true"
                         class="actives-list"
                         :class="{'allPage':listData.length == 0 && InvalidList.length ==0}"
                         @bindscrolltoupper="upper"
                         @scrollToLower="onReachBottom"
                         @bindscroll="scroll"
                         @scroll-into-view="toView"
                         @scroll-top="scrollTop">

                <div class="actives-con">
                    <ul>
                        <li v-for="item in listData"
                            :key="item.id"
                            :data-id="item.id"
                            :data-title="item.title"
                            class="my-shadow actives-item"
                            style="position:relative">
                            <!-- <auth-btn @pass="toDetails(item)" /> -->
                            <div class="actives-info">
                                <img :src="item.thumbnail"
                                     class="activies-img" />
                                <div class="actives-content">
                                    <div class="actives-title">
                                        {{ item.prodName }}
                                    </div>
                                    <div class="actives-des">
                                        <div class="gift">
                                            <span v-if="item.couponType == 1">现金券</span>
                                            <span v-if="item.couponType == 2">满减券</span>
                                            <span v-if="item.couponType == 3">满减券</span>
                                            <span v-if="item.couponType == 4">停车券</span>
                                            <span v-if="item.couponType == 5">积分券</span>
                                            <span v-if="item.couponType == 6">礼品券</span>
                                        </div>
                                        <div class="inter">
                                            <span v-if="!item.useIntegral">免费兑换</span>
                                            <span v-else>{{item.useIntegral}}积分</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- des -->
                            <div class="label">
                                <p class="actives-time">
                                    使用时间: <span>{{item.exchangeStartTime}}-{{item.exchangeEndTime}}</span>
                                </p>
                                <div class="actives-status"
                                    @click="toDetails(item)">
                                    <span>立即使用</span>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <div v-if="listData.length ==0 && requstFalg"
                         class="tipPage">
                        <block-page :type="typeText"></block-page>
                        <div class="goIntegral"
                             @click="toIntegral">去在线商城看看</div>
                    </div>
                    <div v-if="InvalidList.length > 0"
                         class="openPage">
                        <div class="line"></div>
                        <div class="text">
                            <span v-if="!invalidFlag">失效券已隐藏 <span @click="open"
                                      class="open">点击展开</span></span>
                            <span v-if="invalidFlag">失效券已展开 <span @click="open"
                                      class="open">点击隐藏</span></span>
                        </div>
                        <div class="line"></div>
                    </div>
                    <div v-if="InvalidList.length > 0"
                         class="grayBox">
                        <ul v-if="invalidFlag">
                            <li v-for="item in InvalidList"
                                :key="item.id"
                                :data-id="item.id"
                                :data-title="item.title"
                                class="my-shadow actives-item gray"
                                style="position:relative">
                                <div class="actives-info">
                                    <img :src="item.thumbnail"
                                         class="activies-img" />
                                    <div class="actives-content">
                                        <div class="actives-title">
                                            {{ item.prodName }}
                                        </div>
                                        <div class="actives-des">
                                            <div class="gift">
                                                <span v-if="item.couponType == 1">现金券</span>
                                                <span v-if="item.couponType == 2">满减券</span>
                                                <span v-if="item.couponType == 3">满减券</span>
                                                <span v-if="item.couponType == 4">停车券</span>
                                                <span v-if="item.couponType == 5">积分券</span>
                                                <span v-if="item.couponType == 6">礼品券</span>
                                            </div>
                                            <div class="inter">
                                                <span v-if="!item.useIntegral">免费兑换</span>
                                                <span v-else>{{item.useIntegral}}积分</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- des -->
                                <div class="label">
                                    <p class="actives-time">
                                        使用时间: <span>{{item.exchangeStartTime}}-{{item.exchangeEndTime}}</span>
                                    </p>
                                    <dev class="actives-status">
                                        <span v-if="item.chargeOffStatus == 1">已过期</span>
                                        <span v-if="item.chargeOffStatus == 2">已使用</span>
                                    </dev>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <load-more v-if="reachFinish" />
                </div>
            </scroll-view>
        </view>
    </div>
</template>

<script>
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import moment from 'moment'
import SearchComp from '@/components/SearchComp'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import loadMore from '@/components/loadMore'
import BlankPage from '@/components/blankPage'
import BlockPage from '@/components/blockPage'
import { setTimeout } from 'timers'
import { mapState, mapMutations } from 'vuex'
import AuthBtn from '@/components/AuthBtn'
import wxUtils from '@/plugins/wxUtils'
export default {
    components: {
        SearchComp,
        loadMore,
        BlankPage,
        BlockPage,
        AuthBtn
    },
    data() {
        return {
            invalidFlag: false,
            total: 0, //可使用列表总数
            invalidTotal: 0, //失效列表总数
            pageStayTime: 0, //页面停留时间
            listData: [], // 可使用列表
            InvalidList: [], //失效列表
            requstFalg: false, //接口是否调通
            activityNameLike: '',
            ipt: '搜索',
            listFrom: {
                pageNum: 1,
                pageSize: 20,
                memberCode: null
            },
            pageNum: 1,
            toView: 'red',
            scrollTop: 100,
            isClear: false,
            reachFinish: false,
            hasFetchData: false, //拉取数据状态
            typeText: '兑换记录'
        }
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo'])
    },
    mounted() {},
    onShow() {
        if (this.vipInfo) {
            this.listFrom.memberCode = this.vipInfo.memberCode
        }
        this.resetRefresh()
    },
    onHide() {
        this.hidePage()
    },
    onUnload() {
        this.hidePage()
    },
    methods: {
        open() {
            this.invalidFlag = !this.invalidFlag
        },
        hidePage() {
            this.hasFetchData = false
        },
        resetRefresh() {
            //重置刷新
            this.reachFinish = false
            this.invalidFlag = false
            this.listFrom.pageNum = 1
            this.pageNum = 1
            this.listData = []
            this.InvalidList = []
            this.requstFalg = false
            this.getRecordList()
            this.getInvailRecordList()
        },
        // 获取兑换记录可使用列表
        getRecordList() {
             wx.showLoading({
                title: '加载中',
            })
            let t = this
            t.hasFetchData = false
            wx.request({
                url: api.exchangeRecordList + '?orderStatus=1&pageNum=' + t.listFrom.pageNum + '&pageSize=' + t.listFrom.pageSize + '&memberCode=' + t.listFrom.memberCode,
                method: 'POST',
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    wx.hideLoading()
                    t.requstFalg = true
                    if (res.data.code === 200) {
                        let records = res.data.data.list
                        t.total = res.data.data.total
                        if (records) {
                            records.forEach(v => {
                                if (v.exchangeStartTime) {
                                    v.exchangeStartTime = moment(v.exchangeStartTime).format('YYYY.MM.DD')
                                }
                                if (v.exchangeEndTime) {
                                    v.exchangeEndTime = moment(v.exchangeEndTime).format('YYYY.MM.DD')
                                }
                            })
                            let list = records
                            t.listData = t.listData.concat(list)
                        }
                    }
                }
            })
        },
        getInvailRecordList() {
            var t = this
            wx.request({
                url: api.exchangeRecordList + '?orderStatus=0&pageNum=' + t.pageNum + '&pageSize=' + t.listFrom.pageSize + '&memberCode=' + t.listFrom.memberCode,
                method: 'POST',
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(resp) {
                    let respData = resp.data.data.list
                    t.invalidTotal = resp.data.data.total
                    if (respData) {
                        respData.forEach(i => {
                            if (i.exchangeStartTime) {
                                i.exchangeStartTime = moment(i.exchangeStartTime).format('YYYY.MM.DD')
                            }
                            if (i.exchangeEndTime) {
                                i.exchangeEndTime = moment(i.exchangeEndTime).format('YYYY.MM.DD')
                            }
                        })
                        t.InvalidList = t.InvalidList.concat(respData)
                        t.reachFinish = false
                    }
                }
            })
        },
        upper(e) {
            console.log(e)
        },
        lower(e) {
            console.log(e)
        },
        scroll(e) {
            console.log(e)
        },
        // 跳转至详情页
        toDetails(item) {
            wx.navigateTo({
                url: `/pagesMine/exchangeDetail?id=${item.id}`
            })
        },
        //兑换记录
        toIntegral() {
            wx.switchTab({
                url: `/pages/integralMall/index`
            })
        }
    },
    // 触底加载更多
    onReachBottom() {
        if(this.listData.length == 0 && this.InvalidList.length == 0){
             return
        }
        if (this.listFrom.pageNum * this.listFrom.pageSize > this.total && this.pageNum * this.listFrom.pageSize > this.invalidTotal) {
            if(this.listData.length == 0 && !this.invalidFlag){
               return
            }
            this.reachFinish = true
        } else {
            this.listFrom.pageNum++
            if (this.pageNum * this.listFrom.pageSize <= this.invalidTotal) {
                this.pageNum++
                this.getInvailRecordList()
            }
            this.getRecordList()
        }
    }
}
</script>

<style lang="less">
@import '../assets/styles/vars';
#listOfActivitiesPopular {
    // min-width: height 100vh;
    background-color: #f4f4f4;
    .actives-list {
        min-height: 100vh;
        background: #f4f4f4;
    }
    .my-shadow{
        box-shadow:none;
    }
    .actives-con {
        // min-height: 100vh;
        padding-bottom: 50px;
        .actives-item:nth-child(1){
            margin-top: 0px;
        }
        .actives-item {
            margin-top: 15px;
            overflow: hidden;
            padding: 16px;
            padding-bottom: 0;
            background: #ffffff;
            // box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            .actives-info {
                overflow: hidden;
                display: flex;
                padding-bottom: 10px;
                border-bottom: 0.5px solid #f0f0f0;
                .activies-img {
                    width: 78px;
                    height: 78px;
                    margin-right: 18px;
                }
                .actives-content {
                    width: 245px;
                    overflow: hidden;
                    .actives-title {
                        display: -webkit-box;
                        word-break: break-all;
                        width: 100%;
                        font-size: 14px;
                        height: 40px;
                        line-height: 20px;
                        color: #333333;
                        overflow: hidden; //一定要写
                        text-overflow: ellipsis; //超出省略号
                        -webkit-line-clamp: 2; //控制行数
                        -webkit-box-orient: vertical; //一定要写
                    }
                    .actives-des {
                        overflow: hidden;
                        margin-top: 14px;
                        .gift {
                            color: #9975F3;
                            line-height: 22px;
                            text-align: center;
                            width: 67px;
                            height: 22px;
                            font-size: 14px;
                            border-radius: 13px;
                            border: 0.5px solid #9975F3;
                            float: left;
                            font-size: 14px;
                        }
                        .inter {
                            float: right;
                            font-size: 14px;
                            line-height: 30px;
                            color: #9975F3;
                        }
                    }
                }
            }
            .label {
                padding: 16px 0;
                overflow: hidden;
                .actives-time {
                    color: #999999;
                    font-size: 14px;
                    float: left;
                    line-height: 24px;
                    span{
                        font-weight: 200
                    }
                }
                .actives-status {
                    border-radius: 2px;
                    color: #fff;
                    background: #9975F3;
                    float: right;
                    width: 72px;
                    height: 28px;
                    font-size: 14px;
                    line-height: 28px;
                    text-align: center;
                }
            }
        }
        .actives-item.gray {
            background: rgba(0, 0, 0, 0.15);
            .actives-info {
                border-bottom: 1px solid #CACACA;
                .actives-des {
                    .gift {
                        color: rgba(119, 199, 198, 0.8);
                        border: 1px solid rgba(119, 199, 198, 0.8);
                    }
                }
            }
            .label {
                .actives-status {
                    background: rgba(0, 0, 0, 0.4);
                    color: rgba(255, 255, 255, 0.4);
                }
            }
        }
    }
    .actives-con ul li {
        cursor: pointer;
    }
    .actives-detail {
        color: #fff;
        border-radius: 12px;
        width: 52px;
        height: 24px;
        border: solid 1px #9975F3;
        background: #9975F3;
        padding-left: 4px;
        padding-right: 4px;
        line-height: 24px;
        display: block;
        float: right;
        text-align: center;
        cursor: pointer;
    }
    .btn-clear {
        z-index: 10;
        width: 15px;
        height: 16px;
        padding: 9.5px;
        position: absolute;
        top: 50%;
        right: 15px;
        transform: translateY(-50%);
        font-size: 15px;
    }
    .search-btn {
        text-align: left;
        line-height: 50%;
        .search-btn-wrap {
            background-color: #ffffff;
            border-radius: 4px;
        }
        .icon-search {
            position: absolute;
            top: 50%;
            left: 15%;
        }
        .search-input {
            padding-left: 30px;
        }
        .active-search-input {
            height: 38px;
            line-height: 28px;
            width: 90%;
            background: #ffffff;
            display: inline-block;
            padding-left: 30px;
            background-color: #ffffff;
        }
    }
}
.blockPage_img {
    padding: 100px 0 !important;
    padding-bottom: 80px !important;
}
.blockPage_text {
    font-size: 15px !important;
    color: #333333 !important;
}
.loginPage {
    position: absolute;
    top: 0;
    height: 10px;
}
.openPage {
    height: 20vh;
    position: relative;
    display: flex;
    padding: 8.5vh 8px;
    box-sizing: border-box;
    .line {
        flex: 1;
        height: 0.5px;
        background: #cacaca;
        flex: 1;
        position: relative;
        top: 10px;
    }
    .text {
        flex: 3;
        font-size: 14px;
        text-align: center;
        color: #444444;
        .open {
            color: #9975F3;
            text-decoration: underline;
            margin-left: 3px;
        }
    }
}
.tipPage {
    height: 80vh;
    width: 100%;
    background: #ffffff;
    position: relative;
    .blockPage{height:auto!important;}
}
.goIntegral {
    color: #9975F3;
    text-decoration: underline;
    text-align: center;
    margin-top: 15px;
    width: 100%;
}
.allPage {
    background: #ffffff !important;
}
.grayBox{margin-top:-5px;}
</style>
