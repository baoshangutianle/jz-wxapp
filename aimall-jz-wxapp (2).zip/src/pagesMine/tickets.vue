<template>
    <div class="tickets-container">
        <ul>
            <li
                v-for="(item,index) in data"
                :key="index"
                class="flex-wrp tickets-item"
            >
                <span class="flex-item tickets-icon-wrap">
                    <div>
                        <img
                            :src="picPrex+item.pic"
                            class="tickets-icon"
                            alt="状态图片"
                        >
                    </div>
                    <div
                        v-if="item.auditStatus == '2'"
                        class="tickets-text"
                    >积分失败</div>
                    <div v-else-if="item.auditStatus == '0'"
                        class="tickets-text"
                    >等待审核</div>
                    <div v-else class="tickets-text">
                        积分成功
                    </div>
                </span>
                <span class="flex-item tickets-flow-wrap">
                    <div class="tickets-flow">
                        <ul>
                            <li class="tickets-status-audit">上传时间:</li>
                            <li class="tickets-status-time">{{ item.createTime }}</li>
                            <li
                                v-if="item.auditStatus!='2' && item.auditStatus!='0'"
                                :class="['tickets-status-audit','status-'+item.auditStatus]"
                            >{{ item.auditStatus=='2'?'积分失败':item.auditStatus=='0'?'等待审核':'积分成功' }}:</li>
                            <li
                                v-if="item.auditStatus!='2' && item.auditStatus!='0'"
                                class="tickets-status-time2"
                            >{{ item.auditTime }}</li>
                            <li
                                v-if="item.auditStatus=='2'"
                                :class="['tickets-status-audit','status-'+item.auditStatus]"
                            >积分失败:</li>
                            <li
                                v-if="item.auditStatus=='2'"
                                class="tickets-status-time2"
                            >{{ item.auditTime }}</li>
                        </ul>
                    </div>
                </span>
                <span class="flex-item btn-wrap">
                    <button
                        class="btn-detail"
                        @tap="getDetail(item)"
                    >查看详情</button>
                </span>
            </li>
        </ul>
        <!-- 无数据显示提示图片 -->
        <div v-if="hasFetchData&&data.length===0">
            <block-page :type="typeText" />
        </div>
        <div v-show="reachFinish">
            <load-more />
        </div>
        <!-- 模态框 -->
        <div
            v-show="isPreviewShow"
            catchtouchmove="preventTouchMove"
            class="value-point-mask"
        >
            <div class="value-point-mask-con">
                <div class="fail-con">
                    <div>
                        <div class="fail-name">
                            <!-- <img class="icon-fail-info" src="/static/images/icon-tickets-info@2x.png" alt="提示图标"> -->
                            <!-- {{ detail.auditStatusDes }} -->
                            <span v-if="detail.auditStatus == '2'">积分失败</span>
                            <span v-else-if="detail.auditStatus == '0'">等待审核</span>
                            <span v-else>积分成功</span>
                        </div>
                        <div
                            v-if="detail.remark"
                            class="fail-text"
                        >
                            {{ detail.remark }}
                        </div>
                    </div>

                </div>
                <img
                    :src="detail.imgUrl"
                    class="value-point-mask-pic"
                    mode="aspectFit"
                    alt="图片"
                >
            </div>
            <div
                class="value-point-mask-close"
                @click="closePreview()"
            >
                <img src="/static/images/point-close.png">
            </div>
        </div>
    </div>
</template>

<script>
import api from '@/plugins/api'
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils';
import loadMore from '@/components/loadMore'
import blockPage from '@/components/blockPage'
export default {
    components: {
        loadMore,
        blockPage
    },
    data() {
        return {
            data: [],
            page: {
                pageNum: 1,
                pageSize: 10,
                total: 0
            },
            loaderMore: false,
            isDataFinish: false, // 数据加载完成状态
            picPrex: '/static/images/',//图片前缀
            isPreviewShow: false,
            detail: {},
            isDataList: false,
            typeText: '小票',
            reachFinish: false,
            hasFetchData: false //拉取数据状态
        }
    },
    mounted() {
        this.resetRefresh()
    },
    methods: {
        closePreview() {
            this.isPreviewShow = false
        },
        getDetail(item) {
            let vm = this
            vm.detail = item
            vm.isPreviewShow = true
        },
        getData(times) {
            this.hasFetchData = false
            return new Promise(resolve => {
                this.loaderMore = true
                this.reachFinish = false
                let params = Object.assign({}, {
                    memberCode: wxUtils.getUserCodeStorage()
                }, this.page)
                delete params.total
                let requestOptions = {
                    path: api.getIntegralRecord,
                    method: 'post',
                    data: params
                }
                request(requestOptions).then(res => {
                    this.hasFetchData = true
                    let { list, total } = res.data
                    this.page.total = total
                    let limitTime = 16
                    list.map(item => {
                        item.createTime = item.createTime ? item.createTime.substr(0, limitTime) : ""
                        item.auditTime = item.auditTime ? item.auditTime.substr(0, limitTime) : ""
                        item.pic = item.auditStatus == 0 ? 'icon-tickets-audit@2x.png' :
                            (item.auditStatus == 1 || item.auditStatus == 3) ? 'icon-tickets-pass@2x.png' : 'icon-tickets-fail@2x.png'
                    })
                    if (times == 1) {
                        this.data = list
                    } else {
                        this.data = this.data.concat(list)
                    }
                    if (this.data.length == 0) {
                        this.isDataList = false;
                        this.reachFinish = false
                    } else {
                        this.isDataList = true;
                    }

                    //数据加载结束
                    let receivedNum = (this.page.pageNum - 1) * this.page.pageSize + this.data.length
                    if (receivedNum >= this.page.total) {
                        this.isDataFinish = true
                    }

                    this.loaderMore = false
                }).catch(err => {
                    this.loaderMore = false
                })
            })
        },
        resetRefresh() {
            this.loaderMore = true
            this.data = []
            this.page.pageNum = 1
            this.isDataFinish = false
            this.getData(1)
        },
        //防止底层view滑动
        preventTouchMove(e) {
            return
        },
    },
    onUnload() {
        this.hasFetchData = false
        this.isPreviewShow = false
    },
    // 页面滚动到底部
    onReachBottom() {
        if (!this.isDataFinish && !this.loaderMore) {
            this.page.pageNum++
            this.getData()
        } else {
            if (this.data.length > 6) {
                this.reachFinish = true
            } else {
                this.reachFinish = false
            }
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.tickets-container {
    color: @black-color;
    .tickets-item {
        margin: 10px 15px 0;
        padding: 10px 10px 10px 15px;
        box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
        border-radius: 4px;
        // height: 100px;
        .tickets-icon-wrap {
            overflow: hidden;
            flex: 0 1 20%;
            padding-right: 15px;
            text-align: center;
            padding-top: 20px;
            .tickets-icon {
                display: inline-block;
                width: 30px;
                height: 30px;
            }
            .tickets-text {
                margin-top: 4px;
                font-size: 15px;
            }
        }
        .tickets-flow-wrap {
            flex: 1;
            .tickets-flow {
                overflow: hidden;
                display: flex;
                align-items: center;
                position: relative;
                height: 100%;
                padding-left: 14px;
                font-size: 12px;
                color: @black-color;
                .tickets-status-audit {
                    position: relative;
                    padding-left: 10px;
                    color: #cecece;
                    &:before {
                        position: absolute;
                        left: 0;
                        top: 50%;
                        transform: translateY(-50%);
                        display: inline-block;
                        content: '';
                        width: 5px;
                        height: 5px;
                        margin-right: 4px;
                        background: #cecece;
                        border-radius: 50%;
                    }
                    &:last-child {
                        color: @black-color;
                        &:before {
                            background: @gray-color;
                        }
                    }
                    &.status-1,
                    &.status-3 {
                        &:before {
                            background: @theme-color;
                        }
                    }
                    &.status-2 {
                        &:before {
                            background: @pink-color;
                        }
                    }
                    & + li {
                        margin-top: 15px;
                    }
                }
                &:before {
                    position: absolute;
                    top: 0px;
                    bottom: 0px;
                    left: 0;
                    display: inline-block;
                    content: '';
                    width: 1px;
                    background: @line-color;
                }
            }
            .tickets-status-audit2 {
                color: @black-color !important;
            }
        }
        .btn-wrap {
            flex: 0 1 auto;
            display: flex;
            align-items: center;
            justify-content: center;
            .btn-detail {
                padding: 4px 11px;
                line-height: initial;
                background: transparent;
                border: 1px solid @theme-color;
                color: @theme-color;
                font-size: 15px;
                border-radius: 15px;
                &:active {
                    opacity: 0.8;
                }
            }
        }
    }
    .value-point-mask {
        box-sizing: border-box;
        z-index: 2;
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: rgba(0, 0, 0, 0.7);
        text-align: center;
        overflow: hidden;
        .value-point-mask-close {
            padding-top: 26px;
            image {
                display: inline-block;
                width: 30px;
                height: 30px;
                &:active {
                    opacity: 0.8;
                }
            }
        }
        .value-point-mask-con {
            position: relative;
            display: flex;
            flex-direction: column;
            width: 90vw;
            margin: 0 auto;
            background: #fff;
            margin-top: 10vh;
            height: 75vh;
            border-radius: 6px;
            .fail-con {
                overflow: hidden;
                padding-top: 25px;
                color: #333333;
                text-align: center;
                .fail-name {
                    // display: flex;
                    // align-items: center;
                    // justify-content: flex-start;
                    text-align: center;
                    font-size: 15px;
                    font-size: 18px;
                    color: #333333;
                    padding-bottom: 15px;
                    .icon-fail-info {
                        display: inline-block;
                        width: 20px;
                        height: 20px;
                        margin-right: 4px;
                    }
                }
                .fail-text {
                    font-size: 15px;
                    color: #333333;
                    font-weight: 200;
                    padding-bottom: 15px;
                }
            }
            .value-point-mask-pic {
                height: 90%;
                border: solid 1px #e7e7e7;
                margin: 15px auto;
                margin-top: 0px;
            }
            .btn-upload {
                height: 44px;
                line-height: 44px;
                margin: 35px 50px 0;
                font-size: 15px;
            }
            .btn-photo {
                display: inline-block;
                margin: 30px 0 60px;
                font-size: 15px;
                color: @theme-color;
            }
        }
    }
    .tickets-status-time {
        color: rgba(206, 206, 206, 1);
        margin-top: 3px !important;
        padding-bottom: 12px;
    }
    .tickets-status-time2 {
        color: #333333;
        margin-top: 3px !important;
    }
}
</style>
