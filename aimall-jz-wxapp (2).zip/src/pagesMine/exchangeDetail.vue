<template>
    <div class="exchange-detail-container">
        <div class="card-detail-main">
            <div class="card-detail-con">
                <div class="card">
                    <div class="card_con">
                        <div class="card_img">
                            <img :src="detailData.thumbnail"/>
                        </div>
                        <div class="card_info">
                            <p class="card_title">{{detailData.prodName}}</p>
                            <div class="card_type">
                                <span class="type_span" v-if="detailData.couponType == 1">现金券</span>
                                <span class="type_span" v-if="detailData.couponType == 2">满减券</span>
                                <span class="type_span" v-if="detailData.couponType == 3">满减券</span>
                                <span class="type_span" v-if="detailData.couponType == 4">停车券</span>
                                <span class="type_span" v-if="detailData.couponType == 5">积分券</span>
                                <span class="type_span" v-if="detailData.couponType == 6">礼品券</span>
                                <span class="card_intall">{{detailData.useIntegral}}积分</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card_time">
                    <div class="times">
                        <span class="times">使用时间: {{detailData.exchangeStartTime}}-{{detailData.exchangeEndTime}}</span>
                    </div>
                    <div class="times_btn">
                        <!-- <button class="time_btn" @click="goToDetail">查看详情</!-->
                    </div>
                </div>
            </div>

            <div
                class="card-code-wrap"
                v-if="detailData.couponType != '4'"
            >

                <div class="card-qrcode-wrap">
                    <div class="card-qrcode">
                        <qrcode-comp
                            :data="qrCode"
                            width="274"
                            height="274"
                        />
                    </div>
                </div>
                <div class="card-code">
                    券号：{{ couponCode }}
                </div>
            </div>

            <div class="coupon-rule-wrap">
                <p>
                    <span class="line"></span>
                    <span class="text">使用须知</span>
                </p>
                <div class="exchange_remark">
                    <span v-html="detailData.usageRule"></span>
                    <!-- <p>1.门店扫码使用</p>
                    <p>2.兑换成功后在"我的"-"我的卡券"内查看</p>
                    <p>3.请到麦麦山云南呢菜门店出示卡券使用</p> -->
                </div>
            </div>
        </div>
        <canvas
            style="margin-top:100px;width: 686rpx;height: 686rpx;background:#f1f1f1;opacity:0;"
            canvas-id="mycanvas"
        />
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import api from '@/plugins/api'
import moment from 'moment'
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils';
import CardItem from '@/components/CardItem';
import QrcodeComp from '@/components/QrcodeComp'
import CouponRule from '@/components/CouponRule'
export default {
    components: {
        CardItem,
        QrcodeComp,
        CouponRule
    },
    data() {
        return {
            qrCode: '',
            couponId: '',
            couponBatchId: '',
            couponCode: '',
            detailData: {},
            id: '',
            prodId:''
        }
    },
    computed: {
        ...mapState(['wxUserInfo','vipInfo'])
    },
    methods: {
        getDeatilInfo() {
            if(this.id){
                let opsiton = { path: api.getIntegralOrder +"/" + this.id }
                request(opsiton).then(res => {
                    if (res.code == 200) {
                        this.prodId = res.data.prodId
                        res.data.usageRule = res.data.usageRule ? res.data.usageRule.replace(/\n/g, '<br>') : ''
                        this.integralProdDetail = res.data.integralProdDetailVO ? res.data.integralProdDetailVO.detail :''
                        //判断是否授权登录
                        if(this.wxUserInfo && this.wxUserInfo != ''){
                            this.cardName = res.data.integralGradeName ? res.data.integralGradeName :'尊享普卡'
                        }else {
                            this.cardName = '尊享普卡'
                        }
                        //判断用户是否可以兑换
                        if(res.data.availableIntegral){
                            if(res.data.availableIntegral >= res.data.integral){
                                this.available = true
                            }else if(res.data.integral == '0' || !res.data.integral){ //当为免费兑换时
                                this.available = true
                            }else{
                                this.available = false
                            }
                        }else{
                            //当为免费兑换时
                            if(res.data.integral == '0' || !res.data.integral){
                                this.available = true
                            }else {
                                this.available = false
                            }
                        }
                        this.qrCode = res.data.couponCode
                        res.data.exchangeStartTime = moment(res.data.exchangeStartTime).format('YYYY.MM.DD')
                        res.data.exchangeEndTime = moment(res.data.exchangeEndTime).format('YYYY.MM.DD')
                        this.couponCode = res.data.couponCode.slice(0, 4) + '****'+res.data.couponCode.slice(-4)
                        this.detailData = res.data
                    }
                })
            }
        },
        goToDetail(){
            wx.navigateTo({
                url: `/pages/integralMall/detail?id=${this.prodId}`
            })
        }
    },
    onLoad() {
    },
    onShow() {
        this.id = this.$root.$mp.query.id
        this.getDeatilInfo();
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.exchange-detail-container {
    color: @black-color;
    height: 100vh;
    overflow: hidden;
    background: #F4F4F4;
    .card-detail-main {
        height: 100vh;
        overflow: auto;
    }
    .card-detail-con{

        background: #ffffff;
        padding: 0 15px;
    }
    .card {
        overflow: hidden;
        padding-bottom: 18px;
        border-bottom: solid 1px #F0F0F0;
        .card_con{
            display: flex;
            padding-top: 15px;
        }
        .card_img{
            width: 78px;
            height: 78px;
            img{
                width: 78px;
                height: 78px;
            }
        }
        .card_info{
            padding-left: 18px;
            height: 78px;
            width: 100%;
            position: relative;
        }
        .card_title{
            color: #333333;
            font-size: 14px;
             display: -webkit-box;
            word-break: break-all;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .card_type{
            padding-top: 17px;
            display: flex;
            position: absolute;
            z-index: 99;
            bottom: 0px;
            width: 100%;
        }
        .type_span{
            display: inline-block;
            font-size: 14px;
            color: #ED8C5A;
            border-radius: 11px;
            padding: 1px 12px;
            border: solid 1px #ED8C5A;
            font-weight: 200;
        }
        .card_intall{
            flex: 1;
            color: #9975F3;
            text-align: right;
            float: right;
            margin-right: 30px;
        }
    }
    .card_time{
        overflow: hidden;
        height: 65px;
        line-height: 65px;
        .times{
            color: #999999;
            font-size: 14px;
            float: left;
            font-weight: 200;
        }
        .times_btn{
            float: right;
            text-align: right;
            padding-top: 15px;
            padding-bottom: 15px;
        }
        .time_btn{
            background: #9975F3;
            width: 72px;
            color: #fff;
            border-radius: 4px;
            font-size: 14px;
            height: 28px;
            line-height: 28px;
            padding: 0;
        }
    }
    .card-code-wrap {
        text-align: center;
        border-bottom: 0.5px solid #D8D8D8;
        .card-code {
            font-size: 14px;
            color: #333333;
            padding-bottom: 24px;
        }
        .card-qrcode-wrap{
            width: 186px;
            height: 186px;
            margin: 37px 0px 24px;
            background: #DCDCDC;
            display: inline-block;
        }
        .card-qrcode {
            display: inline-block;
            width: 174px;
            height: 174px;
            padding-top: 6px
        }
    }

    .coupon-rule-wrap {
        margin-bottom: 48px;
        padding: 19px 15px;
        .line{
            width: 2px;
            height: 10px;
            background: #9975F3;
            display: inline-block;
        }
        .text{
            color: #333333;
            font-size: 15px;
            padding-left: 6px;
        }
        .exchange_remark{
            padding-top: 10px;
            color: #666666;
            font-size: 14px;
            padding-left: 6px;
            font-weight: 200;
            span{
                font-weight: 200;
            }
        }
    }
}
</style>
