<template>
    <div id="listOfActivities">
        <div class="listOfActivities">
            <ul class="flex-wrp tabs">
                <li class="flex-item tab">
                    <span
                        :class="{'active':currTab=='food'}"
                        @tap="currTab='food'"
                    >
                        店铺
                    </span>
                </li>
                <li class="flex-item tab">
                    <span
                        :class="{'active':currTab=='article'}"
                        @tap="currTab='article'"
                    >
                        文章
                    </span>
                </li>
            </ul>

            <div class="activity-content">
                <scroll-view
                    v-if="currTab=='food'"
                    :style="{'height': '100%'}"
                    class="brand_list"
                    scroll-y
                    lower-threshold="100"
                >
                    <ul>
                        <collect-food :data="foods" :isExpired="isExpired"/>
                    </ul>
                    <div v-if="hasFetchData&&foods.length===0">
                        <block-page :type="foodsText" />
                    </div>
                    <load-more v-if="reachFinish" />
                </scroll-view>
                <scroll-view
                    v-if="currTab=='article'"
                    :scroll-y="true"
                    :style="{'height': '100%'}"
                    class="actives-con"
                    lower-threshold="100"
                    @scrolltolower="scrollToLower"
                >
                    <ul>
                        <collect-article :data="articles" :isExpiredArticle ="isExpiredArticle"/>
                    </ul>
                    <div v-if="hasFetchData&&articles.length===0">
                        <block-page :type="articlesText" />
                    </div>

                    <load-more v-if="reachFinishArticle" />
                </scroll-view>
            </div>
        </div>
    </div>
</template>

<script>
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import CollectFood from '@/components/CollectFood'
import CollectArticle from '@/components/CollectArticle'
import wxUtils from '@/plugins/wxUtils';
import blockPage from '@/components/blockPage'
import loadMore from '@/components/loadMore'

export default {
    components: {
        CollectFood,
        CollectArticle,
        blockPage,
        loadMore
    },

    data() {
        return {
            currTab: 'food',
            articles: [],
            foods: [],
            loadingMore: false,
            page: {//分页信息
                pageNo: 1,
                pageSize: 10
            },
            isFoodList: false,
            isArticleList: false,
            foodsText: '店铺',
            articlesText: '文章',
            reachFinish: false,//是否显示底线
            reachFinishArticle: false,//是否显示底线
            hasFetchData: false, //拉取数据状态
            isDeleteFood: false,
            isDeleteArticle: false,
            isExpired: false,
            isExpiredArticle: false,
            slideButtons: [{
              type: 'warn',
              text: '删除',
              extClass: 'test',
              src: '', // icon的路径
            }]
        }
    },
    watch: {
        currTab() {
            //回到顶部
            wx.pageScrollTo({
                scrollTop: 0
            })
            this.resetRefresh()
        }
    },
    onShow(){
        this.resetRefresh()
    },
    mounted() {
        this.resetRefresh()
    },
    methods: {
        getFood(times) {
            this.hasFetchData = false
            this.loadingMore = false
            let userCode = wxUtils.getUserCodeStorage()
            let params = Object.assign({}, { userCode }, this.page)
            let requestOptions = {
                path: api.getMyCollectFood,
                method: 'get',
                data: params,
                hideLoading: false
            }
            request(requestOptions).then(res => {
                this.hasFetchData = true
                const t = this;
                let list = res.data.records
                if (list) {
                    list.forEach(function(item, key) {
                        if (item.userTag) {
                            t.$set(item, 'tags', item.userTag.split(','))
                        }
                        item.textStyle = "";
                        item.textStyle1 = "";
                        if(item.isDelete){
                            t.isExpired = true
                        }
                        item.txtStyle = ''
                    })
                    if (times != 1) {
                        t.foods = t.foods.concat(list)
                    } else {
                        t.foods = list
                    }
                    t.loadingMore = true;
                    this.reachFinish = false
                    t.isFoodList = true;
                } else {
                    t.foods = []
                    if(t.isDeleteFood){
                        t.isExpired = false
                    }
                    if (this.page.pageNo == 1) {
                        t.isFoodList = false;
                    }
                }

            })
        },
        getArticle(times) {
            this.hasFetchData = false
            this.loadingMore = false
            let userCode = wxUtils.getUserCodeStorage()
            let params = Object.assign({}, { userCode }, this.page)

            let requestOptions = {
                path: api.getMyCollectArticle,
                method: 'get',
                data: params
            }

            request(requestOptions).then(res => {
                this.hasFetchData = true
                let list = res.data.records
                if (list) {
                    console.log('我进list')
                    list.map(item => {
                        var limit = 28
                        if (item.title && item.title.length > limit) {
                            item.title = item.title.substr(0, limit) + '...'
                        }
                        limit = 10
                        if (item.subtitle && item.subtitle.length > limit) {
                            item.subtitle = item.subtitle.substr(0, limit) + '...'
                        }
                        limit = 10
                        if (item.author && item.author.length > limit) {
                            item.author = item.author.substr(0, limit) + '...'
                        }
                        if(item.contentStatus !=2 && item.contentStatus !=4){
                            this.isExpiredArticle = true
                        }
                        item.textStyle = "";
                        item.textStyle1 = "";
                        item.txtStyle = ''
                        return item
                    })
                    if (times != 1) {
                        this.articles = this.articles.concat(list)
                    } else {
                        this.articles = list
                    }
                    this.loadingMore = true
                    this.reachFinishArticle = false
                    this.isArticleList = true
                } else {
                    if(!this.isDeleteArticle){
                        this.articles = []
                        this.isExpiredArticle = false
                    }
                    if (this.page.pageNo == 1) {
                        this.isArticleList = false
                    }
                }
            })
        },
        getData(times) {
            if (this.currTab == 'food') {
                this.getFood(times)
            } else {
                this.getArticle(times)
            }
        },
        goFoodDetail(item) {
            let type = 1
            wx.navigateTo({
                url: `/pages/restaurant/detail?id=${item.id}&type=${type}`
            })
        },
        goArticleDetail(item) {
            let { putPosition } = item
            let url
            if (putPosition == 2) {//热门活动
                url = `/listOfActivities/details?id=${item.id}`
            } else if (putPosition == 1) {//潮逛指南
                url = `/pages/guide/details?id=${item.id}&type=${item.putType}`
            }
            wx.navigateTo({
                url
            })
        },
        resetRefresh() {
            this.loadingMore = true
            this.page.pageNo = 1
            this.isDeleteFood = false
            this.isDeleteArticle = false
            this.isExpired = false
            this.isExpiredArticle = false
            this.getData(1)
        },

    },
    // 页面滚动到底部
    onReachBottom() {
        this.isDeleteFood = false
        this.isDeleteArticle = false
        if (this.loadingMore) {
            this.page.pageNo++
            this.getData()
            if (this.foods.length > 10 && this.currTab == 'food') {
                this.reachFinish = true
            } else {
                this.reachFinish = false
            }
            if (this.articles.length > 10 && this.currTab == 'article') {
                this.reachFinishArticle = true
            } else {
                this.reachFinishArticle = false
            }
        } else {
            if (this.foods.length > 5 && this.currTab == 'food') {
                this.reachFinish = true
            } else {
                this.reachFinish = false
            }
            if (this.articles.length > 5 && this.currTab == 'article') {
                this.reachFinishArticle = true
            } else {
                this.reachFinishArticle = false
            }
        }
    },
    onUnload() {
        this.hasFetchData = false
    },
    // 下拉刷新
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
        this.resetRefresh()
    },
}
</script>

<style lang="less">
@import '../assets/styles/vars';
page {
    height: 100%;
}
#listOfActivities {
    height: 100%;
    min-height: 100vh;
    // display: flex;
    // flex-direction: column;
    .listOfActivities{
        position: relative;
    }
    .tabs {
        z-index: 99;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: #fff;
        border-bottom: 1px solid #ddd;
    }
    .activity-content {
        background: #fff;
        flex: 1;
        display: flex;
        flex-direction: column;
        // border-top: 1px solid #ddd;
        padding-top: 70px;
        .collect-food-item {
            margin: 0 17px;
            border-bottom: 1px solid @border-color;
            padding: 10px 0;
            &:last-child {
                border: 0;
            }
        }
        .filter-box {
            height: 50px;
        }
        .actives-con {
            flex: 1;
            height: 100%;
            overflow-y: auto;
        }
    }
    .actives-list {
        min-height: 100vh;
        background: #ffffff;
    }
    .actives-con {
        padding: 0px;
        width: 100%;
        box-sizing: border-box;
    }
    .actives-con ul li:nth-child(1) {
        padding-top: 0px;
    }
    .actives-con ul li {
        padding-top: 28px;
        height: 80px;
        border-bottom: 1px solid #eff1f8;
        cursor: pointer;
        display: flex;
    }
    .actives-con ul li:last-child {
        border-bottom: none;
    }
    .actives-time {
        font-size: 12px;
        color: #999999;
    }
}
</style>
