<template>
    <div id="myIndex">
        <ul class="user-operate">
            <li class="myApply myApply-avator">
                <span class="input-label">头像</span>
                <span
                    class="input-val flex-item-arrow"
                    @click="selectImg"
                >
                    <div class="user-avator">
                        <img
                            :src="userForm.avatarUrl"
                            mode="scaleToFill"
                            alt=""
                        >
                    </div>
                    <img
                        class="arrow"
                        src="/static/images/arrow_right.png"
                    >
                </span>
            </li>
            <li class="myApply">
                <span class="input-label">昵称</span>
                <span class="input-val user-name">
                    <input
                        :value="userForm.memberName"
                        type="text"
                        @blur="memberNameChange"
                    >
                    <img
                        class="arrow"
                        src="/static/images/arrow_right.png"
                    >
                </span>
            </li>
            <li class="myApply">
                <span class="input-label">性别</span>
                <span class="input-val">
                    <picker
                        :value="index"
                        :range="senderSource"
                        style="position: absolute;left:0;top:0;bottom: 0;text-align: right;width: 100%"
                        class="picker picker-marry"
                        @change="senderChange"
                    >
                        <view style="position: absolute;left:0;top:0;text-align: right;width: 100%;bottom: 0;display: flex;align-items: center;justify-content: flex-end;">
                            {{ (userForm.sex==0||userForm.sex)?senderSource[userForm.sex]:'' }}
                            <img
                                class="arrow"
                                src="/static/images/arrow_right.png"
                            >
                        </view>
                    </picker>
                </span>
            </li>
            <li class="myApply">
                <span class="input-label">所在城市</span>
                <span class="input-val">
                    <picker
                        :value="region"
                        style="position: absolute;left:0;top:0;bottom: 0;text-align: right;width: 100%"
                        mode="region"
                        @change="bindRegionChange"
                    >
                        <view
                            style="position: absolute;left:0;top:0;text-align: right;width: 100%;bottom: 0;display: flex;align-items: center;justify-content: flex-end;"
                            class="picker"
                        >
                            {{ region.length>0?(region[0]+region[1]+region[2]):'' }}
                            <img
                                class="arrow"
                                src="/static/images/arrow_right.png"
                            >
                        </view>
                    </picker>
                </span>
            </li>
            <li class="myApply">
                <span class="input-label">生日
                    <span class="input-remark">暂不支持修改，请谨慎填写</span>
                </span>
                <span class="input-val" v-if="!isBirthday">
                    <picker
                        :value="index"
                        style="position: absolute;left:0;top:0;bottom: 0;text-align: right;width: 100%"
                        mode="date"
                        class="picker picker-marry"
                        @change="birthdayChange"
                    >
                        <view style="position: absolute;left:0;top:0;text-align: right;width: 100%;bottom: 0;display: flex;align-items: center;justify-content: flex-end;">
                            {{ userForm.birthday?userForm.birthday:'' }}
                            <img
                                class="arrow"
                                src="/static/images/arrow_right.png"
                            >
                        </view>
                    </picker>
                </span>
                <span class="input-val" v-else @click="remarkBtn">
                    <view style="position: absolute;left:0;top:0;text-align: right;width: 100%;bottom: 0;display: flex;align-items: center;justify-content: flex-end;">
                        {{ userForm.birthday?userForm.birthday:'' }}
                        <img
                            class="arrow"
                            src="/static/images/arrow_right.png"
                        >
                    </view>
                </span>
            </li>
            <li class="myApply">
                <span class="input-label">情感状况</span>
                <span class="input-val">
                    <picker
                        :value="index"
                        :range="marrySource"
                        style="position: absolute;left:0;top:0;bottom: 0;text-align: right;width: 100%"
                        class="picker picker-marry"
                        @change="marryChange"
                    >
                        <view style="position: absolute;left:0;top:0;text-align: right;width: 100%;bottom: 0;display: flex;align-items: center;justify-content: flex-end;">
                            {{ userForm.maritalStatus==0||userForm.maritalStatus?marrySource[''+userForm.maritalStatus]:'' }}
                            <img
                                class="arrow"
                                src="/static/images/arrow_right.png"
                            >
                        </view>
                    </picker>
                </span>
            </li>
            <li class="myApply myApply-hobbits">
                <span class="myApply-hobbits-name">业余爱好</span>
                <span class="myApply-hobbits-val">
                    <ul class="edit-tags">
                        <li
                            v-for="(item,index) in tags"
                            :key="index"
                            class="edit-tag-wrap"
                        >
                            <div>
                                <span
                                    :class="{active:currTag[item.id]}"
                                    @click="clickTag(item)"
                                >
                                    {{ item.tagName }}
                                </span>
                                <!-- <input type="checkbox" name="hobbit" :id="item.id" :checked="selTags[item.id]">
                                <label :for="item.id" @tap="tagChange(item)">{{item.tagName}}</label> -->
                                <!-- <input type="checkbox" name="hobbit" :id="item.id">
                                <label :for="item.id">{{item.tagName}}</label> -->
                            </div>
                        </li>
                    </ul>
                </span>
            </li>
        </ul>
        <button
            class="btn-operate btn-save"
            @click="save"
        >保 存</button>
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import request from '@/plugins/request'
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import wxUtils from '@/plugins/wxUtils'
export default {
    components: {

    },
    data() {
        return {
            currTag: {},
            userForm: {
                memberCode: '',
                memberName: '',
                memberId: '',
                avatarUrl: '',
                sex: '',
                provinceCode: '',
                province: '',
                cityCode: '',
                city: '',
                hasBaby: 0,
                address: '',
                districtCode: '',
                district: '',
                birthday: '',
                maritalStatus: '',
                memberInterestTagVoList: []

            },
            isBirthday: false,
            region: [],
            tags: [],
            marrySource: ["未婚", "已婚", "保密"],
            senderSource: ["男", "女", "保密"],
            activeTag: '',
            selTags: {},
            rules: {
                avatarUrl: [{
                    required: true,
                    msg: '头像不可为空'
                }],
                memberName: [{
                    required: true,
                    msg: "昵称不可为空"
                }, {
                    max: 30,
                    min: 1,
                    msg: "昵称可填1-30字节"
                }],
                sex: [{
                    required: true,
                    msg: "性别不可为空"
                }],
                districtCode: [{
                    required: true,
                    msg: "所在城市不可为空"
                }],
                birthday: [{
                    required: true,
                    msg: "生日不可为空"
                }],
                maritalStatus: [{
                    required: true,
                    msg: "情感状况不可为空"
                }]
            }
        }
    },
    computed: {
        ...mapState(['isVip', 'vipInfo', 'wxUserInfo', 'vipAvatar']),
    },
    onLoad(){

    },
    mounted() {
        let vm = this
        vm.getAllTags()

        vm.simpleCopy(vm.userForm, vm.vipInfo)
        if (vm.userForm.province) {
            vm.regionCode = [vm.userForm.provinceCode, vm.userForm.cityCode, vm.userForm.districtCode]
            vm.region = [vm.userForm.province, vm.userForm.city, vm.userForm.district]
        }

        var selTags = {};
        vm.userForm.avatarUrl = vm.vipInfo.avatarUrl
        vm.userForm.memberInterestTagVoList.forEach(item => {
            selTags[item.interestTagId] = true
        })
        vm.selTags = selTags
        if(vm.userForm.birthday != '' && vm.userForm.birthday){
            vm.isBirthday = true
        }
    },
    methods: {
        ...mapMutations(["update"]),
        remarkBtn(){
            if(this.userForm.birthday!= '' && this.userForm.birthday!= null){
                wx.showToast({
                    title: '请到服务台修改',
                    icon: 'none',
                    duration: 2000
                })
            }

        },

        clickTag(data) {
            this.$set(this.currTag, data.id, !this.currTag[data.id])
        },
        simpleCopy(target, source) {
            for (var key in target) {
                if (source[key] == 0 || typeof source[key] != "undefined") {
                    target[key] = source[key]
                }
            }
        },
        memberNameChange(e) {
            let vm = this
            vm.userForm.memberName = e.target.value
        },
        tagChange(item) {
            let vm = this
            item.active = !item.active
            vm.selTags[item.id] = !vm.selTags[item.id]
        },
        selectImg() {
            let vm = this
            wx.chooseImage({
                count: 1,
                sizeType: ['original', 'compressed'],
                sourceType: ['album', 'camera'],
                success(res) {
                    // tempFilePath可以作为img标签的src属性显示图片
                    const tempFilePath = res.tempFilePaths[0]
                    vm.doUpload(tempFilePath)
                }
            })
        },
        doUpload(data) {
            let vm = this
            wx.uploadFile({
                url: api.uploadAvatar,
                filePath: data,
                name: 'file',
                header: {
                    'Content-Type': 'application/json',
                    Authorization: wxUtils.getSessionKeyStorage(),
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                formData: {},
                success(response) {
                    vm.userForm.avatarUrl = JSON.parse(response.data).data
                }
            })
        },
        senderChange(e) {
            this.userForm.sex = e.target.value
        },
        marryChange(e) {
            this.userForm.maritalStatus = e.target.value
        },
        birthdayChange(e) {
            this.userForm.birthday = e.target.value
        },
        bindRegionChange: function(e) {
            console.log('picker发送选择改变，携带值为', e.target.value)
            if (!e.target.code[0] || !e.target.code[1] || !e.target.code[2]) {
                wxUtils.showConfirmMsg("所在城市不可选全部")
                return false
            }
            this.region = e.target.value
            this.regionCode = e.target.code
            this.userForm.province = this.region[0]
            this.userForm.city = this.region[1]
            this.userForm.district = this.region[2]
            this.userForm.provinceCode = this.regionCode[0]
            this.userForm.cityCode = this.regionCode[1]
            this.userForm.districtCode = this.regionCode[2]
        },
        getAllTags() {
            let vm = this
            let params = {

            }
            let requestOptions = {
                path: api.getAllInterestTags,
                method: 'get',
                data: params
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    if (res.data) {
                        vm.tags = res.data
                    }
                } else {
                    let msg = res.message
                    wxUtils.showConfirmMsg(msg)
                }
            })
        },
        saveAvatar(cb) {
            let vm = this
            let params = {
                headImgUrl: vm.userForm.avatarUrl
            }
            let requestOptions = {
                path: api.saveAvatar + '/' + wxUtils.getPhoneStorage() + '?headImgUrl=' + vm.userForm.avatarUrl,
                method: 'post',
                data: {}
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    cb && cb.call(null)
                } else {
                    let msg = res.message
                    wxUtils.showConfirmMsg(msg)
                }
            })
        },
        saveBasic(cb) {
            let vm = this
            var memberInterestTagVoList = []
            for (let key in this.currTag) {
                if (this.currTag[key]) {
                    memberInterestTagVoList.push({
                        interestTagId: Number(key)
                    })
                }
            }
            let params = Object.assign({}, vm.userForm)
            params.memberCode = wxUtils.getUserCodeStorage()
            params.memberId = vm.vipInfo.id
            params.memberInterestTagVoList = memberInterestTagVoList
            params.provinceCode = vm.regionCode[0]
            params.province = vm.region[0]
            params.cityCode = vm.regionCode[1]
            params.city = vm.region[1]
            params.districtCode = vm.regionCode[2]
            params.district = vm.region[2]
            params.address = params.province + params.city + params.district
            params.hasBaby = 0
            let requestOptions = {
                path: api.savePerosnInfo,
                method: 'post',
                data: params
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    cb && cb.call(null)
                } else {
                    let msg = res.message
                    wxUtils.showConfirmMsg(msg)
                }
            })
        },
        isEmpty(value) {
            var result = false;
            if (!value) {
                result = true
            }
            if (Object.prototype.toString.call(value) == "[object Number]") {
                if (typeof value == "undefined") {
                    result = true
                }
            }

            if (Object.prototype.toString.call(value) == "[object String]") {
                if (value == "0") {
                    result = false
                }
            }

            if (Object.prototype.toString.call(value) == "[object Number]") {
                if (value == 0) {
                    result = false
                }
            }

            return result
        },
        checkFields() {
            let vm = this
            var result = true
            for (var key in vm.userForm) {
                var temp = vm.userForm[key]
                var rules = vm.rules[key]
                if (rules) {
                    for (var i = 0; i < rules.length; i++) {
                        var rule = rules[i]
                        if (rule.required && vm.isEmpty(temp)) {
                            wxUtils.showConfirmMsg(rule.msg)
                            result = false
                            break;
                        }
                        if (rule.min && temp.length < rule.min) {
                            wxUtils.showConfirmMsg(rule.msg)
                            result = false
                            break;
                        }
                        if (rule.max && temp.length > rule.max) {
                            wxUtils.showConfirmMsg(rule.msg)
                            result = false
                            break;
                        }
                    }
                    if (!result) {
                        break;
                    }
                }
            }
            return result
        },
        save() {
            let vm = this
            if (!vm.checkFields()) {
                return
            }
            vm.saveAvatar(function() {
                vm.saveBasic(function() {
                    vm.isBirthday = true
                    wx.showToast({ title: "保存成功" })
                    utils.getVipInfo().then(data => {
                        vm.update({
                            vipInfo: data
                        })
                        wx.navigateBack()
                    })
                })
            })
        }
    }
}
</script>

<style lang="less">
@import '../assets/styles/vars';
@import '../assets/styles/common';
#myIndex {
    width: 100vw;
    height: 100vh;
    overflow: auto;
    background-color: #fff;
    .user-avator {
        margin: 15px 0;
        display: inline-block;
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: gray;
        img {
            display: block;
            width: 100%;
            height: 100%;
            border-radius: 50%;
        }
    }
    .user-name {
        display: flex;
        align-items: center;
        input {
            flex: 1;
            text-align: right;
        }
    }
    .picker {
        width: 100%;
        height: 100%;
    }
    .btn-save {
        margin: 70px 15px 140px;
    }
    .setting-company {
        margin-top: 31px;
        font-size: 15px;
        color: @black-color;
        text-align: center;
    }
    .user {
        position: relative;
        background: @theme-color;
        padding-bottom: 100px;
        .bottom-arrow {
            display: inline-block;
            position: absolute;
            bottom: -43px;
            border-style: solid;
            border-color: @theme-color transparent transparent transparent;
            border-top-width: 40px;
            border-left-width: 50vw;
            border-right-width: 50vw;
        }
        .backgroundImg {
            width: 100%;
            img {
                width: 100%;
            }
        }
        .userInfo {
            overflow: hidden;
            margin: 0 30px;
            padding: 0 0 10px;
            border-bottom: 1px solid #fff;
            text-align: center;
            .user-icon {
                margin: 25px auto 0;
                width: 70px;
                height: 70px;
                border-radius: 50%;
                background: #e6e6e6;
            }
            .user-name {
                display: inline-block;
                margin-top: 11px;
                font-size: 15px;
                color: #fff;
                margin-bottom: 4px;
            }
            .mall {
                font-size: 12px;
                color: #ffffff;
            }
        }
        .user-money {
            color: #fff;
            .flex-item {
                position: relative;
                text-align: center;
                & + .flex-item:before {
                    position: absolute;
                    top: 50%;
                    left: 0;
                    transform: translateY(-50%);
                    display: inline-block;
                    content: '';
                    width: 1px;
                    height: 34px;
                    background: #fff;
                }
                .user-money-name {
                    margin-top: 14px;
                    font-size: 12px;
                    &:after {
                        display: inline-block;
                        content: '';
                        margin-left: 4px;
                        border: 4px solid;
                        border-color: transparent transparent transparent #fff;
                    }
                }
                .user-money-name {
                    margin-top: 5px;
                    font-size: 15px;
                }
            }
        }
        .user-card {
            position: absolute;
            left: 50%;
            bottom: -120px;
            transform: translateX(-50%);
            .user-card-qrcode {
                display: inline-block;
                width: 100px;
                height: 100px;
                padding: 10px;
                background: #fff;
                box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
                canvas {
                    display: inline-block;
                }
            }
            .user-card-img {
                margin: 0 auto;
                width: 315px;
                height: 207px;
                background: @theme-color;
                border-radius: 9px;
                box-shadow: 0 0 4px #a9a9a9;
            }
        }
    }
    .user-operate {
        padding: 0 15px;
        .myApply {
            position: relative;
            height: 50px;
            box-sizing: border-box;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid #F7F7F7;
            .input-label {
                position: absolute;
                top: 50%;
                left: 0;
                transform: translateY(-50%);
            }
             .input-remark{
                font-size: 12px !important;
                color: #FF4747 !important;
            }
            .input-val {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                width: 100%;
                height: 100%;
                text-align: right;
                picker {
                    display: flex;
                    align-items: center;
                    justify-content: flex-end;
                }
            }
            &.myApply-hobbits {
                height: auto;
                flex-direction: column;
                justify-content: flex-start;
                align-items: flex-start;
                .myApply-hobbits-name {
                    margin-top: 15px;
                    font-size: 15px;
                }
                .myApply-hobbits-val {
                    width: 100%;
                }
            }
            &.myApply-avator {
                height: auto;
            }
            .flex-item-arrow {
                flex: 1;
                text-align: right;
                height: 100%;
                display: flex;
                align-items: center;
                justify-content: flex-end;
            }
            &:last-child {
                border-bottom: 1px solid #eff1f8;
            }
            span {
                font-size: 15px;
                color: @black-color;
            }
            .arrow {
                display: inline-block;
                margin-left: 9px;
                width: 12px;
                height: 12px;
                padding-top: 2px;
            }
        }
    }
    .edit-tags {
        margin: 15px 0 15px;
        .edit-tag-wrap {
            position: relative;
            display: inline-block;
            width: 30.3%;
            font-size: 0;
            margin-right: 10px;
            margin-bottom: 10px;
            input {
                position: absolute;
                opacity: 0;
                left: 0;
                right: 0;
                top: 0;
                bottom: 0;
                z-index: 2;
                &:hover {
                    cursor: pointer;
                }
            }
            input + label,
            span {
                display: inline-block;
                width: 100%;
                height: 30px;
                line-height: 30px;
                text-align: center;
                background: #fff;
                font-size: 12px;
                color: @theme-color;
                border: 1px solid;
                border-radius: 4px;
            }
            checkbox[aria-checked='true'] + label,
            span.active {
                background: @theme-color;
                color: #fff;
                border-color: @theme-color;
            }
        }
    }

}
</style>
