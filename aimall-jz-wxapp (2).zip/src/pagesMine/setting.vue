<template>
    <div id="myIndex">
        <div class="setting-header">
            <div class="logo">
                <img src="https://img-cdn.aimall.cloud/as/20200601/fe00f23bcba043d68dad9d046af65f7f.png" alt="logo" mode="scaleToFill">
            </div>
            <div class="setting-company">
                南海嘉洲广场
            </div>
        </div>
        <ul class="user-operate">
            <!-- <li class="myApply" @tap="jump('policy')">
                <span>用户协议</span>
                <span class="flex-item-arrow">
                    <img src="/static/images/arrow_right.png">
                </span>
            </li> -->
            <!-- <li class="myApply">
                <span>隐私协议</span>
                <span class="flex-item-arrow"
                      @click="jump('protocol')">
                    <img src="/static/images/arrow_right.png">
                </span>
            </li> -->
        </ul>
        <button class="btn-operate-outline btn-logout"
                @click="logout">退出登录</button>
    </div>
</template>

<script>
import { mapState,mapMutations } from "vuex"
import wxUtils from '@/plugins/wxUtils'
export default {
    components:{

    },
    computed: {
        ...mapState(['isLogined'])
    },
    data() {
        return {

        }
    },
    mounted(){
        let vm = this
    },
    methods: {
        ...mapMutations(["update"]),
        jump(type){
            var url = ''
            if(type == 'policy'){
                url = '/pages/mine/policy'
            }
            // else if(type == 'protocol'){
            //     url = '/pages/mine/protocol'
            // }
            wx.navigateTo({
                url: url
            })
        },
        logout(){
            let vm = this
            // let oldIsLogined = vm.isLogined
            let oldIsLogined = vm.isLogined
            wxUtils.clearLoginStorage()
            vm.update({
                vipInfo: null,
                sessionId: '',
                isLogined: oldIsLogined
                // wxUserInfo: null
            })
            wx.switchTab({
                url: '/pages/mine/index'
            })
        }
    }
}
</script>

<style lang="less">
@import '../assets/styles/vars';
@import '../assets/styles/common';
#myIndex {
    width: 100vw;
    height: 100vh;
    overflow: auto;
    background-color: #fff;
    .logo{
        margin-top: 52px;
        text-align: center;
        img{
            display: inline-block;
            width: 100px;
            height: 102px;
        }
    }
    .btn-logout{
        margin: 90px 15px 0;
    }
    .setting-company{
        margin-top: 20px;
        font-size: 15px;
        color: @black-color;
        text-align: center;
    }
    .user {
        position: relative;
        background: @theme-color;
        padding-bottom: 100px;
        .bottom-arrow{
            display: inline-block;
            position: absolute;
            bottom: -43px;
            border-style: solid;
            border-color: @theme-color transparent transparent transparent;
            border-top-width: 40px;
            border-left-width: 50vw;
            border-right-width: 50vw;
        }
        .backgroundImg {
            width: 100%;
            img {
                width: 100%;
            }
        }
        .userInfo {
            overflow: hidden;
            margin: 0 30px;
            padding: 0 0 10px;
            border-bottom: 1px solid #fff;
            text-align: center;
            .user-icon{
                margin: 25px auto 0;
                width: 70px;
                height: 70px;
                border-radius: 50%;
                background: #E6E6E6;
            }
            .user-name {
                display: inline-block;
                margin-top: 11px;
                font-size: 15px;
                color: #fff;
                margin-bottom: 4px;
            }
            .mall {
                font-size: 12px;
                color: #ffffff;
            }
        }
        .user-money{
            color: #fff;
            .flex-item{
                position: relative;
                text-align: center;
                &+.flex-item:before{
                    position: absolute;
                    top: 50%;
                    left: 0;
                    transform: translateY(-50%);
                    display: inline-block;
                    content: '';
                    width: 1px;
                    height: 34px;
                    background: #fff;
                }
                .user-money-name{
                    margin-top: 14px;
                    font-size: 12px;
                    &:after{
                        display: inline-block;
                        content: '';
                        margin-left: 4px;
                        border: 4px solid;
                        border-color: transparent transparent transparent #fff;
                    }
                }
                .user-money-name{
                    margin-top: 5px;
                    font-size: 15px;
                }
            }
        }
        .user-card{
            position: absolute;
            left: 50%;
            bottom: -120px;
            transform: translateX(-50%);
            .user-card-qrcode{
                display: inline-block;
                width: 100px;
                height: 100px;
                padding: 10px;
                background: #fff;
                box-shadow: 0 0 5px rgba(0,0,0,.5);
                canvas{
                    display: inline-block;
                }
            }
            .user-card-img{
                margin: 0 auto;
                width: 315px;
                height: 207px;
                background: @theme-color;
                border-radius: 9px;
                box-shadow: 0 0 4px #A9A9A9;
            }
        }
    }
    .user-operate{
        margin: 76px 15px 0;
        .myApply {
            height: 50px;
            box-sizing: border-box;
            padding: 0 0 0 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            .flex-item-arrow{
                flex: 0 1 100px;
                text-align: right;
                height: 100%;
                display: flex;
                align-items: center;
                justify-content: flex-end;
            }
            &:last-child{
                border-bottom: 1px solid #f7f7f7;
            }
            span {
                font-size: 15px;
                color: @black-color;
            }
            img {
                display: inline-block;
                margin: 0 15px 0 17px;
                width: 12px;
                height: 12px;
            }
        }
    }
}
</style>
