<template>
    <div class="integral-container">
        <div class="flex-wrp integral-basic">
            <span class="flex-item integral-avatar-wrap">
                <img class="integral-avatar" :src="vipInfo&&vipInfo.avatarUrl" alt="头像">
            </span>
            <!-- <div
                class="inter-rule"
                 @click="toRule"
            >
                <span class="inter-rule-icon">
                    <img src="/static/images/icon-msg.png">
                </span>
                <span class="inter-rule-text">积分规则</span>

            </div> -->
            <span class="flex-item integral-info">
                <div class="integral-total">
                    <span>我的积分：</span>
                    <span class="pt5 totla-inter">{{totalPoints}}</span>
                    <span class="pl10">分</span>
                    </div>
                <div class="integral-month">
                    <p class="integral-val">即将到期的积分：{{effectiveIntegral}}分</p>
                    <p class="integral-time pt5" v-if="effectiveTime.year !='' && effectiveTime.month !=''">({{effectiveTime.year}}.{{effectiveTime.month}}.{{effectiveTime.day}}到期)</p>
                    <p class="integral-time pt5" v-if="effectiveTime.year ==''"></p>
                    <!-- <span class="integral-month-val" @click="toRule">积分规则</span> -->
                </div>
            </span>
        </div>
        <!-- <div class="inte_remark">
            <p>温馨提示：为了您的积分安全，积分支付未成功将冻结支付积分，15分钟后返还。</p>
        </div> -->
        <div class="integral-days" v-if="!noList">
            <span class="integral-month-name">近30天积分明细</span>
        </div>
        <div class="integral-record">
            <ul>
                <li class="flex-wrp integral-record-item" v-for="(item,index) in list" :key="index">
                    <span class="flex-item">
                        <p class="name">{{item.adjustReason}}</p>
                        <p class="date">{{item.createTime}}</p>
                    </span>
                    <span :class="['flex-item','val-wrap',{add:item.adjustIntegral>0}]">
                        <span class="val" :class="{'isAdd':item.adjustIntegral>0}">{{item.adjustIntegral>0?('+'+item.adjustIntegral):item.adjustIntegral}}</span>
                    </span>
                </li>
            </ul>
            <div v-if="hasFetchData&&list.length==0" class="noIntegral">
                <block-page :type="noListName"></block-page>
            </div>
            <!-- <loaderMore :loadermore="loaderMore">&nbsp;</loaderMore> -->
        </div>
    </div>
</template>

<script>
import { mapState,mapMutations } from "vuex"
import moment from 'moment'
import request from '@/plugins/request'
import api from '@/plugins/api'
import wxUtils from '@/plugins/wxUtils';
import loaderMore from '@/components/loaderMore'
import blockPage from '@/components/blockPage'
export default {
    components:{
        loaderMore,
        blockPage
    },
    data(){
        return{
            effectiveTime:{
                year:'',
                month:'',
                day:''
            },
            effectiveIntegral:'0',
            page:{
                pageNum: 1,
                pageSize: 10,
                total: 0
            },
            format: "YYYY-MM-DD",
            loaderMore: false,
            list:[],
            totalPoints: 0,
            sumMonthIntegral: 0,
            isDataFinish: false, // 数据加载完成状态
            noList :true,
            noListName:'积分',
            hasFetchData: false //拉取数据状态
        }
    },
    computed: {
        ...mapState(['vipInfo'])
    },
    methods:{
        toRule(){
            wx.navigateTo({url:'/pagesMine/interalRule'})
        },
        formatTime(time){
            this.effectiveTime.year = new Date(time).getFullYear()
            this.effectiveTime.month = new Date(time).getMonth()+1
            this.effectiveTime.day = new Date(time).getDate()
        },
        getData(times){
            this.hasFetchData = false
            return new Promise(resolve=>{
                this.hasFetchData = true
                this.loaderMore = true
                let params = Object.assign({},this.page,{
                    memberId: this.vipInfo.id,
                    startTime: moment().subtract(30, 'days').format(this.format)+" 00:00:00",
                    endTime: moment().format(this.format)+" 23:59:59"
                })
                delete params.total
                let requestOptions = {
                    path: api.getIntegralDetail,
                    method: 'get',
                    data: params
                }
                request(requestOptions).then(res=>{
                    let {totalPoints,sumMonthIntegral,pageInfo,effectiveIntegral,effectiveTime} = res.data
                    this.totalPoints = totalPoints
                    this.sumMonthIntegral = sumMonthIntegral
                    this.effectiveIntegral = effectiveIntegral ? effectiveIntegral :'0'
                    this.formatTime(effectiveTime) //获取年月日
                    this.page.total =  pageInfo.total
                    pageInfo.list = pageInfo.list ? pageInfo.list :[]

                    if(times == 1){
                        this.list = pageInfo.list
                    }else{
                        this.list = this.list.concat(pageInfo.list)
                    }
                    // var arr = new Array(20)
                    // arr.fill(this.list[0])
                    // this.list = this.list.concat(arr)
                    if(this.list.length == 0){
                        this.noList = true
                    }else {
                        this.noList = false
                    }

                    //数据加载结束
                    let receivedNum = this.list.length
                    console.log(receivedNum, this.page.total)
                    if(receivedNum>=this.page.total){
                        this.isDataFinish = true
                    }

                    this.loaderMore = false
                })
            })
        },
        resetRefresh(){
            this.loaderMore = true
            this.list = []
            this.page.pageNum = 1
            this.isDataFinish = false
            this.hasFetchData = false
            this.getData(1)
        }
    },
    mounted(){
        this.resetRefresh()
    },
    // 页面滚动到底部
    onReachBottom() {
        if (!this.isDataFinish&&!this.loaderMore) {
            this.page.pageNum++
            this.getData()
        }
    },
    onUnload(){
        this.hasFetchData = false
    }
}
</script>

<style lang="less" scoped>
@import url('../assets/styles/vars');
.integral-container{
    .integral-basic{
        align-items: center;
        height: 124px;
        padding: 0 12px;
        // background: @theme-color;
        // background: url('../static/images/interal-bg.png') no-repeat;
        // background-size: convert;
        background: url('https://img-cdn.aimall.cloud/as/20200601/b918334715d14518ab5d73372028e60d.png') no-repeat left center;
            background-size: 100%;
            vertical-align: top;
            position: relative;
        .integral-avatar-wrap{
            flex: 0 1 auto;
            .integral-avatar{
                display: inline-block;
                width: 70px;
                height: 70px;
                border-radius: 50%;
                margin-top: 10px;
            }
        }
        .integral-info{
            padding-left: 18px;
            font-size: 14px;
            color: #fff;
            .integral-total{
                .totla-inter{
                    font-size: 18px;
                    font-weight: 600;
                }
            }
            .integral-month{
                margin-top: 5px;
                font-size: 11px;
                .integral-month-val{
                    margin-left: 10px;
                    border-bottom: 1px solid #0000FF;
                    color: #0000FF;
                }
            }
        }
    }
    .pt5{
        padding-top: 5px;
    }
    .pl10{
        padding-left: 10px;
    }
    .integral-val,.integral-time{
        color: #fff;
        font-weight: 400;
        font-size: 14px;
    }
    .inter-rule{
        position: absolute;
        z-index: 99;
        top: 15px;
        right: 15px;
        color: #fff;
        font-size: 12px;
        font-weight: 400;
        .inter-rule-icon{
            width: 12px;
            height: 12px;
            display: inline-block;
            position: relative;
            img{
                width: 12px;
                height: 12px;
                position: absolute;
                top: 1px;

            }
        }
        .inter-rule-text{
            display: inline-block;
            padding-left: 5px;
            position: relative;
        }

    }
    .integral-record{
        color: @black-color;
        padding: 0 15px;
        .integral-record-item{
            height: 70px;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid @line-color;
            .name{
                font-size: 15px;
            }
            .date{
                margin-top: 7px;
                font-size: 15px;
                color: @gray-color;
            }
            .val-wrap{
                flex: 0 1 20%;
                text-align: right;
                .val{
                    font-size: 15px;
                    font-weight: bold;
                }
                &.add{
                    color: @pink-color;
                }
            }
        }
    }
    .integral-days{
        margin: 15px;
        color: @gray-color;
        font-size: 15px;
        border-bottom: solid 1px @line-color;
        padding-bottom: 10px;
        margin-bottom: 0px;

    }
    .isAdd{
        color: #FF4747;
    }
    .inte_remark{
        width:100%;
        height:47px;
        background:rgba(105,189,185,1);
        font-size: 12px;
        color: #fff;
        p{
            padding: 7px 15px;
        }
    }
}
</style>
