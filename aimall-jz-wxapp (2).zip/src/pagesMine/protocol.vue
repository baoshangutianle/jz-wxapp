<template>
    <div class="protocol-container">
        隐私协议
    </div>
</template>

<script>
export default {
    data(){

    }
}
</script>

<style lang="less">

</style>
