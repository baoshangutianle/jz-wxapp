<template>
    <div class="card-container">
        <div>
            <sel-enum-coupon :itemName="itemName" :itemAll="itemAll" :itemList="itemList"  @change="change" @selectType="selectType"/>
        </div>
        <!-- <ul class="flex-wrp tabs">
            <li class="flex-item tab" @tap="currTab='all'">
                <span :class="{'active':currTab=='all'}">
                    全部
                </span>
            </li>
            <li class="flex-item tab" @tap="currTab='preferential'">
                <span :class="{'active':currTab=='preferential'}">
                    优惠券
                </span>
            </li>
            <li class="flex-item tab" @tap="currTab='park'">
                <span :class="{'active':currTab=='park'}">
                    停车券
                </span>
            </li>
        </ul> -->
        <scroll-view
            :style="{'height': '100%'}"
            class="card-list"
            scroll-y="true"
            lower-threshold="100"
            @scrolltolower="scrollToLower"
        >
            <ul>
                <li class="card-item" v-for="(item,index) in list" :key="index">
                    <div>
                        <!-- <card-item :data="item"/> -->
                        <coupon-item :data="item" from="mine"/>
                    </div>
                </li>
            </ul>
            <load-more v-if="reachFinish" />
            <div v-if="hasFetchData&&list.length==0">
                <block-page :type="typeText"></block-page>
                <div class="goList" @click="goList">去超值领券看看</div>
            </div>
        </scroll-view>
        <!-- <gzh-login-comp :is-show="isGzhLoginShow"
                    @close="closeGzhLogin"/> -->
    </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import moment from 'moment'
import api from '@/plugins/api'
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils';
import utils from '@/plugins/utils'
import CardItem from '@/components/CardItem';
import CouponItem from '@/components/CouponItem'
import {getCards} from '@/service/mine'
import blockPage from '@/components/blockPage';
import GzhLoginComp from '@/components/GzhLoginComp'
import loadMore from '@/components/loadMore'
import SelEnumCoupon from '@/components/SelEnumCoupon'
export default {
    components:{
        GzhLoginComp,
        blockPage,
        CouponItem,
        loadMore,
        SelEnumCoupon
    },
    data(){
        return{
            currTab: 'all',
            list:[],
            page:{
                pageNum: 1,
                pageSize: 10,
                total: 0
            },
            picPrex: '/static/images/',//图片前缀
            format: "YYYY-MM-DD",
            detail: {},
            loaderMore: true,
            isDataFinish: false, // 数据加载完成状态
            isDataList: false,
            typeText: '卡券',
            hasFetchData: false, //拉取数据状态
            isGzhLoginShow: false,
            reachFinish:false,
            isExpired: false,
            invalidFlag: false,
            itemName: '全部券',
            itemAll:[{
                name:'可使用'
            },{
                name:'已使用'
            },{
                name:'已过期'
            }],
            itemList: [],
            chargeOffStatus: '1',
            outOfDate: '0',
            couponType:''
        }
    },
    computed: {
        ...mapState(['sessionId','scene'])
    },
    methods:{
        closeGzhLogin(flag){
            this.isGzhLoginShow = false//关闭弹框
            if(flag){
                this.resetRefresh()
            }
        },
        change(data){
            this.chargeOffStatus = data.chargeOffStatus
            this.outOfDate = data.outOfDate
            this.loaderMore = true
            this.list = []
            this.page.pageNum = 1
            this.isDataFinish = false
            this.reachFinish = false
            this.isExpired = false
            this.invalidFlag = false
            //不同类型显示文案不同
            if(this.chargeOffStatus == '2' && this.outOfDate == ''){
                this.typeText = '已使用卡券'
            }else if(this.chargeOffStatus == '1' && this.outOfDate == '1'){
                this.typeText = '已过期卡券'
            }else{
                this.typeText = '卡券'
            }
            this.getData(1)
        },
        async getData(times){
            if(utils.isFromGzh(this.scene) && !this.sessionId){
                this.isGzhLoginShow = true
                wx.navigateTo({
                    url: `/listOfActivities/shareAuth`
                })
                return
            }

            this.hasFetchData = false
            this.loaderMore = false
            //可使用参数
            let params = Object.assign({},this.page,{
                couponType:this.couponType,
                chargeOffStatus:this.chargeOffStatus,
                outOfDate:this.outOfDate
            })
            delete params.total

            let res = await getCards(params)
            this.hasFetchData = true
            let {list} = res
            list = !list?[]:list
            if(list.length ==0){
                this.isDataFinish = true
            }

            list.map(item=>{
                item.couponBatchId = item.batchId
                item.couponUrl = item.singleImageUrl
                item.chargedOffBeginTime = item.chargeOffBeginTime?moment(item.chargeOffBeginTime).format('YYYY.MM.DD'):''
                item.chargedOffEndTime = item.chargeOffEndTime?moment(item.chargeOffEndTime).format('YYYY.MM.DD'):''
                //判断是否存在已经过期的卡券
                if(item.outOfDate == 1){
                    this.isExpired = true
                }else{
                    this.isExpired = false
                }
                let statusObj = this.getStatus(item)
                Object.assign(item,statusObj)
            })

            if(times == 1){
                this.list = list
            }else{
                this.list = this.list.concat(list)
            }

            if(this.list.length ==0){
                this.isDataList = false
            }else{
                this.isDataList = true
            }

            this.loaderMore = true
        },
        //获取所有卡券信息
        selectType(data){
            this.couponType = data.dictValue
            this.itemName = data.dictName
            this.loaderMore = true
            this.list = []
            this.page.pageNum = 1
            this.isDataFinish = false
            this.reachFinish = false
            this.isExpired = false
            this.invalidFlag = false
            this.getData(1)
        },
        getCardsType(){
            const opsiton = { path: api.getCardsType }
            request(opsiton).then( res => {
                if(res.code == 200){
                    let val = [{
                        'dictValue':'',
                        'dictName':'全部券'
                    }]
                    let newVal =val.concat(res.data)
                    this.itemList = newVal
                }
            })
        },
        getStatus(data){
             let { chargeOffStatus, outOfDate } = data

            let pic,checkDisable,isUse
            if(this.chargeOffStatus ==1 && this.outOfDate == 0){
                pic = ''
                checkDisable = false
                isUse = false
            }else if(this.chargeOffStatus ==2 && this.outOfDate == ''){
                pic = 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/d118a7866b36470eb2e3c6b557ec9f44.png'
                isUse = true
                checkDisable = false
            }else if(this.chargeOffStatus ==1 && this.outOfDate == 1){
                pic = 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/a8815bbeaea2483fb248c1310daf9611.png'
                checkDisable = true
                isUse = false
            }

            return {
                statusPic: pic,
                checkDisable: checkDisable,
                isUse: isUse
            }
        },
        goDetail(item){
            if(item.outOfDate != 1){
                wx.navigateTo({
                    url: `/pagesMine/cardDetail?couponId=${item.id}`
                })
            }
        },
        resetRefresh(){
            this.loaderMore = true
            this.list = []
            this.page.pageNum = 1
            this.isDataFinish = false
            this.reachFinish = false
            this.isExpired = false
            this.invalidFlag = false
            this.itemName = '全部券'
            this.couponType = ''
            this.chargeOffStatus = '1'
            this.outOfDate = '0'
            this.getCardsType()
            this.getData(1)
        },
        scrollToLower(){
            if (!this.isDataFinish&&this.loaderMore) {
                this.page.pageNum++
                this.getData()
                if (this.list.length > 5) {
                    this.reachFinish = true
                } else {
                    this.reachFinish = false
                }
            }else{
                if (this.list.length > 5) {
                    this.reachFinish = true
                } else {
                    this.reachFinish = false
                }
            }
        },
        openShow() {
            this.invalidFlag = !this.invalidFlag
        },
        hidePage() {
            this.hasFetchData = false
        },
        goList() {
            wx.navigateTo({
                url: `/pages/coupon/index`
            })
        },
    },
    onLoad(){
        this.resetRefresh()
    },
    mounted(){
        this.currTab = 'all'
    },
    // 下拉刷新
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
        this.resetRefresh()
    },
    watch: {
        currTab(newVal){
            if(newVal){
                this.resetRefresh()
            }
        }
    },
    onUnload(){
        this.hasFetchData = false
    }
}
</script>

<style lang="less" scoped>
@import "../assets/styles/vars";
.card-container{
    color: @black-color;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    height: 100vh;
    .goList{
        color: #9975F3;
        font-size: 15px;
        width: 100%;
        text-align: center;
        padding-top: 10px;
        text-decoration: underline;
    }
    .tabs {
        flex: 0 1 auto;
        background: #fff;
        border-bottom: 1px solid #ddd;
    }
    .card-list{
        flex: 1;
        overflow: auto;
        height: 100%;
    }
    .card-item{
        position: relative;
        margin: 20px 15px 0;
        &:last-child{
            margin-bottom: 34px;
        }
    }
    .value-point-mask{
        box-sizing: border-box;
        z-index: 2;
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: rgba(0,0,0,.8);
        text-align: center;
        overflow: hidden;
        .value-point-mask-con{
            position: relative;
            width: 90vw;
            margin: 0 auto;
            height: 100%;
            overflow: auto;
            .value-point-mask-close{
                position: absolute;
                right: 0;
                top: 16px;
                image{
                    display: inline-block;
                    width: 24px;
                    height: 24px;
                    &:active{
                        opacity: .8;
                    }
                }
            }
            .fail-con{
                overflow: hidden;
                padding-top: 25px;
                color: #fff;
                text-align: left;
                .fail-name{
                    display: flex;
                    align-items: center;
                    justify-content: flex-start;
                    font-size: 15px;
                    .icon-fail-info{
                        display: inline-block;
                        width: 20px;
                        height: 20px;
                        margin-right: 4px;
                    }
                }
                .fail-text{
                    margin-top: 4px;
                    font-size: 13px;
                }
            }
            .value-point-mask-pic{
                margin: 30px 0 191px;
                width: 100%;
            }
            .btn-upload{
                height: 44px;
                line-height: 44px;
                margin: 35px 50px 0;
                font-size: 15px;
            }
            .btn-photo{
                display: inline-block;
                margin: 30px 0 60px;
                font-size: 15px;
                color: @theme-color;
            }
        }
    }
    .openPage {
        height: 20vh;
        position: relative;
        display: flex;
        padding: 8.5vh 8px;
        box-sizing: border-box;
        z-index: 99;
        .line {
            flex: 1;
            height: 0.5px;
            background: #cacaca;
            flex: 1;
            position: relative;
            top: 10px;
        }
        .text {
            flex: 3;
            font-size: 14px;
            text-align: center;
            color: #444444;
            .open {
                color: #9975F3;
                text-decoration: underline;
                margin-left: 3px;
            }
        }
    }
}
</style>
