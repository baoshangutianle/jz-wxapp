<script>
import wxp from 'minapp-api-promise'
import wxUtils from '@/plugins/wxUtils'
import utils from '@/plugins/utils'
import api from './plugins/api'
import request from '@/plugins/request'
import { mapState, mapMutations } from 'vuex'
export default {
    async onShow(e) {
        let vm = this

        vm.judgeEnv()

        //更新卖场id
        this.setScene(e)
        let data = await utils.getMalls()
        await this.update({
            mallCode: data.mallCode
        })
        if (e.path == 'pages/parkPay/pay') {
            if (typeof e.referrerInfo != 'undefined' && e.referrerInfo.extraData.errMsg == 'requestPayment:ok') {
                console.log('成功')
                wx.redirectTo({
                    url: `/pages/parkPay/status?type=success&id=${e.query.id}`
                })
            } else {
                console.log('失败')
                // wx.navigateTo({
                //     url: `/pages/parkPay/pay?id=${e.query.id}`
                // })
            }
        }
        wx.login({
            success(res) {
                let code = res.code
                if (code) {
                    let params = {
                        appid: wx.getAccountInfoSync().miniProgram.appId,
                        code: code
                    }
                    let requestOptions = {
                        path: api.getOpenId,
                        method: 'get',
                        data: params,
                        hideLoading: true
                    }
                    request(requestOptions).then(res2 => {
                        let { sessionKey, openid, unionid } = res2.data
                        wxUtils.setSessionKeyStorage(sessionKey)
                        wxUtils.setOpenIdStorage(openid)
                    })
                }
            }
        })
    },
    onLaunch: function() {
        if (wx.canIUse('getUpdateManager')) {
            const updateManager = wx.getUpdateManager()
            updateManager.onCheckForUpdate(function(res) {
                // 请求完新版本信息的回调
                // console.log(res.hasUpdate)
            })
            //updateManager.onCheckForUpdate(function(res) {
                //console.log('onCheckForUpdate====', res)
                // 请求完新版本信息的回调
                //if (res.hasUpdate) {
                    //console.log('res.hasUpdate====')
                    updateManager.onUpdateReady(function() {
                        wx.showModal({
                            title: '温馨提示',
                            content: '开启新版本，享受更流畅的服务体验',
                            cancelText: '先不了',
                            confirmText: '试试看',
                            success: function(res) {
                                console.log('success====', res)
                                // res: {errMsg: "showModal: ok", cancel: false, confirm: true}
                                if (res.confirm) {
                                    // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                                    updateManager.applyUpdate()
                                }
                            }
                        })
                    })
                    updateManager.onUpdateFailed(function() {
                        // 新的版本下载失败
                        wx.showModal({
                            title: '已经有新版本了哟~',
                            content: '新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~'
                        })
                    })
                //}
            //})
        }
    },
    computed: {
        ...mapState(['isLogined', 'vipInfo'])
    },
    methods: {
        ...mapMutations(['update']),
        ...mapMutations(['setScene']),
        judgeEnv() {
            //判断环境，如果环境不同，则清除缓存，重头来过
            let vm = this
            if (!utils.isEnvEqual()) {
                console.log('======env change=====')
                utils.setEnvStorage()
                // wxUtils.clearLoginStorage()
                // vm.update({
                //     wxUserInfo: null,
                //     vipInfo: null,
                //     sessionId: '',
                //     isLogined: false,
                // })

                if (vm.isLogined) {
                    //如果登录过了，则刷新下sessionId
                    wxUtils.getUserCode((err, data) => {
                        let { sessionId, userCode, mobile } = data
                        wxUtils.setPhoneStorage(mobile)
                        wxUtils.setUserCodeStorage(userCode)
                        console.log('======new session generate=====')
                        console.log(sessionId, userCode, mobile)
                        if (this.vipInfo) {
                            //更新会员信息
                            utils.getVipInfo().then(vipInfo => {
                                console.log('======vipInfo update=====')
                                vm.update({
                                    vipInfo: vipInfo,
                                    sessionId
                                })
                            })
                        }
                    })
                }
            }
        }
    }
}
</script>

<style lang="less">
// @import 'static/styles/weui.css';
@import 'assets/styles/common.less';
</style>
