import Vue from 'vue'
import App from '@/App'

//引入store
import store from '@/store/index'
//把store挂载到全局
Vue.prototype.$store = store;

Vue.config.productionTip = false
App.mpType = 'app'

const app = new Vue(App)
app.$mount()

export default {
    // 这个字段走 app.json
    config: {
        pages: [],
        window: {
            backgroundTextStyle: 'dark',
            backgroundColor: '#fff',
            navigationBarBackgroundColor: '#F2F2F2',
            navigationBarTitleText: '南海嘉洲广场',
            navigationBarTextStyle: 'black',
        },
        tabBar: {
            color: '#7F8389',
            // selectedColor: '#5ECEBE',
            selectedColor: '#9975F3',
            list: [{
                    pagePath: 'pages/home',
                    text: '首页',
                    iconPath: 'static/images/low-home.png',
                    selectedIconPath: 'static/images/high-home.png'
                    // iconPath: 'static/images/homeIcon_1.png',
                    // selectedIconPath: 'static/images/homeIcon_2.png'
                },
                {
                    pagePath: 'pages/integralMall/index',
                    text: '在线商城',
                    iconPath: 'static/images/low-mall.png',
                    selectedIconPath: 'static/images/high-mall.png'
                },
                {
                    pagePath: 'pages/cart/index',
                    text: '购物车',
                    iconPath: 'static/images/low-cart.png',
                    selectedIconPath: 'static/images/high-cart.png'
                    // iconPath: 'static/images/restaurant.png',
                    // selectedIconPath: 'static/images/restaurant.png'
                },
                {
                    pagePath: 'pages/restaurant/index',
                    text: '品牌指引',
                    iconPath: 'static/images/low-brand.png',
                    selectedIconPath: 'static/images/high-brand.png'
                    // iconPath: 'static/images/restaurant.png',
                    // selectedIconPath: 'static/images/restaurant.png'
                },
                {
                    pagePath: 'pages/mine/index',
                    text: '我的',
                    iconPath: 'static/images/low-personal.png',
                    selectedIconPath: 'static/images/high-personal.png'
                    // iconPath: 'static/images/myIndexIcon_1.png',
                    // selectedIconPath: 'static/images/myIndexIcon_2.png'
                }
            ]
        },
        // 生产appid
        navigateToMiniProgramAppIdList: ['wxfbb998275db834d9','wx31edd5740a6eb912'],
        // 测试appid
        // navigateToMiniProgramAppIdList: ['wx31edd5740a6eb912']
        // "plugins": {
        //     "live-player-plugin": {
        //         "version": "1.0.2", // 注意填写该直播组件最新版本号，微信开发者工具调试时可获取最新版本号
        //         "provider": "wx2b03c6e691cd7370" // 必须填该直播组件appid，该示例值即为直播组件appid
        //     }
        // },
        "usingComponents": {
            "slide-view": "./static/slideview/slideview",
            "painter": "/static/painter/painter"
        }

    },

}
