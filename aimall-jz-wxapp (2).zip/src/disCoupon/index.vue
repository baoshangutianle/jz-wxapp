<!-- 
 * @description 优惠券-列表
 * @author jwt
 * @date 2020-07-01
 * @version 1.0.0
 * @lastModifiedBy jwt
 * @lastModifiedTime 2020-07-10
-->
<template>
    <div class="wrap">
        <view class="list">
            <view class="test">可用券</view>
            <view class="list_item" v-for="(item,index) in list" :key="index">
                <view :class="['list_item_goods']">
                    <view class="checkbox list_item_goods_l">
                        <image
                            v-if="item.checked"
                            src="/static/images/car-checked.png"
                            mode="widthFix"
                        />
                        <image v-else src="/static/images/pay-unchecked.png" mode="widthFix" />
                        <!-- <image src="/static/images/pay-lock.png" mode="widthFix" /> -->
                    </view>
                    <view class="list_item_goods_c">
                        <image
                            src="http://jz.uat1.rscloud.com/img/logo.3c167510.png"
                            mode="widthFix"
                        />
                    </view>
                    <view class="list_item_goods_r">
                        <view class="list_item_goods_rt">{{item.couponName}}</view>
                        <view class="list_item_goods_rc">{{item.discount}}</view>
                        <view class="list_item_goods_rb">{{item.startTime}}至{{item.endTime}}</view>
                    </view>
                </view>
            </view>
        </view>
        <view class="list">
            <view class="test">不可用券</view>
            <view class="list_item" v-for="(item,index) in list" :key="index">
                <view :class="['list_item_goods','filter_gray']">
                    <view class="checkbox list_item_goods_l">
                        <image
                            v-if="item.checked"
                            src="/static/images/car-checked.png"
                            mode="widthFix"
                        />
                        <image v-else src="/static/images/pay-unchecked.png" mode="widthFix" />
                    </view>
                    <view class="list_item_goods_c">
                        <image
                            src="http://jz.uat1.rscloud.com/img/logo.3c167510.png"
                            mode="widthFix"
                        />
                    </view>
                    <view class="list_item_goods_r">
                        <view class="list_item_goods_rt">{{item.couponName}}</view>
                        <view class="list_item_goods_rc">{{item.discount}}</view>
                        <view class="list_item_goods_rb">{{item.startTime}}至{{item.endTime}}</view>
                    </view>
                </view>
            </view>
        </view>
        <view class="tips"><image src='http://img1.uat1.rs.com/g2/M00/02/B7/CgsZj18JMNGARwmcAAAEckX4Y2A811.png!' mode="widthFix"/>已选择{{count}}张，可抵扣<span class="disPrice">￥{{disPrice}}</span>，订单实际付款金额<span class="totalPrice">￥{{totalPrice}}</span></view>
        <view class="footer" >
            <button class="submit_btn" @click="toConfirmDetai">完 成</button>
        </view>
    </div>
</template>

<script>
import api from '@/plugins/api'
import request from '@/plugins/request'
export default {
    data() {
        return {
            list: [
                {
                    usable: true,
                    checked: true,
                    couponName: '100元现金抵用券',
                    discount: '满100减100元',
                    startTime: '2017-10-01',
                    endTime: '2019-10-01'
                },
                {
                    usable: true,
                    checked: true,
                    couponName: '100元现金抵用券',
                    discount: '满100减100元',
                    startTime: '2017-10-01',
                    endTime: '2019-10-01'
                },
                {
                    usable: false,
                    checked: false,
                    couponName: '100元现金抵用券',
                    discount: '满100减100元',
                    startTime: '2017-10-01',
                    endTime: '2019-10-01'
                },
                {
                    usable: false,
                    checked: false,
                    couponName: '100元现金抵用券',
                    discount: '满100减100元',
                    startTime: '2017-10-01',
                    endTime: '2019-10-01'
                }
            ],
            count: 1,
            disPrice: 100.00,
            totalPrice: 989.00
        }
    },
    onShow() {},
    //一个数据受多个数据影响
    computed: {},
    //一个数据影响多个数据
    watch: {},
    methods: {}
}
</script>

<style lang="less" scoped>
.wrap {
    background: #f7f7f7;
}
.test {
    font-size: 15px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: rgba(51, 51, 51, 1);
    line-height: 21px;
    padding: 15px 0 4px 15px;
    background-color: #fff;
}
.list {
    margin-bottom: 10px;
}
.list_item {
    background: #fff;
    .list_item_t {
        display: flex;
        padding: 30rpx 0 20rpx;
    }
    .list_item_act {
        margin: 0 30rpx 0 96rpx;
        background: rgba(153, 117, 243, 0.1);
        color: #9975f3;
        border-radius: 12rpx;
        font-size: 24rpx;
        padding: 10rpx;
    }
    .list_item_goods {
        height: 220rpx;
        display: flex;
        align-items: center;
        margin: 0 30rpx;
        position: relative;
        .u-number-box {
            position: absolute;
            right: 0;
            bottom: 30rpx;
        }
        .list_item_goods_l {
            flex-shrink: 0;
            image {
                margin: 30rpx 30rpx 30rpx 0;
            }
        }
        .list_item_goods_c {
            background: #efefef;
            border-radius: 12rpx;
            width: 160rpx;
            height: 160rpx;
            line-height: 160rpx;
            flex-shrink: 0;
            text-align: center;
            image {
                width: 90%;
                vertical-align: middle;
            }
        }
        .list_item_goods_r {
            margin-left: 20rpx;
            .list_item_goods_rt {
                .line_2;
                font-size: 15px;
                font-weight: 600;
                color: rgba(51, 51, 51, 1);
                line-height: 28px;
                letter-spacing: 1rpx;
            }
            .list_item_goods_rc {
                font-size: 15px;
                font-weight: 300;
                color: rgba(102, 102, 102, 1);
                line-height: 21px;
                margin: 2px 0;
                letter-spacing: 1rpx;
            }
            .list_item_goods_rb {
                font-size: 12px;
                font-weight: 300;
                color: rgba(153, 153, 153, 1);
                line-height: 17px;
                letter-spacing: 1px;
            }
        }
    }
    .list_item_goods_b {
        margin: 0 30rpx;
        padding: 0 0 20rpx 60rpx;
        display: flex;
        justify-content: space-between;
        border-bottom: 2rpx solid #f1f1f1;
        text {
            font-size: 24rpx;
            color: #999;
        }
    }
}

.checkbox {
    display: flex;
    justify-content: center;
    align-items: center;
    image {
        width: 36rpx;
        height: 36rpx;
    }
}
.tips {
  padding: 30rpx;
  font-size:12px;
  font-family:PingFangSC-Regular,PingFang SC;
  font-weight:400;
  color:rgba(153,153,153,1);
  line-height:17px;
  display: flex;
  align-items: center;
  letter-spacing: 1px;
  image {
    width: 18px;
    height: 18px;
    margin-right: 8px;
  }
  .disPrice, .totalPrice {
    color:rgba(234,82,5,1);
  }
}
.footer {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 18px;
  .submit_btn {
      width:94%;
      line-height:44px;
      background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
      border-radius:22px;
      font-size:15px;
      font-family:PingFangSC-Medium,PingFang SC;
      font-weight:500;
      color:rgba(255,255,255,1);
  }
}
//一行
.line_1 {
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    word-break: break-all;
}
//两行
.line_2 {
    text-overflow: -o-ellipsis-lastline;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
}
/* ==================
          网页变灰色
 ==================== */
.filter_gray {
    filter: progid:DXImageTransform.Microsoft.BasicImage(grayscale=1);
    -webkit-filter: grayscale(100%);
    /*-------------------*/
    opacity: 0.5;
    pointer-events: none;
}
</style>>