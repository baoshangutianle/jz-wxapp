import moment from 'moment'
moment.locale('zh-cn')

export default {
    formatTime(date) {
        if (date !== undefined) {
            return moment(parseInt(date)).format('YYYY-MM-DD HH:mm:ss')
        }
        return ''
    }
}
