import wxUtils from './wxUtils'
import request from './request'
import api from './api'
import md5 from 'md5';
const NODE_ENV = process.env.NODE_ENV

export default {
    checkURL(URL) {
        var str = URL;
        //判断URL地址的正则表达式为:http(s)?://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)?
        //下面的代码中应用了转义字符"\"输出一个字符"/"
        var Expression = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w- .\/?%&=]*)?/;
        var objExp = new RegExp(Expression);
        if (objExp.test(str) == true) {
            return true;
        } else {
            return false;
        }
    },
    // 获取URL参数
    getUrlParam(name, url) {
        var pairs = url.substring(url.indexOf('?') + 1).split('&')
        for (var i = 0; i < pairs.length; i++) {
            var pos = pairs[i].indexOf('=')
            if (pos === -1) {
                continue
            }
            if (pairs[i].substring(0, pos) === name) {
                return decodeURIComponent(pairs[i].substring(pos + 1))
            }
        }
    },

    // 日期转化
    dateFormatter(value, fmt = 'yyyy-MM-dd') {
        if (!value) {
            return ''
        }
        let date = new Date(Number(value));
        let o = {
            "M+": date.getMonth() + 1, //月份
            "d+": date.getDate(), //日
            "h+": date.getHours(), //小时
            "m+": date.getMinutes(), //分
            "s+": date.getSeconds(), //秒
            "q+": Math.floor((date.getMonth() + 3) / 3), //季度
            "S": date.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt))
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt))
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    },

    // 没有图标的提示
    showToast(title) {
        wx.showToast({
            title: title,
            icon: 'none'
        })
    },

    // 替换emoji表情
    filterEmoji(name) {
        var str = name.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/ig, "");
        return str;
    },
    //获取会员完整信息
    getVipInfo() {
        return new Promise((resolve, reject) => {
            Promise.all([
                    this.getVipBasicInfo(),
                    this.getAvatar()
                ])
                .then(([basic, avatar]) => {
                    if (basic) {
                        basic.avatarUrl = avatar
                        resolve(basic)
                    } else {
                        if (wxUtils.getUserCodeStorage()) {
                            resolve({
                                memberCode: wxUtils.getUserCodeStorage(),
                                avatarUrl: avatar
                            })
                        } else {
                            wx.showToast({
                                title: "授权登录失败"
                            })
                            reject("授权登录失败")
                        }
                    }
                })
                .catch(function (reason) {
                    wx.showToast({
                        title: reason
                    })
                });
        })
    },
    //获取会员基本信息（不包含头像）
    getVipBasicInfo(cb) {
        return new Promise(resolve => {
            let memberCode = wxUtils.getUserCodeStorage()
            let mobile = wxUtils.getPhoneStorage()

            let params = {
                memberCode,
                mobile
            }
            let requestOptions = {
                path: api.getVipInfo,
                method: 'get',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                resolve(res.data)
            })
            // .catch(error=>{
            //     wx.showModal({
            //         title: "错误",
            //         content: error
            //     })
            // })
        })
    },
    //获取会员头像
    getAvatar() {
        return new Promise(resolve => {
            let memberCode = wxUtils.getUserCodeStorage()
            let mobile = wxUtils.getPhoneStorage()

            let params = {
                memberCode,
                mobile
            }
            let requestOptions = {
                path: api.getAvatar + `/${mobile}`,
                method: 'get',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                resolve(res.data)
            })
        })
    },
    getMalls() {
        return new Promise(resolve => {
            let params = {

            }
            let requestOptions = {
                path: api.getMalls,
                method: 'get',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                resolve(res.data)
            })
        })
    },
    //md5机密
    md5Encrypt(value) {
        return md5(value)
    },
    //上传
    doUpload(filePath) {
        return new Promise(function (resolve) {
            wx.uploadFile({
                url: api.uploadAvatar,
                filePath: filePath,
                name: 'file',
                header: {
                    'Content-Type': 'application/json',
                    Authorization: wxUtils.getSessionKeyStorage(),
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                formData: {},
                success(response) {
                    let url = JSON.parse(response.data).data
                    resolve(url)
                }
            })
        })
    },
    previewFile() {
        wx.downloadFile({
            url: 'http://video.317hu.com/917b3140-3da6-47d5-911c-a15462fcdeb2.pdf',
            success: function (res) {
                var filePath = res.tempFilePath
                wx.openDocument({
                    filePath: filePath,
                    success: function (res) {
                    }
                })
            }
        })
    },
    setAfterLoginStorage(data, updateStoreFun) {
        return new Promise(resolve => {
            let {
                sessionId,
                userCode
            } = data
            wxUtils.setUserCodeStorage(userCode)
            getVipInfo().then(vipInfo => {
                updateStoreFun({
                    sessionId: sessionId,
                    vipInfo: vipInfo
                });
                resolve()
            })
        })
    },
    /*获取当前页url*/
    getCurrentPageUrl() {
        var pages = getCurrentPages() //获取加载的页面
        var currentPage = pages[pages.length - 1] //获取当前页面的对象
        var url = currentPage.route //当前页面url
        return url
    },
    /*获取当前页带参数的url*/
    getCurrentPageUrlWithArgs() {
        var pages = getCurrentPages() //获取加载的页面
        var currentPage = pages[pages.length - 1] //获取当前页面的对象
        var url = currentPage.route //当前页面url
        var options = currentPage.options //如果要获取url中所带的参数可以查看options

        return options
    },
    setPageLoadingStatus(key, val) {
        let pageLoading = wx.getStorageSync('pageLoading') || {}
        pageLoading[key] = val
        wx.setStorageSync('pageLoading', pageLoading)
    },
    getPageLoadingStatus(key) {
        return wx.getStorageSync('pageLoading')[key]
    },
    clearPageLoadingStatus() {
        wx.removeStorageSync('pageLoading')
    },
    getsourceFrom(val) {
        if (val == 'wuliao') {
            return '15'
        } else if (val == '01') {
            return '2'
        } else if (val == '02') {
            return '8'
        } else if (val == '0201') {
            return '9'
        } else if (val == '03') {
            return '10'
        } else if (val == '0301') {
            return '11'
        } else if (val == '0401') {
            return '12'
        } else if (val == '0402') {
            return '13'
        } else if (val == '05') {
            return '14'
        }
    },
    isFromGzh(platform) { //来源是公众号
        return platform == 1035
    },
    //分钟转化为时分秒
    formatSeconds(value) {
        var secondTime = parseInt(value); // 秒
        var minuteTime = 0; // 分
        var hourTime = 0; // 小时
        var dayTime = ''; //天
        if (secondTime > 60) { //如果秒数大于60，将秒数转换成整数
            //获取分钟，除以60取整数，得到整数分钟
            minuteTime = parseInt(secondTime / 60);
            //获取秒数，秒数取佘，得到整数秒数
            secondTime = parseInt(secondTime % 60);
            //如果分钟大于60，将分钟转换成小时
            if (minuteTime > 60) {

                //获取小时，获取分钟除以60，得到整数小时
                hourTime = parseInt(minuteTime / 60);
                //获取小时后取佘的分，获取分钟除以60取佘的分
                minuteTime = parseInt(minuteTime % 60);
                if (hourTime > 24) {
                    dayTime = parseInt(hourTime / 24);
                    hourTime = parseInt(hourTime % 24);
                }
            }
        }
        // var result = "" + parseInt(secondTime) + "秒";

        var result = "";

        if (minuteTime > 0) {
            result = "" + parseInt(minuteTime) + "分" + result;
        }
        if (hourTime > 0) {
            result = "" + parseInt(hourTime) + "小时" + result;
        }
        if (dayTime > 0) {
            result = "" + parseInt(dayTime) + "天" + result;
        }
        return result;
    },
    formatNumber (n) {
        const str = n.toString()
        return str[1] ? str : `0${str}`
    },
    transTime (value) {
        let D = new Date(value).getDate();
        let h = new Date(value).getHours();
        let m = new Date(value).getMinutes()
        return `${this.formatNumber(D)}日${this.formatNumber(h)}:${this.formatNumber(m)}`
    },
    setEnvStorage() {
        wx.setStorageSync('env', NODE_ENV)
    },
    getEnvStorage() {
        wx.getStorageSync('env')
    },
    isEnvEqual() {
        return wx.getStorageSync('env') == NODE_ENV
    },
    runAsync(time) {
        return new Promise(function (resolve, reject) {
            const timer = setTimeout(function () {
                resolve()
                clearTimeout(timer)
            }, time)
        })
    },
    multiply(arg1, arg2) {
        var m = 0,
          s1 = arg1.toString(),
          s2 = arg2.toString()
        if (s1.includes('.')) {
            m += s1.split('.')[1].length
        }
        if (s2.includes('.')) {
            m += s2.split('.')[1].length
        }
        // try {
        //   m += s1.split('.')[1].length
        // } catch (e) {
        //   console.log(e)
        // }
        // try {
        //   m += s2.split('.')[1].length
        // } catch (e) {
        //   console.log(e)
        // }
        return (
          (Number(s1.replace('.', '')) * Number(s2.replace('.', ''))) /
          Math.pow(10, m)
        )
    },
    add(arg1, arg2){
        var r1, r2, m, c
        try {
          r1 = arg1.toString().split('.')[1].length
        } catch (e) {
          r1 = 0
        }     
        try {
          r2 = arg2.toString().split('.')[1].length
        } catch (e) {
          r2 = 0
        } 
        c = Math.abs(r1 - r2)
        m = Math.pow(10, Math.max(r1, r2))
        if (c > 0) {
          var cm = Math.pow(10, c)
          if (r1 > r2) {
            arg1 = Number(arg1.toString().replace('.', ''))
            arg2 = Number(arg2.toString().replace('.', '')) * cm
          } else {
            arg1 = Number(arg1.toString().replace('.', '')) * cm
            arg2 = Number(arg2.toString().replace('.', ''))
          }
        } else {
          arg1 = Number(arg1.toString().replace('.', ''))
          arg2 = Number(arg2.toString().replace('.', ''))
        }
        return (arg1 + arg2) / m
      }
}
