import wxp from 'minapp-api-promise'
import wxUtils from '@/plugins/wxUtils'
import store from '../store/index'
import Vue from 'vue'
const BASE_URL = process.env.BASE_URL

/**
 * @params options options.hideLoading：隐藏加载框
 */
export default options => {
    return new Promise((resolve, reject) => {

        // if(options.isLoading != "false")
        // {

            if(!options.hideLoading){
                wxp.showLoading({
                    title: '加载中',
                })
            }
        // }
        let sessionId = wx.getStorageSync("sessionId")
        const requestOptions = {
            url: options.fullPath ? options.fullPath : (BASE_URL + options.path),
            header: {
                'Content-Type': options.contentType || 'application/json',
                'Authorization': sessionId,
                'L-A-Platform': 'mini-program' //后端日志埋点渠道
            },
            method: options.method || 'get',
            data: options.data || ''
        }
        wxp.request(requestOptions).then(response => {
            if (response.data.status === 200 || response.data.code === 200 || response.data.code === 0 || response.data.code === 130007) {
                resolve(response.data)
            } else {
                let message;
                if(typeof response.data.code != "undefined"){
                    message = response.data.code == 115004?"短信验证码不匹配":
                              response.data.code == 500?"网络开了小差，请重新尝试":response.data.message

                }else{
                    message = response.data
                }
                wx.showModal({
                    title: '温馨提示',
                    content: message||"网络开了小差，请重新尝试",
                    showCancel: false,
                    confirmText: '确认',
                    confirmColor: '#4694FA',
                    success (res) {
                        if (res.confirm) {
                            //用户信息过期后重新授权
                          if(response.data.code == 4001 || response.data.code == 4000 || response.data.code == 216001){
                                const oldisLogined = Vue.prototype.$store.state.isLogined
                                wxUtils.clearLoginStorage()
                                wx.setStorageSync('vipInfo',null)
                                wx.setStorageSync('sessionId','')
                                wx.setStorageSync('isLogined',oldisLogined)
                                Vue.prototype.$store.state.vipInfo = null
                                Vue.prototype.$store.state.wxUserInfo = null
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        } else if (res.cancel) {
                        }
                    }
                })
                reject(response.data)
            }
            if(!options.hideLoading){
                wxp.hideLoading()
            }
        }).catch(error => {
            wxp.showModal({
                title: '提醒',
                content: '网络开了小差，请重新尝试',
                showCancel: false,
                confirmText: '确认',
                confirmColor: '#4694FA'
            })
            reject(error)
            if(!options.hideLoading){
                wxp.hideLoading()
            }
        })
    })
}
