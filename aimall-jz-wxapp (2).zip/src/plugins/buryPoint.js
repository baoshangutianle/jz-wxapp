/***
 * desc：埋点通用方法
 * author： gry
 * date： 2019年8月22日10:05:20
 * 埋点教程：http://wiki.corp.rs.com/pages/viewpage.action?pageId=24873339
 */
import wxUtils from './wxUtils'
import Utils from './utils'
const BASE_URL_BIGDATA = process.env.BASE_URL_BIGDATA
//是否进行埋点请求
const flag = true

//获取通用参数
const getCommonParams = () => {
    return {
        u_mid: wxUtils.getOpenIdStorage(),
        u_id: wxUtils.getUserCodeStorage(),
        service: 'xiaochengxu',
        ts: parseInt(Date.now() / 1000), //10位时间戳
        d_os_version: wxUtils.getSystemInfo().system, //系统版本号
        d_prixel_x: wxUtils.getSystemInfo().screenWidth, //屏幕宽度
        d_prixel_y: wxUtils.getSystemInfo().screenHeight, //屏幕高度
        d_model: wxUtils.getSystemInfo().model, //设备型号
        p_url: Utils.getCurrentPageUrl(), // 当前页面路径
    }
}

//监测进入页面
const setP = (params = {}) => {
    if (flag) {
        let data = Object.assign({}, getCommonParams(), params)
        const requestP = wx.request({
            url: `${BASE_URL_BIGDATA}/p`,
            data
        })
        setTimeout(() => {
            requestP.abort();
        },5000)
        return requestP;
    }
}

//监测页面停留时间
const setZ = (params) => {
    if (flag) {
        let data = Object.assign({}, getCommonParams(), params)
        const requestZ = wx.request({
            url: `${BASE_URL_BIGDATA}/z`,
            data
        })
        setTimeout(() => {
            requestZ.abort();
        },5000)
        return requestZ;
    }
}

//监测页面操作
const setF = (params) => {
    if (flag) {
        let data = Object.assign({}, getCommonParams(), params)
        const requestF = wx.request({
            url: `${BASE_URL_BIGDATA}/f`,
            data: data
        })
        setTimeout(() => {
            requestF.abort();
        },5000)
        return requestF;
    }
}

export default {
    setP,
    setZ,
    setF
}
