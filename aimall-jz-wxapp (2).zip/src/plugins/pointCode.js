const HOME_P = 10 //首页_P
const HOME_Z = 11 //首页_Z
const HOME_BANNER = 68 //首页_banner
const HOME_PARK = 13 //首页_停车缴费
const HOME_GRADE = 14 //首页_自助积分
const HOME_VR = 15 //首页_VR逛商场
const HOME_CHECK = 16 //首页_签到福利
const HOME_VIP = 17 //首页_会员权益
const HOME_ACTIVITY = 18 //首页_热门活动
const HOME_AR = 19 //首页_AR寻宝
const HOME_SHOP = 20 //首页_商场服务
const HOME_NAVIGATE = 21 //首页_商场导航
const HOME_CARD = 22 //首页_超值领券
const HOME_CARD_MORE = 23 //首页_超值领券_查看更多
const HOME_GUIDE = 24 //首页_潮逛指南
const HOME_GUIDE_MORE = 25 //首页_潮逛指南-查看更多
// tabBar
const TABBAR_F_HOME = 6 //首页
const TABBAR_F_BRAND = 7 //品牌指引
const TABBAR_F_MINE = 9 //我的
// 潮逛指南
const GUIDE_P = 53
const GUIDE_Z = 54
const GUIDE_F_SEARCH = 55
const GUIDE_F_DETAIL = 56
const GUIDE_DETAIL_P = 57
const GUIDE_DETAIL_Z = 58
// 自助积分
const POINT_VALUE_P = 38
const POINT_VALUE_Z = 39
const POINT_VALUE_Photo = 40
// 热门活动
const ACTIVITY_P = 42
const ACTIVITY_Z = 43
const ACTIVITY_F_DETAIL = 44
const ACTIVITY_P_DETAIL = 45
const ACTIVITY_Z_DETAIL = 46
// 超值领券
const COUPON_P = 47
const COUPON_Z = 48
const COUPON_F_SEARCH = 49
const COUPON_F_GET = 50
const COUPON_DETAIL_P = 51
const COUPON_DETAIL_Z = 52
const COUPON_DETAIL_F = 6772
// 品牌指引
const BRAND_P = 60
const BRAND_Z = 61
const BRAND_F_SEARCH = 62
const BRAND_F_DETAIL = 63
const BRAND_DETAIL_P = 64
const BRAND_DETAIL_Z = 65
// 我的
const MINE_P = 70
const MINE_Z = 71
const MINE_F_COLLECT = 72
const MINE_F_TICKETS = 73
const MINE_F_CAR = 74
const MINE_F_SERVICE = 75
const MINE_F_SETTING = 76
// 停车
const CAR_P = 26
const CAR_Z = 27
const CAR_F_ADD = 28
const CAR_PAY_P = 29
const CAR_PAY_Z = 30
const CAR_PAY_F_CARD = 31
const CAR_PAY_F_PAY = 32

// 活动
const POPULAR_ACTIVITY_P = 6762
const POPULAR_ACTIVITY_Z = 6763
const POPULAR_ACTIVITY_F = 6764
// 活动报名
const ACTIVITY_SIGN_UP_P = 6765
const ACTIVITY_SIGN_UP_Z = 6766
const ACTIVITY_SIGN_UP_F = 6767
// 活动报名结果页
const ACTIVITY_SIGN_UP_SUCCESS_P = 6768
const ACTIVITY_SIGN_UP_SUCCESS_Z = 6769
const ACTIVITY_SIGN_UP_SUCCESS_GOHOME_F = 6770
const ACTIVITY_SIGN_UP_SUCCESS_F = 6771

//转盘抽奖
const LOTTERY_P = 6774   //大盘抽奖
const LOTTERY_Z = 6775  //大盘抽奖
const LOTTERY_START_F = 6776  //开始抽奖
const LOTTERY_IMMEDIATELY_F = 6777 //立即抽奖
const LOTTERY_LUCK_F = 6778 //嗮好运
const LOTTERY_SHARE_F = 6779 //分享给好友
const LOTTERY_SAVE_F = 6780 //保存至相册
const LOTTERY_INVITE_F = 6781 //邀请好友试一试
const LOTTERY_SHARE_P = 6782 //分享页面P
const LOTTERY_SHARE_Z = 6783 //分享页面Z
const LOTTERY_TRY_f = 6784 //我也试一试
const LOTTERY_ALREADY_F = 6785  //抽到了，知道了
const LOTTERY_INTEGRAL_F = 6786  //积分不足，知道了

//大屏转盘游戏埋点
const BIG_LOTTERY_P = 6787   //大盘抽奖
const BIG_LOTTERY_Z = 6788  //大盘抽奖
const BIG_LOTTERY_START_F = 6800  //开始抽奖
const BIG_LOTTERY_IMMEDIATELY_F = 6789 //立即抽奖
const BIG_LOTTERY_ALREADY_F = 6790  //抽过，知道了
const BIG_LOTTERY_INTEGRAL_F = 6792  //积分不足，知道了
const BIG_LOTTERY_RESULT_P = 6793  //大屏抽奖的结果页
const BIG_LOTTERY_RESULT_Z = 6794  //大屏抽奖的结果页
const BIG_LOTTERY_GO_F = 6795  //弹窗中奖去看看
const BIG_LOTTERY_GOHOME_F = 6796  //弹窗为中奖去首页

//扭蛋埋点
const GASHAPON_Index_P = 6893 // 扭蛋抽奖
const GASHAPON_Index_Z = 6894 // 扭蛋抽奖
const GASHAPON_Index_START_F = 6895 //扭一扭抽奖
const GASHAPON_Index_GO_F = 6896 // 立即抽奖
const GASHAPON_Index_KNOW_F = 6897 //积分不足--知道了
const GASHAPON_Index_Finish_F = 6898 // 抽过了-- 知道了
const GASHAPON_RESULT_SHARE_F = 6899 // 邀请好友试一试
const GASHAPON_RESULT_LUCK_F = 6900 // 晒好运
const GASHAPON_RESULT_INVITE_F = 6901 // 转发
const GASHAPON_RESULT_IMG_F = 6902 // 生成图片
const GASHAPON_SHARE_Index_P = 6903 // 扭蛋分享页
const GASHAPON_SHARE_Index_Z = 6904// 扭蛋分享页
const GASHAPON_SHARE_Index_F = 6905 // 我也去试试

//大屏扭蛋埋点
const BIG_GASHAPON_Index_P = 6906 // 扭蛋抽奖
const BIG_GASHAPON_Index_Z = 6907 // 扭蛋抽奖
const BIG_GASHAPON_Index_GO_F = 6908 // 立即抽奖
const BIG_GASHAPON_Index_KNOW_F = 6909 //积分不足--知道了
const BIG_GASHAPON_Index_Finish_F = 6910 // 抽过了-- 知道了
const BIG_GASHAPON_GO_CARDTICKET = 6911  //中奖去卡包看看
const BIG_GASHAPON_GOHOME_F = 6912  //为中奖去首页


export default {
    HOME_P,
    HOME_Z,
    HOME_BANNER,
    HOME_PARK,
    HOME_GRADE,
    HOME_VR,
    HOME_CHECK,
    HOME_VIP,
    HOME_ACTIVITY,
    HOME_AR,
    HOME_SHOP,
    HOME_NAVIGATE,
    HOME_CARD,
    HOME_CARD_MORE,
    HOME_GUIDE,
    HOME_GUIDE_MORE,
    TABBAR_F_HOME,
    TABBAR_F_BRAND,
    TABBAR_F_MINE,
    GUIDE_P,
    GUIDE_Z,
    GUIDE_F_SEARCH,
    GUIDE_F_DETAIL,
    GUIDE_DETAIL_P,
    GUIDE_DETAIL_Z,
    POINT_VALUE_P,
    POINT_VALUE_Z,
    POINT_VALUE_Photo,
    ACTIVITY_P,
    ACTIVITY_Z,
    ACTIVITY_F_DETAIL,
    ACTIVITY_P_DETAIL,
    ACTIVITY_Z_DETAIL,
    COUPON_P,
    COUPON_Z,
    COUPON_F_SEARCH,
    COUPON_F_GET,
    COUPON_DETAIL_P,
    COUPON_DETAIL_Z,
    COUPON_DETAIL_F,
    BRAND_P,
    BRAND_Z,
    BRAND_F_SEARCH,
    BRAND_F_DETAIL,
    BRAND_DETAIL_P,
    BRAND_DETAIL_Z,
    MINE_P,
    MINE_Z,
    MINE_F_COLLECT,
    MINE_F_TICKETS,
    MINE_F_CAR,
    MINE_F_SERVICE,
    MINE_F_SETTING,
    CAR_P,
    CAR_Z,
    CAR_F_ADD,
    CAR_PAY_P,
    CAR_PAY_Z,
    CAR_PAY_F_CARD,
    CAR_PAY_F_PAY,
    POPULAR_ACTIVITY_P,
    POPULAR_ACTIVITY_Z,
    POPULAR_ACTIVITY_F,
    ACTIVITY_SIGN_UP_P,
    ACTIVITY_SIGN_UP_Z,
    ACTIVITY_SIGN_UP_F,
    ACTIVITY_SIGN_UP_SUCCESS_P,
    ACTIVITY_SIGN_UP_SUCCESS_Z,
    ACTIVITY_SIGN_UP_SUCCESS_GOHOME_F,
    ACTIVITY_SIGN_UP_SUCCESS_F,
    LOTTERY_P,
    LOTTERY_Z,
    LOTTERY_START_F,
    LOTTERY_IMMEDIATELY_F,
    LOTTERY_LUCK_F,
    LOTTERY_SHARE_F,
    LOTTERY_SAVE_F,
    LOTTERY_INVITE_F,
    LOTTERY_SHARE_P,
    LOTTERY_SHARE_Z,
    LOTTERY_TRY_f,
    LOTTERY_ALREADY_F,
    LOTTERY_INTEGRAL_F,
    BIG_LOTTERY_P,
    BIG_LOTTERY_Z,
    BIG_LOTTERY_START_F,
    BIG_LOTTERY_IMMEDIATELY_F,
    BIG_LOTTERY_ALREADY_F,
    BIG_LOTTERY_INTEGRAL_F,
    BIG_LOTTERY_RESULT_P,
    BIG_LOTTERY_RESULT_Z,
    BIG_LOTTERY_GO_F,
    BIG_LOTTERY_GOHOME_F,
    GASHAPON_Index_P,
    GASHAPON_Index_Z,
    GASHAPON_Index_START_F,
    GASHAPON_Index_GO_F,
    GASHAPON_Index_KNOW_F,
    GASHAPON_Index_Finish_F,
    GASHAPON_RESULT_SHARE_F,
    GASHAPON_RESULT_LUCK_F,
    GASHAPON_RESULT_INVITE_F,
    GASHAPON_RESULT_IMG_F,
    GASHAPON_SHARE_Index_P,
    GASHAPON_SHARE_Index_Z,
    GASHAPON_SHARE_Index_F,
    BIG_GASHAPON_Index_P,
    BIG_GASHAPON_Index_Z,
    BIG_GASHAPON_Index_GO_F,
    BIG_GASHAPON_Index_KNOW_F,
    BIG_GASHAPON_Index_Finish_F,
    BIG_GASHAPON_GO_CARDTICKET,
    BIG_GASHAPON_GOHOME_F
}
