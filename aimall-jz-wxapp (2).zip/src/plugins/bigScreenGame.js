const BASE_URL_AIGAME = process.env.BASE_URL_AIGAME;
const BASE_URL = process.env.BASE_URL;

const startGame = (id, memberCode, callback)=>{
    
    wx.request({
        url: `${BASE_URL_AIGAME}/round/${id}/start?memberCode=${memberCode}`,
        method: 'PUT',
        success (res) {
            callback(res)
        }
    })
    
}

const endGame = (id,callback)=>{
    
    wx.request({
        url: `${BASE_URL_AIGAME}/round/${id}/end`,
        method: 'PUT',
        success (res) {
            callback(res)
        }
    })
    
}

const getGameTime = (callback)=>{
    
    wx.request({
        url: `${BASE_URL_AIGAME}/app/key/gesture-lottery`,
        method: 'get',
        success (res) {
            callback(res)
        }
    })
    
}

const getActivityId = (callback)=>{
    
    wx.request({
        url: `${BASE_URL_AIGAME}/app/key/lucky-lottery`,
        method: 'get',
        success (res) {
            callback(res)
        }
    })
    
}

const getShaponActivityId = (callback)=>{
    
    wx.request({
        url: `${BASE_URL_AIGAME}/app/key/shapon-lottery`,
        method: 'get',
        success (res) {
            callback(res)
        }
    })
    
}

const getSlotMachineActivityId = (callback)=>{
    
    wx.request({
        url: `${BASE_URL_AIGAME}/app/key/slot-machine`,
        method: 'get',
        success (res) {
            callback(res)
        }
    })
    
}


const getLedGameTime = (callback)=>{
    
    wx.request({
        url: `${BASE_URL_AIGAME}/app/key/led-lottery`,
        method: 'get',
        success (res) {
            callback(res)
        }
    })
    
}

const getParkOurGameTime = (callback)=>{
    
    wx.request({
        url: `${BASE_URL_AIGAME}/app/key/parkour`,
        method: 'get',
        success (res) {
            callback(res)
        }
    })
    
}



const fnGetDrawsNum = (id, sessionId, callback) => {
    wx.request({
        url: `${BASE_URL}/api-coupon-c/c/raffleActivity/checkMemberLotteryEligible/${id}`,
        method: 'get',
        header: {
            'Content-Type': 'application/json',
            Authorization: sessionId,
        },
        success (res) {
            callback(res)
        }
    })
}

const updateRoundMsg = (id,data,callback)=>{
    wx.request({
        url: `${BASE_URL_AIGAME}/round/${id}/data`,
        method: 'PUT',
        data: data,
        success (res) {
            callback(res)
        }
    })
    
}

const updateStatus = (id,callback)=>{
    wx.request({
        url: `${BASE_URL_AIGAME}/round/${id}`,
        method: 'get',
        success (res) {
            callback(res)
        }
    })
    
}

const updateLedRoundMsg = (id,data,callback)=>{
    wx.request({
        url: `${BASE_URL_AIGAME}/round/${id}/data/user`,
        method: 'post',
        data: data,
        success (res) {
            callback(res)
        }
    })
    
}

const getLedRoundMsg = (id,sessionId,callback)=>{
    wx.request({
        url: `${BASE_URL_AIGAME}/round/${id}/data/result/${sessionId}`,
        method: 'get',
        success (res) {
            callback(res)
        }
    })
    
}

const getParkOurRoundMsg = (id,sessionId,callback)=>{
    wx.request({
        url: `${BASE_URL_AIGAME}/round/${id}/data/result/${sessionId}`,
        method: 'get',
        success (res) {
            callback(res)
        }
    })
    
}



export default {
    startGame,
    getGameTime,
    getLedGameTime,
    getParkOurGameTime,
    updateRoundMsg,
    updateStatus,
    endGame,
    getActivityId,
    getShaponActivityId,
    fnGetDrawsNum,
    updateLedRoundMsg,
    getLedRoundMsg,
    getParkOurRoundMsg,
    getSlotMachineActivityId
}