const BASE_URL = process.env.BASE_URL
const BASE_CAR_URL = process.env.BASE_CAR_URL
const BASE_JINKE_URL = process.env.BASE_JINKE_URL

//接口前缀
const prefix_aegean = ''//总的前缀
const prefix_operation = "/api-operation-c"
const prefix_applet = "/api-applet-c"
const prefix_member = "/api-member-c"//会员
const prefix_coupon = "/api-coupon-c"//卡券
const prefix_e = "/api-coupon-e"
// const prefix_rest = "/member-c-rest"//订单

//获取小程序信息
const accountInfo = wx.getAccountInfoSync()
const appId = accountInfo.miniProgram.appId

export default {
    // 授权后保存微信用户信息  POST /v1/c/wx/user/saveOrUpdateWxUserInfo
    saveOrUpdateWxUserInfo: `${prefix_aegean}${prefix_applet}/v1/c/wx/user/saveOrUpdateWxUserInfo`, //授权后保存微信用户信息
    //获取session、openid
    getOpenId: `${prefix_aegean}${prefix_applet}/wxminiapp/user/${appId}/login`,
    //获取短信验证码
    getVertCode: `${prefix_aegean}${prefix_operation}/v1/msg/sendMessage`,
    // 登录
    login: `${prefix_aegean}${prefix_applet}/c/login`, //登录
    //保存用户信息
    saveUserInfo: `${prefix_aegean}${prefix_applet}/wxminiapp/user/${appId}/info`,
    // 获取手机号
    getPhone: `${prefix_aegean}${prefix_applet}/wxminiapp/user/${appId}/phone`,
    // 获取房间号
    getRoomId: `${BASE_URL}${prefix_applet}/wx/live/getRoomId`,
    // 获取直播列表
    getRoomList: `${BASE_URL}${prefix_applet}/wx/live/roomList`,
    //获取视频回放
    getReplay: `${BASE_URL}${prefix_applet}/wx/live/getReplay`,
    //获取直播房间详情
    getRoomInfo: `${BASE_URL}${prefix_applet}/wx/live/room`,
    // 获取会员信息
    getVipInfo: `${prefix_aegean}${prefix_member}/c/member/findMemberDetail`,
    // 获取会员code
    getUserCode: `${prefix_aegean}${prefix_applet}/v1/c/wx/user/findUserByOpenId`,
    // 获取所有兴趣标签
    getAllInterestTags: `${prefix_aegean}${prefix_member}/c/member/findInterestTag`,
    // 获取卡类型
    getAllCardTypes: `${prefix_aegean}${prefix_member}/c/member/findIntegralGradeList`,
    savePerosnInfo: `${prefix_aegean}${prefix_member}/c/member/perfectMemberInfo`,
    // 上传头像
    uploadAvatar: `${BASE_URL}${prefix_operation}/v1/file/upload`,
    saveAvatar: `${prefix_aegean}${prefix_applet}/v1/c/wx/user/uploadHeadImgUrl`,
    getAvatar: `${prefix_aegean}${prefix_applet}/v1/c/wx/user/getHeadImgUrl`,
    //获取弾层
    getLayer: `${prefix_aegean}${prefix_operation}/v1/cmsPopupLayer/getCmsPopupLayer`,
    // 公告
    findShopNotice: '/api-aegean-b/operation-b/v1/b/notice/findShopNotice', //查看店铺公告列表
    getNotice: '/api-aegean-b/operation-b/v1/b/notice/getNotice', //查看公告详情号
    createOrEditShopAccount: '/api-aegean-b/operation-b/v1/b/shopUser/createOrEditShopAccount', //创建账户
    // 活动
    createShopActivity: '/api-aegean-b/operation-b/v1/b/shop/activity/createShopActivity', //提报活动
    // 枚举
    enumInfo: '/api-aegean-b/ad-b/b/adCommon/getEnumInfo', // 枚举列表
    // 租赁申请
    adApplyDetils: '/api-aegean-b/ad-b/b/adApply/getAdApplyInfo', // 营销位详情
    queryScheduledDate: '/api-aegean-b/ad-b/b/adScheduling/selectScheduledDate', // 查询已排期日期列表
    adApplySubmit: '/api-aegean-b/ad-b/b/adApply/apply', // 提交申请
    // 活动清单
    getPromtionPage: '/api-aegean-b/activity-b/b/v1/mp/promotion/getPromotionShopVoForB', // 促销查询
    promotionShow: '/api-aegean-b/activity-b/b/v1/mp/promotion/show', // 查看促销
    signPromotion: '/api-aegean-b/activity-b/b/v1/mp/promotionShop/signPromotion', // 店铺报名
    // 核销卡券
    findUsedCoupon: '/api-aegean-b/activity-b/b/v1/mp/usedCoupon/findCoupon', // 查询核销劵
    usedCoupon: '/api-aegean-b/activity-b/b/v1/mp/usedCoupon/usedCoupon', // 使用核销劵
    usedCouponPage: '/api-aegean-b/activity-b/b/v1/mp/usedCoupon/usedCouponPage', // 查询核销劵
    // 上传文件
    // uploadFile: uploadFile, //上传文件
    // 其他
    getShopInfoForB: '/api-aegean-b/operation-b/v1/b/shop/getShopInfoForB', //查询店铺信息
    findCostArrearsOrderFeign: '/api-aegean/finance/e/costOrder/findCostArrearsOrderFeign', //查询欠费
    adMakeBillSelecteNew: '/api-aegean-b/ad-b/b/adMakeBill/selecteNew', //查询新的制作单
    adMakeBillUpdateNew: '/api-aegean-b/ad-b/b/adMakeBill/updateNew', //更新制作单
    getIntegralStatus:`${prefix_aegean}${prefix_applet}/c/function/readFlag`, //获取积分商城是否第一次
    // -----------------------------------小程序-----------------------------------------//
    getEffectCmsResource: `${prefix_aegean}${prefix_operation}/v1/cmsResource/getEffectCmsResource/1`, //获取轮播图
    getCmsContent: `${prefix_aegean}${prefix_operation}/v1/cmsContent/queryCmsContent`, //获取潮逛指南列表
    getCmsContentById: `${prefix_aegean}${prefix_operation}/v1/cmsContent/getCmsContent/`, //获取潮逛指南列表
    getStoreNav: `${prefix_aegean}${prefix_operation}/v1/category/selectList`, //获取人气餐饮菜单列表
    getStoreFloor: `${prefix_aegean}${prefix_operation}/v1/floors/`, //获取人气餐饮楼层列表
    getStoreList: `${prefix_aegean}${prefix_operation}/v1/store/query`, //获取人气餐饮店铺列表
    getStoreListDetail: `${prefix_aegean}${prefix_operation}/v1/store/get/`, //获取人气餐饮店铺详情
    getMalls: `${prefix_aegean}${prefix_operation}/v1/malls`,
    // 车牌管理
    getUserCars: `${BASE_CAR_URL}/bindingCar/getUserCars`,  // 用户车牌列表
    bindingCar: `${BASE_CAR_URL}/bindingCar/bindingCar`,  // 用户车牌绑定
    unBindingCar: `${BASE_CAR_URL}/bindingCar/unBindingCar`,  // 用户车牌解绑
    getOrderDetail: `${BASE_CAR_URL}/order/getOrderDetail`,  // 根据车牌获取车辆付款信息
    verifyOrder: `${BASE_CAR_URL}/order/verifyOrder`,  // 验单
    cancelOrder: `${BASE_CAR_URL}/order/cancelOrder`,

    // 积分
    getVipInfoByMobile: `${BASE_URL}${prefix_member}/c/member/findMemberDetail`,  // 获取积分
    getLoginMemberDetail: `${BASE_URL}${prefix_member}/c/member/loginFindMemberDetail`,  // 判断用户是否已经过期获取积分
    findIntegralConvert: `${BASE_URL}${prefix_member}/c/integral/findIntegralConvert`,  // 积分兑换金额
    doIntegralPhoto: `${prefix_aegean}${prefix_member}/c/integralApply/addIntegralApply`,//拍照积分
    getIntegralRecord: `${prefix_aegean}${prefix_member}/c/integralApply/getIntegralApplyCPage`,//积分记录
    getIntegralDetail: `${prefix_aegean}${prefix_member}/c/integral/manualadjust/findIntegralPage`,//个人积分详情
    doScan: `${prefix_aegean}${prefix_member}/c/integral/consume`,//扫码积分
    registerIntergral: `${prefix_aegean}${prefix_member}/c/integral/manualadjust/adjust`,//注册积分

    //我的收藏
    getMyCollectArticle: `${prefix_aegean}${prefix_applet}/v1/c/collect/collectAritcleList`,
    // getMyCollectFood: `${prefix_aegean}${prefix_applet}/v1/c/collect/collectStoreList`,
    getMyCollectFood: `${prefix_aegean}${prefix_applet}/v1/c/collect/storeFavoritesList`,
    doCollect: `${prefix_aegean}${prefix_applet}/v1/c/collect/create`,  // 收藏
    getCollectStatus: `${prefix_aegean}${prefix_applet}/v1/c/collect/getCollectState`,  // 收藏状态

    //卡券
    // getCards: `${prefix_aegean}${prefix_coupon}/c/couponMemberRelation/list`,  // 卡券列表
    getCards: `${prefix_aegean}${prefix_coupon}/c/couponMemberRelation/listDetail`,  // 卡券列表
    getCouponNumForC: `${prefix_aegean}${prefix_coupon}/c/couponMemberRelation/getCouponNumForC`,  // 卡券列表
    getCouponUserDetail: `${prefix_aegean}${prefix_coupon}/c/couponMemberRelation/getExchangeCouponDetailById`,  // 我的卡券详情
    getCardsType: `${prefix_aegean}${prefix_coupon}/c/couponMemberRelation/couponType`,  // 获取所有券类型

    //超值领券
    getCouponBatchPage: `${prefix_aegean}${prefix_coupon}/c/couponMall/getCommendCouponBatchPage`,  // 超值领券列表
    getCouponNormalBatchPage: `${prefix_aegean}${prefix_coupon}/c/couponMall/getCouponBatchPage`,  // 超值领券列表
    buyCoupon: `${prefix_aegean}${prefix_coupon}/c/couponMall/buyCoupon`,  // 超值领券购买
    getCouponDetail: `${prefix_aegean}${prefix_coupon}/c/couponMall/findInfo`,  // 超值领券购买、未激活会员
    getCouponDetail2: `${prefix_aegean}${prefix_coupon}/c/couponMemberRelation/findDetailByCouponCode`,  // 超值领券购买、会员
    // getCouponDetailNormal: `${prefix_aegean}${prefix_coupon}/c/couponMall/getDetailById`,  // 超值领券购买、未激活会员
    getCouponStatus: `${prefix_aegean}${prefix_coupon}/c/couponMemberRelation/findDetailStatus`,//获取卡券领取状态

    // 停车券
    parkCouponList: `${BASE_URL}${prefix_coupon}/c/parkCoupon/list`, // 停车券获取

    // 获取新版可报名热门活动
    queryMmcApplyActivity: `${BASE_URL}${prefix_member}/c/mmcApplyActivity/queryMmcApplyActivity`,
    // 活动详情
    getMmcApplyActivity: `${BASE_URL}${prefix_member}/c/mmcApplyActivity/getMmcApplyActivity`,
    //热门活动详情下载小程序码
    getQrcodeUrl:`${BASE_URL}${prefix_member}/c/mmcApplyActivity/mmcApplyActivityCreateImage`,
    //我的--报名活动列表
    getMyActivity: `${prefix_member}/c/mmcMemberApply/queryMmcMemberApply`,
    // 报名
    mmcMemberApply: `${BASE_URL}${prefix_member}/c/mmcMemberApply/apply`,
    // 获取我的活动中的活动详情
    getMmcMemberApply: `${BASE_URL}${prefix_member}/c/mmcMemberApply/getMmcMemberApply`,

    //积分商城
    //首页分类
    getFirstPageCategoryList: `${prefix_aegean}${prefix_member}/c/mallGoods/getFirstPageCategoryList`,
    deleteMemberAddress: `${prefix_aegean}${prefix_member}/c/mallMemberAddress/deleteMemberAddress/`,

    //兑换记录列表
    exchangeRecordList: `${BASE_URL}${prefix_member}/c/integralOrder/queryIntegralOrder`,
    //积分商城列表
    integralList: `${prefix_aegean}${prefix_member}/c/integralmallProd/queryIntegralProdList`,
    // 积分商品详情
    getIntegralProd: `${prefix_aegean}${prefix_member}/c/integralmallProd/browseIntegralProd`,
     // 积分商品详情new
     getIntegralProdNew: `${BASE_URL}${prefix_member}/c/integralmallProd/browseIntegralProd`,
    //积分商品兑换
    exchange: `${prefix_aegean}${prefix_member}/c/integralmallProd/exchange`,
    // 已兑换商品详情
    getIntegralOrder: `${prefix_aegean}${prefix_member}/c/integralOrder/getIntegralOrder`,
    // -------------------抽奖---------------------//
    // 查询活动详情
    getActivityDetail: `${prefix_aegean}${prefix_coupon}/c/raffleActivity/getActivityDetail/`,
    // 查询抽奖资格
    checkLuckyDraw: `${prefix_aegean}${prefix_coupon}/c/raffleActivity/checkMemberLotteryEligible/`,
    checkMemberLotteryEligible: `${BASE_URL}${prefix_coupon}/c/raffleActivity/checkMemberLotteryEligible/`,
    //查询抽奖奖品列表
    listOfPrizes:`${prefix_aegean}${prefix_coupon}/c/raffleActivity/listOfPrizes`,
    // 查询中奖结果
    luckyTry: `${prefix_aegean}${prefix_coupon}/c/raffleActivity/luckyTry`,
    // 下载照片接口
    downLoadPhoto: `${prefix_aegean}${prefix_coupon}/c/raffleActivity/createPicture`,
    //判断用户是否30天过期
    tokenIsExpired: `${BASE_URL}${prefix_applet}/c/tokenIsExpired`,
    //判断是否有签到活动
    getActivitySign: `${prefix_aegean}${prefix_coupon}/c/activity/sign/activityInfo`,
    //获取签到日历
    getSignInfo: `${prefix_aegean}${prefix_coupon}/c/activity/sign/getSignInfo`,
    getSignCalendar: `${prefix_aegean}${prefix_coupon}/c/activity/sign/signCalendar`,
    //签到
    signIn: `${BASE_URL}${prefix_coupon}/c/activity/sign/signIn`,
    //签到明细
    signDetails: `${prefix_aegean}${prefix_coupon}/c/activity/sign/signDetail`,
    //转发
    shareAdd: `${prefix_aegean}${prefix_applet}/v1/c/relay/add`,
    //获取转发数量
    shareNum: `${prefix_aegean}${prefix_applet}/v1/c/relay/getCollectAndRelayNum`,
    //收藏、数量新接口
    creatCollect: `${prefix_aegean}${prefix_applet}/v1/c/relay/create`,
    //获取扭蛋抽奖弹幕
    barrageList: `${prefix_aegean}${prefix_coupon}/c/raffleActivity/barrageByActiviyId`,
    //获取扭蛋抽奖的Id
    getGashaponNo: `${prefix_aegean}${prefix_coupon}/c/raffleActivity/getGashaponNo`,
    checkLuckyDraw: `${prefix_aegean}${prefix_coupon}/c/raffleActivity/checkMemberLotteryEligible/`,
    //聚合页面
    polymerization: `${prefix_aegean}${prefix_coupon}/c/raffleActivity/polymerization`,
    //校验用户是否被剔出
    tokenIsExpired: `${BASE_URL}${prefix_applet}/c/tokenIsExpired`,
    //会员获取停车券通知接口
    getMemberNotice: `${prefix_aegean}${prefix_member}/c/memberNotice/getMemberNotice`,
    //获取首页icon
    queryIcon:`${prefix_aegean}${prefix_operation}/v1/cicon/queryIcon`,
    //在线商城-商品详情接口
    goodsDtails:`${BASE_URL}${prefix_member}/c/mallGoods/goodsDetail/`,
    //在线商城列表
    onlineMallList: `${prefix_aegean}${prefix_member}/c/mallGoods/queryGoodsList`,


    //收货人地址列表
    findMemberAddress: `${prefix_aegean}${prefix_member}/c/mallMemberAddress/findMemberAddress`,
    getOneAddress: `${prefix_aegean}${prefix_member}/c/mallMemberAddress/`,
    updateOneAddress: `${prefix_aegean}${prefix_member}/c/mallMemberAddress/insertOrUpdate`,
    //商品详情
    prodctDetail: `${prefix_aegean}${prefix_member}/c/mallGoods/goodsDetail/`,
    //创建订单
    createOrder: `${prefix_aegean}${prefix_member}/c/order/create`,

    //订单管理
    getOrderList: `${prefix_aegean}${prefix_member}/c/order/list`,
    //订单收货
    receiptOrder: `${prefix_aegean}${prefix_member}/c/order/receipt`,
    //取消收货
    cancelOrder: `${prefix_aegean}${prefix_member}/c/order/cancel`,
    //取消收货
    repayOrder: `${prefix_aegean}${prefix_member}/c/order/repay`,
    //订单详情
    queryOrderDetail: `${prefix_aegean}${prefix_member}/c/order/detail`,
    //获取秒杀场次
    queryEffective: `${prefix_aegean}${prefix_member}/c/seckillRound/queryEffectiveRoundActivity`,
    //根据时间获取秒杀商品
    queryEffectiveGoods: `${prefix_aegean}${prefix_member}/c/seckillGoods/queryEffectiveSeckillGoods`,
    //获取秒杀详情 GET /c/seckillGoods/querySeckillGoodsDetail
    querySeckillGoodsDetail: `${prefix_aegean}${prefix_member}/c/seckillGoods/querySeckillGoodsDetail`,
    //购物车列表
    cartList:`${prefix_member}/c/cart/list`,
    //添加到购物车
    saveCart:`${prefix_member}/c/cart/save`,
    //分享裂变有奖标识接口
    getShareIdentify:`${prefix_member}/c/shareFission/activity/info`,
     //获取分享裂变活动分享码
    getShareCode:`${prefix_member}/c/shareFission/activity/sharecode`
}
