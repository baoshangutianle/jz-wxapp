/***
 * desc：微信通用方法
 * author： gry
 * date： 2019年8月7日18:12:50
 */
import api from '@/plugins/api'
import request from '@/plugins/request'
const accountInfo = wx.getAccountInfoSync()//获取小程序信息
const appId = accountInfo.miniProgram.appId
const USER_STORAGE = 'wxUserInfo'
const SESSION_STORAGE = 'wxSession'
const OPENID_STORAGE = 'wxOpenId'
const USER_CODE = 'wxUserCode'
const PHONE = 'wxPhone'
const LOGINTYPE_STORAGE = 'loginType'//登录类型，wx-微信、system-系统
const LOGINTYPE_WX = 'wx'
const LOGINTYPE_SYSTEM = 'system'
const ISVIP_STORAGE = 'isVip' //是否vip
const SHARE_CODE = 'shareCode' //是否vip

 //获取用户sessionKey
const getUserSession = function(cb) {
    wx.login({
        success(res) {
            let code = res.code
            if (code) {
                let params = {
                    appid: appId,
                    code: code
                }
                let requestOptions = {
                    path: api.getOpenId,
                    method: 'get',
                    data: params,
                    hideLoading: true
                }
                request(requestOptions)
                    .then(res2 => {
                        let {sessionKey,openid} = res2.data
                        setSessionKeyStorage(sessionKey)
                        setOpenIdStorage(openid)
                        cb&&cb.call(null,{
                            sessionKey,
                            openId: openid
                        })
                    })
            }
        }
    })
}

//设置用户信息缓存
const setUserStorage = function(val){
    wx.setStorageSync(USER_STORAGE,val)
}

//获取用户信息缓存
const getUserStorage = function(){
    return wx.getStorageSync(USER_STORAGE)
}

//删除USER_CODE缓存
const removeUserStorage = function(){
    wx.removeStorageSync(USER_STORAGE)
}

//设置sessionKey缓存
const setSessionKeyStorage = function(val){
    wx.setStorageSync(SESSION_STORAGE,val)
}

//获取sessionKey缓存
const getSessionKeyStorage = function(){
    return wx.getStorageSync(SESSION_STORAGE)
}

//设置openId缓存
const setOpenIdStorage = function(val){
    wx.setStorageSync(OPENID_STORAGE,val)
}

//获取openId缓存
const getOpenIdStorage = function(){
    return wx.getStorageSync(OPENID_STORAGE)
}

//获取shareCode缓存
const getShareCodeStorage = function(){
    return wx.getStorageSync(SHARE_CODE) || null
}

//设置USER_CODE缓存
const setUserCodeStorage = function(val){
    wx.setStorageSync(USER_CODE,val)
}

//获取USER_CODE缓存
const getUserCodeStorage = function(){
    return wx.getStorageSync(USER_CODE)
}

//删除USER_CODE缓存
const removeUserCodeStorage = function(){
    wx.removeStorageSync(USER_CODE)
}

//设置Phone缓存
const setPhoneStorage = function(val) {
    wx.setStorageSync(PHONE,val)
}

//获取Phone缓存
const getPhoneStorage = function(){
    return wx.getStorageSync(PHONE)
}

//设置IsViper缓存
const setIsViperStorage = function(val) {
    wx.setStorageSync(ISVIP_STORAGE,val)
}

//获取Phone缓存
const getIsViperStorage = function(){
    return wx.getStorageSync(ISVIP_STORAGE)
}

//设置LoginType缓存
const setLoginTypeStorage = function(val) {
    wx.setStorageSync(LOGINTYPE_STORAGE,val)
}

//获取LoginType缓存
const getLoginTypeStorage = function(){
    let result = LOGINTYPE_WX
    let loginType = wx.getStorageSync(LOGINTYPE_STORAGE)
    let wxUserInfo = getUserStorage()
    let userCode = getUserCode()
    if(isStorageEmpty(loginType)){//如果不存在登录类型缓存
        if(!isStorageEmpty(wxUserInfo)&&!isStorageEmpty(userCode)){//如果存在微信信息且会员code不为空
            result = LOGINTYPE_SYSTEM
        }
    }else{
        result = wx.getStorageSync(LOGINTYPE_STORAGE)
    }

    return result
}

//设置当前登录方式为：微信登录
const setWxLoginStorage = function() {
    setLoginTypeStorage(LOGINTYPE_WX)
}

//设置当前登录方式为：系统登录
const setSystemLoginStorage = function() {
    setLoginTypeStorage(LOGINTYPE_SYSTEM)
}

//获取小程序完整信息
const getAppInfo = function() {
    return accountInfo
}

//获取小程序appId
const getAppId = function() {
    return appId
}

//获取UserCode
const getUserCode = function(cb) {
    let params = {
        openId: getOpenIdStorage()
    }
    let requestOptions = {
        path: api.getUserCode,
        method: 'get',
        data: params,
        hideLoading: true
    }
    request(requestOptions).then(res=>{
        if(res.code == 200){
            wx.setStorageSync('newWxUserFlag',res.data.newWxUserFlag)
        }
        cb&&cb.call(null,null,res.data)
    })
}

//手机号登录
const loginByAuth = function(phone,cb) {
    let openId = getOpenIdStorage()
    // let shareCode = getShareCodeStorage()
    let wxUserInfo = Object.assign({},getUserStorage().userInfo)
    let {nickName} = wxUserInfo
    let params = {
        mobile: phone,
        loginSource: "b-mini-program",
        // shareCode,
        loginType: "nopassword",
        userName:nickName,
        sourceFrom:wx.getStorageSync('sourceFrom') ? wx.getStorageSync('sourceFrom') :'',
        openId
    }

    login(params,cb)
}

//微信授权登录
const loginByPhone = function(phone,code,cb) {
    let wxUserInfo = Object.assign({},getUserStorage().userInfo)
    // let shareCode = getShareCodeStorage()
    let {nickName} = wxUserInfo
    let params = {
        openId: getOpenIdStorage(),
        // shareCode,
        mobile: phone,
        loginSource: 'c-mobile-captcha',
        loginType: "nopassword",
        userName: nickName,
        verifyCode: code
    }

    login(params,cb)
}

const isStorageEmpty = function(value){
    return (Object.prototype.toString.call(value)=="[object Object]"&&Object.keys(value).length==0)||
                (Object.prototype.toString.call(value)=="[object String]"&&!value)
}

//获取用户激活状态
const getActiveStatus = function(cb) {
    var result = false;
    let userCode = getUserCodeStorage()
    if(isStorageEmpty(userCode)){
        getUserCode(function(err,res){
            if(!err&&res){
                let {userCode,mobile} = res
                setPhoneStorage(mobile)
                setUserCodeStorage(userCode)
                result = (userCode&&userCode.length>0)?true:false
                cb&&cb.call(null,result,res)
            }
        })
    }else{
        result = true
        cb&&cb.call(null,result)
    }
}

const registerIntergral = ()=>{
    return new Promise(resolve=>{
        let mallCode = wx.getStorageSync("mallCode")
        let memberCode = getUserCodeStorage()
        let mobile = getPhoneStorage()

        let params = {
            "mallCode": mallCode,
            "memberCode": memberCode,
            "mobile": mobile,
            "adjustIntegral": "100",
            "adjustReason": "CS0018",
            "integralAdjustTypeEnums": "GENERAL_ADJUST",
            "integralSourceFromEnums": "REGISTER_MEMBER",
            "integralSource": "5"
        }
        let requestOptions = {
            path: api.registerIntergral,
            method: 'post',
            data: params
        }
        request(requestOptions).then(res=>{
            resolve(res.data)
        })
    })
}

//登录
const login = function(params,cb) {
    //加入注册来源
    var commonParms = {
        sourceFrom: wx.getStorageSync('sourceFrom') ? parseInt(wx.getStorageSync('sourceFrom')) :''
    }
    Object.assign(params,commonParms)
    let requestOptions = {
        path: api.login,
        method: 'post',
        data: params
    }
    request(requestOptions).then(res=>{
        cb&&cb.call(null,res.data)
    })
}

//退出登录，删除全部缓存，除了vip状态。因为我的头像操作具有2种判断状态
const logout = function(cb) {
    clearLoginStorage()
    cb&&cb.call(null)
}

//显示确认弹框
const showConfirmMsg = function(msg) {
    return new Promise((resolve, reject) => {
        wx.showModal({
            title: '',
            content: msg,
            showCancel: false,
            confirmText: '确定',
            success(){
                resolve()
            }
        })
    })
}

//重新加载页面
const reloadPage = function() {
    //判断是否有打开过页面
    if (getCurrentPages().length != 0) {
        //刷新当前页面的数据
        getCurrentPages()[getCurrentPages().length - 1].onLoad()
    }
}

//系统登录状态
const isSystemLogin = function(){
    let result = false
    let userCode = getUserCodeStorage()
    if(!isStorageEmpty(userCode)){
        result = true
    }
    return result
}

const getWxLoginType = function() {
    return LOGINTYPE_WX
}

const getSystemLoginType = function() {
    return LOGINTYPE_SYSTEM
}

const clearLoginStorage = () => {
    wx.removeStorageSync(USER_STORAGE)
    wx.removeStorageSync("isLogined")
    wx.removeStorageSync(SESSION_STORAGE)
    wx.removeStorageSync(OPENID_STORAGE)
    wx.removeStorageSync(USER_CODE)
    wx.removeStorageSync(PHONE)
}
//获取设备信息
const getSystemInfo = function() {
    let systemInfo = ''
    wx.getSystemInfo({
        success:function(res){
            systemInfo = res
        }
    });
    return systemInfo
}

export default {
    getUserSession,
    setUserStorage,
    getUserStorage,
    setSessionKeyStorage,
    getSessionKeyStorage,
    setOpenIdStorage,
    getOpenIdStorage,
    getShareCodeStorage,
    setUserCodeStorage,
    getUserCodeStorage,
    setPhoneStorage,
    getPhoneStorage,
    setLoginTypeStorage,
    getLoginTypeStorage,
    setIsViperStorage,
    getIsViperStorage,
    getAppInfo,
    getAppId,
    loginByAuth,
    loginByPhone,
    showConfirmMsg,
    getActiveStatus,
    logout,
    reloadPage,
    isStorageEmpty,
    isSystemLogin,
    setWxLoginStorage,
    setSystemLoginStorage,
    getWxLoginType,
    getSystemLoginType,
    clearLoginStorage,
    registerIntergral,
    getUserCode,
    getSystemInfo
}
