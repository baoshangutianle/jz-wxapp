export const INTELSORT = '智能排序';
export const ALLSORT = '筛选';
export const ISFOOD = '美食';
export const MALLCODE = 'HXSGSH01';
export const BUILDINGID = '2';
