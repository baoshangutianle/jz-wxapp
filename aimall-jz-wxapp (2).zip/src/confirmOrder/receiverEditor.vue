<template>
    <div class="receiverEditor">
        <div class="formContent">
            <div class="formLine">
                <div class="name">收件人</div>
                <input type="text" placeholder="请填写收件人" placeholder-style="color:#999" v-model="form.consigeeName" />
            </div>
            <div class="formLine">
                <div class="name">手机号码</div>
                <input type="text" placeholder="请填写手机号码" placeholder-style="color:#999" v-model="form.consigeeMobile" />
            </div>
            <div class="formLine">
                <div class="name">所在地区</div>
                <input type="text" placeholder="请填写所在地区" placeholder-style="color:#999" v-model="form.province" />
                <picker
                    :value="region"
                    style="position: absolute;left:0;top:0;bottom: 0;text-align: right;width: 100%;z-index:99"
                    mode="region"
                    @change="bindRegionChange"
                >
                    <view
                        style="position: absolute;left:0;top:0;text-align: right;width: 100%;bottom: 0;display: flex;align-items: center;justify-content: flex-end;"
                        class="picker"
                    >
                    </view>
                </picker>
            </div>
            <div class="formLine">
                <div class="name">详细地址</div>
                <textarea
                    name
                    id
                    cols="30"
                    rows="10"
                    placeholder-style="color:#999"
                    placeholder="请填写详细地址"
                    v-model="form.consigeeAddress"
                ></textarea>
            </div>
            <div class="formLine setDefault">
                <div class="name">设置默认地址</div>
                <div :class="['switch', {'active': isDefault}]" @click="setDefault">
                    <div class="dot"></div>
                </div>
            </div>
        </div>
        <div :class="['bottomAdaptor',{'iphoneX': isIphoneX}]">
            <div class="buttonWrap">
                <!-- <div class="btnConfirm" @click="updateNReturn" v-if="isAdd">添加新地址</div>
                <div class="btnConfirm" v-else>添加新地址</div> -->
                 <div class="btnConfirm" @click="updateNReturn" v-if="isAdd">保存</div>
                <div class="btnConfirm" v-else>保存</div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import wxUtils from '@/plugins/wxUtils'
import api from '@/plugins/api'
import utils from '@/plugins/utils'
import request from '@/plugins/request'

export default {
    name: 'receiverEditor',
    data() {
        return {
            form: {},
            isDefault: 0,
            address:'',
            isIphoneX: wxUtils.getSystemInfo().model.indexOf('iPhone X') >= 0,
            isAdd:true,
            region:[]
        }
    },
    computed: {
        ...mapState(['wxUserInfo','vipInfo','sessionId','isLogined'])
    },
    mounted() {
        let _this = this
        _this.isAdd = true
        this.form = {
            // memberCode: this.vipInfo.memberCode //todo
            memberCode: wx.getStorageSync('wxUserCode')
        }
        this.addressId = this.$mp.query.addressId || 0
        
        // console.log(this.$mp.query)
        wx.setNavigationBarTitle({
            title: _this.addressId ? '编辑地址' : '添加地址'
        })
        if(!_this.addressId){
            this.region = []
        }
        if (!!this.addressId) this._fetchAddressDetail() 
    },
    onShow(){
        // this.form.province = getApp().globalData.address || ''
    },
    methods: {
        _fetchAddressDetail() {
            let opsiton = {
                path: api.getOneAddress + this.addressId,
                method: 'get',
                data: null,
                hideLoading: true
            }
            request(opsiton).then(res => {
                console.log(res.data,res.data.province)
                let data = res.data
                if (data) {
                    this.form = data
                    this.isDefault = data.useFlag
                    this.form.province = data.province
                    this.region = data.province?data.province.split(' '):[]
                    console.log('region',this.region)
                }
            })
        },

        bindRegionChange: function(e) {
            console.log('picker发送选择改变，携带值为', e.target.value)
            if (!e.target.code[0] || !e.target.code[1] || !e.target.code[2]) {
                wxUtils.showConfirmMsg("所在城市不可选全部")
                return false
            }
            this.region = e.target.value
            this.form.province=''
            this.region.forEach((item,index)=>{
                if(index==0){
                    this.form.province += item
                }else{
                    this.form.province += ' '+item
                }
            })
            // this.form.province += this.region
            console.log(e.target.value,e.target.code,this.region,this.form.province)
            // this.regionCode = e.target.code
            // this.userForm.province = this.region[0]
            // this.userForm.city = this.region[1]
            // this.userForm.district = this.region[2]
            // this.userForm.provinceCode = this.regionCode[0]
            // this.userForm.cityCode = this.regionCode[1]
            // this.userForm.districtCode = this.regionCode[2]
        },
        _updateAddress(cb) {
            if(!this.form.consigeeName){
                this.isAdd = true
                return utils.showToast('收件人不能为空')
            }else if(!this.form.consigeeMobile){
                this.isAdd = true
                return utils.showToast('手机号不能为空')
            }else if(this.form.consigeeMobile && !this.validateField("phone", this.form.consigeeMobile)){
                this.isAdd = true
                return utils.showToast('您输入的号码有误')
            }else if(!this.form.province){
                this.isAdd = true
                return utils.showToast('所在地区不能为空')
            }else if(!this.form.consigeeAddress){
                this.isAdd = true
                return utils.showToast('详细地址不能为空')
            }
            let opsiton = {
                path: api.updateOneAddress,
                method: 'post',
                data: this.form,
                hideLoading: true
            }
            request(opsiton).then(res => {
                console.log(res.data,res)
                if(res.code!=200){
                    this.isAdd  = true 
                }
                cb()
            })
        },
        validateField(type, value) {
            var result = true
            if (type == "phone") {
                if (!value || value.length != 11 || value.slice(0, 1) != 1) {
                    result = false
                }
            }

            return result
        },
        updateNReturn() {
            this.isAdd = false
            this._updateAddress(() => {
                wx.navigateBack({ delta: 1 })
            })
        },
        setDefault() { 
            this.form.useFlag = this.isDefault = !this.isDefault
        },
        goLocation(){
             wx.navigateTo({
                url: `/confirmOrder/addressLocation`
            })
        }
    }
}
</script>

<style lang="less">
page {
    height: 100%;
    overflow: hidden;
}
</style>

<style lang="less" scoped>
.receiverEditor {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    .flexOne {
        flex: 1;
        overflow: hidden;
    }
    .formContent {
        .flexOne;
        overflow-y: auto;
    }
    .myApply {
            position: relative;
            height: 50px;
            box-sizing: border-box;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid #F7F7F7;
            .input-label {
                position: absolute;
                top: 50%;
                // left: 0;
                transform: translateY(-50%);
            }
            .input-val {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                width: 100%;
                height: 100%;
                text-align: right;
                picker {
                    display: flex;
                    align-items: center;
                    justify-content: flex-end;
                }
            }
    }
    .formLine {
        position: relative;
        display: flex;
        // align-items: center;
        padding: 0 12px;
        font-size: 15px;
        color: #333;
        line-height: 54px;
        &:not(:first-child):before {
            content: '';
            display: block;
            position: absolute;
            top: 0;
            right: 12px;
            left: 12px;
            border-top: 1px solid #efefef;
        }
        &.setDefault {
            align-items: center;
            justify-content: space-between;
        }
        .name {
            min-width: 72px;
        }
        > input {
            flex: 1;
            height: 54px;
            line-height: 54px;
            overflow: hidden;
        }
        > textarea {
            padding-top: 16px;
            flex: 1;
            height: 76px;
            overflow: hidden;
            line-height: 1.5;
        }
        .getLocation {
            display: flex;
            align-items: center;
            span{
                display: inline-block;
                width:16px;
                height: 16px;
                margin-right: 3px;
                img{
                    width: 100%;
                    height: 100%;
                }
            }
        }
        .switch {
            position: relative;
            width: 50px;
            height: 28px;
            background-color: #efefef;
            border-radius: 14px;
            .dot {
                position: absolute;
                top: 2px;
                bottom: 2px;
                left: 2px;
                width: 24px;
                height: 24px;
                background-color: #fff;
                border-radius: 50%;
                transition: left 0.5s;
            }
            &.active {
                background-color:#9975F3;
                .dot {
                    left: 24px;
                }
            }
        }
    }
    .bottomAdaptor {
        padding-bottom: 0;
        background-color: #fff;
        &.iphoneX {
            padding-bottom: 20px;
        }
    }
    .buttonWrap {
        padding: 13px 15px 13px;
        .btnConfirm {
            text-align: center;
            line-height: 50px;
            color: #fff;
            font-size: 18px;
            background-color:#9975F3;
            border-radius: 25px;
        }
    }
}
</style>