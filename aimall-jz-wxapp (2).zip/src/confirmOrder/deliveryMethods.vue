<template>
    <div class="deliveryMethods">
        <div class="flexOne">
            <div class="sectionBlock">
                <product-info :product="product"></product-info>
                <div class="receipt">
                    <div
                        :class="['method', {'active':receiptMethod==1}]"
                        @click="changeReceipt(1)"
                    >自提</div>
                    <div
                        :class="['method', {'active':receiptMethod==2}]"
                        @click="changeReceipt(2)"
                    >送货</div>
                </div>
            </div>

            <div class="sectionBlock" style="padding-bottom:0">
                <div class="formLine">
                    <div class="textGray">自提地址</div>
                    <div class="flexOne" v-if="product.extractAddress">{{product.extractAddress}}</div>
                </div>
                <div class="formLine">
                    <div class="textGray">营业时间</div>
                    <div class="flexOne">10:00 - 22:00</div>
                </div>
            </div>
        </div>
        <div :class="['bottomAdaptor',{'iphoneX': isIphoneX}]">
            <div class="buttonWrap">
                <div class="btnConfirm" @click="saveNBack()">确定</div>
            </div>
        </div>
    </div>
</template>

<script>
import ProductInfo from '@/components/confirmOrder/productInfo'
import wxUtils from '@/plugins/wxUtils'
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'

export default {
    name: 'deliveryMethods',
    components: {
        ProductInfo
    },
    data() {
        return {
            product: {},
            receiptMethod: 2,
            deliveryWay:'',
            isIphoneX: wxUtils.getSystemInfo().model.indexOf('iPhone X') >= 0 
        }
    },
    mounted() {
        let that = this
        wx.getStorage({
            key: 'parcelHandle',
            success(res) {
                that.receiptMethod = res.data
            }
        })
        this.deliveryWay = getApp().globalData.flag 
        // this.deliveryWay = this.$mp.query.distributionMode
        if(this.$mp.query.distributionMode){
            this.receiptMethod = this.$mp.query.distributionMode
        }else{
            this.receiptMethod = this.deliveryWay == 0 || this.deliveryWay == 2 ? 2 : 1
        }
        wx.setNavigationBarTitle({
            title: '配送方式'
        })
        this._fetchProdDetail()
    },
    methods: {
        _fetchProdDetail() {
            let opsiton = {
                path: api.prodctDetail + this.$mp.query.productId,
                method: 'get',
                data: null,
                hideLoading: true
            }
            request(opsiton).then(res => {
                console.log(res.data)
                if (res.data) {
                    this.product = res.data  
                }
            })
        },
        changeReceipt(method) {
            if(this.deliveryWay == 1 && method === 2){
                return utils.showToast('此商品不支持送货')
            }else if(this.deliveryWay == 2 && method === 1){
                return utils.showToast('此商品不支持自提')
            }else{
                this.receiptMethod = method
                wx.setStorageSync('distributionMode', method)    
            }
        },
        saveNBack() {
            wx.navigateBack({ delta: 1 })
        }
    }
}
</script>

<style lang="less">
page {
    height: 100%;
    overflow: hidden; //撑开底层容器
}
</style>
<style lang="less" scoped>
.deliveryMethods {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background-color: #f7f7f7;
    .textGray {
        color: #999;
    }
    .flexOne {
        flex: 1;
        overflow: hidden;
        line-height:22px;
    }
    .bottomAdaptor {
        padding-bottom: 0;
        background-color: #fff;
        &.iphoneX {
            padding-bottom: 20px;
        }
    }
    .buttonWrap {
        padding: 13px 15px 13px;
        .btnConfirm {
            text-align: center;
            line-height: 50px;
            color: #fff;
            font-size: 18px;
            background-color:#9975F3;
            border-radius: 4px;
        }
    }
    .sectionBlock {
        position: relative;
        padding-bottom: 40px;
        margin-bottom: 12px;
        background-color: #fff;
        .receipt {
            position: absolute;
            right: 12px;
            bottom: 16px;
            display: flex;
            width: 90px;
            height: 26px;
            border-radius: 14px;
            color: #999;
            background-color: #ebebeb;
            .method {
                width: 45px;
                font-size: 15px;
                text-align: center;
                line-height: 26px;
                &.active {
                    color: #fff;
                    background-color:#9975F3;
                    border-radius: 14px;
                }
            }
        }
    }
    .formLine {
        position: relative;
        display: flex;
        align-items: center;
        padding: 0 12px;
        font-size: 15px;
        color: #333;
        line-height: 54px;
        &:not(:first-child):before {
            content: '';
            display: block;
            position: absolute;
            top: 0;
            right: 12px;
            left: 12px;
            border-top: 1px solid #efefef;
        }
        .flexOne {
            text-align: right;
        }
    }
}
</style>