<template>
    <div class="confirmOrder">
        <div class="orderContent">
            <div class="sectionBlock" v-if="goodsType === 1">
                <!-- <div class="formLine withComponent" @click="jumpToDeliveryWay()">
                    <div class="name">配送方式</div>
                    <div class="solution">{{distributeWay == 1 ? '自提':'快递送货'}}</div>
                </div> -->
                <div class="formLine flexible pd_t">
                    <div :style="[distributeWay==2 ? bgImg : '']" :class="{'bgImg': distributeWay==2}"  @click="judgeDeliver(2)">
                        <img class="express"   :src='distributeWay==2 ? express_selected : express'/>
                        <span>快速配送</span>
                    </div>
                    <div :style="[distributeWay==1 ? bgImg : '']" :class="{'bgImg': distributeWay==1}"  @click="judgeDeliver(1)">
                        <img class="deliver"  :src='distributeWay==1 ? selfmention_selected : selfmention '/>
                        <span>商场自提</span>
                    </div>
                </div>
                <div class="formLine" :class="{withComponent: distributeWay==2}" @click="jumpTo('receiverList')"  style="color:#999">
                    <input type="text" readonly class="address" v-if="distributeWay==2" placeholder="请填写送货地址" :value="address"/>
                    <span   class="byself" v-if="distributeWay==1">{{product.extractAddress}}</span>
                </div>
            </div>

            <div class="sectionBlock">
                <product-info :product="product" :counter='counter'></product-info>
            </div>

            <div class="sectionBlock">
                <div class="formLine">
                    <div class="flexOne">
                        数量：
                        <span class="textGray">库存{{stock}}件</span>
                    </div>
                    <div class="counter">
                        <div class="mathOpe" @click="mathCounter(0)">-</div>
                        <input type="text" class="number" @input="maxNumber" v-model="counter" disabled/>
                        <div class="mathOpe" @click="mathCounter(1)">+</div>
                    </div>
                </div>
            </div> 

            <div class="sectionBlock">
                <div class="formLine">
                    <div class="name">付款方式</div>
                    <div class="payment" v-if="buyWay == 1">积分支付</div>
                    <div class="payment" v-if="buyWay == 2">微信支付</div>
                    <div class="payment" v-if="buyWay == 3">积分+微信 支付</div>
                </div>
            </div>

            <div class="sectionBlock">
                <div class="formLine">
                    <div class="name">商品金额</div>  
                    <div class="price" v-if="buyWay===2 || buyWay===3">￥{{salePrice}}</div>
                    <div class="price" v-if="buyWay===1">{{integral}}积分</div>
                </div>
                <div class="formLine" v-if="distributeWay===2 && goodsType===1">
                    <div class="name">运费</div> 
                    <div class="parcelFee">￥{{freightFee}}</div>
                </div>
            </div>

            <div class="sectionBlock">
                <div class="flexRow note">
                    <div class="textGray">备注</div>
                    <div v-if="!isFoucusInText" @click="foucusToText" :class="{flexOne:true, commentShow:true,textColor:remark === '' ? true : false}">{{ remark === '' ? '可填写备注' : remark }}</div>
                    <textarea v-else  name id v-bind:focus="isFoucusInText" cols="30" rows="10" class="flexOne" placeholder="可填写备注" maxlength='50' placeholder-style="color:#999" v-model="remark" @blur="isFoucusInText = false" style="font-size: 14px; line-height: 18px;"></textarea>
                </div>   
            </div>
        </div>
 
        <div :class="['bottomAdaptor',{'iphoneX': isIphoneX}]">
            <div class="orderHandeler">
                <span class="txt">合计：</span>
                <!-- 纯现金支付 -->
                <div class="payWay pay-cash" v-if="buyWay===2">
                     <span>
                        <span class="dollar">￥</span>
                        {{salePriceMulCounter}}
                    </span>
                    <!-- <span v-if="distributeWay===2">
                        <span class="dollar">￥</span>
                        {{salePrice * counter + freightFee}}
                    </span>
                    <span v-if="distributeWay===1 || goodsType != 1">
                        <span class="dollar">￥</span>
                        {{salePrice * counter}}
                    </span> -->
                </div>
                <!-- 纯积分支付 -->
                <div class="payWay pay-integral" v-if="buyWay===1">
                    <span>
                        {{integralMulCounter}}<span class="integral">积分</span>
                        <span class="integral" v-if="distributeWay===2">+</span>
                        <span class="integral pay-integral-dollar" v-if="distributeWay===2">￥<span>{{freightFee}}</span> </span>
                    </span>
                    <!-- <span>
                        {{integral* counter}}<span class="integral">积分</span>
                    </span> -->
                </div>  
                <!-- 积分+现金支付 -->
                <div class="payWay pay-cashAndIntegral" v-if="buyWay===3">
                    <span>
                        {{integralMulCounter}}<span class="integral">积分 + </span><span class="dollar">￥</span>{{salePriceMulCounter}} 
                    </span>
                    <!-- <span v-if="distributeWay===2">
                        {{integral* counter}}<span class="integral">积分 + </span><span class="dollar">￥</span>{{salePrice * counter + freightFee}}
                    </span>
                    <span v-if="distributeWay===1 || goodsType != 1">
                        {{integral* counter}}<span class="integral">积分 + </span><span class="dollar">￥</span>{{salePrice * counter}}
                    </span> -->
                </div>
                <div class="payNow" @click="payNow">立即支付</div>
            </div>
        </div>
    </div>
</template>

<script>
import ProductInfo from '@/components/confirmOrder/productInfo'
import wxUtils from '@/plugins/wxUtils'
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'

export default {
    name: 'confirmOrder',
    components: {
        ProductInfo
    },
    data() {
        return {
            form: {},
            distributeWay: 2,
            address: '',
            selfmention: '/static/images/selfmention.png',
            selfmention_selected: '/static/images/selfmention_selected.png',
            express: '/static/images/express.png',
            express_selected: '/static/images/express_selected.png',
            bgImg: "background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVYAAACGCAYAAACG5qIYAAAAAXNSR0IArs4c6QAACDtJREFUeAHt20+IlHUYwPHfb9YW94+lJJUgQh0CC5QOEZ0EA0Gxq8dOkkWdouhqx/7QqajMDtGtW0UIKwVeukREhRARHkzyUFRkq7a5+/b+xn11XndGd3YfUHc+c5mdP+/jvh8evszOjDldczny8rmHqyofTFW1J+W0LVVp+pqnuEmAAIHRFsjpn7qNp1POMzlXR59+dcPJXpDc3Pj4cDX+5+z5N1Ounq2j2mnud02AAAEC1xHIeSFV+Z1NU5MvHDic58ozu2EtUf1rdvZYlard1zncQwQIECAwQCCn/OXGqam9Ja7rynO6r1R7orrlgbG0c9d42ry1kyY3XHlRO2CcuwkQIDBaAufPVen3MwvpuxNz6eyp+e7Jlxeml1uans+L76l+3/z5/8gT4+nRPeOLr2VHC8vZEiBAYCiBKqWvZ+bSt1903wGou5kX6vdcd3QWP6jqvqdaXqmK6lCsnkyAwCgL1H/Ql2aWdnYv9edTpamd7qf/izDlz//L77qOspRzJ0CAwBACdVy77WwOqb9R1el+pWrxjvKeqgsBAgQIDCfQamf9NdX6FevV76n6oGo4TM8mQIBAEWi1s26ql6j2ggABAsECwhoMahwBAgSE1Q4QIEAgWEBYg0GNI0CAgLDaAQIECAQLCGswqHEECBAQVjtAgACBYAFhDQY1jgABAsJqBwgQIBAsIKzBoMYRIEBAWO0AAQIEggWENRjUOAIECAirHSBAgECwgLAGgxpHgAABYbUDBAgQCBYQ1mBQ4wgQICCsdoAAAQLBAsIaDGocAQIEhNUOECBAIFhAWINBjSNAgICw2gECBAgECwhrMKhxBAgQEFY7QIAAgWABYQ0GNY4AAQLCagcIECAQLCCswaDGESBAQFjtAAECBIIFhDUY1DgCBAgIqx0gQIBAsICwBoMaR4AAAWG1AwQIEAgWENZgUOMIECAgrHaAAAECwQLCGgxqHAECBITVDhAgQCBYQFiDQY0jQICAsNoBAgQIBAsIazCocQQIEBBWO0CAAIFgAWENBjWOAAECwmoHCBAgECwgrMGgxhEgQEBY7QABAgSCBYQ1GNQ4AgQICKsdIECAQLCAsAaDGkeAAAFhtQMECBAIFhDWYFDjCBAgIKx2gAABAsECwhoMahwBAgSE1Q4QIEAgWEBYg0GNI0CAgLDaAQIECAQLCGswqHEECBAQVjtAgACBYAFhDQY1jgABAsJqBwgQIBAsIKzBoMYRIEBAWO0AAQIEggWENRjUOAIECAirHSBAgECwgLAGgxpHgAABYbUDBAgQCBYQ1mBQ4wgQICCsdoAAAQLBAsIaDGocAQIEhNUOECBAIFhAWINBjSNAgICw2gECBAgECwhrMKhxBAgQEFY7QIAAgWABYQ0GNY4AAQLCagcIECAQLCCswaDGESBAQFjtAAECBIIFhDUY1DgCBAgIqx0gQIBAsICwBoMaR4AAAWG1AwQIEAgWENZgUOMIECAgrHaAAAECwQLCGgxqHAECBITVDhAgQCBYQFiDQY0jQICAsNoBAgQIBAsIazCocQQIEBBWO0CAAIFgAWENBjWOAAECwmoHCBAgsEqBb47PtSYIa4vDDQIECAwnUKIqrMOZeTYBAgQGCvSLanmyV6wDyTxAgACBwQKDolqOENbBbh4hQIBAX4HrRbUcIKx92dxJgACB/gI3imo5Slj727mXAAECSwSWE9VykLAuoXMHAQIElgosN6rlSGFd6uceAgQItASGiWo5UFhbfG4QIECgLTBsVMvRwto2dIsAAQJXBFYS1XKwsF4h9AMBAgSuCqw0qmWCsF519BMBAgS6AquJahkgrBaJAAECPQKrjWoZJaw9oH4kQGC0BSKiWgSFdbT3yNkTILAoEBXVMk5YrRUBAiMvEBnVgimsI79SAAiMtkB0VIumsI72Tjl7AiMtsNqobrq3kw68OJke2zfechTWFocbBAiMikBEVPcfWp823tNJd6zPLTZhbXG4QYDAKAhERXViupNO/3gpffXJvy02YW1xuEGAwFoXiI7qzIcX08J8W21d+6ZbBAgQWLsCMVGdSBPTuftKtV9Ui56wrt0dcmYECPQIDIrqk89MpPGJlI59cDGd/7vqOaL9Y/mgav+hG0e1HOWtgLadWwQIrEGBQVEtp7owX6W7t4ylEtjJO9sfQjUUw0S1HCOsjZxrAgTWpMD1olpO+PhHF9Nvv8ynuzZ3+sZ12KiWmcJaFFwIEFiTAjeKajnpuYspff7+hb5xXUlUy0xhLQouBAisOYHlRLU56X5x3frg2LLfU23mNNfC2ki4JkBgzQgME9XmpK+N676Dy/ugqjm+97qTcvqnueP8ucGfiDXPcU2AAIFbWWAlUW3Opzeu5b7y5f9BX6lqjulzXa1LVTpdP/BQefD3Mwtp2/axPs9zFwECBG59gdVEtTm7EtfP3r2Q7rt/LP3683xaWGgeWfb1XP2KNc80T//uxFyqQ+tCgACB204gIqrNSV/6L6UzP60oqvWIzslOztXROq7dJp89NZ++nhHXBtc1AQK3h0BkVFdzxjnlKuf0SvfbsO+9NPtW/TXZ55qBWx4YSzt3jafNWztpckP/L8w2z3VNgACBmylwq0T1skH+4dDr0zu6/6V109TkC3/Nzm6vUrW7PFheuZ49deFmWvm3CRAgcFsJ1K9W/1hfTT1efunu160OHM5zG6em9tY3327eFritzsgvS4AAgZskUP78Tyn/UEd121Nv5Nnyayz5O//Iy+cerqp8MFXVnvrRbfWHWdM36ff1zxIgQOBWFSgf89cfSHVOlvdUn35t6tPeX/R//0HdMjv7vfoAAAAASUVORK5CYII=');",
            counter: 1,
            product: {},
            remark:'',
            code:'',
            isIphoneX: wxUtils.getSystemInfo().model.indexOf('iPhone X') >= 0,
            isFoucusInText: false, // 是否聚焦到textArea
            stock:'',
            salePrice:'',
            freightFee:'',
            extractAddress:'',
            skuCode:'',
            buyWay:'',
            integral:'',
            goodsType:'',
            flag:'',
            salePriceMulCounter:'',
            integralMulCounter:''
        }
    },
    watch:{
        counter(newVal){
            this.salePriceMulCounter = utils.multiply(+this.salePrice,+newVal)
            this.integralMulCounter = utils.multiply(+this.integral,+newVal)
            if(this.distributeWay===2){
                this.salePriceMulCounter = utils.add(+this.salePriceMulCounter,+this.freightFee)
            }

        }
    },
    onHide(){
        wx.setStorageSync('distributionMode', '')
    },
    onShow() {
        let _this = this
        if(wx.getStorageSync('distributionMode')){
            this.distributeWay = wx.getStorageSync('distributionMode')
            if( this.distributeWay === 1){
                this.address = ''
                this.salePriceMulCounter = utils.multiply(+this.salePrice,+this.counter)
            }else{
                this.salePriceMulCounter = utils.add(+this.salePriceMulCounter,+this.freightFee)
            }
        }


        let consignee = wx.getStorageSync('address')
        if(consignee){
                if(consignee){
                    _this.address = `${consignee.consigeeName} ${consignee.consigeeAddress} ${consignee.consigeeMobile}`
                    Object.assign(_this.form, {
                        consigneeAddress: consignee.consigeeAddress,
                        consigneeMobile: consignee.consigeeMobile,
                        consigneeName: consignee.consigeeName,
                        addressId:consignee.id
                    })
                }
        }else{
             this._fetchAddress()
        }

        wx.login({
            success(res) {
                _this.code = res.code
            }
        })
        
    },
    mounted() {
        this.remark = ''
        this._fetchProdDetail()
        this._fetchAddress()
        console.log('mounted')
    },
    methods: {
        maxNumber(){
            if( this.stock && this.counter > this.stock ){
                this.counter = this.stock
            }
        },
        _fetchProdDetail() {
            let opsiton = {
                path: api.prodctDetail + this.$mp.query.productId,
                method: 'get',
                data: null,
                hideLoading: true
            }
            request(opsiton).then(res => {
                let skuData = this.$mp.query.skuData
                if (res.data) {  
                    this.product = res.data 
                    this.stock = res.data.stock
                    this.counter = 1;
                    this.salePrice = res.data.price ? (res.data.price/100).toFixed(2) : 0
                    this.integral = res.data.integral
                    if (skuData) {
                        this.product.specsValue = JSON.parse(skuData).specsValue
                        this.product.buyCount = JSON.parse(skuData).buyCount
                        this.stock = JSON.parse(skuData).stock
                        this.counter = JSON.parse(skuData).buyCount;
                        if (res.data.buyWay == 1) {
                            this.integral = JSON.parse(skuData).transPrice
                        } else if (res.data.buyWay == 2) {
                            this.salePrice = (JSON.parse(skuData).transPrice/100).toFixed(2)
                        } else {
                            this.salePrice = ((JSON.parse(skuData).transPrice[0])/100).toFixed(2);
                            this.integral = JSON.parse(skuData).transPrice[1]
                        }
                    }
                    this.freightFee = res.data.freightFee ? (res.data.freightFee/100).toFixed(2) : 0
                    this.extractAddress = res.data.extractAddress
                    if (res.data.specsType ==1) {
                        this.skuCode =  res.data.skuList[0].skuCode
                    }
                    this.buyWay = res.data.buyWay
                    this.goodsType = res.data.goodsType
                    this.distributeWay = res.data.distributeWay == 0 || res.data.distributeWay  == 2 ? 2 : 1
                    this.flag =  res.data.distributeWay 
                    getApp().globalData.flag = res.data.distributeWay 
                    this.salePriceMulCounter = utils.multiply(+this.salePrice,1)
                    this.integralMulCounter = utils.multiply(+this.integral,1)
                    if(this.distributeWay===2){
                        this.salePriceMulCounter = utils.add(+this.salePriceMulCounter,+this.freightFee)

                    }       
                    
                }
            })   
        },
           _fetchAddress() {
            let opsiton = {
                path: api.findMemberAddress,
                method: 'get',
                // data: { memberCode: this.vipInfo.memberCode },//todo
                data: { memberCode: wx.getStorageSync('wxUserCode') },
                hideLoading: true
            }
            request(opsiton).then(res => {
                if (res.data && res.data.length > 0) {
                    let list = res.data
                    list = list.filter(item=>item.useFlag)
                    let selectedData = JSON.stringify(list)=='[]'?res.data[0]:list[0]
                    this.address = `${selectedData.consigeeName} ${selectedData.consigeeAddress} ${selectedData.consigeeMobile}`
                    Object.assign(this.form, {
                            consigneeAddress: selectedData.consigeeAddress,
                            consigneeMobile: selectedData.consigeeMobile,
                            consigneeName: selectedData.consigeeName,
                            addressId:selectedData.id
                        })
                  
                }else{
                  //收货人列表数据为空

                    this.address = ''

                }
            })
        },
        mathCounter(plus) {
            if( plus ){
                this.counter++;
                if( this.counter > this.stock ){
                    this.counter = this.stock
                    wx.showToast({
                        icon: 'none',
                        title:"已达最大购买数量"
                    })
                }
            }else{
                this.counter--;
                if( this.counter < 1 ){
                    this.counter = 1
                    wx.showToast({
                        icon: 'none',
                        title:"最小购买数量为1"
                    })
                }
            }
        },
        jumpTo(pageName) {
            if (this.distributeWay == 1) return
            wx.navigateTo({
                url: `/confirmOrder/${pageName}`
            })
        },
        judgeDeliver (type) {
            if(this.flag == 1 && type === 2){
                return utils.showToast('此商品不支持送货')
            }else if(this.flag == 2 && type === 1){
                return utils.showToast('此商品不支持自提')
            }
            if (this.distributeWay == type) return
            this.salePriceMulCounter = type == 1 ? utils.multiply(+this.salePrice,+this.counter) : utils.add(+this.salePriceMulCounter,+this.freightFee)
            this.distributeWay = type
        },
        jumpToDeliveryWay(deliveryWay){
            // if(wx.getStorageSync('distributionMode')){
            //     const distributionMode = wx.getStorageSync('distributionMode')
            // }else{
            //     const distributionMode = ''
            // }
            wx.navigateTo({
                url: `/confirmOrder/deliveryMethods?productId=${this.$mp.query.productId}&distributionMode=${this.distributeWay}`
            })
        },
        payNow(){
            if(this.distributeWay === 2 && !this.address){
                return utils.showToast('收货地址不能为空')
            }
            if (this.$mp.query.skuData) {
                this.skuCode = JSON.parse(this.$mp.query.skuData).skuCode[0]
            }
            let params = {
                buyCount: this.counter,
                distribute: {
                    distributeId: this.distributeWay === 1 ? this.extractAddress * 1 : this.form.addressId,
                    distributeWay: this.distributeWay 
                },
                skuCode: this.skuCode,
                remark:this.remark,
                miniAppletTempAuthCode:this.code,
                shareCode: wxUtils.getShareCodeStorage()
            }
            let requestOptions = {
                path: api.createOrder,
                method: 'post',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                const payargs = res.data
                if(payargs.shouldPayCash){
                    wx.requestPayment({
                        timeStamp: payargs.timeStamp,
                        nonceStr: payargs.nonceStr,
                        package: payargs.dataPackage,
                        signType: payargs.signType,
                        paySign: payargs.paySign,
                        success:function(res){
                            if(res.errMsg == "requestPayment:ok"){  // 调用支付成功
                            　　wx.redirectTo({
                                    url: '/pages/ordermanage/orderlist'   
                                })
                            }else if(res.errMsg == 'requestPayment:cancel'){
                        　　　　　// 用户取消支付的操作
                                wx.redirectTo({
                                    url: '/pages/ordermanage/orderlist'   
                                })
                        　　}
                        },
                        fail:function(res){
                        console.log('支付失败',res)
                            wx.redirectTo({
                                url: '/pages/ordermanage/orderlist'   
                            })
                        }
                    })
                }else{
                    wx.redirectTo({
                        url: '/pages/ordermanage/orderlist'   
                    })
                }
             
            })
            
            
        },
        foucusToText() {
            this.isFoucusInText = true
        }
    }
}
</script>

<style lang="less">
page {
    height: 100%;
    overflow: hidden;
}
</style>
<style lang="less" scoped>
.confirmOrder {
    position: relative;
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background-color: #f7f7f7;
    // public
    .textGray {
        color: #999;
    }
    .flexRow {
        display: flex;
    }
    .flexOne {
        flex: 1;
        overflow: hidden;
    }

    //
    .orderContent {
        flex: 1;
        overflow: hidden;
        overflow-y: auto;
        .sectionBlock {
            margin-bottom: 12px;
            background-color: #fff;
            .pd_t {
                padding-top: 40rpx;
            }
        }
        .formLine {
            position: relative;
            display: flex;
            align-items: center;
            padding: 0 12px;
            font-size: 15px;
            color: #333;
            line-height: 54px;
            &:not(:first-child):before {
                content: '';
                display: block;
                position: absolute;
                top: 0;
                right: 12px;
                left: 12px;
                // border-top: 1px solid #efefef;
            }
            &.withComponent:after {
                content: '';
                width: 6px;
                height: 6px;
                margin-left: 10px;
                border-style: solid;
                border-color: transparent #cbcbcb #cbcbcb transparent;
                border-width: 1px;
                transform: rotate(-45deg);
            }
            .name {
                flex: 1;
                .textGray;
            }
            input.address {
                flex: 1;
                height: 54px;
                line-height: 54px;
                overflow: hidden;
            }
            .byself {
                display: inline-block;
                width: 100%;
                word-wrap: break-word;
            }
            .counter {
                display: flex;
                width: 102px;
                height: 30px;
                text-align: center;
                background-color: #f6f6f6;
                border-radius: 6px;
                .mathOpe {
                    width: 30px;
                    line-height: 30px;
                    font-size: 18px;
                }
                .number {
                    width: 40px;
                    line-height: 30px;
                    height: 30px;
                    border-right: 1px solid #fff;
                    border-left: 1px solid #fff;
                }
            }
            .price,
            .parcelFee {
                color: #fd600e;
            }
        }
        .flexible {
            display: flex;
            justify-content: center;
            align-items: center;
            
            & > div {
                flex: 1;
                width: 171px;
                height: 67px;
                display: flex;
                align-items: center;
                justify-content: center;
                background-size: 100% 100%;
                // box-shadow: rgba(255,255,255,.8) 0px 0px 30px 10px;
            &:first-child{
                margin-right: 18rpx;
            }
                & > image {
                    height: 28px;
                }
                .express {
                    width: 44px;
                    margin-right: 12px;
                }
                .deliver {
                    width: 37px;
                    margin-right: 19px;
                }
                & > span {
                    font-size:18px;
                    font-family:PingFangSC-Regular,PingFang SC;
                    font-weight:400;
                    color:rgba(102,102,102,1);
                }
            }
            .bgImg {
                background-size:100% 100%;
                span {
                    color:#9975F3;
                }
            }
        }
        .note {
            padding: 17px 12px;
            textarea {
                margin-left: 10px;
                text-align: right;
                height: 77px;
            }
            .commentShow {
                margin-left: 10px;
                text-align: right;
                height: 77px;
                font-size: 14px;
                line-height: 18px;
                white-space:normal;
                word-break:break-all;
                word-wrap:break-word; 
            }
        }
    }
    .bottomAdaptor {
        padding-bottom: 0;
        background-color: #fff;
        &.iphoneX {
            padding-bottom: 20px;
        }
    }
    .orderHandeler {
        height: 70px;
        padding-right: 12px;
        padding-left: 12px;
        display: flex;
        align-items: center;
        font-size: 18px;
        .txt{
            display: inline-block;
            width: 55px;
        }
        .payWay{
            flex: 1;
            overflow: hidden;
        }
        .pay-cash{
            color:#FF4747;
            font-size: 20px;
            .dollar{
                font-size: 15px;
            }
        }
        .pay-integral{
            color:#FF4747;
            font-size: 20px;
            .integral{
                font-size: 15px;
                color: #333;
            }
            .pay-integral-dollar{
                color:#FF4747;
                span{
                    font-size: 20px;
                } 
            }
        }
        .pay-cashAndIntegral{
            color:#FF4747;
            font-size: 20px;
            .integral{
                font-size: 15px;
                color: #333;
            }
            .dollar{
                font-size: 15px;
            }
        }
        // .price {
        //     flex: 1;
        //     overflow: hidden;
        //     > span {
        //         font-size: 22px;
        //         color: #fd600e;
        //         .dollar {
        //             font-size: 15px;
        //         }
        //     }
        // }
        .payNow {
            width: 160px;
            line-height: 44px;
            text-align: center;
            color: #fff;
            background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
            border-radius: 22px;
        }
    }
    .modal {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background-color: #fff;
        z-index: 2;
    }
    .textColor {
        color: #999;
        font-size: 14px;
    }
}
</style>