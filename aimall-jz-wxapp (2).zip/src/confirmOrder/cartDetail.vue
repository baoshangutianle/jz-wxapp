<template>
    <div class="confirmOrder">
        <div class="orderContent">
            <div class="sectionBlock">
                <div class="formLine flexible pd_t">
                    <div :style="[distributeWay==2 ? bgImg : '']" :class="{'bgImg': distributeWay==2}"  @click="judgeDeliver(2)">
                        <img class="express"   :src='distributeWay==2 ? express_selected : express'/>
                        <span>快速配送</span>
                    </div>
                    <div :style="[distributeWay==1 ? bgImg : '']" :class="{'bgImg': distributeWay==1}"  @click="judgeDeliver(1)">
                        <img class="deliver"  :src='distributeWay==1 ? selfmention_selected : selfmention '/>
                        <span>商场自提</span>
                    </div>
                </div>
                <div class="formLine" :class="{withComponent: distributeWay==2}" @click="jumpTo('receiverList')"  style="color:#999">
                    <input type="text" readonly class="address" v-if="distributeWay==2" placeholder="请填写送货地址" :value="address"/>
                    <span   class="byself" v-if="distributeWay==1">{{product.extractAddress}}</span>
                </div>
            </div>

            <div class="sectionBlock" v-for="(item,idx) in product" :key="idx">
                <div class="flexRow pd_t10">
                    <div class="flexOne">{{item.shopName}}</div>
                </div>
                <div class="productInfo" v-for="(value,index) in item.goods" :key="index">
                    <div class="proDetail">
                        <div class="coverImg">
                            <img :src="value.skuImageUrl ? value.skuImageUrl : 'http://img1.uat1.rs.com/g2/M00/02/AF/CgsZj176h9OABqy7AAsrFKKQuXQ558.png!'" />
                        </div>
                        <div class="detail">
                            <div :class="['prodName', 'hasProdName']">{{value.prodName}}</div>
                            <div class="flexOne">
                                <span class="cartPrice">{{value.specsValue}}</span>
                            </div>
                            <div class="flexRow">
                                <div class="flexOne" >
                                    <span>￥{{value.price}}</span>
                                </div>
                                <div class="formLine">
                                    <div class="counter">
                                        <div class="mathOpe" @click="mathCounter(0,value)">-</div>
                                        <input type="text" class="number" @input="()=>maxNumber(value)" v-model="value.goodsNum" disabled/>
                                        <div class="mathOpe" @click="mathCounter(1,value)">+</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="cartLine"></div>
                </div>
            </div>
            <div class="sectionBlock">
                <div class="formLine withComponent">
                    <div class="name" @click="selectChecked(0)">
                        <image
                            v-if="activityChecked"
                            src="/static/images/car-checked.png"
                            mode="widthFix"
                        />
                        <image v-else src="/static/images/pay-unchecked.png" mode="widthFix" />满减优惠</div>  
                    <div class="price activity">-￥{{30}}</div>
                </div>
                <div class="formLine withComponent">
                    <div class="name" @click="selectChecked(1)">
                        <image
                            v-if="disCouponChecked"
                            src="/static/images/car-checked.png"
                            mode="widthFix"
                        />
                        <image v-else src="/static/images/pay-unchecked.png" mode="widthFix" />优惠券</div>
                    <div class="price discount" @click="toDiscoupon">5折券</div>
                </div>
                <div class="flexRow note mgBorder">
                    <div class="textGray">备注</div>
                    <div v-if="!isFoucusInText" @click="foucusToText" :class="{flexOne:true, commentShow:true,textColor:remark === '' ? true : false}">{{ remark === '' ? '可填写备注' : remark }}</div>
                    <textarea v-else  name id v-bind:focus="isFoucusInText" cols="30" rows="10" class="flexOne" placeholder="可填写备注" maxlength='50' placeholder-style="color:#999" v-model="remark" @blur="isFoucusInText = false" style="font-size: 14px; line-height: 18px;"></textarea>
                </div> 
            </div>
            <div class="sectionBlock">
                <div class="formLine">
                    <div class="name">付款方式</div>
                    <div class="payment">微信支付</div>
                </div>
                <div class="formLine">
                    <div class="name">商品金额</div>  
                    <div class="price">￥{{salePriceMulCounter}}</div>
                </div>
                <div class="formLine" v-if="distributeWay===2">
                    <div class="name">运费</div> 
                    <div class="parcelFee">￥{{freightFee}}</div>
                </div>
                <div class="formLine" v-if="distributeWay===2">
                    <div class="name">优惠金额</div> 
                    <div class="parcelFee">￥{{freightFee}}</div>
                </div>
            </div>


        </div>
 
        <div :class="['bottomAdaptor',{'iphoneX': isIphoneX}]">
            <div class="orderHandeler">
                <span class="txt">合计：</span>
                <!-- 纯现金支付 -->
                <div class="payWay pay-cash">
                     <span>
                        <span class="dollar">￥</span>
                        {{salePriceMulCounter}}
                    </span>
                </div>
                <div class="payNow" @click="payNow">结算</div>
            </div>
        </div>
    </div>
</template>

<script>
import wxUtils from '@/plugins/wxUtils'
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'

export default {
    name: 'cartDetail',
    data() {
        return {
            form: {},
            distributeWay: 2,
            address: '',
            selfmention: '/static/images/selfmention.png',
            selfmention_selected: '/static/images/selfmention_selected.png',
            express: '/static/images/express.png',
            express_selected: '/static/images/express_selected.png',
            bgImg: "background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVYAAACGCAYAAACG5qIYAAAAAXNSR0IArs4c6QAACDtJREFUeAHt20+IlHUYwPHfb9YW94+lJJUgQh0CC5QOEZ0EA0Gxq8dOkkWdouhqx/7QqajMDtGtW0UIKwVeukREhRARHkzyUFRkq7a5+/b+xn11XndGd3YfUHc+c5mdP+/jvh8evszOjDldczny8rmHqyofTFW1J+W0LVVp+pqnuEmAAIHRFsjpn7qNp1POMzlXR59+dcPJXpDc3Pj4cDX+5+z5N1Ounq2j2mnud02AAAEC1xHIeSFV+Z1NU5MvHDic58ozu2EtUf1rdvZYlard1zncQwQIECAwQCCn/OXGqam9Ja7rynO6r1R7orrlgbG0c9d42ry1kyY3XHlRO2CcuwkQIDBaAufPVen3MwvpuxNz6eyp+e7Jlxeml1uans+L76l+3/z5/8gT4+nRPeOLr2VHC8vZEiBAYCiBKqWvZ+bSt1903wGou5kX6vdcd3QWP6jqvqdaXqmK6lCsnkyAwCgL1H/Ql2aWdnYv9edTpamd7qf/izDlz//L77qOspRzJ0CAwBACdVy77WwOqb9R1el+pWrxjvKeqgsBAgQIDCfQamf9NdX6FevV76n6oGo4TM8mQIBAEWi1s26ql6j2ggABAsECwhoMahwBAgSE1Q4QIEAgWEBYg0GNI0CAgLDaAQIECAQLCGswqHEECBAQVjtAgACBYAFhDQY1jgABAsJqBwgQIBAsIKzBoMYRIEBAWO0AAQIEggWENRjUOAIECAirHSBAgECwgLAGgxpHgAABYbUDBAgQCBYQ1mBQ4wgQICCsdoAAAQLBAsIaDGocAQIEhNUOECBAIFhAWINBjSNAgICw2gECBAgECwhrMKhxBAgQEFY7QIAAgWABYQ0GNY4AAQLCagcIECAQLCCswaDGESBAQFjtAAECBIIFhDUY1DgCBAgIqx0gQIBAsICwBoMaR4AAAWG1AwQIEAgWENZgUOMIECAgrHaAAAECwQLCGgxqHAECBITVDhAgQCBYQFiDQY0jQICAsNoBAgQIBAsIazCocQQIEBBWO0CAAIFgAWENBjWOAAECwmoHCBAgECwgrMGgxhEgQEBY7QABAgSCBYQ1GNQ4AgQICKsdIECAQLCAsAaDGkeAAAFhtQMECBAIFhDWYFDjCBAgIKx2gAABAsECwhoMahwBAgSE1Q4QIEAgWEBYg0GNI0CAgLDaAQIECAQLCGswqHEECBAQVjtAgACBYAFhDQY1jgABAsJqBwgQIBAsIKzBoMYRIEBAWO0AAQIEggWENRjUOAIECAirHSBAgECwgLAGgxpHgAABYbUDBAgQCBYQ1mBQ4wgQICCsdoAAAQLBAsIaDGocAQIEhNUOECBAIFhAWINBjSNAgICw2gECBAgECwhrMKhxBAgQEFY7QIAAgWABYQ0GNY4AAQLCagcIECAQLCCswaDGESBAQFjtAAECBIIFhDUY1DgCBAgIqx0gQIBAsICwBoMaR4AAAWG1AwQIEAgWENZgUOMIECAgrHaAAAECwQLCGgxqHAECBITVDhAgQCBYQFiDQY0jQICAsNoBAgQIBAsIazCocQQIEBBWO0CAAIFgAWENBjWOAAECwmoHCBAgsEqBb47PtSYIa4vDDQIECAwnUKIqrMOZeTYBAgQGCvSLanmyV6wDyTxAgACBwQKDolqOENbBbh4hQIBAX4HrRbUcIKx92dxJgACB/gI3imo5Slj727mXAAECSwSWE9VykLAuoXMHAQIElgosN6rlSGFd6uceAgQItASGiWo5UFhbfG4QIECgLTBsVMvRwto2dIsAAQJXBFYS1XKwsF4h9AMBAgSuCqw0qmWCsF519BMBAgS6AquJahkgrBaJAAECPQKrjWoZJaw9oH4kQGC0BSKiWgSFdbT3yNkTILAoEBXVMk5YrRUBAiMvEBnVgimsI79SAAiMtkB0VIumsI72Tjl7AiMtsNqobrq3kw68OJke2zfechTWFocbBAiMikBEVPcfWp823tNJd6zPLTZhbXG4QYDAKAhERXViupNO/3gpffXJvy02YW1xuEGAwFoXiI7qzIcX08J8W21d+6ZbBAgQWLsCMVGdSBPTuftKtV9Ui56wrt0dcmYECPQIDIrqk89MpPGJlI59cDGd/7vqOaL9Y/mgav+hG0e1HOWtgLadWwQIrEGBQVEtp7owX6W7t4ylEtjJO9sfQjUUw0S1HCOsjZxrAgTWpMD1olpO+PhHF9Nvv8ynuzZ3+sZ12KiWmcJaFFwIEFiTAjeKajnpuYspff7+hb5xXUlUy0xhLQouBAisOYHlRLU56X5x3frg2LLfU23mNNfC2ki4JkBgzQgME9XmpK+N676Dy/ugqjm+97qTcvqnueP8ucGfiDXPcU2AAIFbWWAlUW3Opzeu5b7y5f9BX6lqjulzXa1LVTpdP/BQefD3Mwtp2/axPs9zFwECBG59gdVEtTm7EtfP3r2Q7rt/LP3683xaWGgeWfb1XP2KNc80T//uxFyqQ+tCgACB204gIqrNSV/6L6UzP60oqvWIzslOztXROq7dJp89NZ++nhHXBtc1AQK3h0BkVFdzxjnlKuf0SvfbsO+9NPtW/TXZ55qBWx4YSzt3jafNWztpckP/L8w2z3VNgACBmylwq0T1skH+4dDr0zu6/6V109TkC3/Nzm6vUrW7PFheuZ49deFmWvm3CRAgcFsJ1K9W/1hfTT1efunu160OHM5zG6em9tY3327eFritzsgvS4AAgZskUP78Tyn/UEd121Nv5Nnyayz5O//Iy+cerqp8MFXVnvrRbfWHWdM36ff1zxIgQOBWFSgf89cfSHVOlvdUn35t6tPeX/R//0HdMjv7vfoAAAAASUVORK5CYII=');",
            counter: 1,
            product: [],
            remark:'',
            code:'',
            isIphoneX: wxUtils.getSystemInfo().model.indexOf('iPhone X') >= 0,
            isFoucusInText: false, // 是否聚焦到textArea
            stock:'',
            salePrice:'',
            freightFee:'',
            extractAddress:'',
            skuCode:'',
            salePriceMulCounter:'',
            activityChecked: false,
            disCouponChecked: false,
        }
    },
    onShow () {
        const t = this;
        wx.login({
            success(res) {
                t.code = res.code
            }
        })
    },
    watch:{
        product: {
            handler(newVal, oldVal) {
                this.salePriceMulCounter = 0
                if (this.product.length) {
                    this.product.map(item => {
                        item.goods.map(item2 => {
                            this.salePriceMulCounter += item2.goodsNum * item2.price
                        })
                    })
                } else {
                    this.salePriceMulCounter = 0
                }
                return this.salePriceMulCounter
            },
            deep: true
        }
    },
    mounted() {
        this.product = this.$mp.query.list && JSON.parse(this.$mp.query.list)
        this.distributeWay = this.product[0].goods[0].distributeWay
    },
    methods: {
        //优惠方式单选，可取消
        selectChecked (type) {
            const t = this;
            let name1,name2;
            name1 = type ? 'disCouponChecked' : 'activityChecked'
            name2 = type ? 'activityChecked' : 'disCouponChecked'
            t[name1] = !t[name1]
            if (t[name2]) {
                t[name2] = !t[name2]
            }
        },
        //到优惠券列表
        toDiscoupon () {
            wx.navigateTo({
                url: '/disCoupon/index'
            })
        },
        maxNumber(value){
            if( value.stock && value.goodsNum > value.stock ){
                value.goodsNum = value.stock || 10
            }
        },
        mathCounter(plus,value) {
            if( plus ){
                value.goodsNum++;
                if( value.goodsNum > value.stock ){
                    value.goodsNum = value.stock
                    wx.showToast({
                        icon: 'none',
                        title:"已达最大购买数量"
                    })
                }
            }else{
                value.goodsNum--;
                if( value.goodsNum < 1 ){
                    value.goodsNum = 1
                    wx.showToast({
                        icon: 'none',
                        title:"最小购买数量为1"
                    })
                }
            }
        },
        jumpTo(pageName) {
            if (this.distributeWay == 1) return
            wx.navigateTo({
                url: `/confirmOrder/${pageName}`
            })
        },
        judgeDeliver (type) {
            if(type === 2 && this.distributeWay==1){
                return utils.showToast('此商品不支持送货')
            }else if(type === 1&& this.distributeWay==2){
                return utils.showToast('此商品不支持自提')
            }
            if (this.distributeWay == type) return
            this.distributeWay = type
        },
        payNow(){
            if(this.distributeWay === 2 && !this.address){
                return utils.showToast('收货地址不能为空')
            }
            let goodsVos = []
            this.product.forEach((v,idx)=>{
                if (v.goods.length) {
                    v.goods.forEach((item,index)=>{
                        goodsVos.push({
                            goodsBaseId:  item.id,
                            skuCode: item.goodsSku,
                            buyCount: item.goodsNum
                        })
                    })
                }
            })
            let params = {
                mallCode: wx.getStorageSync('mallCode'),
                memberCode: wx.getStorageSync('wxUserCode'),
                orderType: 1,
                distribute: {
                    distributeId: this.distributeWay === 1 ? this.extractAddress * 1 : this.form.addressId,
                    distributeWay: this.distributeWay
                },
                orderKind: 1,
                goodsVos,
                remark:this.remark,
                miniAppletTempAuthCode:this.code,
                shareCode: wxUtils.getShareCodeStorage()
            }
            let requestOptions = {
                path: api.createOrder,
                method: 'post',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                const payargs = res.data
                if(payargs.shouldPayCash){
                    wx.requestPayment({
                        timeStamp: payargs.timeStamp,
                        nonceStr: payargs.nonceStr,
                        package: payargs.dataPackage,
                        signType: payargs.signType,
                        paySign: payargs.paySign,
                        success:function(res){
                            if(res.errMsg == "requestPayment:ok"){  // 调用支付成功
                            　　wx.redirectTo({
                                    url: '/pages/ordermanage/orderlist'   
                                })
                            }else if(res.errMsg == 'requestPayment:cancel'){
                        　　　　　// 用户取消支付的操作
                                wx.redirectTo({
                                    url: '/pages/ordermanage/orderlist'   
                                })
                        　　}
                        },
                        fail:function(res){
                        console.log('支付失败',res)
                            wx.redirectTo({
                                url: '/pages/ordermanage/orderlist'   
                            })
                        }
                    })
                }else{
                    wx.redirectTo({
                        url: '/pages/ordermanage/orderlist'   
                    })
                }
             
            })
            
            
        },
        foucusToText() {
            this.isFoucusInText = true
        }
    }
}
</script>

<style lang="less">
page {
    height: 100%;
    overflow: hidden;
}
</style>
<style lang="less" scoped>
.confirmOrder {
    position: relative;
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background-color: #f7f7f7;
    // public
    .textGray {
        color: #999;
    }
    .flexRow {
        display: flex;
    }
    .flexOne {
        flex: 1;
        overflow: hidden;
        .cartPrice {
            font-size:12px;
            font-family:PingFangSC-Regular,PingFang SC;
            font-weight:400;
            color:rgba(153,153,153,1);
            line-height:17px;
        }
    }

    //
    .orderContent {
        flex: 1;
        overflow: hidden;
        overflow-y: auto;
        .sectionBlock {
            margin-bottom: 12px;
            background-color: #fff;
            .pd_t {
                padding-top: 40rpx;
            }
            .textGray {
                color: #999;
            }
            .pd_t10 {
                padding: 17px 12px 0;
            }
            .flexRow {
                display: flex;
            }
            .flexOne {
                flex: 1;
                overflow: hidden;
                color: #333;
            }

            .productInfo {
                .proDetail {
                    display: flex;
                    padding: 17px 12px;
                    .coverImg {
                        width: 88px;
                        height: 98px;
                        > img {
                            width: 100%;
                            height: 100%;
                            object-fit: cover;
                        }
                    }
                    .detail {
                        flex: 1;
                        padding-left: 9px;
                        overflow: hidden;
                        .hasProdName {
                            height: 70px;
                        }
                        .noProdName {
                            height: 35px;
                        }
                        .prodName {
                            overflow: hidden;
                            display: -webkit-box;
                            -webkit-line-clamp: 2;
                            text-overflow: ellipsis;
                            -webkit-box-orient: vertical;
                        }
                    }
                }
                .cartLine {
                    width: calc(100% - 24px);
                    margin-left: 12px;
                    height: 1px;
                    background-color: #F1F1F1;
                }
            }
        }
        .formLine {
            position: relative;
            display: flex;
            align-items: center;
            padding: 0 12px;
            font-size: 15px;
            color: #333;
            line-height: 54px;
            &:not(:first-child):before {
                content: '';
                display: block;
                position: absolute;
                top: 0;
                right: 12px;
                left: 12px;
                border-top: 1px solid #efefef;
            }
            &.withComponent:after {
                content: '';
                width: 6px;
                height: 6px;
                margin-left: 10px;
                border-style: solid;
                border-color: transparent #cbcbcb #cbcbcb transparent;
                border-width: 1px;
                transform: rotate(-45deg);
            }
            .name {
                display: flex;
                align-items: center;
                flex: 1;
                .textGray;
                image {
                    width: 18px;
                    height: 18px;
                    margin-right: 8px;
                }
            }
            input.address {
                flex: 1;
                height: 54px;
                line-height: 54px;
                overflow: hidden;
            }
            .byself {
                display: inline-block;
                width: 100%;
                word-wrap: break-word;
            }
            .counter {
                display: flex;
                width: 102px;
                height: 30px;
                text-align: center;
                background-color: #f6f6f6;
                border-radius: 6px;
                .mathOpe {
                    width: 30px;
                    line-height: 30px;
                    font-size: 18px;
                }
                .number {
                    width: 40px;
                    line-height: 30px;
                    height: 30px;
                    border-right: 1px solid #fff;
                    border-left: 1px solid #fff;
                }
            }
            .price,
            .parcelFee {
                color: #fd600e;
            }
            .activity {
                font-size:15px;
                font-family:PingFangSC-Regular,PingFang SC;
                font-weight:400;
                color:rgba(153,153,153,1);
            }
            .discount {
                font-size:15px;
                font-family:PingFangSC-Regular,PingFang SC;
                font-weight:400;
                color:rgba(51,51,51,1);
            }
        }
        .flexible {
            display: flex;
            justify-content: center;
            align-items: center;
            
            & > div {
                flex: 1;
                width: 171px;
                height: 67px;
                display: flex;
                align-items: center;
                justify-content: center;
                background-size: 100% 100%;
                // box-shadow: rgba(255,255,255,.8) 0px 0px 30px 10px;
            &:first-child{
                margin-right: 18rpx;
            }
                & > image {
                    height: 28px;
                }
                .express {
                    width: 44px;
                    margin-right: 12px;
                }
                .deliver {
                    width: 37px;
                    margin-right: 19px;
                }
                & > span {
                    font-size:18px;
                    font-family:PingFangSC-Regular,PingFang SC;
                    font-weight:400;
                    color:rgba(102,102,102,1);
                }
            }
            .bgImg {
                background-size:100% 100%;
                span {
                    color:#9975F3;
                }
            }
        }
        .note {
            padding: 17px 12px;
            textarea {
                margin-left: 10px;
                text-align: right;
                height: 77px;
            }
            .commentShow {
                margin-left: 10px;
                text-align: right;
                height: 77px;
                font-size: 14px;
                line-height: 18px;
                white-space:normal;
                word-break:break-all;
                word-wrap:break-word; 
            }
        }
        .mgBorder {
            border-top: 1px solid #efefef;
        }
    }
    .bottomAdaptor {
        padding-bottom: 0;
        background-color: #fff;
        &.iphoneX {
            padding-bottom: 20px;
        }
    }
    .orderHandeler {
        height: 70px;
        padding-right: 12px;
        padding-left: 12px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 18px;
        .txt{
            display: inline-block;
            width: 55px;
        }
        .payWay{
            flex: 1;
            overflow: hidden;
        }
        .pay-cash{
            color:#FF4747;
            font-size: 20px;
            .dollar{
                font-size: 15px;
            }
        }
        .pay-integral{
            color:#FF4747;
            font-size: 20px;
            .integral{
                font-size: 15px;
                color: #333;
            }
            .pay-integral-dollar{
                color:#FF4747;
                span{
                    font-size: 20px;
                } 
            }
        }
        .pay-cashAndIntegral{
            color:#FF4747;
            font-size: 20px;
            .integral{
                font-size: 15px;
                color: #333;
            }
            .dollar{
                font-size: 15px;
            }
        }
        // .price {
        //     flex: 1;
        //     overflow: hidden;
        //     > span {
        //         font-size: 22px;
        //         color: #fd600e;
        //         .dollar {
        //             font-size: 15px;
        //         }
        //     }
        // }
        .payNow {
            width: 160px;
            line-height: 44px;
            text-align: center;
            color: #fff;
            background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
            border-radius: 22px;
        }
    }
    .modal {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background-color: #fff;
        z-index: 2;
    }
    .textColor {
        color: #999;
        font-size: 14px;
    }
}
</style>