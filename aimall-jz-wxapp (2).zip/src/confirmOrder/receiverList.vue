<template>
    <div class="receiverList">
        <div v-if="addressList && addressList.length != 0">
            <div class="addressList">
                <div
                    v-for="(receiver, index) in addressList"
                    :key="receiver.id"
                    :class="['addressItem',{'active': receiver.useFlag}]"
                >
                    <div
                        class="name"
                        @click="setDefault({receiver:receiver, index: index})"
                    >{{receiver.consigeeName}}</div>
                    <div class="flexOne" @click="setDefault({receiver:receiver, index: index})">
                        <div class="tel">{{receiver.consigeeMobile}}</div>
                        <div class="textGray">{{receiver.province+receiver.consigeeAddress}}</div>
                    </div>
                    <div class="edit" @click="jumpTo({id:receiver.id})">编辑</div>
                    <div class="delted" @click="delted({id:receiver.id},receiver)">删除</div>
                </div>
            </div>
            <div :class="['bottomAdaptor',{'iphoneX': isIphoneX}]">
                <div class="buttonWrap">
                    <div class="btnConfirm" @click="jumpTo">添加新地址</div>
                </div>
            </div>
        </div>

        <!-- 空态页 -->
        <div v-if="!addressList || addressList.length == 0">
            <img
                class="empty-img"
                src="https://img-cdn.aimall.cloud/as/20200601/1fe93444cffd4fcb93b9ba800b1dd426.png"
            />
            <p class="tips">还未添加配送地址信息～</p>
            <div class="new-but" @click="jumpTo">添加新地址</div>
        </div>
    </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import wxUtils from '@/plugins/wxUtils'
import api from '@/plugins/api'
import request from '@/plugins/request'

export default {
    name: 'receiverList',
    data() {
        return {
            addressList: [],
            selected: 0,
            isIphoneX: wxUtils.getSystemInfo().model.indexOf('iPhone X') >= 0
        }
    },
    onShow() {
        this._fetchAddress()
        console.log('onShow', '收件人地址')
    },
    computed: {
        ...mapState(['wxUserInfo', 'vipInfo', 'sessionId', 'isLogined'])
    },
    methods: {
        _fetchAddress() {
            let opsiton = {
                path: api.findMemberAddress,
                method: 'get',
                // data: { memberCode: this.vipInfo.memberCode },//todo
                data: { memberCode: wx.getStorageSync('wxUserCode') },
                hideLoading: true
            }
            request(opsiton).then(res => {
                console.log(res.data)
                if (res.data && res.data.length > 0) {
                    // res.data.forEach(item => {
                    //     if (item.useFlag) {
                    //         this.selected = item.id
                    //         wx.setStorage({
                    //             key: 'address',
                    //             data: item
                    //         })
                    //     }
                    // })
                    this.addressList = res.data
                } else {
                    //收货人列表数据为空

                    this.addressList = []
                }
            })
        },
        _updateAddress({ receiver, cb }) {
            let opsiton = {
                path: api.updateOneAddress,
                method: 'post',
                data: {
                    useFlag: 1,
                    id: receiver.id,
                    memberCode: receiver.memberCode,
                    consigeeMobile: receiver.consigeeMobile
                },
                hideLoading: true
            }
            request(opsiton).then(res => {
                console.log(res.data)
                cb()
            })
        },
        // 选中地址的时候，如果有默认的，我就存默认的，没有默认的，我就存第一条，
        setDefault({ receiver, index }) {
            let _this = this
            this.selected = receiver.id
            let addressList = this.addressList
            let selectedAddress = addressList.filter(item => item.useFlag)
            console.log(selectedAddress, this.addressList[0])
            wx.setStorage({
                key: 'address',
                data: receiver
            })
            wx.navigateBack({ delta: 1 })
            // this._updateAddress({
            //     receiver: receiver,
            //     cb: () => {
            //       wx.navigateBack({delta:1})
            //     }
            // })
        },
        delted({ id }, receiver) {
            wx.getStorage({
                key: 'address',
                success(res) {
                    if (res.data && res.data.id == receiver.id) {
                        wx.removeStorage({
                            key: 'address'
                        })
                    }
                }
            })
            // if(receiver.useFlag){
            let position = { path: api.deleteMemberAddress + id, method: 'delete', hideLoading: true }
            request(position).then(res => {
                this._fetchAddress()
            })
        },

        jumpTo({ id }) {
            if (id) {
                wx.navigateTo({
                    url: `/confirmOrder/receiverEditor?addressId=${id}`
                })
            } else {
                wx.navigateTo({
                    url: `/confirmOrder/receiverEditor`
                })
            }
        }
    }
}
</script>

<style lang="less">
page {
    height: 100%;
    overflow: auto;
}
</style>

<style lang="less" scoped>
.receiverList {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background-color: #f7f7f7;
    .textGray {
        color: #999;
    }
    .flexRow {
        display: flex;
    }
    .flexOne {
        flex: 1;
        overflow: hidden;
    }
    .addressList {
        flex: 1;
        overflow: hidden;
        overflow-y: auto;
        .addressItem {
            position: relative;
            display: flex;
            padding-top: 14px;
            padding-bottom: 14px;
            font-size: 15px;
            background-color: #fff;
            &.active {
                &:before {
                    content: '';
                    position: absolute;
                    top: 0;
                    bottom: 0;
                    left: 0;
                    border-left: 4px solid#9975F3;
                }
                .tel:after {
                    content: '默认';
                    display: inline-block;
                    width: 38px;
                    margin-left: 7px;
                    text-align: center;
                    font-size: 12px;
                    line-height: 18px;
                    color:#9975F3;
                    background-color: #F4F2FC;
                    border-radius: 4px;
                }
            }
            &:not(:first-child):after {
                content: '';
                display: block;
                position: absolute;
                top: 0;
                right: 12px;
                left: 12px;
                border-top: 1px solid #efefef;
            }

            .name {
                width: 50px;
                padding-left: 13px;
                word-break: break-all;
            }
            .edit {
                width: 62px;
                align-self: center;
                text-align: center;
                line-height: 28px;
                border-right: 1px solid #efefef;
                .textGray;
            }
            .delted {
                width: 62px;
                align-self: center;
                text-align: center;
                line-height: 28px;
                color: red;
            }
        }
    }
    .bottomAdaptor {
        padding-bottom: 0;
        background-color: #fff;
        &.iphoneX {
            padding-bottom: 20px;
        }
    }
    .buttonWrap {
        width: 100%;
        position: fixed;
        bottom: 0;
        padding-bottom: 20px;
        background-color: #fff;
        .btnConfirm {
            margin: 13px 15px 13px;
            text-align: center;
            line-height: 50px;
            color: #fff;
            font-size: 18px;
            background-color:#9975F3;
            border-radius: 25px;
        }
    }
}
.empty-img {
    display: block;
    margin: 102px auto 0;
    width: 245px;
    height: 171px;
}
.tips {
    font-size: 14px;
    color: #999999;
    line-height: 20px;
    margin-top: 16px;
    text-align: center;
}
.new-but {
    width: 225px;
    height: 50px;
    background: linear-gradient(144deg, rgba(179, 116, 248, 1) 0%, rgba(109, 120, 238, 1) 100%);
    border-radius: 25px;
    font-size: 18px;
    line-height: 50px;
    text-align: center;
    color: white;
    margin: 70px auto 0;
}
</style>