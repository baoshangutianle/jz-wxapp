<template>
    <div class="grade-star-container">
        <ul>
            <!-- <li v-for="(item,index) in data"
                :key="index"
                :class="['grade-item',index<value?'active':'']"/> -->
            <li v-for="(item,index) in data"
                :key="index"
                class="grade-item"
                >
                <img v-if="index < value" src="/static/images/high-threshold.png" alt="">
                <img v-else  src="/static/images/low-threshold.png" alt="">
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    props:{
        value: {
            type: Number,
            default: 0
        }
    },
    data(){
        return{
            data:[1,2,3,4,5]
        }
    }
}
</script>

<style lang="less">
@import '../assets/styles/vars';
.grade-item{
    display: inline-block;
    width: 13px;
    height: 13px;
    vertical-align: middle;
    background: #E6E6E6;
    &+.grade-item{
        margin-left: 4px;
    }
    &.active{
        background: @theme-color;
    }
    img{
        width: 13px;
        height: 13px;
    }
}
</style>
