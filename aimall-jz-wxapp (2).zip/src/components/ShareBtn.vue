<template>
    <div class="share-btn-container" style="vertical-align: middle;">
        <div class="btn-share-wrap">
            <img class="active-icon-real" src="/static/images/icon_share.png" alt="">
            <button class="active-icon" open-type="share">
            </button>
        </div>
        <span class="shareNum">
            {{shareNum}}</span>
    </div>
</template>

<script>
export default {
    props: {
        shareNum: {
            type: 'String',
            default: ''
        }
    }
}
</script>

<style lang="less" scoped>
.share-btn-container{
    display: inline-block;
    .btn-share-wrap{
        position: relative;
        display: inline-block;
        width: 40rpx;
        height: 40rpx;
        overflow: hidden;
        .active-icon {
            z-index: 2;
            opacity: 0;
            display: inline-block;
            position:absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100% !important;
            height: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
        }
        .active-icon-real{
            display: inline-block;
            width: 100%;
            height: 100%;
            &:hover{
                opacity: .8;
            }
        }
    }
    .shareNum{
        font-size: 15px;
        color: #333333 !important;
        padding-left: 3px;
        vertical-align: top;
    }
}
</style>
