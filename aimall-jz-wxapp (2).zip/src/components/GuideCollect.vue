<template>
    <div class="collect-comp-container">
        <auth-btn @pass="doCollect" />
        <img
            v-if="collectState"
            class="collect-comp-icon"
            src="/static/images/icon-common-collect@2x.png"
            alt="收藏"
        >
        <img
            v-else
            class="collect-comp-icon"
            src="/static/images/no-collect.png"
            alt="未收藏"
        >
        <span class="collect-num">{{collectNum}}</span>
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import AuthBtn from '@/components/AuthBtn'
import request from '@/plugins/request'
import api from '@/plugins/api'
import wxUtils from '../plugins/wxUtils';
export default {
  components: {
    AuthBtn
  },
  props: ['contentType', 'contentId','collectNum','collectState'],
    data() {
        return {
            status: false
        }
    },
    computed: {
        ...mapState(['vipInfo'])
    },
  watch: {
    // contentId (newVal) {
    //   if (this.vipInfo && newVal) {
    //     this.getStatus()
    //   }
    // },
    // vipInfo (newVal) {
    //   if (newVal) {
    //     this.getStatus()
    //   }
    // }
  },
  onShow(){
      this.status = false
  },
  methods: {
    getStatus () {
      let params = {
        "contentId": this.contentId,
        "contentType": this.contentType,
        "userCode": wxUtils.getUserCodeStorage()
      }
      let requestOptions = {
        path: api.getCollectStatus,
        method: 'get',
        data: params,
        hideLoading: true
      }
      request(requestOptions).then(res => {
        this.status = res.data
      })
    },
    doCollect () {
        this.$emit('getCollectNum','collectFlag')
    //   this.status = !this.status
    //   let params = {
    //     "contentId": this.contentId,
    //     "contentType": this.contentType,
    //     "userCode": wxUtils.getUserCodeStorage()
    //   }
    //   let requestOptions = {
    //     path: api.doCollect,
    //     method: 'post',
    //     data: params,
    //     hideLoading: true
    //   }
    //   request(requestOptions).then(res => {
    //     var msg = this.status ? '已收藏' : '取消收藏'
    //     wx.showToast({
    //       icon: 'success',
    //       title: msg
    //     })


    //   })
    }
  },
}
</script>

<style lang="less" scoped>
.collect-comp-container {
    position: relative;
    .collect-comp-icon {
        display: inline-block;
        width: 20px;
        height: 19px;
    }
    .collect-num{
        font-size: 15px;
        color: #ffffff;
        padding-left: 8px;
        vertical-align: top;
    }
}
</style>
