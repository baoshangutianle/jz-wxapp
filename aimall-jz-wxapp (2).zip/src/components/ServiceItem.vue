<template>
    <div class="services_info">
        <p class="shopping_p">
            <span class="shopping_icon" />
            <span class="shopping_title">{{ item.title }}</span>
        </p>
        <p class="services_p2 pt10">
            <img
                class="services_icon address"
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/95aa9e7491344db6bb8e99ee6a724f14.png"
                alt=""
            >{{ item.text }}</p>
        <p class="services_p2">
            <img
                class="services_icon"
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/523a81a7d71c4f2f8872cc5d3aa401bb.png"
                alt=""
            >{{ item.time }}</p>
        <p class="services_p2">
            <img
                class="services_icon"
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/7c0999f103bc413cbe917035dec2d9da.png"
                alt=""
            >{{ item.phone }}</p>
        <div
            class="services"
            @click="showPhone"
        >
            <img
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/2c19b5c9304d4d51a5f8bd7fb63a3da3.png"
                alt=""
            >
        </div>
    </div>
</template>

<script>
import pointCode from '@/plugins/pointCode'
import buryPoint from '@/plugins/buryPoint'
export default {
    props: {
        item: {
            type: Object,
            default: ''
        },
        isPhoneShow: false,
        isShow: false,
        upLink: false
    },
    methods: {
        onTabItemTap(item) {
            //埋点
            buryPoint.setF({
                id: pointCode.TABBAR_F_MINE
            })
        },
        //详情埋点
        doBuryPoint(type, url) {
            let id;
            switch (type) {
                case 'collect':
                    id = pointCode.MINE_F_COLLECT
                    break;
                case 'tickets':
                    id = pointCode.MINE_F_TICKETS
                    break;
                case 'car':
                    id = pointCode.MINE_F_CAR
                    break;
                case 'phone':
                    id = pointCode.MINE_F_SERVICE
                    break;
                case 'setting':
                    id = pointCode.MINE_F_SETTING
                    break;
                default:
                    id = ''
            }
            if (id) {
                buryPoint.setF({
                    id: id
                })
            }
        },
        showPhone() {
            this.doBuryPoint('phone')
            wx.makePhoneCall({
                phoneNumber: "021-60906008"
            })
        },
        closePhone() {
            this.isPhoneShow = false
        },
        showText() {
            this.isShow = !this.isShow;
            this.upLink = !this.upLink;
        }
    }
}
</script>

<style lang="less" scoped>
.services_info {
    background: #ffffff;
    border-bottom: 1px solid #e7e7e7;
    padding-left: 24px;
    padding-top: 30px;
    position: relative;
    height: 184px;
    box-sizing: border-box;
    .services {
        width: 82px;
        height: 98px;
        border-left: 1px solid #e7e7e7;
        position: absolute;
        right: 0px;
        top: 43px;
        img {
            width: 16px;
            height: 22px;
            margin: 37px auto;
        }
    }
    .services_icon {
        display: inline-block;
        width: 16px !important;
        height: 16px !important;
        position: relative;
        top:3px;
    }
    .services_icon.address {
        width: 13px !important;
        height: 16px !important;
        margin-right: 7px;
        position: relative;
        top: 3px;
    }
    .services_p2 {
        font-family: PingFangHK;
        font-weight: 300;
        line-height: 23px;
        font-size: 15px;
        color: #333333;
        padding-bottom: 10px;
    }
    .pt10 {
        padding-top: 10px;
    }
}
.shopping_p {
    display: flex;
    align-items: center;
}
.shopping_title {
    color: #333333;
    font-weight: 500;
    font-size: 18px;
    margin-left: 15px;
}
.shopping_icon {
    width: 4px;
    height: 10px;
    background: #9975F3;
    border-radius: 3px;
}
</style>
