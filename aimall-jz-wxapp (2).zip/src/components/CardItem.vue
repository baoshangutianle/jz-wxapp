<template>
    <div class="card-item-container">
        <div :class="['flex-wrp','card-item-content','status-'+data.outOfDate]">
            <span class="flex-item card-icon-wrap">
                <img v-if="data.outOfDate==1" class="card-icon" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200109/847d5fe220b3411a8b98ac6bf4420645.png" alt="状态图片">
                <img v-else class="card-icon" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200109/93c5d6746878415cb477900054c25e80.png" alt="状态图片">
            </span>
            <span :class="['flex-item','card-info-wrap']">
                <div class="card-info">
                    <p class="card-name">
                        {{data.couponName}}
                    </p>
                    <p class="ecllip card-tip">
                        {{data.couponSubtitle?data.couponSubtitle:''}}
                    </p>
                    <p class="card-date">
                        {{data.chargeOffBeginTime}} ～ {{data.chargeOffEndTime}}
                    </p>
                </div>
            </span>
            <div :class="['flex-item','btn-wrap',{'detail':type=='detail'}]">
                <span v-if="type=='detail'" class="card-status">
                    {{data.chargeOffStatusDesc}}
                </span>
                <span v-else class="btn-detail">
                    <div v-if="data.outOfDate==1">
                        <!-- <button class="btn-received">去使用</button> -->
                        <img v-if="data.outOfDate==1" class="icon-card-arrow" src="/static/images/icon-card-arrow.png" alt="箭头">
                    </div>
                </span>
            </div>
        </div>
        <div>
            <img v-if="data.outOfDate&&data.outOfDate==1" src="/static/images/icon-card-staus1.png" alt="" class="icon-card-status">
        </div>
    </div>
</template>

<script>
export default {
    props:{
        data: {
            type: Object,
            default: {}
        },
        type:{
            type: String,
            default: ''
        }
    },
    data(){
        return{
            picPrex: '/static/images/',//图片前缀
        }
    },
}
</script>

<style lang="less" scoped>
@import "../assets/styles/vars";
.card-item-container{
    position: relative;
    box-shadow: 0 0 8px rgba(0,0,0,.1);
    .card-item-content{
        overflow: hidden;
        padding: 2px;
        align-items: center;
        border-radius: 4px;
        height: 90px;
        .card-icon-wrap{
            height: 100%;
            flex: 0 1 auto;
            display: flex;
            align-items: center;
            justify-content: center;
            .card-icon{
                display: inline-block;
                width: 68px;
                height: 70px;
                margin: 0 8px;
            }
            .card-text{
                margin-top: 4px;
                font-size: 15px;
            }
        }
        .card-info-wrap{
            overflow: hidden;
            position: relative;
            height: 100%;
            // &:before,
            // &:after{
            //     z-index: 2;
            //     position: absolute;
            //     left: -5px;
            //     display: inline-block;
            //     content: '';
            //     width: 10px;
            //     height: 10px;
            //     border-radius: 50%;
            //     background: #fff;
            //     box-shadow: 0 0 5px rgba(0,0,0,.1);
            // }
            // &:before{
            //     top: -5px;
            // }
            // &:after{
            //     bottom: -5px;
            // }
            .card-info{
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                justify-content: center;
                height: 100%;
                padding-left: 10px;
                // color: @black-color;
                border-left: 1px dashed rgba(0,0,0,.1);
                .card-name{
                    font-size: 20px;
                    color: @black-color;
                    display: -webkit-box;
                    -webkit-box-orient: vertical;
                    -webkit-line-clamp: 2;
                    overflow: hidden;
                }
                .card-tip{
                    width: 100%;
                    font-size: 12px;
                }
                .card-date{
                    font-size: 12px;
                    margin-top: 4px;
                    transform: scale(.8);
                    transform-origin: 0 0;
                    text-align: left;
                    white-space: nowrap;
                    // color: @theme-color;
                }
            }
        }
        .btn-wrap{
            flex: 0 1 auto;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            .btn-detail{
                display: flex;
                align-items: center;
                line-height: initial;
                background: transparent;
                font-size: 12px;
                font-weight: bold;
                border: 0;
                margin: 0 10px;
                &:active{
                    opacity: .8;
                }
                .icon-card-arrow{
                    display: inline-block;
                    width: 6px;
                    height: 12px;
                }
            }
            &.detail{
                align-self: flex-start;
                .card-status{
                    margin: 10px 10px 0;
                    font-size: 15px;
                    color: @theme-color;
                }
            }
        }
        .card-info{
            color: @black-color;
            .card-date{
                color: @theme-color;
            }
            .card-tip{
                color: @gray-color;
            }
        }
        .btn-detail{
            color: @black-color;
        }
        .btn-detail{
            color: @disable-color;
        }
        &.status-1{
            .card-info{
                color: @disable-color;
                .card-date{
                    color: @disable-color;
                }
                .card-tip{
                    color: @disable-color;
                }
            }
        }
    }
    .icon-card-status{
        z-index: 2;
        position: absolute;
        // top: 50%;
        right: 0;
        // transform: translateY(-50%);
        bottom: 0;
        display: inline-block;
        width: 68px;
        height: 53px;
    }
    .btn-received{
        background:rgba(255,255,255,1);
        border-radius:17px;
        border:1px solid rgba(114,197,193,1);
        font-size: 15px;
        color: #9975F3;
        padding: 4px 10px;
        font-weight: 200;
        line-height: normal;
    }
}

</style>
