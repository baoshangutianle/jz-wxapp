<template>
    <div ref="domEl" 
         class="sel-enum-container">
        <div class="brand_sel filter-title-text-wrap" 
             @tap="open">
            <div>
                <div v-if="currSecCategoryName" 
                     class="ecllip filter-title-text">
                    {{ currSecCategoryName }}
                </div>
                <div v-else 
                     class="ecllip filter-title-text">
                    {{ curr.showName||curr.name }}
                </div>
                <span :class="['filter-title-img',{expand:show}]">
                    <img src="/static/images/arrow-down2.png" >
                </span>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        curr: {
            type: Object,
            default: {}
        },
        show: {
            type: Boolean,
            default: false
        },
        data: {
            type: Array,
            default: []
        },
        currSecCategoryName:{
            type:String,
            default:''
        }
    },
    methods:{
        open(){
            this.$emit('update:show', !this.show)
        }
    }
}
</script>

<style lang="less" scoped>
@import url(../assets/styles/vars);
.sel-enum-container{
    height: 100%;
    .sel-dom{
        z-index: 2;
        opacity: 0;
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: transparent;
        height: 100%;
    }
    .brand_sel{
        position: relative;
        height: 100%;
        line-height: 50px;
        background: #fff;
        text-align: center;
        font-size: 15px;
        color: @black-color;
        border-bottom: 1px solid #ddd;
        padding: 0 15px;
        &:after{
            display: inline-block;
            content: '';
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            right: 0;
            height: 20px;
            width: 1px;
            background: #ddd;
        }
        .brand_sel_text_wrap{
            width: 100%;
            height: 100%;
            display: inline-block;
            .brand_sel_text{
                position: relative;
                box-sizing: border-box;
                width: 100%;
                height: 100%;
                padding-right: 16px;
                box-sizing: none;
                display: inline-block;
                .brand_sel_text_2{
                    display: inline-block;
                }
            }
        }
        .brand_sel_arrow{
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            display: inline-block;
            right: 6px;
            display: inline-block;
            width: 8px;
            height: 5px;
            img{
                display: inline-block;
                width: 100%;
                height: 100%;
            }
        }
    }
    .brand_sel_enum{
        box-sizing: border-box;
        max-height: 200px;
        background: #fff;
        overflow: auto;
        position: absolute;
        z-index: 2;
        width: 100%;
        margin-top: 0px;
        box-shadow: 0 3px 8rpx rgba(0, 0, 0, 0.1);
        li{
            height: 50px;
            padding: 0 15px;
            line-height: 50px;
            font-size: 15px;
            color: @gray-color;
            display: flex;
            .brand_nav_li_text{
                position: relative;
                width: 100%;
                border-bottom: 1px solid @border-color;
                .brand_nav_arrow{
                    position: absolute;
                    top: 50%;
                    right: 0;
                    transform: translateY(-50%);
                    width: 24rpx;
                    height: 18rpx;
                }
            }
            &.brand_nav_active{
                color: @theme-color;
            }
        }
    }
    .filter-title-text-wrap{
        overflow: hidden;
        font-size:15px;
        color: #333;
        line-height: 50px;
        text-align: center;
        position: relative;
        display: flex;
        padding: 0 15px;
        justify-content: center;
        align-items: center;
        &>div{
            position: relative;
            display: inline-block;
            padding-right: 23px;
            height: 100%;
            overflow: hidden;
        }
        .filter-title-text{
            box-sizing: border-box;
            display: inline-block;
            width: 100%;
        }
        .filter-title-img{
            position: absolute;
            top: 50%;
            display: inline-block;
            right: 6px;
            transform: translateY(-50%);
            img{
                width: 8px;
                height: 5px;
            }
        }
    }
}
</style>
