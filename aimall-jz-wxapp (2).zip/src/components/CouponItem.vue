<template>
    <!-- <div :class="['flex-wrp','coupon-item-conatiner',{used:data.chargeOffStatus==1}]"> -->
    <div
        :class="['flex-wrp','coupon-item-conatiner',{'check-disable':data.checkDisable}]"
        @tap="goMineDetail"
    >
        <span class="coupon-logo-wrap">
            <auth-btn
                auth="phone"
                @pass="goNormalDetail(data)"
            />
            <img
                :src="data.couponUrl"
                class="coupon-logo"
                mode="scaleToFill"
                alt=""
            >
        </span>
        <span :class="['coupon-basic',{'allWidth':from=='mine'}]">
            <auth-btn
                auth="phone"
                @pass="goNormalDetail(data)"
            />
            <div class="coupon-price">{{data.couponName ? data.couponName : ""}}</div>
             <!-- <div class="coupon-price"  v-if="data.couponType ==4">{{data.couponName}}</div>
             <div class="coupon-price" v-else>{{ data.couponType==6?data.couponName:(data.couponType==3?data.couponName:(data.couponWorth+'元')) }}</div> -->
            <div
                v-if="data.couponType ==4"
                class="ecllip coupon-name"
            >停车抵用券</div>
            <div
                v-else
                class="ecllip coupon-name"
            >{{ data.shopNameList&&data.shopNameList.length==1?(data.shopNameList[0]):'通用券' }}</div>
            <div class="coupon-time" :class="data.isUse ? 'blockTime':''">{{ data.chargedOffBeginTime }}~{{ data.chargedOffEndTime }}</div>
        </span>
        <span class="coupon-item-info"  v-if="from!='mine'">
            <div class="flex-wrp"
            >
                <span class="conpon-oper">
                    <div
                        v-if="sessionId&&data.chargeOffStatus==1"
                        class="flex-itemfdfdd btn-wrp"
                    >
                        <button
                            class="btn-received"
                            @tap="goDetail(data)"
                        >去使用</button>
                    </div>
                    <div
                        v-else
                        class="flex-itemsssss btn-wrp"
                    >
                        <div v-show="!sessionId">
                            <auth-btn @pass="refreshParent(data)" />
                        </div>
                        <button
                            class="btn-receive"
                            @tap="buy(data)"
                        >领 &nbsp;取</button>
                    </div>
                </span>
            </div>
            <!-- <div
                v-else
                class="flex-wrp"
            >
                <span class="conpon-oper">
                    <img
                        :src="data.statusPic"
                        class="icon-status"
                        alt="状态图片"
                    >
                </span>
            </div> -->
        </span>
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import { getCouponBatchPage } from '@/service/mine'
import wxUtils from '../plugins/wxUtils';
import AuthBtn from '@/components/AuthBtn'
import { buyCoupon } from '@/service/mine'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
export default {
    components: {
        AuthBtn
    },
    props: {
        data: {
            type: Object,
            default: null
        },
        from: {
            type: String,
            default: ''
        }
    },
    data() {
        return {

        }

    },
    computed: {
        ...mapState(['mallCode', 'sessionId'])
    },
    methods: {
        async buy(data) {
            //埋点
            buryPoint.setF({
                id: pointCode.COUPON_F_GET,
                p_action_id: data.couponId,
                p_action: data.couponName
            })

            let params = {
                mallCode: this.mallCode,
                couponId: data.couponId,
                couponBatchId: data.couponBatchId,
                buyAmount: 1
            }
            await buyCoupon(params)
            wx.showToast({
                title: "领取成功，请到我的-卡券查看",
                icon: "none"
            })
            this.$parent && this.$parent.resetRefresh()
        },
        goNormalDetail() {
            if (this.from == 'mine') {//来源是从我的页面进入，则直接跳转到二维码页面
                return
            } else {
                //埋点
                buryPoint.setF({
                    id: pointCode.COUPON_DETAIL_F
                })
                if (this.data.chargeOffStatus != 1) {
                    buryPoint.setF({
                        id: 50
                    })
                }
                let { couponId, couponBatchId, chargeOffStatus } = this.data
                wx.navigateTo({
                    url: `/pages/coupon/details?couponId=${couponId}&couponBatchId=${couponBatchId}&chargeOffStatus=${chargeOffStatus}`
                })
            }
        },
        goMineDetail() {
            if (this.from == 'mine') {//来源是从我的页面进入，则直接跳转到二维码页面
                if (this.data.checkDisable) {
                    return
                }
                if(this.data.isUse){
                    return
                }
                this.goDetail()
            }
        },
        goDetail() {
            if (this.sessionId) {
                let { couponId, couponBatchId,couponCode } = this.data
                wx.navigateTo({
                    url: `/pagesMine/cardDetail?couponCode=${couponCode}`
                })
            }
        },
        refreshParent(data) {
            //埋点
            buryPoint.setF({
                id: pointCode.COUPON_F_GET,
                p_action_id: data.couponId,
                p_action: data.couponName
            })

            this.$parent.getData(1)
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.coupon-item-conatiner {
    width: 100%;
    min-height: 90px;
    overflow: hidden;
    box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    // padding: 7px 0;
    // box-sizing: border-box;
    .coupon-logo-wrap {
        // position: relative;
        // margin: 0px 10px;
        // flex: 0 1 60px;
        // border-radius: 0 4px 4px 0;
        // display: flex;
        // align-items: center;
        display: inline-block;
        padding: 15px 10px;
        border-radius: 0 4px 4px 0;
        .coupon-logo {
            width: 60px;
            height: 60px;
        }
    }
    .coupon-item-info {
        //flex: 0 1 auto;
        align-self: center;
        position: relative;
        padding: 10px 0 10px 10px;
        border-radius: 4px 0 0 4px;
        & > flex-wrp {
            height: 100%;
        }
    }
    .coupon-price {
        font-size: 16px;
        font-weight: bold;
        margin-top: 13px; // +7
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;

    }
    .coupon-tip {
        margin-top: 5px;
        font-size: 12px;
    }
    .coupon-name {
        display: block;
        max-width: 150px;
        margin-top: 2px; //-2-1
        font-size: 13px;
        color: #999;
    }
    .coupon-time {
        margin-top: 2px; //-5-3
        font-size: 13px;
        font-weight: 200;
        color: @gray-color;
        margin-bottom: 7px; // +7
        color: #999;
    }
    .coupon-basic {
        // position: relative;
        // flex: 1;
        // display: flex;
        // flex-direction: column;
        // align-items: flex-start;
        // justify-content: center;
        // padding-left: 10px;
        border-left: 1px dashed rgba(0, 0, 0, 0.1);
        display: inline-block;
        padding-left: 10px;
        width: 44%;
    }
    .btn-wrp {
        position: relative;
        flex: 0 1 auto;
        padding: 0 10px;
        display: flex;
        align-items: center;
        justify-content: flex-end;
        .btn-con {
            position: relative;
        }
        .btn-receive {
            position: relative;
            width: 72px;
            height: 30px;
            padding: 0;
            border-radius: 15px;
            background: @theme-color;
            font-size: 15px;
            color: #fff;
            line-height: 30px;
            text-align: center;
        }
        .btn-received {
            width: 72px;
            height: 30px;
            padding: 0;
            border-radius: 15px;
            background: @white-color;
            font-size: 15px;
            color: @theme-color;
            // -----------------------
            line-height: 28px;
            text-align: center;
            border: 1px solid @theme-color;
        }
    }
    .conpon-oper {
        position: relative;
        display: flex;
        align-items: center;
        .icon-status {
            width: 46px;
            height: 46px;
            padding: 0 18px;
        }
    }
    &.used {
        .coupon-time {
            color: @theme-color;
        }
    }
    &.check-disable {
        color: #cecece;
        .coupon-logo {
            opacity: 0.3;
        }
        .coupon-time{
            color: #cecece;
        }
    }
    .allWidth{
        width: 72% !important;
    }
    .blockTime{
        color: #999999;
    }
}
</style>
