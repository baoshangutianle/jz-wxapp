
<template>
    <view class="modals modals-bottom-dialog" v-if="isShow">
        <view class="modals-cancel" @click="hideModal"></view>
        <view class="bottom-dialog-body bottom-pos" :style="{height:height+'rpx'}" :animation="animationData">
        <view class="modal-container">
            <image class="goods-image" :src='product.thumbnail'/>
            <image
                class="close-window-image"
                src="/static/images/icon_window_close.png"
                @click="hideModal"
            />
            <view class="price-container">
                <view class="price-text">{{showPrice}}</view>
                <view class="stock-text">库存{{count}}件</view>
                <view class="select-container" v-if="goodsId">
                    <view class="select-text">已选:</view>
                    <view class="select-text-value">{{showSpecText}}</view>
                </view>
                <view class="select-container" v-else>
                    <view class="select-text">请选择&nbsp;</view>
                    <view class="select-text-value">{{needSelect}}</view>
                </view>
            </view>
            <!-- 规格 -->
            <view class="scroll-container">
                <scroll-view scroll-y class="scroll-view">
                    <block v-for="(sectionItem,sectionIndex) in propsList" :key="sectionIndex">
                        <view class="block">
                            <view class="prop-title">{{sectionItem.key}}</view>
                            <view class="prop-value-container">
                                <block
                                    v-for="(rowItem,rowIndex) in sectionItem.values"
                                    :key="rowIndex"
                                >
                                    <view
                                        :class='[rowItem.isSelect == 1 ? "prop-value-s" : rowItem.isSelect == 0 ? "prop-value-n" : "prop-value-ns"]'
                                        @click="itemClick(rowItem,rowIndex,sectionIndex)"
                                    >{{rowItem.value}}</view>
                                </block>
                            </view>
                        </view>
                    </block>
                    <div class="formLine">
                        <div class="flexOne">
                            购买数量
                        </div>
                        <div class="counter">
                            <div class="mathOpe" @click="mathCounter(0)">-</div>
                            <input type="text" class="number" @input="maxNumber" v-model="buyCount" disabled/>
                            <div class="mathOpe" @click="mathCounter(1)">+</div>
                        </div>
                    </div>
                </scroll-view>
            </view>
            <!-- 提交 -->
            <view class="submit-button" @click="submitAction">
                <view class="submit-text">确定</view>
            </view>
        </view>
        </view>
    </view>
</template>
<script>
import utils from '../plugins/utils'
const { createDateSource, getObjKeys } = require('../plugins/sku.js')
export default {
    data() {
        return {
            skuResult: [], //处理好的排列组合方式
            selectedIdArray: [], //存放选中属性id的数组
            selectedValueArray: [], //存放选中属性名的数组
            initialPrice: '', //初始价格
            showPrice: '', //显示价格
            transPrice: '',
            showSpecText: '', //显示规格
            goodsId: '', //商品id
            count: 0, //库存数
            totalCount: 0,
            buyCount: 1,
            height: 1020,
            isShow: false,
            animationData: {},
            needSelect: '',
            specsList: [],
            pageData: {},
            arrList: [],
            propsList: [], //属性数据
            skuData: {} //商品对应的sku组合
        }
    },
    props: ['product'],
    watch: {
        product (newVal,oldVal) {
            let hasSkuData = 0, hasPropsList=0;
            let thumbnail = ''
            if (this.product.thumbnail && this.product.thumbnail.indexOf(',') !== -1) {
                thumbnail = this.product.thumbnail.split(',')[0]
            } else {
                thumbnail = this.product.thumbnail
            }
            this.product.thumbnail = thumbnail
            this.reInitData()
            this.pageData = newVal
            this.propsList = newVal.attributeList
            this.propsList && this.propsList.length && this.propsList.forEach((v,idx) => {
                hasPropsList = 1
                v.values && v.values.length && v.values.forEach((k,index)=>{
                    k.isSelect = 0
                })
            })
            this.skuData = newVal.seckillSkuList ? newVal.seckillSkuList : newVal.skuList
            this.skuData && this.skuData.length &&this.skuData.forEach(v=>{ 
                hasSkuData = 1
                this.count+=v.stock
            })
            if (!hasPropsList || !hasSkuData) return
            this.init()
        }
    },
    methods: {
        reInitData () {
            this.skuResult = []
            this.selectedIdArray = []
            this.selectedValueArray = []
            this.initialPrice = ''
            this.showPrice = ''
            this.transPrice = ''
            this.showSpecText = ''
            this.goodsId = ''
            this.count = 0;
            this.totalCount = 0;
            this.buyCount = 1
            this.specsList = []
            this.pageData = {}
            this.arrList = []
            this.propsList = []
            this.skuData = {}
        },
        ///组件初始化 处理数据
        init () {
            this.propsList.forEach((v,idx) => {
                this.specsList.push(v.key)
            })
            this.needSelect = this.specsList.join('/')
            let obj = {};
            for (let item of this.skuData) {
                obj[item.specsValue] = item
            }
            this.skuResult = createDateSource(obj)
            this.reloadDataSource()
        },
        ///显示弹窗
        showModal: function() {
            let that = this
            that.isShow = true
            let animation = wx.createAnimation({
                duration: 600, //动画的持续时间 默认400ms   数值越大，动画越慢   数值越小，动画越快
                timingFunction: 'ease' //动画的效果 默认值是linear
            })
            this.animation = animation
            setTimeout(function() {
                that.showAnimation() //调用显示动画
            }, 200)
        },
        //显示动画
        showAnimation: function() {
            this.animation.translateY(0).step()
            this.animationData = this.animation.export()
        },

        // 隐藏弹窗
        hideModal: function() {
            let that = this
            let animation = wx.createAnimation({
                duration: 800, //动画的持续时间 默认400ms   数值越大，动画越慢   数值越小，动画越快
                timingFunction: 'ease' //动画的效果 默认值是linear
            })
            this.animation = animation
            that.hideAnimation() //调用隐藏动画
            setTimeout(function() {
                that.isShow = false
            }, 320) //先执行下滑动画，再隐藏模块
        },
        //隐藏动画
        hideAnimation: function() {
            let height = this.height
            this.animation.translateY(height).step()
            this.animationData = this.animation.export()
        },
        maxNumber(){
            if( this.count && this.buyCount > this.count ){
                this.buyCount = this.count
            }
        },
        mathCounter(plus) {
            if( plus ){
                this.buyCount++;
                if( this.buyCount > this.count ){
                    this.buyCount = this.count
                    wx.showToast({
                        icon: 'none',
                        title:"已达最大购买数量"
                    })
                }
            }else{
                this.buyCount--;
                if( this.buyCount < 1 ){
                    this.buyCount = 1
                    wx.showToast({
                        icon: 'none',
                        title:"最小购买数量为1"
                    })
                }
            }
        },
        ///处理初始页面的展示数据 可选 选中 不可选
        reloadDataSource () {
            let skuKeys = getObjKeys(this.skuResult)
            ///取出sku所有组合的价格 取出最大值和最小值 获得价格区间
            let allPrice = []
            skuKeys.forEach(item => {
                let skuData = this.skuResult[item]
                let prices = skuData['prices']
                if (typeof  prices == 'object') {
                    allPrice = allPrice.concat(prices)
                }
            })
            ///取出最大值和最小值 这就是初始价格
            // let maxPrice = Math.max.apply(Math, allPrice)
            // let minPrice = Math.min.apply(Math, allPrice)
            switch(this.pageData.buyWay) {
                    case 1:
                        this.showPrice = this.pageData.integral+'积分'
                        break;
                    case 2:
                        this.showPrice = (this.pageData.price / 100).toFixed(2)+'元'
                        break;
                    case 3:
                        this.showPrice = this.pageData.integral+'积分+'+(this.pageData.price / 100).toFixed(2)+'元'
                        break;
                }
            // this.showPrice = maxPrice == minPrice ? `￥${minPrice}` : `￥${minPrice}~￥${maxPrice}`
            if (this.propsList.length == 0) {
                return
            }
            ///遍历属性列表
            this.propsList.forEach((item, i) => {
                let standardInfoList = item.values
                let x = -1
                let attrValueId = ''
                let standardName = ''
                ///遍历各种规格的值的列表
                for (let j = 0; j < standardInfoList.length; j++) {
                    let dict = standardInfoList[j]
                    let isSelected = dict.isSelected
                    let AttrValueId = dict.attrValueId
                    let StandardName = dict.standardName
                    ///如果有选中的就跳出该循环
                    if (isSelected == 1) {
                        x = j
                        attrValueId = AttrValueId
                        standardName = StandardName
                        break
                    }
                }
                //如果x = -1表示当前没有选中的 添加默认值
                if (x == -1) {
                    this.selectedIdArray.push('')
                    this.selectedValueArray.push('')
                } else {
                    //表示有选中的 把选中id添加到数组中
                    this.selectedIdArray.push(attrValueId)
                    this.selectedValueArray.push(standardName)
                }
            })
            this.initialPrice = this.showPrice
            // this.count = count
            this.totalCount = this.count
            this.handDisEnableData()
            this.handSpecifications()
        },
        ///处理不可选的数据
        handDisEnableData: function() {
            let skuKeys = getObjKeys(this.skuResult)
            ///遍历属性列表
            this.propsList.forEach((item, i) => {
                let standardInfoList = item.values
                standardInfoList.forEach(item2 => {
                    let attrValueId = item2.value
                    ///将selectedIdArray赋值给一个临时数组 这个地方需要解构 不然会有问题
                    let tempArray = [...this.selectedIdArray]
                    ///从已经选好的组合中 移除当前组之前的id 并插入新的id
                    tempArray.splice(i, 1, attrValueId)
                    ///移除没有选中的组 即 '' 空字符串
                    let next = true
                    while (next) {
                        let index = tempArray.indexOf('')
                        if (index == -1) {
                            next = false
                        } else {
                            tempArray.splice(index, 1)
                        }
                    }
                    ///将处理完的组合排序
                    tempArray.sort(function(value1, value2) {
                        return parseInt(value1) - parseInt(value2)
                    })
                    ///排序之后进行拼接
                    let resultKey = tempArray.join(',')
                    ///如果找不到当前的组合 表示当前属性不可选 则改变属性列表中isSelect的值
                    let index = skuKeys.indexOf(resultKey)
                    if (index == -1) {
                        item2.isSelect = -1
                    } else {
                        ///如果之前是不可选的 然而后续可选  就将isSelect换为0
                        if (item2.isSelect == -1) {
                            item2.isSelect = 0
                        }
                    }
                })
            })
        },
        ///计算价格 库存 已经获取商品id
        calculatePrice() {
            let skuKeys = getObjKeys(this.skuResult)
            let tempArray = [...this.selectedIdArray]
            ///移除没有选中的组 即 '' 空字符串
            let next = true
            while (next) {
                let index = tempArray.indexOf('')
                if (index == -1) {
                    next = false
                } else {
                    tempArray.splice(index, 1)
                }
            }
            ///将处理完的组合排序
            tempArray.sort(function(value1, value2) {
                return parseInt(value1) - parseInt(value2)
            })
            ///排序之后进行拼接
            let resultKey = tempArray.join(',')
            let index = skuKeys.indexOf(resultKey)
            ///重置 在全部取消选中时需要还原
            this.showPrice = this.initialPrice
            this.goodsId = ''
            this.count = this.totalCount
            ///表示匹配到了
            if (index != -1) {
                let skuData = this.skuResult[resultKey];
                let prices = skuData['prices']
                let integral = skuData['integral']
                //取出最大值和最小值
                let maxPrice = Math.max.apply(Math, prices)
                let minPrice = Math.min.apply(Math, prices)
                let maxintegral = Math.max.apply(Math, integral)
                let minintegral = Math.min.apply(Math, integral)
                if (tempArray.length == this.propsList.length) {
                    switch(this.pageData.buyWay) {
                        case 1:
                            this.showPrice = maxintegral == minintegral ? `${minintegral}积分` : `${minintegral}~${maxintegral}积分`
                            this.transPrice = minintegral
                            break;
                        case 2:
                            this.showPrice = maxPrice == minPrice ? `${(minPrice / 100).toFixed(2)}元` : `${(minPrice / 100).toFixed(2)}~${(maxPrice / 100).toFixed(2)}元`
                            this.transPrice = minPrice
                            break;
                        case 3:
                            this.showPrice = maxPrice == minPrice && maxintegral == minintegral ? `${minintegral}积分+${(minPrice / 100).toFixed(2)}元` : `${minintegral}~${maxintegral}积分+${(minPrice / 100).toFixed(2)}~${(maxPrice / 100).toFixed(2)}元`
                            this.transPrice = [minPrice,minintegral]
                            break;
                    }
                    ///当所有属性全部选中时 只会有一个id 所以 取第一个就可以了
                    let specsValue = skuData['specsValue']
                    this.goodsId = skuData['skuCode']
                    this.count = skuData['stock']
                }
            }
        },
        ///处理规格
        handSpecifications: function() {
            let selectedValueArray = this.selectedValueArray
            let tempArray = [...selectedValueArray]
            ///移除没有选中的组 即 '' 空字符串
            let next = true
            while (next) {
                let index = tempArray.indexOf('')
                if (index == -1) {
                    next = false
                } else {
                    tempArray.splice(index, 1)
                }
            }

            let showSpecText = tempArray.join(',')
            this.showSpecText = showSpecText
        },

        //属性点击事件
        itemClick(rowItem,rowIndex,sectionIndex) {
            ///取到当前点击的组
            let sectionItem = this.propsList[sectionIndex].values
            ///取到当前点击的行
            let isSelect = rowItem.isSelect
            ///表示不可选 直接return
            if (isSelect == -1) {
                return
            }
            ///可选 替换原本的id 插入新的id
            if (isSelect == 0) {
                let attrValueId = rowItem.value
                let standardName = rowItem.value
                this.selectedIdArray.splice(sectionIndex, 1, attrValueId)
                this.selectedValueArray.splice(sectionIndex, 1, standardName)
                ///遍历当前组 如果已经有选中的 则去掉之前的选中
                sectionItem.forEach(item => {
                    if (item.isSelect == 1) {
                        item.isSelect = 0
                    }
                })
            }
            ///选中  取消选中
            else {
                this.selectedIdArray.splice(sectionIndex, 1, '')
                this.selectedValueArray.splice(sectionIndex, 1, '')
            }
            rowItem.isSelect = isSelect == 1 ? 0 : 1
            let standardListName = this.propsList[sectionIndex].key
            if (rowItem.isSelect) {
                let flag = 0
                this.arrList.forEach(v => {
                    if (standardListName == v) {
                        flag = 1
                    }
                })
                if (!flag) {
                    this.arrList.push(standardListName)
                }
            } else {
                this.arrList.forEach((v,idx) => {
                    if (standardListName == v) {
                        this.arrList.splice(idx,1)
                    }
                })
            }
            let concArrList,difArrList,equalArrList;
            concArrList = [...this.arrList,...this.specsList]
            difArrList = Array.from(new Set(concArrList))
            equalArrList = [...difArrList.filter(_=>!this.arrList.includes(_)),...difArrList.filter(_=>!this.specsList.includes(_))]
            this.needSelect = equalArrList.join('/')
            this.handDisEnableData()
            this.calculatePrice()
            this.handSpecifications()
        },
        ///提交
        submitAction() {
            const t = this
            if (t.goodsId) {
                t.$emit('toDetail',{skuCode: t.goodsId, buyCount: t.buyCount,specsValue:t.showSpecText,stock:t.count,transPrice:t.transPrice})
                return
            } else {
                wx.showToast({
                    icon: 'none',
                    title:`请选择${t.needSelect}`
                })
            }
        }
    }
}
</script>
<style lang="less">
/* component/specwindow/specwindow.wxss */

.modal-container {
    width: 100%;
    height: 100%;
    background-color: white;
    border-top-left-radius: 10rpx;
    border-top-right-radius: 10rpx;
}
.modal-container::before {
    content:'';
    display:table;
}

/* 商品信息 */

.goods-image {
    height: 176rpx;
    width: 164rpx;
    background-color: white;
    border: #eaeaea 1rpx solid;
    border-radius: 10rpx;
    position: absolute;
    top: 30rpx;
    left: 30rpx;
}

.close-window-image {
    width: 20px;
    height: 20px;
    position: absolute;
    right: 0rpx;
    padding: 24rpx;
    top: 0rpx;
}

/* 价格 */

.price-container {
    /* height: 200rpx; */
    display: flex;
    flex-direction: column;
    margin-top: 60rpx;
    /* justify-content: flex-end; */
}

.price-text {
    color: #FF4747;
    font-size: 40rpx;
    font-weight:500;
    margin-left: 210rpx;
    margin-bottom: 8rpx;
}
.stock-text {
    font-size:15px;
    margin-left: 210rpx;
    margin-bottom: 8rpx;
    font-family:PingFangSC-Regular,PingFang SC;
    font-weight:400;
    color:rgba(51,51,51,1);
    line-height:21px;
}

.select-container {
    display: flex;
    flex-direction: row;
    margin-bottom: 20rpx;
}

.select-text {
    color:rgba(51,51,51,1);
    font-size:15px;
    margin-left: 210rpx;
}

.select-text-value {
    margin-right: 30rpx;
    flex: 1;
    font-size:15px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* 规格 */

.scroll-container {
    /* margin-top: 20rpx; */
    height: 580rpx;
    background-color: #fff;
    padding: 5rpx 0rpx;
}

.scroll-view {
    overflow: hidden;
    height: 100%;
}
.formLine {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 12px;
        font-size: 15px;
        color: #333;
        line-height: 54px;
        &:not(:first-child):before {
            content: '';
            display: block;
            position: absolute;
            top: 0;
            right: 12px;
            left: 12px;
            border-top: 1px solid #efefef;
        }
        &.withComponent:after {
            content: '';
            width: 6px;
            height: 6px;
            margin-left: 10px;
            border-style: solid;
            border-color: transparent #cbcbcb #cbcbcb transparent;
            border-width: 1px;
            transform: rotate(-45deg);
        }
        .name {
            flex: 1;
        }
        input.address {
            flex: 1;
            height: 54px;
            line-height: 54px;
            overflow: hidden;
        }
        .byself {
            display: inline-block;
            width: 100%;
            word-wrap: break-word;
        }
        .counter {
            display: flex;
            width: 102px;
            height: 30px;
            text-align: center;
            background-color: #f6f6f6;
            border-radius: 6px;
            .mathOpe {
                width: 30px;
                line-height: 30px;
                font-size: 18px;
            }
            .number {
                width: 40px;
                line-height: 30px;
                height: 30px;
                border-right: 1px solid #fff;
                border-left: 1px solid #fff;
            }
        }
        .price,
        .parcelFee {
            color: #fd600e;
        }
    }

.prop-value-container {
    display: flex;
    flex-flow: wrap;
    flex-direction: row;
}

.prop-title {
    font-size: 30rpx;
    color: #333333;
    height: 88rpx;
    display: flex;
    align-items: center;
}

.block {
    border-top: 1px solid rgba(239,239,239,1);
    margin: 10rpx 30rpx;
}

.prop-value-n {
    color:rgba(51,51,51,1);
    font-size: 26rpx;
    background-color: #f5f5f5;
    height: 50rpx;
    border-radius: 4rpx;
    margin-right: 20rpx;
    margin-bottom: 20rpx;
    padding: 4rpx 20rpx;
    display: flex;
    justify-content: center;
    align-items: center;
    min-width: 15%;
}

.prop-value-s {
    font-size: 26rpx;
    color:#9975F3;
    height: 46rpx;
    background:#F4F2FC;
    border-radius:4px;
    border:1px solid #9975F3;
    margin-right: 18rpx;
    margin-bottom: 20rpx;
    padding: 4rpx 20rpx;
    display: flex;
    justify-content: center;
    align-items: center;
    min-width: 15%;
}

.prop-value-ns {
    color: #c8c8c8;
    font-size: 26rpx;
    background-color: #f5f5f5;
    height: 50rpx;
    border-radius: 4rpx;
    margin-right: 20rpx;
    margin-bottom: 20rpx;
    padding: 4rpx 20rpx;
    display: flex;
    justify-content: center;
    align-items: center;
    min-width: 15%;
}

/* 确认 */

.submit-button {
    height: 100rpx;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 20px;

}

.submit-text {
    text-align: center;
    line-height: 100rpx;
    width:345px;
    letter-spacing: 16rpx;
    color: white;
    font-size:18px;
    font-family:PingFangSC-Medium,PingFang SC;
    font-weight:500;
    background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
    border-radius:25px;
}
.modals {
    position: fixed;
    z-index: 999;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
}

.modals-cancel {
    position: absolute;
    z-index: 1000;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
}

.bottom-dialog-body {
    position: absolute;
    z-index: 10001;
    bottom: 0;
    left: 0;
    right: 0;
}

/*动画前初始位置*/

.bottom-pos {
    -webkit-transform: translateY(100%);
    transform: translateY(100%); 
}
</style>