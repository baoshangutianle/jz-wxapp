<template>
    <div class="sel-enum-container">
        <view class='list-fix' v-show="show[showName]" @tap='outbtn' @touchmove="outbtn"/>
        <div class="in-list brand_box">
            <div class="brand_nav">
                <sel-enum-item :curr.sync="currType" :show.sync="isTypePopShow"/>
            </div>
            <div class="brand_nav">
                <sel-enum-item :curr.sync="currFloor" :show.sync="isFloorPopShow"/>
            </div>
        </div>
        <ul class="in-list brand_sel_enum" v-show="show[showName]">
            <li :class="{'brand_nav_active': curr.id === item.id}" v-for="item in popData" :key="item.id" @tap="select(item)">
                <div class="brand_nav_li_text">
                    {{item.name}}
                    <img class="brand_nav_arrow" v-show="curr.id === item.id" src="/static/images/icon-check.png" >
                </div>
            </li>
        </ul>
    </div>
</template>

<script>
import selEnumItem from './selEnumItem'
export default {
    props: {
        typeData: {
            type: Array,
            default: []
        },
        floorData: {
            type: Array,
            default: []
        },
        moneyData: {
            type: Array,
            default: []
        }
    },
    components: {
        selEnumItem
    },
    data(){
        return{
            mengShow:true,//蒙层的显示与否
    　　    aniStyle:true,    //动画效果，默认slideup
            show: {
                type: false,
                floor: false,
                money: false
            },
            isTypePopShow: false,
            isFloorPopShow: false,
            isMoneyPopShow: false,
            popData: [],
            currType: {},
            currFloor: {},
            currMoeny: {},
            curr: {},
            showName: '',
        }
    },
    methods:{
        outbtn:function(e){
            this.hideAll()
        },
        select(data){
            this.$set(this.show,this.showName,false)
            this.curr = data
            this.isTypePopShow = false
            this.isFloorPopShow = false
            // this.isMoneyPopShow = false
            if(this.showName == 'type'){
                this.currType = data
            }else if(this.showName == 'floor'){
                this.currFloor = data
            }
            this.$emit('change',this.showName,data)
        },
        hideAll(){
            for(var key in this.show){
                if(this.show[key]){
                    // this.show[key] = false
                    this.$set(this.show,key,false)
                }
            }
        }
    },
    watch:{
       typeData(newVal){
           if(newVal&&newVal.length>0){
               this.currType = newVal[0]
           }
       },
       floorData(newVal){
           if(newVal&&newVal.length>0){
               this.currFloor = newVal[0]
           }
       },
       isTypePopShow(newVal){
            if(newVal){
                this.popData = this.typeData
                this.curr = this.currType
                this.showName = 'type'
            }
            this.hideAll()
            this.$set(this.show,this.showName,newVal)
       },
       isFloorPopShow(newVal){
            if(newVal){
                this.popData = this.floorData
                this.curr = this.currFloor
                this.showName = 'floor'
            }
            this.hideAll()
            this.$set(this.show,this.showName,newVal)
       },
       isMoneyPopShow(newVal){
            if(newVal){
                this.popData = this.moneyData
                this.curr = this.currMoeny
                this.showName = 'money'
            }
            this.hideAll()
            this.$set(this.show,this.showName,newVal)
       },
    }
}
</script>

<style lang="less" scoped>
@import url(../assets/styles/vars);
.sel-enum-container{
    position: relative;
    height: 50px;
    .brand_box{
        flex: 1;
        display: flex;
        overflow: hidden;
        width: 100%;
        height: 50px;
        border-bottom: 1px solid @border-color;
        .brand_nav{
            position: relative;
            overflow: hidden;
            flex: 1;
            height: 100%;
            color: #000;
            font-size:12px;
            // overflow-y: auto;
            // overflow-x: hidden;
            .brand_sel{
                position: relative;
                height: 100%;
                line-height: 50px;
                background: #fff;
                text-align: center;
                font-size: 15px;
                color: @black-color;
                border-bottom: 1px solid #ddd;
                padding: 0 15px;
                &:after{
                    display: inline-block;
                    content: '';
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    right: 0;
                    height: 20px;
                    width: 1px;
                    background: #ddd;
                }
                .brand_sel_text_wrap{
                    width: 100%;
                    height: 100%;
                    display: inline-block;
                    .brand_sel_text{
                        position: relative;
                        box-sizing: border-box;
                        width: 100%;
                        height: 100%;
                        padding-right: 16px;
                        box-sizing: none;
                        display: inline-block;
                        .brand_sel_text_2{
                            display: inline-block;
                        }
                    }
                }
                .brand_sel_arrow{
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    display: inline-block;
                    right: 6px;
                    display: inline-block;
                    width: 8px;
                    height: 5px;
                    img{
                        display: inline-block;
                        width: 100%;
                        height: 100%;
                    }
                }
            }
        }
        .brand_content{
            overflow: hidden;
            flex: 2;
            display: flex;
            flex-direction: column;
            .brand_type{
                height: 50px;
            }
            .brand_list{
                flex: 1;
                overflow-y: auto;
                z-index:9;
                .noMore{
                    text-align: center;
                    color: #999;
                    padding-bottom: 10px;
                }
            }
        }
    }
    .brand_sel{
        position: relative;
        height: 100%;
        line-height: 50px;
        background: #fff;
        text-align: center;
        font-size: 15px;
        color: @black-color;
        border-bottom: 1px solid #ddd;
        padding: 0 15px;
        &:after{
            display: inline-block;
            content: '';
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            right: 0;
            height: 20px;
            width: 1px;
            background: #ddd;
        }
        .brand_sel_text_wrap{
            width: 100%;
            height: 100%;
            display: inline-block;
            .brand_sel_text{
                position: relative;
                box-sizing: border-box;
                width: 100%;
                height: 100%;
                padding-right: 16px;
                box-sizing: none;
                display: inline-block;
                .brand_sel_text_2{
                    display: inline-block;
                }
            }
        }
        .brand_sel_arrow{
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            display: inline-block;
            right: 6px;
            display: inline-block;
            width: 8px;
            height: 5px;
            img{
                display: inline-block;
                width: 100%;
                height: 100%;
            }
        }
    }
    .brand_sel_enum{
        position: absolute;
        top: 50px;
        box-sizing: border-box;
        max-height: 200px;
        background: #fff;
        overflow: auto;
        width: 100%;
        margin-top: 0px;
        box-shadow: 0 3px 8rpx rgba(0, 0, 0, 0.1);
        .slide-ul{
            position: relative;
        }
        li{
            height: 50px;
            padding: 0 15px;
            line-height: 50px;
            font-size: 15px;
            color: @gray-color;
            display: flex;
            .brand_nav_li_text{
                position: relative;
                width: 100%;
                border-bottom: 1px solid @border-color;
                .brand_nav_arrow{
                    position: absolute;
                    top: 50%;
                    right: 0;
                    transform: translateY(-50%);
                    width: 24rpx;
                    height: 18rpx;
                }
            }
            &.brand_nav_active{
                color: @theme-color;
            }
        }
    }
    .filter-title-text-wrap{
        overflow: hidden;
        font-size:15px;
        color: #333;
        line-height: 50px;
        text-align: center;
        position: relative;
        display: flex;
        padding: 0 15px;
        justify-content: center;
        align-items: center;
        &>div{
            position: relative;
            display: inline-block;
            padding-right: 23px;
            height: 100%;
            overflow: hidden;
        }
        .filter-title-text{
            box-sizing: border-box;
            display: inline-block;
            width: 100%;
        }
        .filter-title-img{
            position: absolute;
            top: 50%;
            display: inline-block;
            right: 6px;
            transform: translateY(-50%);
            img{
                width: 8px;
                height: 5px;
            }
        }
    }
}
</style>
