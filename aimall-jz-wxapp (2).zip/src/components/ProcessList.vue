<!--
 * @Author: your name
 * @Date: 2020-03-02 22:11:46
 * @LastEditors: your name
 * @LastEditTime: 2020-03-05 04:11:57
 * @Description: file content
 -->
<template>
    <div>
        <div class="ProcessList" v-if="!isPeople&&options">
            <p class="ProcessList_t">
                正在拼团,可直接参与
                <span class="ProcessList_title">({{options[0].successNumber}}人成团)</span>
            </p>
            <ul class="content">
                <li v-for="(item, index) in options" :key="item.groupInfoId">
                    <ul class="ProcessList_pt">
                        <li v-for="(list, id) in item.buyingUserVos" :key="id">
                            <img src="https://saas-cdn.aimall.cloud/as/20200414/6c9c9f82ee8c47d9a341113bf5c3118f.png" class="ProcessList_img" />
                        </li>
                    </ul>
                    <div class="ProcessList_con">
                        <!-- <div class="count-down">
                            <time-count :countDownTime="item.residueTime" />
                        </div> -->
                        <ul class="ProcessList_name">
                            <li v-for="(list, id) in item.buyingUserVos" :key="id">
                                <span>
                                    {{list.memberName ? list.memberName : list.memberMobile}}
                                    <span class="dot-span" v-if="item.buyingUserVos.length == 0"></span>
                                     <span class="dot-span" v-else-if="item.buyingUserVos.length - 1 == id"></span>
                                     <span class="dot-span" v-else>,</span>
                                </span>
                            </li>
                        </ul>
                        <div class="ProcessList_div">
                            <div class="ProcessList_num">
                                <span class="text">
                                    还差
                                    <span>{{item.needNumber}}</span> 人拼成
                                </span>
                                <span class="clockTime">
                                    <time-count :countDownTime="item.residueTime" />
                                </span>
                            </div>
                            <button class="payGroup" @click="goGroup(item)">去拼单</button>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="ProcessList" v-if="isPeople&&groupData">
            <ul class="contentorder">
                <li :class="{'flexCenter': isDetail && !invite}" >
                    <ul class="ProcessList_ptOrder">
                        <li v-for="(list, id) in groupData.buyingUserVos" :key="id" :style="id == 0 ? 'margin-top: 5px;':''">
                            <img src="https://saas-cdn.aimall.cloud/as/20200414/6c9c9f82ee8c47d9a341113bf5c3118f.png" class="ProcessList_imgT" />
                        </li>
                    </ul>
                    <span>{{grounpstatus}}</span>
                    <span
                        v-if="groupData.groupBuyingStatus===1&&groupData.needNumber>0"
                    >,还差{{groupData.needNumber}}人...</span>
                    <span
                        class="clockTimeOrder"
                        v-if="groupData.groupBuyingStatus===1 && !isDetail"
                    >{{peopleClock}}</span>
                     <button class="payGroupT" v-if="isDetail && invite" @click="invitePeople(groupData)">
                    <span>邀请好友</span></button>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
import moment from 'moment'
import buryPoint from "@/utils/buryPoint";
import { diff } from 'semver'
import timeCount from '@/components/timeCount'
/**
 * @author: jxy
 * @since: 2020-03-02
 * @router('/ProcessList')
 */
export default {
    components: {
        timeCount
    },
    props: {
        options: {
            type: Array,
            default() {
                return []
            }
        },
        groupData: {
            type: Object,
            default() {
                return {}
            }
        },
        successNumber: {
            type: Number,
            default: 0
        },
        isPeople: {
            type: Boolean,
            default: false
        },
        isShare: {
            type: Boolean,
            default: false
        },
        isDetail: {
            type: Boolean,
            default: false
        },
        invite: {
            default: false
        },
    },
    data() {
        return {
            isCountTime: true,
            peopleClock: '',
            grounpstatus: '',
            interval: [],
            countDownTime: [],
            countdown: '',
            endDate2: '2020-08-08 11:41:00'
        }
    },
    beforeDestroy() {
        this.isCountTime = false
        this.clearTimeList()
    },
    methods: {
        countTimeNew() {
            // var that = this
            // var date = new Date()
            // var now = date.getTime()
            // var endDate = new Date(that.endDate2.replace(/-/g, "/")) //设置截止时间
            // var end = endDate.getTime()
            // var leftTime = end - now //时间差
            // var d, h, m, s, ms
            // if (leftTime >= 0) {
            //     d = Math.floor(leftTime / 1000 / 60 / 60 / 24)
            //     h = Math.floor((leftTime / 1000 / 60 / 60) % 24)
            //     m = Math.floor((leftTime / 1000 / 60) % 60)
            //     s = Math.floor((leftTime / 1000) % 60)
            //     ms = Math.floor(leftTime % 1000)
            //     ms = ms < 100 ? '0' + ms : ms
            //     s = s < 10 ? '0' + s : s
            //     m = m < 10 ? '0' + m : m
            //     h = h < 10 ? '0' + h : h
            //     that.countdown = d + '：' + h + '：' + m + '：' + s
            //     console.log(that.countdown);
            //     //递归每秒调用countTime方法，显示动态时间效果
            //     setTimeout(that.countTimeNew, 100)
            // } else {
            //     console.log('已截止')
            //     that.countdown ='00:00:00'
            // }
        },
        goGroup(item) {
            this.$emit('goGroup', item)
        },
        invitePeople (item) {
            buryPoint.setF({
                id: 8756,
                p_title: item.prodName,
                p_id: item.id
            })
            this.$emit('invitePeople', item)
        },
        clearTimeList() {
            let _this = this
            for (let i = 0; i < _this.interval.length; i++) {
                let index = i
                clearInterval(_this.interval[index])
            }
        },
        filterStatus(val) {
            switch (val) {
                case 0:
                    return '未生效'
                case 1:
                    return '拼团中'
                case 2:
                    return '拼团成功'
                case 3:
                    return '拼团失败'
            }
        },

        /**
         * @description: 方法一
         * @param {type}
         * @return:
         */
        countTime(val) {
            this.dateformat(val)
            if (val <= 0) {
                this.peopleClock = '00:00:00'
                this.isCountTime = false
                return
            }
            val--
            setTimeout(() => {
                this.countTime(val)
            }, 1000)
        },
        /**
         * @description: 特定时间格式转换
         * @param {type}
         * @return:
         */
        dateformat(micro_second) {
            // 总秒数
            let second = Math.floor(micro_second)
            // 天数
            let day = Math.floor(second / 3600 / 24)
            // 小时
            let hr = Math.floor((second / 3600) % 24)
            let hrStr = hr.toString()
            if (hrStr.length == 1) hrStr = '0' + hrStr
            // 分钟
            let min = Math.floor((second / 60) % 60)
            let minStr = min.toString()
            if (minStr.length == 1) minStr = '0' + minStr
            // 秒
            let sec = Math.floor(second % 60)
            let secStr = sec.toString()
            if (secStr.length == 1) secStr = '0' + secStr
            if (day < 1) {
                this.peopleClock = '剩余'+ hrStr + ':' + minStr + ':' + secStr
            } else {
                this.peopleClock = '剩余'+ day + '天' + hrStr + ':' + minStr + ':' + secStr
            }
        },
        /**
         * @description:  方法二
         * @param {type}
         * @return:
         */
        intervalTime(lastTime, _this, index) {
            _this.interval[index] = setInterval(function() {
                let nowTime = new Date().getTime()
                let differ_time = lastTime - nowTime //时间差：
                if (differ_time >= 0) {
                    let differ_day = Math.floor(differ_time / (3600 * 24 * 1e3)) //相差天数
                    let differ_hour = Math.floor((differ_time % (3600 * 1e3 * 24)) / (1e3 * 60 * 60)) //相差小时
                    let differ_minute = Math.floor((differ_time % (3600 * 1e3)) / (1000 * 60)) //相差分钟
                    let s = Math.floor(((differ_time % (3600 * 1e3)) % (1000 * 60)) / 1e3)
                    // 时间为个位数时，添加0
                    differ_day = differ_day > 0 ? (differ_day.toString()[1] ? differ_day : '0' + differ_day) + '天 ' : '' //天数数
                    differ_hour = differ_hour > 0 ? (differ_hour.toString()[1] ? differ_hour : '0' + differ_hour) + ':' : '' //小时数
                    differ_minute = differ_minute > 0 ? (differ_minute.toString()[1] ? differ_minute : '0' + differ_minute) + ':' : '' //分钟数
                    s = s.toString()[1] ? s : '0' + s //秒数
                    let str = '剩余' + differ_day + differ_hour + differ_minute + s
                    console.log(str)
                    _this.options[index].endTime = str
                } else {
                    // 已到期，不再进行倒计时
                    _this.options[index].endTime = '00:00:00'
                    // 清除到期的计时器
                    clearInterval(_this.interval[index])
                }
            }, 100)
        },
        // 获取剩余时间
        getResidueTime(end, _this, index) {
            _this.interval[index] = setInterval(() => {
                let nowtime = new Date().getTime() // 当前时间 毫秒数
                let endTime = Date.parse(new Date(end.replace(/-/g, '/'))) //结束时间  毫秒数
                let totalSeconds = (endTime - nowtime) / 1000 // 结束时间-当前时间 = 剩余多少时间
                let day = parseInt(totalSeconds / 3600 / 24) //天
                let hour = parseInt((totalSeconds / 3600) % 24) //时
                let minute = parseInt((totalSeconds / 60) % 60) //分
                let second = parseInt(totalSeconds % 60) //秒
                hour = this.addZero(hour)
                minute = this.addZero(minute)
                second = this.addZero(second)
                let residueTime = '剩余' + day + '天' + hour + '时' + minute + '分' + second + '秒'
                if (totalSeconds < 0) {
                    residueTime = '00:00:00'
                    clearInterval(_this.interval[index]) // 清除定时器
                }
                //console.log(residueTime,888)
                _this.options[index].endTime = residueTime
                return residueTime
            }, 100)
        },
        // 补齐格式不满10加0
        addZero(n) {
            return n < 10 ? '0' + n : n
        },
        // 倒计时数组变更
        countDownArray(){
            const t = this;
            let busArray = t.options;
            busArray.forEach(item => {
                let obj = {
                    dayMinutesSeconds: ''
                }
                obj.dayMinutesSeconds = t.secondsToDay(item.residueTime)
                item = Object.assign(item,obj)
                item.residueTime--
            })
            t.options = busArray;
            t.$forceUpdate();
            setTimeout(() => {
                t.countDownArray()
            }, 1000)
        },
        // 秒转换为天时分秒
        secondsToDay(data){
            var time =data
            if (null != time && "" != time) {
                if (time > 60 && time < 60 * 60) {
                    time = "0:" + parseInt(time / 60.0) + ":" + parseInt((parseFloat(time / 60.0) -
                        parseInt(time / 60.0)) * 60) + "";
                }
                else if (time >= 60 * 60 && time < 60 * 60 * 24) {
                    time = parseInt(time / 3600.0) + ":" + parseInt((parseFloat(time / 3600.0) -
                        parseInt(time / 3600.0)) * 60) + ":" +
                        parseInt((parseFloat((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60) -
                        parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60)) * 60) + "";
                } else if (time >= 60 * 60 * 24) {
                    time = parseInt(time / 3600.0/24) + "天" +parseInt((parseFloat(time / 3600.0/24)-
                        parseInt(time / 3600.0/24))*24) + ":" + parseInt((parseFloat(time / 3600.0) -
                        parseInt(time / 3600.0)) * 60) + ":" +
                        parseInt((parseFloat((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60) -
                        parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60)) * 60) + "";
                }
                else {
                    time = "0:0:" + parseInt(time) + "";
                }
            }
            return time;
        }
    },
    created() {
        this.isCountTime = true
        var that = this
        that.countTimeNew()
        // console.log(that.options,"111111111111111111111");
        that.countDownArray();
        // let residueTime = that.options.residueTime;

        if (this.isPeople === false) {
            let _this = this

            for (let i = 0; i < _this.options.length; i++) {
                let index = i
                let lastDate = _this.options[index].endTime
                //_this.intervalTime(lastDate, _this,index);
                // _this.getResidueTime(moment(+lastDate).format('YYYY/MM/DD HH:mm:ss'), _this, index)
            }
        } else {
            if (this.groupData && this.groupData.residueTime) {
                this.countTime(this.groupData.residueTime)
            }
            if (this.groupData && this.groupData.groupBuyingStatus) {
                this.grounpstatus = this.filterStatus(this.groupData.groupBuyingStatus)
            }
        }
    }
}
</script>

<style lang="less">
.ProcessList {
    position: relative;
    background-color: #fff;
    font-size: 12px;
    .count-down{
        position: absolute;
        right: 155rpx;
        font-size: 11px;
        margin-top: 15px;
        color: #999;
    }
    .content {
        margin-top: 10px;
        overflow-y: auto;
        max-height: 270px;

        li {
            overflow: hidden;
            margin-top: 5px;
        }
    }
    .contentorder {
        overflow: hidden;
        color: #333333;
        font-size: 15px;
        line-height: 30px;
        .flexCenter {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
    }
    .ProcessList_t {
        font-size: 15px;
        line-height: 20px;
    }
    .ProcessList_title {
        font-size: 10px;
        color: #999;
    }
    .ProcessList_pt,
    .ProcessList_ptOrder {
        position: relative;
        width: 80px;
        overflow: hidden;
        float: left;
        height: 50px;
        margin-top: -5px;
        li {
            .ProcessList_img {
                width: 40px;
                height: 40px;
                border-radius: 20px;
            }
            .ProcessList_imgT {
                width: 25px;
                height: 25px;
                border-radius: 15px;
            }
        }
        li:nth-child(2) {
            img {
                position: absolute;
                left: 20px;
                top: 5px;
            }
        }
        li:nth-child(3) {
            img {
                position: absolute;
                left: 38px;
                top: 5px;
            }
        }
    }
    .ProcessList_ptOrder {
        height: 30px;

        li image {
            width: 30px !important;
            height: 30px !important;
        }
        li:nth-child(2),
        li:nth-child(3) {
            image {
                top: 0px !important;
            }
        }
    }
    .text {
        font-size: 12px;
        color: #333333;
        span {
            color: red;
        }
    }
    .ProcessList_con {
        overflow: hidden;
        height: 50px;
        line-height: 40px;
    }
    .ProcessList_name {
        position: relative;
        overflow: hidden;
        float: left;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        word-break: break-all;
        display: inline-block;
        max-width: 100px;
        li {
            display: inline-block;
            color: #333333;
        }
        .dot-span{
            margin-left: -4px;
            display: inline-block;
        }
    }
    .ProcessList_div,
    .ProcessList_div2 {
        float: right;
    }
    .ProcessList_div{
        position: relative;
        width: calc(100% - 104px);
    }
    .ProcessList_num,
    .ProcessList_num2 {
        float: left;
        // margin-right: 8px;
    }
    .ProcessList_num2 {
        height: 40px;
        line-height: 40px;
    }
    .payGroup {
        position: absolute;
        right: 5px;
        width: 4.1rem;
        line-height: 1.5rem;
        background: #CEAB72;
        text-align: center;
        font-size: 10px;
        color: #fff;
        border-radius: 22px;
        top: 12px;
    }
    .payGroupT {
        float: right;
        width: 70px;
        height: 28px;
        background: #D9B170;
        text-align: center;
        line-height: 24px;
        font-size: 13px;
        color: #fff;
        border-radius: 22px;
    }
    .payGroupT2 {
        margin-top: 10px;
    }

    .clockTime {
        color: #999999;
        font-size: 10px;
        display: block;
        line-height: 0px;
        text-align: center;
    }
}
</style>
