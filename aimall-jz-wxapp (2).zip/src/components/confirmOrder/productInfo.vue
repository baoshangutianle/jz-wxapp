<template>
    <div >
        <div class="flexRow pd_t10">
            <div class="flexOne">{{product.shopName ? product.shopName : product.goodsName}}</div>
            <div class="textGray" v-if="product.floorNo">{{product.floorNo}}</div>
        </div>
        <div class="productInfo">
            <div class="coverImg">
                <img :src="coverImg" alt />
            </div>
            <div class="detail">
                <div :class="['prodName', 'hasProdName']">{{product.prodName || product.goodsName}}</div>
                <div class="flexRow">
                    <div class="flexOne" >
                        <span class="textGray" v-if="product.goodsType == 1">商品规格：</span>
                        <span v-if="product.goodsType == 1">{{product.specsValue}}</span>
                    </div>
                    <div class="textGray">x{{counter ? counter : product.buyCount}}</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: 
        ['product','counter'],
    data() {
        return {}
    },
    computed: {
        coverImg() {
            if (this.product.thumbnail) {
                return this.product.thumbnail.split(',')[0]
            }
        }
    }
}
</script>

<style lang="less" scoped>
.textGray {
    color: #999;
}
.pd_t10 {
    padding: 17px 12px 0;
}
.flexRow {
    display: flex;
}
.flexOne {
    flex: 1;
    overflow: hidden;
    color: #333;
}

.productInfo {
    display: flex;
    // align-items: center;
    padding: 17px 12px;
    .coverImg {
        width: 88px;
        height: 88px;
        > img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    }
    .detail {
        flex: 1;
        padding-left: 9px;
        overflow: hidden;
        .hasProdName {
            height: 70px;
        }
        .noProdName {
            height: 35px;
        }
        .prodName {
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            text-overflow: ellipsis;
            -webkit-box-orient: vertical;
        }
    }
}
</style>