<template>
    <div>
        <div v-if="loadermore"
             class="weui-loadmore">
            <div class="weui-loading">&nbsp;</div>
            <!-- <div class="weui-loadmore__tips">正在加载</div> -->
        </div>
        <div v-else
             class="weui-loadmore weui-loadmore_line weui-loadmore_dot">
            <div class="weui-loadmore__tips weui-loadmore__tips_in-line weui-loadmore__tips_in-dot">&nbsp;</div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        loadermore: {
            type: Boolean,
            default: true
        }
    }
}
</script>

<style lang="less">
</style>
