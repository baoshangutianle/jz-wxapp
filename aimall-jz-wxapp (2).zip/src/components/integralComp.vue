<template>
    <div class="brand-comp-container">
        <auth-btn @pass="goDetail" />
        <div class="brand-comp-con">
            <div class="item-img">
                <img :src="data.thumbnail" class="restaurant-img" />

                <div v-if="!data.stock" class="mask">
                    <img
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191118/01cab233686a458b85196f370bd7ad7a.png"
                    />
                </div>
            </div>
            <div class="restaurant-info">
                <p>
                    <span class="restaurant-name">{{ data.prodName }}</span>
                </p>
                <p>
                    <span class="store-name">{{ data.shopName }}</span>
                </p>
                <p class="content">
                    <span class="integral">
                        <!-- <span v-if="!data.integral">免费兑换</span> -->
                        <!-- 积分兑换 -->
                        <span v-if="data.buyWay === 1" class="integralExchange">
                            {{ data.listIntegral }}
                            <span>积分</span>
                        </span>
                        <!-- 微信支付 -->
                        <span v-if="data.buyWay === 2" class="wechatBuy">¥{{ data.listPrice}}</span>
                        <!-- 积分 + 微信支付 -->
                        <span v-if="data.buyWay === 3" class="wechatAndIntegral">
                            {{ data.listIntegral }}
                            <span class="wechatAndIntegral_integral">积分 +</span>
                            <span class="wechatAndIntegral_cash">¥</span>
                            {{ data.listPrice }}
                        </span>
                    </span>
                    <span class="oldPrice">
                        <!-- 积分、积分+现价 -->
                        <!-- <span v-if="data.buyWay === 1 || data.buyWay === 2" 
                        class="oldPrice-x" >价格:¥{{ salePrice }}</span>-->
                        <!-- 微信 -->
                        <span class="oldPrice-y">原价:¥{{ data.originalPrice }}</span>
                    </span>
                    <!-- <span class="num">库存<span class="value">{{ data.stock }}</span>件</span> -->
                </p>
                <!-- <p class="restaurant-vip">
                    <span>畅享普卡 29999 积分</span>
                </p>-->
            </div>
        </div>
    </div>
</template>

<script>
import AuthBtn from '@/components/AuthBtn'
import utils from '@/plugins/utils'
export default {
    props: {
        data: {
            type: Object,
            default: {}
        }
    },
    data() {
        return {}
    },
    components: {
        AuthBtn
    },
    methods: {
        goDetail() {
            let item = this.data
            let type = item.isFood === true ? 1 : 2
            this.checkMemberCode(item)
        },
        checkMemberCode(item) {
            const t = this
            let wxUserCode = wx.getStorageSync('wxUserCode')
            if (wxUserCode) {
                //校验会员信息
                utils.getVipInfo().then(vipInfo => {
                    if (vipInfo.status) {
                        wx.navigateTo({
                            url: `/pages/goodsDetails/index?prodId=${item.id}`
                        })
                    } else {
                        // 用户已被冻结，请联系服务台
                        wx.showModal({
                            title: '温馨提示',
                            content: '用户已被冻结，请联系服务台',
                            showCancel: false,
                            confirmText: '知道了'
                        })
                    }
                })
            } else {
                wx.showModal({
                    title: '温馨提示',
                    content: '请先登录',
                    showCancel: false,
                    confirmText: '确认',
                    confirmColor: '#4694FA',
                    success(res) {
                        let oldIsLogined = t.isLogined
                        wxUtils.clearLoginStorage()
                        t.update({
                            vipInfo: null,
                            sessionId: '',
                            isLogined: oldIsLogined
                        })
                        wx.navigateTo({
                            url: `/pages/auth/index`
                        })
                    }
                })
            }
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.brand-comp-container {
    .brand-comp-con {
        .item-img {
            position: relative;
            .mask {
                position: absolute;
                width: 172px;
                height: 172px;
                top: 0;
                left: 0;
                background: rgba(31, 31, 31, 0.7);
                img {
                    width: 84px;
                    height: 84px;
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    margin: auto auto;
                }
            }
            .restaurant-img {
                width: 172px;
                height: 172px;
            }
        }
        .restaurant-info {
            padding: 10px;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            p {
                text-align: center;
                &:last-child {
                    margin-bottom: 0;
                }
                .restaurant-name {
                    font-size: 15px;
                    color: #333333;
                    text-align: left;
                    // overflow:hidden; //超出一行文字自动隐藏
                    // text-overflow:ellipsis;//文字隐藏后添加省略号
                    // white-space:nowrap; //强制不换行
                    display: inline-block;
                    width: 158px;
                    text-overflow: -o-ellipsis-lastline;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    line-clamp: 2;
                    -webkit-box-orient: vertical;
                }
                .integral {
                    // color:#9975F3;
                    // font-size: 14px;
                    float: left;
                    .integralExchange {
                        color: #fd600e;
                        font-size: 15px;
                        span {
                            display: inline-block;
                            color: #666;
                            font-size: 10px;
                            // margin-left: -4px;
                        }
                    }
                    .wechatBuy {
                        color: #fd600e;
                        font-size: 15px;
                        b {
                            display: inline-block;
                            text-decoration: line-through;
                            margin-left: 6px;
                            color: #999;
                            font-size: 12px;
                        }
                    }
                    .wechatAndIntegral {
                        color: #fd600e;
                        font-size: 15px;
                        .wechatAndIntegral_integral {
                            display: inline-block;
                            font-size: 12px;
                            color: #666;
                            margin-right: 3px;
                            // margin-left: -4px;
                        }
                        .wechatAndIntegral_cash {
                            font-size: 12px;
                        }
                    }
                }
                .num {
                    color: #333333;
                    font-size: 10px;
                    float: right;
                    line-height: 22px;
                    font-weight: 200;
                    .value {
                        color: #9975F3;
                    }
                }
                .store-name,
                .oldPrice {
                    display: inline-block;
                    width: 100%;
                    font-size: 12px;
                    color: #999;
                    text-align: left;
                }
                .oldPrice-y {
                    text-decoration: line-through;
                }
            }
            .content {
            }
            .restaurant-tags {
                // display: flex;
                li {
                    display: inline-block;
                    // flex: 1;
                    padding: 2px 6px;
                    border: 1px solid;
                    font-size: 12px;
                    color: @theme-color;
                    & + li {
                        margin-left: 5px;
                    }
                }
            }
            .restaurant-vip {
                color: #999999;
                font-size: 12px;
                text-decoration: line-through;
                text-align: left;
                height: 17px;
                line-height: 17px;
                display: inline-block;
                padding-bottom: 7px;
            }
        }
    }
}
</style>
