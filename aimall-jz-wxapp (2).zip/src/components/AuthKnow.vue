<template name="paybulletCoverView">
    <cover-view v-show="isShow"
                class="pop-up-bg">
        <cover-view class="pop-up-container">
            <cover-view class="auth-know-info">
                <cover-view class="auth-know-item auth-know-title">
                    需要您的授权
                </cover-view>
                <cover-view class="auth-know-item auth-know-tip">
                    <cover-view>为了提供更好的服务</cover-view>
                    <cover-view>请在稍后的提示框中点击“允许”</cover-view>
                </cover-view>
                <cover-view class="auth-know-item auth-know-img">
                    <cover-image src="/static/images/auth-know-remind@2x.png"
                                 alt="图片示例"
                                 mode="widthFix"/>
                </cover-view>
                <cover-view class="auth-know-item auth-know-btn">
                    <button class="btn-operate btn-know"
                            open-type="getUserInfo"
                            lang="zh_CN"
                            @getuserinfo="bindGetUserInfo">
                        我知道了
                    </button>
                </cover-view>
            </cover-view>
        </cover-view>
    </cover-view>
</template>

<script>
import request from '../plugins/request'
import api from '../plugins/api'
import wxUtils from '@/plugins/wxUtils'
export default {
    props: {
        isShow: {
            type: Boolean,
            default: false
        }
    },
    data(){
        return{
            appId: 'wx93a6a167043f0ce5',
            sessionKey: 'c1zQbdnpzPfrAy0vQo6z5g==',
            openId: 'oGUEp4w4NnAe50q-kNC1lAnxzI_g'
        }
    },
    methods:{
        bindGetUserInfo(e){
            let vm = this
            if (e.mp.detail.errMsg == "getUserInfo:ok") {
                wxUtils.setUserStorage(e.mp.detail)
                vm.isShow = false
                wx.navigateTo({
                    url: '/pages/auth/index'
                })
            } else {
                // 用户按了拒绝按钮
                wx.showModal({
                    title: '温馨提示',
                    content: '您还没有授权登录无法享受我们的会员福利啦～',
                    showCancel: false,
                    confirmText: '知道了',
                    success: function(res) {
                        this.isShow = false
                    }
                })
            }
        }
    }
}
</script>


<style lang="less" scoped>
@import '../assets/styles/vars';
@import '../assets/styles/common';
.pop-up-bg {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 9999;
  align-items: center;
  justify-content: center;
}
.pop-up-container {
    position: fixed;
    top: 50%;
    left: 50%;
    width: 315px;
    transform: translate(-50%,-50%);
    color: #666;
    font-size: 15px;
    right: 0;
    background: #fff;
    color: @black-color;
    line-height: 21px;
    text-align: center;
    border-radius: 10px;
    .auth-know-title{
        padding: 15px 0;
        font-size: 20px;
        line-height: 28px;
        border-bottom: 1px solid @border-color;
    }
    .auth-know-tip{
        margin-top: 15px;
        font-size: 15px;
        line-height: 21px;
    }
    .auth-know-img{
        margin: 20px 52px 0;
        img{
            display: block;
            width: 211px;
            height: 170px;
        }
    }
    .btn-know{
        margin: 18px 20px 31px;
    }
    .phone-info{
        .phone-item{
            &.phone-call,
            &.phone-cancel{
                font-size: 18px;
                color: #000;
            }
            &.phone-number{
                padding: 10px 0;
            }
            &.phone-call{
                padding: 10px 0;
                border-top: 1px solid #EFF1F8;;
            }
            &.phone-cancel{
                padding-top: 10px;
                border-top: 6px solid rgba(0, 0, 0, .6);
                &:after{
                    display: block;
                    content: '';
                    width: 135px;
                    height: 7px;
                    margin: 16px auto 6px;
                    background: #171717;
                    border-radius: 4px;
                }
            }
        }
    }
}

.top-view {
  height: 98rpx;
  width: 100%;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: center;
  background-color: #fff;
}

.top-view .title {
  height: 98rpx;
  line-height: 98rpx;
  width: 100%;
  font-size: 36rpx;
  text-align: center;
}

.top-view .cancel {
  position: absolute;
  width: 60rpx;
  height: 60rpx;
  right: 20rpx;
  top:50%;
  transform: translateY(-50%);
}

.line-view, .top-line-view {
  width: 100%;
  height: 2rpx;
  background-color: #eeeeee
}

.top-line-view {
  background-color: #39cc6a
}

.pay-money-title {
  width: 100%;
  height: 98rpx;
  line-height: 98rpx;
  color: #333333;
  font-size: 32;
  text-align: center;
}

.pay-money-view {
  height: 60rpx;
  margin: 36rpx 30rpx 20rpx;
  justify-content: center;
  display: flex;
}

.pay-money-view .symbol {
  width: 33%;
  height: 40rpx;
  line-height: 40rpx;
  margin-top: 20rpx;
  font-size: 30rpx;
  text-align: right;
}

.pay-money-view .price {
  width: 67%;
  height: 60rpx;
  line-height: 60rpx;
  margin-left: 10rpx;
  color: #000;
  font-size: 60rpx;
  text-align: left;
}

.pet-card-view {
  height: 86rpx;
  margin-left: 30rpx;
  margin-right: 30rpx;
  align-items: center;
  display: flex;
}

.pet-card-view .icon{
  width:46rpx;
  height:46rpx;
  border-radius:23rpx
}

.pet-card-view .title{
  width: 200rpx;
  height: 46rpx;
  line-height: 46rpx;
  margin: 20rpx;
  color: #6E726E;
  text-align: left;
}

.bottom-make-sure-button {
  height: 92rpx;
  line-height: 92rpx;
  margin: 40rpx 30rpx 20rpx;
  background-color: #06C160;
  border-radius: 8rpx;
  color: #fff;
  justify-content: center;
  align-items: center;
  text-align: center;
}
</style>
