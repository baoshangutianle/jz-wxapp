<template>
    <div class="sel-enum-container"
         catchtouchmove="stopScroll">
        <view v-show="show[showName]"
              class="list-fix"
              @tap="outbtn"
              @touchmove="outbtn" ></view>
        <div class="in-list brand_box">
            <div class="brand_nav">
                <sel-enum-item :curr.sync="currBuilding"
                               :show.sync="isBuildingPopShow" />
            </div>
            <div class="brand_nav">
                <sel-enum-item :curr.sync="currType"
                               :show.sync="isTypePopShow" />
            </div>
            <div class="brand_nav">
                <sel-enum-item :curr.sync="currCategory"
                               :curr-sec-category-name.sync="currSecondCategoryName"
                               :show.sync="isCategoryPopShow" />
            </div>
        </div>
        <div>
            <div v-show="show[showName]"
                         class="in-list brand_sel_enum"
                        >
                <ul>
                    <!-- <div v-if="isFloorPopShow">
                        <li :class="{'brand_nav_active': curr.id === item.id}" v-for="item in popData" :key="item.id" @tap="select(item)">
                            <div class="loginPage" v-if="item.loginFalg">
                                <auth-btn/>
                            </div>
                            <div class="brand_nav_li_text">
                                {{item.name}}
                                <img class="brand_nav_arrow" v-show="curr.id === item.id" src="/static/images/icon-check.png" >
                            </div>
                        </li>
                    </div> -->
                    <div v-if="showName != 'category'">
                        <li v-for="item in popData"
                            :class="{'brand_nav_active': curr.id === item.id}"
                            :key="item.id">
                            <!-- <div class="loginPage"
                                 v-if="item.loginFalg">
                                <auth-btn @pass="select(item)" />
                                <div class="brand_nav_li_text">
                                    {{item.name}}
                                    <img class="brand_nav_arrow"
                                         v-show="curr.id === item.id"
                                         style="right:60rpx;"
                                         src="/static/images/icon-check.png">
                                </div>
                            </div> -->
                          
                            <div class="brand_nav_li_text"
                                 @tap="select(item)">
                                {{ item.name }}
                                <img v-show="curr.id === item.id"
                                     class="brand_nav_arrow"
                                     src="/static/images/icon-check.png">
                            </div>
                        </li>
                    </div>
                    <div v-else class="category_nav">
                        <!-- <li v-for="item in popData"
                            :class="{'brand_nav_active': curr.id === item.id}"
                            :key="item.id"></li> -->
                            <scroll-view  scroll-y class="outerBox1">
                                <div class="firstCategory">
                                    <div v-for="item in popData"
                                        :key="item.id"
                                        :class="{'firstCategory_txt':true,'firstCategory_txt_active': curr.id === item.id}"
                                        @tap="select(item)">
                                        <p>
                                            {{ item.name }}
                                            <span>{{ item.children && item.children.length ? item.children.length : '' }}</span>
                                        </p>
                                    </div>
                                </div>
                            </scroll-view>
                            
                           <scroll-view class="outerBox2" scroll-y>
                                <div class="secondCategory">
                                    <p v-for="item in secondCategoryArr"
                                    :key="item.id"
                                    class="secondCategory_txt_active"
                                    @tap="selectSecondCategory(item)">
                                        {{ item.categoryName }}
                                        <img v-show="currSecondCategoryId == item.id" 
                                            class="brand_nav_arrow" 
                                            src="/static/images/icon-check.png" >
                                    </p>
                                </div>
                           </scroll-view>
                            
                    </div>
                </ul>
            </div>
        </div>
        
    </div>
</template>

<script>
import selEnumItem from './selEnumItem'
import AuthBtn from '@/components/AuthBtn'
import { mapState, mapMutations } from 'vuex'
export default {
    components: {
        selEnumItem,
        AuthBtn
    },
    props: {
        typeData: {
            type: Array,
            default: []
        },
        buildingData: {
            type: Array,
            default: []
        },
        floorData: {
            type: Array,
            default: []
        },
        categoryData:{
            type: Array,
            default: []
        },
        moneyData: {
            type: Array,
            default: []
        },
        moneyData: {
            type: Array,
            default: []
        },
        categoryId:{
            type: String,
            default: ''
        }
    },
    computed: {
        ...mapState(['isLogined', 'vipInfo'])
    },
    data() {
        return {
            mengShow: true, //蒙层的显示与否
            aniStyle: true, //动画效果，默认slideup
            show: {
                type: false,
                floor: false,
                category: false,
                money: false
            },
            isTypePopShow: false,
            isFloorPopShow: false,
            isCategoryPopShow: false,
            isBuildingPopShow: false,
            isMoneyPopShow: false,
            popData: [],
            currType: this.typeData[0],
            currFloor: this.floorData[0],
            currCategory: this.categoryData[0],
            currMoeny: {},
            currBuilding: this.buildingData[0],
            curr: {},
            showName: '',
            secondCategoryArr:[],
            currSecondCategoryId:'',
            currSecondCategoryName:''
        }
    },
    watch: {
        typeData(newVal) {
            if (newVal && newVal.length > 0) {
                this.currType = newVal[0]
            }
        },
        buildingData(newVal) {
            if (newVal && newVal.length > 0) {
                this.currBuilding = newVal[0]
            }
        },
        floorData(newVal) {
            if (newVal && newVal.length > 0) {
                this.currFloor = newVal[0]
            }
        },
        categoryData(newVal) {
            if (newVal && newVal.length > 0) {
                if(this.categoryId){ 
                    let tempData = newVal.filter(item => item.id === this.categoryId)
                    if(tempData.length){
                        this.currCategory = tempData[0]
                        this.currSecondCategoryName = tempData[0].children && tempData[0].children.length ? tempData[0].children[0].categoryName : ''
                        this.currSecondCategoryId = tempData[0].children && tempData[0].children.length ? tempData[0].children[0].id : ''
                    }
                    // else{
                    //      this.currCategory = newVal[0]
                    //      this.currSecondCategoryName = ''
                    //      this.currSecondCategoryId = ''
                    //      this.$emit('changeFirstCategory', this.showName, newVal[0])
                    // }
                   
                }else{
                    this.currSecondCategoryName = ''
                    this.currSecondCategoryId = ''
                    this.currCategory = newVal[0]
                }
                
            }
        },
        moneyData(newVal) {
            if (newVal && newVal.length > 0) {
                this.currMoeny = newVal[0]
            }
        },
        isTypePopShow(newVal) {
            if (newVal) {
                this.popData = this.typeData
                this.curr = this.currType
                this.showName = 'type'
            }
            this.hideAll()
            this.$set(this.show, this.showName, newVal)
        },
        isBuildingPopShow(newVal) {
            if (newVal) {
                this.popData = this.buildingData
                this.curr = this.currBuilding
                this.showName = 'building'
            }
            this.hideAll()
            this.$set(this.show, this.showName, newVal)
        },
        isFloorPopShow(newVal) {
            if (newVal) {
                this.popData = this.floorData
                this.curr = this.currFloor
                this.showName = 'floor'
            }
            this.hideAll()
            this.$set(this.show, this.showName, newVal)
        },
        isCategoryPopShow(newVal) {
            if (newVal) {
                this.popData = this.categoryData
                this.curr = this.currCategory
                this.secondCategoryArr = this.curr.children ? this.curr.children : []
                this.showName = 'category'
            }
            this.hideAll()
            this.$set(this.show, this.showName, newVal)
        },
        isMoneyPopShow(newVal) {
            if (newVal) {
                this.popData = this.moneyData
                this.curr = this.currMoeny
                this.showName = 'money'
            }
            this.hideAll()
            this.$set(this.show, this.showName, newVal)
        },
    },
    methods: {
        stopScroll() {
            return true
        },
        outbtn: function(e) {
            this.hideAll()
        },
        //选择二级类目
        selectSecondCategory(item){
            this.currSecondCategoryId = item.id
            this.currSecondCategoryName = item.categoryName
            this.$emit('changeSecondCategory', this.showName, item)

        },
        select(data) {
            this.$set(this.show, this.showName, false)
            this.curr = data
            this.isTypePopShow = false
            this.isFloorPopShow = false
            this.isCategoryPopShow = false
            this.isBuildingPopShow = false
            this.isMoneyPopShow = false
            if (this.showName == 'type') {
                this.currType = data
                this.$emit('change', this.showName, data)
            } else if (this.showName == 'building') {
                this.currBuilding = data
                this.$emit('change', this.showName, data)
            } else if (this.showName == 'floor') {
                this.currFloor = data
                this.$emit('change', this.showName, data)
            } else if (this.showName == 'category') {
                this.currCategory = data
                this.currSecondCategoryName = ''
                this.currSecondCategoryId  = ''
                this.secondCategoryArr = data.children ? data.children : []
                this.$emit('changeFirstCategory', this.showName, data)
                // this.$emit('changeSecondCategory', this.showName, {id:''})
            } else if (this.showName == 'money') {
                this.currMoeny = data
                this.$emit('change', this.showName, data)
            }
        },
        hideAll() {
            for (var key in this.show) {
                if (this.show[key]) {
                    // this.show[key] = false
                    this.$set(this.show, key, false)
                }
            }
        }
    },
}
</script>

<style lang="less" scoped>
@import url(../assets/styles/vars);

.sel-enum-container {
    position: relative;
    height: 50px;
    .brand_box {
        flex: 1;
        display: flex;
        overflow: hidden;
        width: 100%;
        height: 50px;
        border-bottom: 1px solid @border-color;
        .brand_nav {
            position: relative;
            overflow: hidden;
            flex: 1;
            height: 100%;
            color: #000;
            font-size: 12px;
            // overflow-y: auto;
            // overflow-x: hidden;
            .brand_sel {
                position: relative;
                height: 100%;
                line-height: 50px;
                background: #fff;
                text-align: center;
                font-size: 15px;
                color: @black-color;
                border-bottom: 1px solid #ddd;
                padding: 0 15px;
                &:after {
                    display: inline-block;
                    content: '';
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    right: 0;
                    height: 20px;
                    width: 1px;
                    background: #ddd;
                }
                .brand_sel_text_wrap {
                    width: 100%;
                    height: 100%;
                    display: inline-block;
                    .brand_sel_text {
                        position: relative;
                        box-sizing: border-box;
                        width: 100%;
                        height: 100%;
                        padding-right: 16px;
                        box-sizing: none;
                        display: inline-block;
                        .brand_sel_text_2 {
                            display: inline-block;
                        }
                    }
                }
                .brand_sel_arrow {
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    display: inline-block;
                    right: 6px;
                    display: inline-block;
                    width: 8px;
                    height: 5px;
                    img {
                        display: inline-block;
                        width: 100%;
                        height: 100%;
                    }
                }
            }
        }
        .brand_content {
            overflow: hidden;
            flex: 2;
            display: flex;
            flex-direction: column;
            .brand_type {
                height: 50px;
            }
            .brand_list {
                flex: 1;
                overflow-y: auto;
                z-index: 9;
                .noMore {
                    text-align: center;
                    color: #999;
                    padding-bottom: 10px;
                }
            }
        }
    }
    .brand_sel {
        position: relative;
        height: 100%;
        line-height: 50px;
        background: #fff;
        text-align: center;
        font-size: 15px;
        color: @black-color;
        border-bottom: 1px solid #ddd;
        padding: 0 15px;
        &:after {
            display: inline-block;
            content: '';
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            right: 0;
            height: 20px;
            width: 1px;
            background: #ddd;
        }
        .brand_sel_text_wrap {
            width: 100%;
            height: 100%;
            display: inline-block;
            .brand_sel_text {
                position: relative;
                box-sizing: border-box;
                width: 100%;
                height: 100%;
                padding-right: 16px;
                box-sizing: none;
                display: inline-block;
                .brand_sel_text_2 {
                    display: inline-block;
                }
            }
        }
        .brand_sel_arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            display: inline-block;
            right: 6px;
            display: inline-block;
            width: 8px;
            height: 5px;
            img {
                display: inline-block;
                width: 100%;
                height: 100%;
            }
        }
    }
    .brand_sel_enum {
        position: fixed;
        top: 50px;
        box-sizing: border-box;
        max-height: 200px;
        background: #fff;
        overflow: auto;
        z-index: 999;
        width: 100%;
        margin-top: 0px;
        box-shadow: 0 3px 8rpx rgba(0, 0, 0, 0.1);
        .slide-ul {
            position: relative;
        }
        li {
            height: 50px;
            padding: 0 15px;
            line-height: 49px;
            font-size: 15px;
            color: @gray-color;
            display: flex;
            position: relative;
            .brand_nav_li_text {
                position: relative;
                width: 100%;
                border-bottom: 1px solid @border-color;
                .brand_nav_arrow {
                    position: absolute;
                    top: 50%;
                    right: 0;
                    transform: translateY(-50%);
                    width: 24rpx;
                    height: 18rpx;
                }
            }

            &.brand_nav_active {
                color: @theme-color;
            }
            // &.brand_nav_active{
            //     .firstCategory_txt{
            //         border-left:4px solid #6CC7C7;
            //         background: #F8F8F8;
            //         p{
            //             border: none !important;
            //         }
            //     }
            // }
        }
        .category_nav{
            height: 400rpx;
            overflow: auto;
            width: 100%;
            line-height: 49px;
            font-size: 15px;
            color: @gray-color;
            display: flex;
            .outerBox1 {
                // max-height: 400rpx;
                height: 400rpx;
                overflow: auto;
                width: 142px;
                background:#fff;
            }
            .outerBox2 {
                // max-height: 400rpx;
                height: 400rpx;
                overflow: auto;
                flex:1;
                background: #F8F8F8;
                padding-left:15px;
            }
            .firstCategory{
                 height: 1000rpx;
                .firstCategory_txt{
                    padding-left:12px;
                    p{
                        border-bottom:1px solid #EFEFEF;
                        font-size:15px;
                        span{
                            float:right;
                            margin-right: 16px;
                            font-size: 13px;
                            color:#999999;
                        }
                    }
                    &.firstCategory_txt_active{
                        color: @theme-color;
                        border-left:4px solid #9975F3;
                        background: #F8F8F8;
                        p{
                            border: none !important;
                        }
                    }
                   
                }
                
            }
            .secondCategory{
                height: 1000rpx;
                p{
                    font-size:15px;
                    color:#666666;
                    height: 50px;
                }
                .secondCategory_txt_active{
                    position: relative;
                    .brand_nav_arrow{
                        position: absolute;
                        top: 50%;
                        right: 20px;
                        transform: translateY(-50%);
                        width: 24rpx;
                        height: 18rpx;
                    }
                }
            }
        }
    }
    .filter-title-text-wrap {
        overflow: hidden;
        font-size: 15px;
        color: #333;
        line-height: 50px;
        text-align: center;
        position: relative;
        display: flex;
        padding: 0 15px;
        justify-content: center;
        align-items: center;
        & > div {
            position: relative;
            display: inline-block;
            padding-right: 23px;
            height: 100%;
            overflow: hidden;
        }
        .filter-title-text {
            box-sizing: border-box;
            display: inline-block;
            width: 100%;
        }
        .filter-title-img {
            position: absolute;
            top: 50%;
            display: inline-block;
            right: 6px;
            transform: translateY(-50%);
            img {
                width: 8px;
                height: 5px;
            }
        }
    }
    .loginPage {
        position: absolute;
        top: 0;
        width: 100%;
        height: 100%;
    }
    .list-fix{
        top:63px;
        background: rgba(0,0,0,0.4);
        z-index: 998;
        position: fixed;
    }
}
</style>
