<template>
    <div v-show="isShow"
         class="search-comp-container">
        <div class="flex-wrp search-btn">
            <span class="flex-item search-input-wrap">
                <img class="icon-search"
                     src="/static/images/icon-common-search@2x.png">
                <input v-model="val"
                       :focus="focus"
                       class="search-input"
                       type="text"
                       @confirm="confirm($event)">
                <span class="btn-clear"
                      @tap="clear()">
                    <img v-show="val"
                         src="/static/images/icon-common-clear@2x.png">
                </span>

            </span>
            <!-- <div class="flex-item btn-cancel-wrp">
                <div class="btn-cancel" @tap="cancel">
                    取消
                </div>
            </div> -->
        </div>
    </div>
</template>

<script>
export default {
    props: {
        isShow: {
            type: Boolean,
            default: true
        }
    },
    data() {
        return {
            val: '',
            focus: true
        }
    },
    watch: {
        isShow(val) {
            this.focus = val
        }
    },
    methods: {
        // 清除输入框
        clear() {
            this.val = ''
            this.focus = false
            this.$emit('cancel', { clear: true })
        },
        // cancel(){
        //     this.val = '';
        //     this.$emit("cancel")
        // },
        confirm(event) {
            this.focus = false
            setTimeout(() => {
                this.$emit('confirm', event.target.value)
                this.val = ''
                this.focus = true
            }, 100)
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.search-comp-container {
    z-index: 9;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: #fff;
    .search-input-wrap {
        position: relative;
        background-color: #fff;
        .search-input {
            text-align: left;
            // padding: 0 28px;
            padding-left: 15px;
            width: 80%;
            // border-right: 1px solid #000000;
        }
        .icon-search {
            left: 33px !important;
            transform: translateY(-50%);
            // margin-left: initial;
        }
        .btn-clear {
            display: block;
            z-index: 10;
            width: 30px;
            height: 16px;
            padding: 9.5px;
            position: absolute;
            top: 50%;
            right: 0px !important;
            // transform: translateY(-50%);
            font-size: 15px;
            img {
                width: 16px;
                height: 16px;
            }
        }
    }
    // .btn-cancel-wrp{
    //     flex: 0 1 auto;
    //     .btn-cancel{
    //         margin-left: 10px;
    //         height: 34px;
    //         line-height: 34px;
    //         font-size: 15px;
    //         color: @theme-color;
    //         &:active{
    //             opacity: .8;
    //         }
    //     }
    // }
}
</style>
