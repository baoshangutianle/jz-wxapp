<template>
    <div class="article-comp-container">
        <div
            v-for="(item,index) in data"
            :data-index="index"
            :key="index"
            class="article-comp-div"
        >
            <div class="item-list" v-if="item.contentStatus == 2 || item.contentStatus == 4">
                <slide-view :buttons="slideButtons" @buttontap="deleteArticle(item)">
                    <div
                    class="article-comp-con"
                    @tap="goArticleDetail(item)"
                >
                        <img
                            :src="item.pictureUrl"
                            class="activies-img"
                        >
                        <div class="actives-desc">
                            <p class="actives-title">{{ item.ownerType == '2'?item.mainBody: item.title }}</p>
                            <div class="actives-bottom-con">
                                <div class="actives-bottom">
                                    <span class="actives-name">{{ item.author }}</span>
                                    <div class="actives-read">
                                        <span class="actives-read-icon">
                                            <image src="/static/images/eye_show.png" />
                                        </span>
                                        <span class="actives-read-val">{{ item.clickNumber }}</span>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </slide-view>
            </div>
        </div>
         <!-- 过期文章 -->
        <div class="expired-title" v-if="isExpiredArticle">
            <span class="expired-span">失效文章</span>
        </div>
        <div
            v-for="(item,index) in data"
            :key="index"
        >
            <div class="item-list" v-if="item.contentStatus != 2 && item.contentStatus != 4">
                <slide-view :buttons="slideButtons" @buttontap="deleteArticle(item)">
                    <div
                    class="article-comp-con article-expired"
                >
                    <img
                        :src="item.pictureUrl"
                        class="activies-img"
                    >
                    <div class="actives-desc">
                        <p class="actives-title">{{ item.ownerType == '2'?item.mainBody: item.title }}</p>
                        <div class="actives-bottom-con">
                            <div class="actives-bottom">
                                <span class="actives-name">{{ item.author }}</span>
                                <div class="actives-read">
                                    <span class="actives-read-icon">
                                        <image src="/static/images/eye_show.png" />
                                    </span>
                                    <span class="actives-read-val">{{ item.clickNumber }}</span>
                                </div>
                            </div>
                        </div>

                    </div>
                    </div>
                </slide-view>
            </div>
        </div>
    </div>
</template>

<script>
import wxUtils from '../plugins/wxUtils';
import api from '@/plugins/api'
import request from '@/plugins/request'
export default {
    props: {
        data: {
            type: Object,
            // eslint-disable-next-line vue/require-valid-default-prop
            default: {}
        },
        isExpiredArticle:{
            type: String,
            default: ""
        }
    },
    data() {
        return {
            deleteFoods: [],
            slideButtons: [{
                type: 'warn',
                text: '删除',
                extClass: 'test',
                src: '', // icon的路径
            }]
        }
    },
    methods: {
        goArticleDetail(item) {
            let { putPosition } = item
            let url
            if (putPosition == 2) {//热门活动
                url = `/listOfActivities/details?id=${item.id}`
            } else if (putPosition == 1) {//潮逛指南
                url = `/pages/guide/details?id=${item.id}&type=${item.putType}`
            }
            wx.navigateTo({
                url
            })
        },
        deleteArticle(item) {
            let params = {
                "contentId": item.id,
                "contentType": 2,//1为美食，2位其他
                "userCode": wxUtils.getUserCodeStorage()
            }
            let requestOptions = {
                path: api.doCollect,
                method: 'post',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    wx.showToast({
                        icon: 'success',
                        title: '已删除'
                    })
                    setTimeout(() => {
                        this.$parent.getArticle(1)
                    }, 2 * 1000)
                }
            })
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.article-comp-container {
    .article-comp-main {
        position: relative;
        background: #ffffff;
        z-index: 999;
    }
    .article-comp-div{
        position: relative;
    }
    .item-list{
        padding-bottom: 20px;
    }
    .expired-title{
            display: flex;
            justify-content: space-between;
            margin: 10px 15px;
            margin-bottom: 10px;
        }
        .expired-icon{
            width: 16px;
            height: 16px;
            display: inline-block;
            vertical-align: middle;
            img{
                width: 16px;
                height: 16px;
            }
        }
        .expired-span{
            color: #9975F3;
            font-size: 12px;
            padding-left: 5px;
            padding-top: 5px;
        }
        .expired-btn{
            background: #ffffff;
            border: solid 1px#9975F3;
            color: #9975F3;
            padding: 2px 15px;
            text-align: center;
            display: inline-block;
            border-radius: 12px;
            font-size: 15px;
            line-height: normal;
            margin-right: 0px;
            letter-spacing: 4px
        }
    .article-comp-con {
        display: flex;
        // border-bottom: solid 1px rgba(239,241,248,1);
        font-size: 0;
        background: #ffffff;
        padding-left: 15px;
        padding-right: 15px;

        .activies-img {
            width: 124px;
            height: 70px;
            border-radius: 4px;
            margin-right: 20px;
        }
        .actives-desc {
            flex: 1;
            width: 205px;
            position: relative;
            .actives-title {
                width: 100%;
                font-size: 15px;
                color: rgba(51, 51, 51, 1);
                // line-height: 1;
                overflow: hidden;
                display: -webkit-box;
                // -webkit-box-pack: center;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
            }
            .actives-sub-title {
                font-size: 12px;
                color: #999;
            }
            .actives-bottom-con{
                position: absolute;
                bottom: 0px;
                width: 100%;
            }
            .actives-bottom {
                margin-top: 10px;
                display: flex;
                align-items: center;
                margin-right: 5px;
                .actives-name {
                    flex: 1;
                    font-size: 12px;
                    color: #999;
                }
                .actives-read {
                    .actives-read-icon {
                        display: inline-block;
                        image {
                            width: 16px;
                            height: 10px;
                        }
                    }
                    .actives-read-val {
                        font-size: 12px;
                        color: #999;
                        margin-left: 10px;
                    }
                }
            }
        }
    }
    .expired-article {
        overflow: hidden;
        .expired-title {
            display: flex;
            justify-content: space-between;
            padding: 10px 10px 0;
        }
        .expired-icon {
            width: 16px;
            height: 16px;
            display: inline-block;
            vertical-align: middle;
            img {
                width: 16px;
                height: 16px;
            }
        }
        .expired-span {
            color: #ff4747;
            font-size: 12px;
            padding-left: 5px;
        }
        .expired-btn {
            background: #9975F3;
            color: #ffffff;
            padding: 4px 8px;
            text-align: center;
            display: inline-block;
            border-radius: 12px;
            font-size: 12px;
            line-height: normal;
            margin-right: 0px;
        }
        .actives-title,
        .actives-name,
        .actives-read,
        .actives-read-val {
            color: #cecece !important;
        }
        .activies-img {
            opacity: 0.4 !important;
        }
    }
    .del{
        width: 180rpx;
        text-align: center;
        z-index: 4;
        right: 0;
        color: #fff;
        background:#b4282d;
        height: 75px;
        top: 2px;
        line-height: 95px;
        position: absolute;
    }
    .article-expired{
        .activies-img{
            opacity: 0.6;
        }
        .actives-title,.actives-name,.actives-read,.actives-read-val{
            color: #cecece !important;
        }
    }
}

</style>
