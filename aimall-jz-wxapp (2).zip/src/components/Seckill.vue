<template>
    <div class="seckillList">
        <div  class="goodsList">
            <div class="goods" v-for="(item,idx) in data" :key="idx">
                <img  class="img" :src="item.thumbnail">
                <div class="originPrice">￥{{item.seckillPrice}}</div>
                <span class="salePrice">￥{{item.goodsPrice}}</span>
                <div class="line"></div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props:{
        data:{
            type: Array,
            default: [],
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.seckillList {
    .goodsList {
        display: flex;
        // justify-content: space-around;
        align-items: center;
        .goods {
            position: relative;
            padding: 10px 20px;
            text-align: center;
            flex: 1;
            &::after {
                content: '';
                width: 1px;
                height: 88%;
                background-color: #F2F2F2;
                position: absolute;
                bottom: 10px;
                right: 0;
            }
            &:last-child::after {
                background: none;
            }
            .img {
                margin: 0 auto;
                width: 76px;
                height: 72px;
            }
            .originPrice {
                margin: 8px 0 0 0;
                font-size: 15px;
                color: #EA5205;
            }
            .salePrice {
                font-size: 11px;
                color: #999999;
                text-decoration: line-through;
            }
        }
    }
}
</style>
