<!--
 * @Author: your name
 * @Date: 2020-03-02 10:46:40
 * @LastEditors: your name
 * @LastEditTime: 2020-03-02 18:49:59
 * @Description: file content
 -->
<template>
   <div class="process">
      <p class='pintuan_text'>支持拼团购买 <span>({{options}}人成团)</span></p>
 <div class='pintuan_content'>

  <ul class='pintuan'>
    <li class="parentLi">
      <div class='pintuan_open'>
        <van-image src='https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200312/9b9c94e9dea243559d29faa8d41aba29.png' class='pintuan_img'/>
        <p>开团/参团</p>
      </div>
    <div class='pin_t'>
      <van-image src='https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200312/4801975ec2684303b05e521528a2d473.png' class='pintuan_tou'/>
    </div>
    </li>
    <li class="parentLi">
      <div class='pintuan_open'>
        <van-image src='https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200312/01935474c40f4f3e8b68011f5b8a48b8.png' class='pintuan_img'/>
        <p>邀请好友</p>
      </div>
      <div class='pin_t'>
        <van-image src='https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200312/4801975ec2684303b05e521528a2d473.png' class='pintuan_tou'/>
      </div>
    </li>
    
    <li>
      <div class='pintuan_open'>
        <van-image src='https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200312/d143f6702d28497b9d2d4bd7b14afdff.png' class='pintuan_img'/>
        <p>满员发货</p>
        <span class='pin_back'>（不满自动退款）</span>
      </div>
    </li>
  </ul>
      </div>
   </div>
</template>

<script>

/**
  * @author: jxy
  * @since: 2020-03-02
  * @router('/process')
  */
export default {
  name:'Process',
  components : {},
  props : {
    options:{
      type:Number,
      default: 0
    }
  },
  data () {
    return {
    }
  },
  computed : {},
  methods : {},
  mounted () {}
}
</script>

<style lang="less">
.process{
  background-color: #fff;
  padding:10px;
    .pintuan_text{
      font-size:15px;
      font-family:PingFangSC-Medium,PingFang SC;
      font-weight:500;
      color:rgba(51,51,51,1);
      line-height:21px;
    span{
      font-size:12px;
      color:rgba(153,153,153,1);
      
    }
    }
  
  .pintuan_content{
    text-align: center;
    .pintuan{
        height:120px;
      li{
        float:left;
        width: 33.33%;
        // &:first-child {
        //   margin-left: 0;
        // }
        // &:last-child {
        //   margin-right: 0;
        // }
        // margin-right:10px;
        // margin-left:10px;
        .pintuan_open{
          // text-align: center;
          margin-top:16px;
          .pintuan_img{
            width:50px;
            height:50px;
          }

        }
        .pintuan_tou{
            width:10px;
            height:10px;
          }
      }
      .parentLi {
        position: relative;
      }
      .pin_t{
          // margin-top: 33px;
          position: absolute;
          left: 100%;
          top:30px;
        }
    }
    .pin_back{
      font-size:12px;
      font-family:PingFangSC-Light,PingFang SC;
      font-weight:300;
      color:rgba(153,153,153,1);
      line-height:17px;
    }

  }
  
}

</style>