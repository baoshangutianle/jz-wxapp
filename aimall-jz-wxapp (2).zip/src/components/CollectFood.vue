<template>
    <div class="food-comp-container">
        <div class="item-box" v-for="(data,index) in data" :key="index" :data-index="index">
            <div class="item-list" v-if="!data.isDelete">
                <slide-view :buttons="slideButtons" @buttontap="delCollect(data)">
                    <div class="items" @click="goFoodDetail(data)">
                        <div class="item-con">
                                <div class="item-img">
                                    <img class="restaurant-img"
                                    mode="scaleToFill"
                                    :src="data.showIcon">
                                </div>
                                <div class="item-foods">
                                    <p>
                                        <span class="restaurant-name">{{data.storeName}}</span>
                                    </p>
                                    <p class="restaurant-add">
                                        <span class="restaurant-address">{{data.floorNo}}</span>
                                    </p>
                                    <p class="flex-wrp restaurant-type-address">
                                        <span class="restaurant-type">{{data.categoryName}}</span>
                                    </p>
                                </div>
                            </div>
                    </div>
                </slide-view>
            </div>
        </div>
        <!-- 过期店铺 -->
        <div class="expired-title" v-if="isExpired">
            <span class="expired-span">失效店铺</span>
        </div>
        <div class="item-box expired-comp" v-for="(data,index) in data" :key="index" :data-index="index">
            <div class="item-list"  v-if="data.isDelete">
                <slide-view :buttons="slideButtons" @buttontap="delCollect(data)">
                    <div class="items">
                        <div class="item-con">
                                <div class="item-img">
                                    <img class="restaurant-img"
                                    mode="scaleToFill"
                                    :src="data.showIcon">
                                </div>
                                <div class="item-foods">
                                    <p>
                                        <span class="restaurant-name">{{data.storeName}}</span>
                                    </p>
                                    <p class="restaurant-add">
                                        <span class="restaurant-address">{{data.floorNo}}</span>
                                    </p>
                                    <p class="flex-wrp restaurant-type-address">
                                        <span class="restaurant-type">{{data.categoryName}}</span>
                                    </p>
                                </div>
                            </div>
                    </div>
                </slide-view>
            </div>
        </div>

    </div>
</template>

<script>
import wxUtils from '../plugins/wxUtils';
import api from '@/plugins/api'
import request from '@/plugins/request'
import GradeStar from '@/components/GradeStar'
import { deflate } from 'zlib';
export default {
    components:{
        GradeStar
    },
    props:{
        data:{
            type: Object,
            default: {}
        },
        isExpired:{
            type: String,
            default: ""
        }
    },
    data(){
        return{
            deleteFoods: [],
            slideButtons: [{
                type: 'warn',
                text: '删除',
                extClass: 'test',
                src: '', // icon的路径
            }]
        }
    },
    onLoad(){
    },
    computed: {
    },
    methods:{
        //清空
        emptyCollect(data){
            let list = []
            list = data.filter( item => item.isDelete)
            this.deleteFoods = list.map( item => {
                if(item.isDelete){
                    return item.id
                }
            })
            this.status = !this.status
            let params = {
                "contentId": this.deleteFoods,
                "contentType": this.contentType,
                "userCode": wxUtils.getUserCodeStorage()
            }
            let requestOptions = {
                path: api.doCollect,
                method: 'post',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                var msg = '已清空'
                wx.showToast({
                    icon: 'success',
                    title: msg
                })
            })
        },
        async delCollect(item) {
            var _this = this;
            let params = {
                "contentId": item.id,
                "contentType": 1,
                "userCode": wxUtils.getUserCodeStorage()
            }
            let requestOptions = {
                path: api.doCollect,
                method: 'post',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res=>{
                wx.showToast({
                    icon: 'success',
                    title: '已删除'
                })
                setTimeout(()=>{
                    this.$parent.page.pageNo = 1
                    this.$parent.isDeleteFood = true
                    this.$parent.isExpired = false
                    this.$parent.getFood(1)
                },2*1000)
            })
        },
        goFoodDetail(data){
            let type;
            if(data.isFood){
                type = 1
            }else {
                type = 2
            }

            wx.navigateTo({
                url: `/pages/restaurant/detail?id=${data.id}&type=${type}`
            })
        },
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.food-comp-container{

    .expired-title{
            display: flex;
            justify-content: space-between;
            margin: 10px 15px;
            margin-bottom: 10px;
        }
        .expired-icon{
            width: 16px;
            height: 16px;
            display: inline-block;
            vertical-align: middle;
            img{
                width: 16px;
                height: 16px;
            }
        }
        .expired-span{
            color: #9975F3;
            font-size: 12px;
            padding-left: 5px;
            padding-top: 5px;
        }
        .expired-btn{
            background: #ffffff;
            border: solid 1px#9975F3;
            color: #9975F3;
            padding: 2px 15px;
            text-align: center;
            display: inline-block;
            border-radius: 12px;
            font-size: 15px;
            line-height: normal;
            margin-right: 0px;
            letter-spacing: 4px
        }

     .restaurant-address{
         color: #333333;
         font-weight: 200;
         font-size: 13px;
         padding-top: 7px;
         display: inline-block;
     }

.item-box{
    margin: 0 auto;
   // padding:40rpx 0;
}
.item-list{
    height: 125px;
}
.items{
    width: 100%;
}
.item{
    position: relative;
    overflow: hidden;

}
.inner{
    position: absolute;
    top:0;
    background: #ffffff;
}
.item-con{
    box-shadow: 0 0 5px 0 rgba(188, 188, 188, 0.3);
    border-radius: 4px;
    margin:0px 20px;
    padding: 14px;
    margin-top: 2px;
}
.item-img{
    float: left;
    width: 68px;
    height: 68px;
    border: 1px solid #e7e7e7;
    margin-right: 14px;
    img{
        width: 68px;
        height: 68px;
    }
 }
 .item-foods{
     display: inline-block;
     width: 72%;
      .restaurant-name{
        font-size: 15px;
        color: #1E1E1E;
        font-weight: bold;
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
        width: 100%;
        display: inline-block;
    }
    .restaurant-address{
        color: #333333;
        font-weight: 200;
        font-size: 13px;
        padding-top: 7px;
        display: inline-block;
    }
    .restaurant-type-address{
        justify-content: space-between;
        font-size: 13px;
        color: #929292;
        flex:1;
        span{
            display: inline-block;
            margin-top: 5px;
        }
    }
 }
  .expired-comp{
        overflow: hidden;
        .restaurant-name,.restaurant-type,.restaurant-price{
            color: #CECECE !important;
        }
        .restaurant-tags li span{
            border:solid 1px #CECECE !important;
            color: #CECECE !important;
        }
        .restaurant-img{
            opacity: 0.4 !important;
        }
        .restaurant-address{
            color: #CECECE !important;
        }
     }


}
</style>
