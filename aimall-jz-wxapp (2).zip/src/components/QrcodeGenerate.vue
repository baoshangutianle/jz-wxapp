<template>
    <div class="qrcode-comp-conatiner">
        <view class="container-box">
            <view class="img-box">
                <image bindtap="previewImg" mode="scaleToFill" :src="imagePath"></image>
            </view>
            <form @submit="formSubmit">
                <view class="input-row">
                    <label>网址</label>
                    <input name='url' value='' type="text" maxlength="255" :placeholder="placeholder"/>
                </view>
                <!--<view class="input-row">
                    <label>金额</label>
                    <input name="money" type="number" maxlength="7"  placeholder="1000000"/>
                </view>-->
                <button formType="submit" class="mybtn" type="primary">生成二维码</button>
            </form>
        </view>
        <view v-show="!maskHidden" class="mask"></view>
        <view v-show="!canvasHidden" class="canvas-box">
        <canvas  style="width: 686rpx;height: 686rpx;background:#f1f1f1;" canvas-id="mycanvas"/>
        </view>

    </div>
</template>

<script>
import QR from '@/plugins/qrcode.js'
export default {
    data(){
        return {
            canvasHidden:false,
            maskHidden:true,
            imagePath:'',
            placeholder:'http://wxapp-union.com'//默认二维码生成文本
        }
    },
    methods:{
        //适配不同屏幕大小的canvas
        setCanvasSize:function(){
            var size={};
            try {
                var res = wx.getSystemInfoSync();
                var scale = 750/686;//不同屏幕下canvas的适配比例；设计稿是750宽
                var width = res.windowWidth/scale;
                var height = width;//canvas画布为正方形
                size.w = width;
                size.h = height;
            } catch (e) {
                // Do something when catch error
            }
            return size;
        } ,
        createQrCode:function(url,canvasId,cavW,cavH){
            //调用插件中的draw方法，绘制二维码图片
            QR.api.draw(url,canvasId,cavW,cavH);
            setTimeout(() => { this.canvasToTempImage();},1000);

        },
        //获取临时缓存照片路径，存入data中
        canvasToTempImage:function(){
            var that = this;
            wx.canvasToTempFilePath({
            canvasId: 'mycanvas',
            success: function (res) {
                var tempFilePath = res.tempFilePath;
                console.log(tempFilePath);
                that.imagePath = tempFilePath
            },
            fail: function (res) {
                console.log(res);
            }
            });
        },
        //点击图片进行预览，长按保存分享图片
        previewImg:function(e){
            var img = this.data.imagePath;
            console.log(img);
            wx.previewImage({
            current: img, // 当前显示图片的http链接
            urls: [img] // 需要预览的图片http链接列表
            })
        },
        formSubmit: function(e) {
            var that = this;
            var url = e.mp.detail.value.url;
            that.maskHidden = false;
            wx.showToast({
            title: '生成中...',
            icon: 'loading',
            duration:2000
            });
            var st = setTimeout(function(){
            wx.hideToast()
            var size = that.setCanvasSize();
            //绘制二维码
            that.createQrCode(url,"mycanvas",size.w,size.h);
            that.maskHidden = true
            clearTimeout(st);
            },2000)

        }
    },
    onLoad:function(options){
        // 页面初始化 options为页面跳转所带来的参数
        var size = this.setCanvasSize();//动态设置画布大小
        var initUrl = this.placeholder;
        this.createQrCode(initUrl, "mycanvas", size.w, size.h);


    },
    onReady:function(){

    },
    onShow:function(){

        // 页面显示
    },
    onHide:function(){
        // 页面隐藏
    },

    onUnload:function(){
        // 页面关闭

    },
}
</script>

<style lang="less" scoped>
.qrcode-comp-conatiner{
    /* pages/main/index.wxss */
.container-box{background-color: #efeff4;height: 100vh}
.img-box{padding: 32rpx;background-color: #fff;border-bottom: 1rpx solid #e5e5e5;position: relative}
.img-box image{width: 686rpx;height: 686rpx;background-color: #f9f9f9}
.input-row{
    margin: 30rpx auto;
    border-bottom: 1rpx solid #e5e5e5;
    border-top: 1rpx solid #e5e5e5;
    display: flex;
    align-items: center;
    height: 88rpx;
    padding: 0 32rpx;
    background-color: #fff;
    font-size: 34rpx;
    color: #000
}

.input-row input{margin-left: 100rpx;flex: 1}
.mybtn{width:686rpx;margin: 60rpx auto }
.mask{position: fixed;top: 0;left: 0;z-index: 3; width: 100%;height: 100%;opacity: 0;}
.canvas-box{position: fixed;top:999999rpx;left: 0}

}
</style>
