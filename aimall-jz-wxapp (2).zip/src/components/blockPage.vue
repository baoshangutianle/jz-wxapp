<template>
    <div class="blockPage">
        <img
            class="blockPage_img"
            :src="imgUrl"
        >
        <span class="blockPage_text">
            {{ text }}
        </span>
    </div>
</template>
<script>
export default {
    props: {
        type: {
            type: String,
            default: ''
        }
    },
    data() {
        return {
            text: '',
            imgUrl:'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/e7e5895097554a059bd358b642a6fa3d.png'
        }
    },
    watch: {
        type() {
            this.resetType()
        }
    },
    methods: {
        resetType() {
            if (this.type == '店铺') {
                this.text = '您还没有收藏店铺哦~'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/dc6693da3d944903b36f432f0cdb28ee.png'
            } else if (this.type == '文章') {
                this.text = '您还没有收藏文章哦~'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/dc6693da3d944903b36f432f0cdb28ee.png'
            } else if (this.type == '积分') {
                this.text = '您还没有积分流水哦~'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/dc6693da3d944903b36f432f0cdb28ee.png'
            } else if (this.type == '卡券') {
                this.text = '您还没有券哦~'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/6d980413f7ab4d8eb374450fc6cb35d0.png'
            } else if (this.type == '已使用卡券') {
                this.text = '您还没有已使用券哦~'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/6d980413f7ab4d8eb374450fc6cb35d0.png'
            } else if (this.type == '已过期卡券') {
                this.text = '您还没有已过期券哦~'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/6d980413f7ab4d8eb374450fc6cb35d0.png'
            } else if (this.type == '小票') {
                this.text = '您还未上传小票哦~'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/dc6693da3d944903b36f432f0cdb28ee.png'
            } else if (this.type == '热门活动'){
                this.text = '暂无热门活动信息'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/dc6693da3d944903b36f432f0cdb28ee.png'
            } else if (this.type == '我的活动'){
                this.text = '暂无该活动信息'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/dc6693da3d944903b36f432f0cdb28ee.png'
            } else if(this.type == '兑换记录'){
                this.text = '您还没有兑换过商品哦～'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/dc6693da3d944903b36f432f0cdb28ee.png'
            } else if (this.type == '签到'){
                this.text = '您还没有签到记录哦～'
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/dc6693da3d944903b36f432f0cdb28ee.png'
            }else if(this.type=='暂无订单'){
                this.imgUrl = 'https://img-cdn.aimall.cloud/as/20200601/42567518e7d343b2bf8f390bbc05fc8c.png'
            }
        }
    },
    onLoad() {
        this.resetType()
    }
}
</script>
<style scoped>
.blockPage {
    width: 100%;
    height: 100%;
    margin: 0px;
    padding: 0px;
    text-align: center;
}
.blockPage_img {
    width: 245px;
    height: 171px;
    display: inline-block;
    text-align: center;
    padding: 105px 0;
    padding-bottom: 20px;
}
.blockPage_text {
    text-align: center;
    display: inline-block;
    font-size: 18px;
    color: #999;
    width: 100%;
}
</style>
