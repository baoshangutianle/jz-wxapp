<template name="paybulletCoverView">
    <div class="auth-btn-container">
        <user-auth
            v-if="auth!='phone'&&!wxUserInfo"
            @afterBind="afterBindUserAuth"
        />
        <phone-auth
            v-if="auth!='user'&&!vipInfo"
            @afterBind="afterBindPhoneAuth"
        />
        <div
            v-else
            class="area-click"
            @click="jump"
        />
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import request from '@/plugins/request'
import api from '@/plugins/api'
import wxUtils from '@/plugins/wxUtils'
import utils from '@/plugins/utils'
import UserAuth from './UserAuth'
import PhoneAuth from './PhoneAuth'

export default {
    components: {
        UserAuth,
        PhoneAuth
    },
    props: {
        auth: {
            type: String,
            default: ''//user、phone
        },
        url: {
            type: String,
            default: ''
        },
        isExpiredHide: {//过期回调提示隐藏
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
        }
    },
    computed: {
        ...mapState(['wxUserInfo', 'isVip', 'vipInfo'])
    },

    methods: {
        ...mapMutations(["update"]),
        afterBindUserAuth(data) {
            let vm = this
            vm.update({ wxUserInfo: data })
            wxUtils.getUserSession(function() {
                vm.saveUserInfo()
                //获取激活状态
                wxUtils.getActiveStatus(async function(flag, data1) {
                    let { sessionId } = data1
                    if (flag) {//账户已激活
                        await vm.update({
                            isLogined: false,
                            sessionId: sessionId
                        });
                        // utils.getVipInfo().then(data => {
                        //     vm.update({
                        //         vipInfo: data
                        //     });
                        //     if (vm.url) {
                        //         wx.navigateTo({
                        //             url: vm.url
                        //         })
                        //     }
                        //     vm.$emit("pass")
                        // })
                        if (vm.url) {
                            wx.navigateTo({
                                url: vm.url
                            })
                        }
                        vm.$emit("pass")
                    } else {
                        if(vm.auth == 'user'){
                            vm.$emit("pass")
                        }
                    }
                })
            })
        },
        afterBindPhoneAuth(data) {
            let vm = this
            wx.getSetting({
                success(res) {
                    //有授权信息
                    // if (res.authSetting['scope.userInfo']) {
                        wxUtils.getUserSession(function() {
                            wx.getUserInfo({
                                success: function(res) {
                                    var userInfo = res
                                    let appid = wxUtils.getAppId()
                                    let sessionKey = wxUtils.getSessionKeyStorage()
                                    let { signature, rawData } = userInfo
                                    let { encryptedData, iv } = data
                                    let params = {
                                        // appid,
                                        openId: wxUtils.getOpenIdStorage(),
                                        sessionKey,
                                        signature,
                                        rawData,
                                        encryptedData,
                                        iv
                                    }
                                    vm.doLoginAuthAction(params)
                                }
                            })
                        })
                    // } else {
                    //     //用户信息过期回调
                    //     if(vm.isExpiredHide){
                    //         vm.$emit("expired")

                    //         return
                    //     }
                    //     wx.showModal({
                    //         title: "温馨提示",
                    //         content: "用户信息已失效，请点击头像重新登录",
                    //         success(res) {
                    //             if (res.confirm) {
                    //                 wxUtils.clearLoginStorage()
                    //                 vm.update({
                    //                     wxUserInfo: null,
                    //                     isLogined: false
                    //                 })
                    //                 setTimeout(() => {
                    //                     wx.switchTab({
                    //                         url: "/pages/mine/index"
                    //                     })
                    //                 }, 2 * 1000)
                    //             }
                    //         }
                    //     })
                    // }
                }
            })
        },
        //获取手机号
        getPhone(params){
            let vm = this
            return new Promise(resolve=>{
                let requestOptions = {
                    path: api.getPhone,
                    method: 'get',
                    data: params
                }
                request(requestOptions)
                    .then(res => {
                        if(res.code == 130007){
                            wx.showToast({
                                icon: 'none',
                                title:"Session失效，重新获取手机号"
                            })
                        //     wxUtils.getUserSession(function(){
                        //         vm.getPhone(params)
                        //     })
                        }else{
                            let phone = res.data.phoneNumber
                            resolve(phone)
                        }
                    })
            })
        },
        //登录操作
        doLoginAuthAction(params) {
            let vm = this
            vm.getPhone(params).then(phone=>{
                wxUtils.setPhoneStorage(phone)
                wxUtils.loginByAuth(phone, async function(data1) {
                    let { sessionId, userCode,newFlag } = data1
                    wxUtils.setUserCodeStorage(userCode)
                    await vm.update({
                        isLogined: true,
                        sessionId: sessionId
                    });
                    if(newFlag){
                        wxUtils.registerIntergral().then(()=>{
                            utils.getVipInfo().then(vipInfo => {
                                vm.update({
                                    vipInfo: vipInfo
                                });
                                if (vm.url) {
                                    wx.navigateTo({
                                        url: vm.url
                                    })
                                }
                                vm.$emit("pass")
                            })
                        })
                    }else{
                        utils.getVipInfo().then(vipInfo => {
                            vm.update({
                                vipInfo: vipInfo
                            });
                            if (vm.url) {
                                wx.navigateTo({
                                    url: vm.url
                                })
                            }
                            vm.$emit("pass")
                        })
                    }
                })
            })
        },
        saveUserInfo(cb) {
            let appid = wxUtils.getAppId()
            let sessionKey = wxUtils.getSessionKeyStorage()
            let wxUser = wxUtils.getUserStorage()
            let { signature, rawData, encryptedData, iv } = wxUser
            let params = {
                // appid,
                openId: wxUtils.getOpenIdStorage(),
                sessionKey,
                signature,
                rawData,
                encryptedData,
                iv
            }
            let requestOptions = {
                path: api.saveUserInfo,
                method: 'get',
                data: params
            }
            request(requestOptions).then(res => {
                cb && cb.call(null)
            })
        },
        jump() {
            let vm = this
            if (vm.url) {
                wx.navigateTo({
                    url: vm.url
                })
            } else {
                vm.$emit("pass")
            }
        }
    }
}
</script>


<style lang="less" scoped>
@import '../assets/styles/vars';
@import '../assets/styles/common';
.auth-btn-container {
    z-index: 3;
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    .area-click {
        width: 100%;
        height: 100%;
    }
}
</style>
