<template>
    <div class="article-comp-container">
        <div class="tap-active article-comp-con">
            <img
                class="activies-img"
                :src="data.pictureUrl"
            >
            <div class="actives-desc">
                <p v-if="data.ownerType == '1'" class="actives-title">{{data.title}}</p>
                <p v-else class="actives-title">{{data.mainBody}}</p>
                <!-- <p class="actives-sub-title">{{data.subtitle}}</p> -->
                <div class="actives-bottom">
                    <span class="actives-name">{{data.author}}</span>
                    <div class="actives-read">
                        <span class="actives-read-icon">
                            <image src="/static/images/icon-home-eye.png"></image>
                            <!-- <image src="../../static/images/eye_hide.png"></image> -->
                        </span>
                        <span class="actives-read-val">{{data.clickNumber }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props:{
        data:{
            type: Object,
            default: {},
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.article-comp-container{
    .article-comp-con{
        display: flex;
        .activies-img{
            width: 124px;
            height: 80px;
            border-radius: 4px;
            margin-right: 20px;
        }
        .actives-desc{
            flex:1;
            width: 205px;
            .actives-title{
                width: 100%;
                height: 42px;
                font-size:15px;
                color:rgba(51,51,51,1);
                line-height: 22px;
                overflow:hidden;//一定要写
                text-overflow: ellipsis;//超出省略号
                display:-webkit-box;//一定要写
                -webkit-line-clamp: 2;//控制行数
                -webkit-box-orient: vertical;//一定要写
                // -webkit-box-pack: center;

            }
            .actives-sub-title{
                font-size: 12px;
                color: #999;
            }
            .actives-bottom{
                margin-top: 19.5px;
                display: flex;
                align-items: center;
                margin-right: 5px;
                .actives-name{
                    flex: 1;
                    font-size:12px;
                    color: #999;
                }
                .actives-read{
                    margin-right: 5px;
                    .actives-read-icon{
                        display: inline-block;
                        image{
                            width: 16px;
                            height: 10px;
                        }
                    }
                    .actives-read-val{
                        font-size:12px;
                        color: #999;
                        margin-left: 8px;
                    }
                }

            }
        }
    }
}
</style>
