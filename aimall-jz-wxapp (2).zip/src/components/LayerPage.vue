<template>
    <div
        v-if="isShow"
        class="layer"
        catchtouchmove="preventTouchMove"
    >
        <div class="layer-con">
            <img
                :src="layerImg.pictureUrl"
                mode="aspectFit"
                @tap="toJumpUrl(layerImg)"
            >

            <div
                class="colse_layer"
                @click="closeImg"
            >
                <img src="../static/images/point-close.png">
            </div>
        </div>
    </div>
</template>
<script>
import { mapState, mapMutations } from "vuex"
import api from '../plugins/api'
import request from '../plugins/request'
export default {
    data() {
        return {
            layerImg: '',
            deviceId: '',
            isShow: false
        }
    },
    computed: {
        ...mapState(['wxOpenId'])
    },
    watch: {
        wxOpenId(newVal) {
            if (newVal) {
                this.device = newVal;
                this.getLayer()
            }
        }
    },
    mouthed() {

    },
    onLoad() {
        if (this.wxOpenId) {
            this.device = this.wxOpenId;
            this.getLayer()
        }
    },
    methods: {
        getLayer() {
            let url = { path: api.getLayer, method: 'post', data: { displayPageType: 1, device: this.device }, hideLoading: true }
            request(url)
                .then(res => {
                    if (res.code == 200) {
                        if (res.data) {
                            this.isShow = true;
                            this.layerImg = res.data;
                        } else {
                            this.isShow = false;
                        }
                    }
                })
                .catch(err => {
                    console.log(err)
                })
        },
        closeImg() {
            this.isShow = false;
        },
        toJumpUrl(data) {
            let vm = this
            if(data.jumpUrl == ''){
                vm.isShow = false;
            }else{
                wx.navigateTo({
                    url: `/pages/banner/index?url=${data.jumpUrl}&title=${data.popupName}`,
                    success() {
                        vm.isShow = false;
                    }
                })
            }
        },
        //防止底层view滑动
        preventTouchMove(e) {
            return
        },
    },

}
</script>
<style scoped>
.layer {
    position: relative;
    background: #000000;
    background: rgba(0, 0, 0, 0.7);
    width: 100%;
    height: 100%;
    top: 0px;
    bottom: 0px;
    position: fixed;
    z-index: 999;
    display: flex;
    align-items: center;
}
.layer-con {
    position: relative;
    flex: 1;
    padding: 0 30px;
    height: 70%;
}
.layer-con img {
    display: inline-block;
    width: 100%;
    height: 100%;
}
.colse_layer {
    position: absolute;
    left: 0;
    right: 0;
    margin-top: 21px;
    text-align: center;
}
.colse_layer img {
    width: 30px;
    height: 30px;
}
</style>
