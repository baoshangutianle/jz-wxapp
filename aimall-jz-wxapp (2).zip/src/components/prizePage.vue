<template>
    <div v-show="prizeFalg" class="prize-page">
        <div class="main">
            <div class="content">
                <div class="awardPage">
                    <div class="title font-color">
                        <span v-if="lotteryStatus" class="f18">恭喜您抽中</span>
                        <span v-else class="f24">好可惜，没抽中</span>
                    </div>
                    <div class="name font-color">
                        <span v-if="lotteryStatus" class="f24">{{lotteryName}}</span>
                        <span v-else class="f15">{{lotteryName}}</span>
                    </div>
                    <img class="img" v-if="lotteryStatus" :src="lotteryImg" />
                    <img
                        v-else
                        class="failImg"
                        src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191031/f0aaa10154464bdbb1cd854dc511b5f0.png"
                    />
                </div>
                <div class="tipPage">
                    <div class="view font-color f15">
                        <span v-if="lotteryStatus&&sourceFrom">
                            可在
                            <span>我的卡包</span>查看
                        </span>
                        <span v-else-if="lotteryStatus&&!sourceFrom">礼品已收入您的卡包</span>
                        <span v-else>送你个小心心安慰一下</span>
                    </div>
                    <div v-if="sourceFrom">
                        <div class="button font-color f18" v-if="lotteryStatus" @click="sharePage">
                            <span>晒好运</span>
                        </div>
                        <button
                            class="button font-color f18"
                            v-else
                            @click="sharePonit"
                            open-type="share"
                        >
                            <span>邀请好友试一试</span>
                        </button>
                    </div>
                    <div v-if="!sourceFrom">
                        <div class="button font-color f18" v-if="lotteryStatus" @click="goView(1)">
                            <span>去查看</span>
                        </div>
                        <div class="button font-color f18" v-else @click="goView(0)">
                            <span>去首页看看</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="close" v-if="sourceFrom">
                <div class="line"></div>
                <img
                    src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/5ec255d63c534452916ebc09c6b28911.png"
                    @click="closePage"
                />
            </div>
        </div>
        <div class="bottomPage" v-show="openFalg" :animation="hAnimate">
            <div class="content">
                <div class="top">
                    <span class="round">
                        <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/6427bd21912444cfacdf46df6a35029f.png" />
                    </span>
                    <span class="name">南海嘉洲广场</span>
                    <img class="right" src="/static/images/icon-home-arrow.png" />
                </div>
                <ul>
                    <li class="share">
                        <button class="page" @click="cancelPage(1)" open-type="share">
                            <img
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191118/1cb96c9c16984b99b8660c8b225072fb.png"
                            />
                        </button>
                        <div class="label">转发</div>
                    </li>
                    <li class="download">
                        <div class="page" @click="downloadImg">
                            <img
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191118/de452d964d874c2bb9ad926ac48e3500.png"
                            />
                            <div class="label">生成分享图片</div>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="cancelPage" @click="cancelPage">取消</div>
        </div>
    </div>
</template>

<script>
import api from '@/plugins/api'
import request from '@/plugins/request'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'

export default {
    props: {
        openFalg: {
            type: Boolean,
            default: false
        },
        lotteryStatus: {
            type: Boolean,
            default: true
        },
        sourceFrom: {
            type: Boolean,
            default: true
        },
        lotteryName: {
            type: String,
            default: ''
        },
        lotteryImg: {
            type: String,
            default: ''
        },
        activityId: {
            type: String,
            default: ''
        },
        luckyPrizeId: {
            type: String,
            default: ''
        },
        pageSource: {
            type: String,
            default: ''
        }
    },
    mounted() {
        this.prizeFalg = this.openFalg
    },
    data() {
        return {
            prizeFalg: false,
            hAnimate: 0
        }
    },
    methods: {
        closePage() {
            this.prizeFalg = false
            this.$emit('close', false)
        },
        sharePage() {
            buryPoint.setF({
                id: pointCode.LOTTERY_LUCK_F,
                p_v1: this.pageSource
            })

            let option = {
                duration: 100, // 动画执行时间
                timingFunction: 'linear' // 动画执行效果
            }
            let hAnimate = wx.createAnimation(option)
            this.hAnimate = hAnimate.height('430rpx').step()
        },
        cancelPage(data) {
            if (data == '1') {
                buryPoint.setF({
                    id: pointCode.LOTTERY_SHARE_F,
                    p_v1: this.pageSource
                })
            }
            let option = {
                duration: 100, // 动画执行时间
                timingFunction: 'linear' // 动画执行效果
            }
            let hAnimate = wx.createAnimation(option)
            this.hAnimate = hAnimate.height(0).step()
        },
        sharePonit() {
            buryPoint.setF({
                id: pointCode.LOTTERY_INVITE_F,
                p_v1: this.pageSource
            })
        },
        goView(status) {
            if (status == 1) {
                wx.navigateTo({ url: '/pagesMine/card' })
            } else {
                wx.switchTab({ url: '/pages/home' })
            }
            this.$emit('resetInfo')
        },
        downloadImg: function(e) {
            buryPoint.setF({
                id: pointCode.LOTTERY_SAVE_F,
                p_v1: this.pageSource
            })

            let requestOptions = {
                path: api.downLoadPhoto,
                method: 'post',
                data: {
                    raffleActivityId: this.activityId,
                    luckyPrizeId: this.luckyPrizeId,
                    qrCodeUrl: 'pages/luckyLottery/index?pageId=lotteryShare&activityId=' + this.activityId + '&luckyPrizeId=' + this.luckyPrizeId + '&qrCode=qrCode'
                }
            }
            request(requestOptions).then(res => {
                if (res.code == 200) {
                    let imgUrl = res.data
                    //触发函数
                    wx.downloadFile({
                        url: imgUrl, //需要下载的图片url
                        success: function(res) {
                            //成功后的回调函数
                            wx.saveImageToPhotosAlbum({
                                //保存到本地
                                filePath: res.tempFilePath,
                                success(res) {
                                    wx.showToast({
                                        title: '保存成功',
                                        icon: 'success',
                                        duration: 2000
                                    })
                                },
                                fail: function(err) {
                                    if (err.errMsg === 'saveImageToPhotosAlbum:fail auth deny') {
                                        wx.openSetting({
                                            success(settingdata) {
                                                
                                            }
                                        })
                                    }
                                }
                            })
                        }
                    })
                    this.cancelPage() //取消下拉框
                }
            })
        }
    },
    watch: {
        openFalg(newVal) {
            if (newVal) {
                this.prizeFalg = true
            } else {
                this.cancelPage()
                this.prizeFalg = false
            }
        },
        lotteryStatus(newVal) {
            this.lotteryStatus = newVal
        },
        lotteryName(newVal) {
            this.lotteryName = newVal
        },
        lotteryImg(newVal) {
            this.lotteryImg = newVal
        },
        activityId(newVal) {
            this.activityId = newVal
        },
        luckyPrizeId(newVal) {
            this.luckyPrizeId = newVal
        },
        sourceFrom(newVal) {
            this.sourceFrom = newVal
        }
    }
}
</script>

<style lang="less">
.prize-page {
    position: fixed;
    width: 100%;
    top: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 9999;
    .font-color {
        color: #ffffff;
        text-align: center;
    }
    .f15 {
        font-size: 15px;
    }
    .f18 {
        font-size: 18px;
    }
    .f24 {
        font-size: 24px;
    }
    .main {
        width: 302px;
        height: 398px;
        position: absolute;
        top: 15%;
        left: 0;
        bottom: 0;
        right: 0;
        margin: 0 auto;
        .content {
            width: 302px;
            height: 398px;
            background: url(https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191107/d560347bb8bd46a5bdae0a5a4f2b634d.png) no-repeat;
            background-size: 100% 100%;
            .awardPage {
                .title {
                    padding: 44px 0 15px;
                }
                .name {
                    width: 244px;
                    height: 33px;
                    background: url(https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191029/1ed6407e1159424ab6ecb58aa1e02256.png) no-repeat;
                    background-size: 100% 100%;
                    margin: 0 auto;
                    line-height: 33px;
                }
                .img {
                    width: 152px;
                    height: 152px;
                    margin: 0 auto;
                    margin-top: 30px;
                }
                .failImg {
                    width: 125px;
                    height: 125px;
                    margin: 26px auto 10px;
                }
            }
            .view {
                padding: 80px 0 20px;
            }
            .button {
                width: 185px;
                height: 45px;
                line-height: 45px;
                border-radius: 45px;
                margin: 0 auto;
                background-image: linear-gradient(#f87191, #e04164);
            }
        }
        .close {
            bottom: -30px;
            .line {
                width: 1.5px;
                height: 30px;
                margin: 0 auto;
                background: rgba(255, 255, 255, 0.4);
            }
            img {
                width: 50px;
                height: 50px;
                margin: 0 auto;
            }
        }
    }
    .tipPage {
        position: absolute;
        bottom: 0;
        background: url(https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191106/d2d1e4e54d1846ceb0d489b26d8fb075.png) no-repeat;
        background-size: 100% 100%;
        height: 194px;
        width: 302px;
        z-index: 10;
    }
    .bottomPage {
        position: absolute;
        bottom: -1px;
        height: 0;
        width: 100%;
        z-index: 200;
        overflow: hidden;
        background: #f8f8f8;
        border-top-right-radius: 30rpx;
        border-top-left-radius: 30rpx;
        .content {
            padding: 4%;
            height: 60%;
            .top {
                height: 80rpx;
                border-bottom: 1px solid #cacaca;
                margin-bottom: 10px;
                span {
                    float: left;
                }
                .round {
                    width: 38px;
                    height: 38px;
                    background: #fff;
                    border-radius: 100%;
                    position: relative;
                    width: 38px;
                    background: #fff;
                    border-radius: 100%;
                    position: relative;
                    top: -5px;
                    margin: 0 10px 0 3px;
                    img {
                        position: absolute;
                        top: 0;
                        bottom: 0;
                        right: 0;
                        left: 0;
                        margin: auto;
                        width: 28px;
                        height: 28px;
                    }
                }
                .name {
                    font-size: 16px;
                    color: #1d1d1d;
                    font-weight: bold;
                    margin-right: 10rpx;
                }
                .right {
                    width: 10px;
                    height: 10px;
                    display: inline-block;
                }
            }
            ul {
                li {
                    float: left;
                    width: 50%;
                    text-align: center;
                    overflow: hidden;
                    button {
                        width: 56px !important;
                        border-radius: 15px;
                    }
                    .page {
                        width: 100px;
                        overflow: hidden;
                        margin: 0 auto;
                        padding: 0;
                        img {
                            margin: 0 auto;
                            width: 56px;
                            height: 56px;
                            margin:0 auto;
                        }
                    }
                    .label {
                        color: #666666;
                        font-size: 14px;
                        text-align: center;
                        line-height: 25px;
                    }
                }
            }
        }
        .cancelPage {
            width: 100%;
            background: #fff;
            position: absolute;
            color: #333333;
            font-size: 18px;
            text-align: center;
            bottom: 0;
            padding: 4% 0;
        }
    }
}
</style>
