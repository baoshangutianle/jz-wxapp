<template>
    <div class="game-dialog"
            v-if="isShowDialog">
        <div class="game-countDown"
                v-if="isShowCountDown">
            <p class="game-countDown-tips">请在大屏玩游戏</p>
            <p class="game-countDown-distanceEnd">距离游戏结束还有</p>
            <div class="game-countDown-bg">
                <button class="game-countDown-second">
                    <span>{{showGameTime}}</span>
                    <span>S</span>
                </button>
            </div>
        </div>
        <div class="game-prize"
                v-if="isShowPrize && isWinPrize">
            <div class="game-dialog-title">
                <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191028/19b0e6299de74fc3ac4e7d4b1e94b3c4.png">
                <div class="game-dialog-subtitle">
                    <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/fa92e868d74541c9bad53de3ca51a450.png">
                    <p>{{prizeObj.prizeName}}</p>
                </div>
            </div>
            <div class="game-dialog-prize-box">
                <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/e0ff7afaf55540e79838d4cc31baa299.png">
                <div class="game-dialog-prize-content"
                        style="position:absolute">
                    <div class="game-dialog-Coupon"
                            style="position:absolute">
                        <span class="white-circle-top"></span>
                        <span class="white-circle-bottom"></span>
                        <div class="game-dialog-Coupon-img">
                            <div class="game-dialog-Coupon-img-content">
                                <img :src="prizeObj.prizeImageUrl">
                            </div>
                        </div>
                        <div class="game-dialog-Coupon-detail">
                            <p class="game-dialog-Coupon-prizeName">{{prizeObj.prizeName}}</p>
                        </div>
                    </div>
                    <p class="game-dialog-tips">奖品已放入卡包</p>
                    <p class="game-dialog-toMind">奖品已放入我的>我的优惠券，可前往查看</p>
                    <div class="game-btn">
                        <button class="checkPrize"
                                @click="checkPrize">查看奖品</button>
                        <button
                            v-if="isHaveOtherNum"
                            class="playAgain"
                            @click="reset">再玩一次</button>
                        <button
                            v-if="!isHaveOtherNum"
                            class="noTimes"
                            @click="reset">次数耗尽</button>
                    </div>
                </div>

            </div>
        </div>
        <div class="game-prize-fail-box"
                v-if="isShowPrize && !isWinPrize">
            <div class="page-dialog-fail">
                <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191028/3ecb1d470d2e47f7bd263cb093c4b5cd.png">
                <p class="page-dialog-fail-txt">{{prizeObj.errMsg}}</p>
                <!-- <span class="page-dialog-fail-info">送你一个小心心</span> -->
                <span class="page-dialog-close-icon"
                        @click="reset">
                    <img src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/0e8b64609d6c4e60be6d14763ea13cf6.png" />
                </span>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {

        }
    },
    props:{
        isShowDialog:{
            type: Boolean,
            default: ()=>{
                return false
            }
        },
        isShowCountDown:{
            type: Boolean,
            default: ()=>{
                return true
            }
        },
        showGameTime:{
            type: String,
            default: ()=>{
                return '60'
            }
        },
        isWinPrize:{
            type: Boolean,
            default: ()=>{
                return true
            }
        },
        prizeObj:{
            type: Object,
            default: ()=>{
                return {}
            }
        },
        isHaveOtherNum:{
            type: Boolean,
            default: ()=>{
                return true
            }
        },
        isShowPrize:{
            type: Boolean,
            default: ()=>{
                return false
            }
        }
    },
    mounted(){

    },
    methods:{
        reset(){
            this.$emit('reset')
        },
        checkPrize(){
            this.$emit('checkPrize')
        }
    }
}
</script>

<style lang="less">
.game-dialog {
    width: 100%;
    height: 100%;
    position: absolute;
    background: rgba(0, 0, 0, 0.8);
    .game-countDown {
        text-align: center;
        color: #ffffff;
        position: relative;
        .game-countDown-tips {
            padding: 72px 36px 38px 36px;
            font-family: PingFangHK-Semibold;
            font-size: 40px;
            letter-spacing: 3.18px;
        }
        .game-countDown-distanceEnd {
            font-family: PingFangHK-Regular;
            font-size: 18px;
            letter-spacing: 1.43px;
            margin-bottom: 32px;
        }
        .game-countDown-bg {
            width: 168px;
            height: 168px;
            border-radius: 50%;
            background: rgba(255, 115, 110, 0.18);
            position: absolute;
            left: 0;
            right: 0;
            margin: 0 auto;
            display: flex;
            justify-content: center;
            align-items: center;
            .game-countDown-second {
                width: 138px;
                height: 138px;
                padding: 0;
                background: #ff736e;
                border-radius: 50%;
                span {
                    display: inline-block;
                    color: #ffffff;
                    letter-spacing: 2.38px;
                }
                span:nth-child(1) {
                    font-size: 50px;
                }
                span:nth-child(2) {
                    font-size: 30px;
                }
            }
        }
    }
    .game-prize {
        .game-dialog-title {
            margin: 8% 9px 0;
            height: 237px;
            position: relative;
            > img {
                width: 357px;
                height: 237px;
                position: absolute;
                left: 0;
                right: 0;
                margin: 0 auto;
                top: 0;
                z-index: 99;
            }
            .game-dialog-subtitle {
                position: absolute;
                left: 82px;
                top: 110px;
                width: 204px;
                height: 31px;
                z-index: 100;
                > img {
                    width: 100%;
                    height: 100%;
                }
                p {
                    position: absolute;
                    width: 100%;
                    color: #fff;
                    top: 0;
                    text-align: center;
                }
            }
        }
        .game-dialog-prize-box {
            position: absolute;
            left: 0;
            top: 32%;
            right: 0;
            margin: 0 auto;
            width: 338px;
            height: 380px;
            // background: #fff;  //todo
            > img {
                width: 100%;
                height: 380px;
                position: absolute;
                left: 0;
                right: 0;
                top: 0;
                margin: 0 auto;
            }
            .game-dialog-prize-content {
                width: 100%;
                .game-dialog-Coupon {
                    position: absoulte;
                    left: 0;
                    right: 0;
                    top: 45px;
                    margin: 0 auto;
                    width: 255px;
                    height: 118px;
                    background: #1A75F3;
                    border-radius: 8.47px;
                    display: flex;
                    > div {
                        flex: 1;
                    }
                    > span {
                        display: inline-block;
                        width: 20px;
                        height: 20px;
                        border-radius: 50%;
                        background: #fff;
                        position: absolute;
                    }
                    .white-circle-top {
                        left: 50%;
                        top: -15px;
                        transform: translate(-50%, 0);
                    }
                    .white-circle-bottom {
                        left: 50%;
                        bottom: -15px;
                        transform: translate(-50%, 0);
                    }
                    .game-dialog-Coupon-img {
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        box-sizing: border-box;
                        .game-dialog-Coupon-img-content {
                            background: #fff;
                            width: 95.6px;
                            height: 92.3px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            > img {
                                display: inline-block;
                                width: 85.9px;
                                height: 82.7px;
                                // background: #ddd;
                            }
                        }
                    }
                    .game-dialog-Coupon-img:after {
                        position: absolute;
                        content: '';
                        border-left: 1px dashed #fff;
                        left: 50%;
                        top: 0;
                        height: 100%;
                    }
                    .game-dialog-Coupon-detail {
                        text-align: center;
                        padding-left: 16px;
                        color: #fff;
                        .game-dialog-Coupon-prizeName{
                            font-size: 16px;
                            padding-top:47px;
                        }
                        .game-dialog-Coupon-price {
                            display: flex;
                            align-items: center;
                            span {
                                font-size: 20px;
                            }
                            p {
                                font-size: 48px;
                                letter-spacing: -2.42px;
                            }
                        }
                        .game-dialog-Coupon-store {
                            font-size: 16px;
                        }
                        .game-dialog-Coupon-premise {
                            font-size: 12px;
                        }
                    }
                }
                .game-dialog-tips {
                    position: absolute;
                    width: 100%;
                    top: 197.6px;
                    font-size: 16.8px;
                    color: #505050;
                    text-align: center;
                }
                .game-dialog-toMind {
                    position: absolute;
                    width: 100%;
                    top: 227px;
                    font-size: 12px;
                    color: #505050;
                    text-align: center;
                }
                .game-btn {
                    position: absolute;
                    width: 100%;
                    top: 297px;
                    padding: 0;
                    display: flex;
                    button {
                        width: 118px;
                        height: 38px;
                        line-height: 38px;
                        border-radius: 74px;
                        border-radius: 19px;
                        font-size: 16px;
                        letter-spacing: 1.27px;
                    }
                    .checkPrize {
                        color: #ff736e;
                        border: 1px solid #ff736e;
                        background: #fff;
                        margin-left: 34px;
                        margin-right: 0;
                    }
                    .playAgain {
                        background: #ff736e;
                        color: #fff;
                        margin-right: 34px;
                    }
                    .noTimes {
                        background: #d2d2d2;
                        color: #fff;
                        margin-right: 34px;
                    }
                }
            }
        }
    }
    .game-prize-fail-box {
        width: 100%;
        .page-dialog-fail {
            width: 70%;
            height: 245px;
            background: #ffffff;
            border: 4px solid #1a75f3;
            border-radius: 2px;
            position: relative;
            left: 0;
            right: 0;
            margin: 160px auto;
            > img {
                position: absolute;
                width: 100px;
                height: 100px;
                left: 0;
                right: 0;
                margin: 0 auto;
                top: -50px;
            }
            .page-dialog-fail-txt {
                // padding-top: 75px;
                font-family: PingFangHK-Medium;
                font-size: 20px;
                color: #505050;
                text-align: center;
                padding: 75px 20px 0;
            }
            .page-dialog-fail-info {
                display: inline-block;
                width: 100%;
                text-align: center;
                font-family: PingFangHK-Light;
                font-size: 14px;
                color: #505050;
                text-align: center;
            }
            .page-dialog-close-icon {
                display: inline-block;
                position: absolute;
                width: 40px;
                height: 40px;
                left: 0;
                right: 0;
                bottom: 30px;
                margin: 0 auto;
                img {
                    width: 100%;
                    height: 100%;
                }
            }
        }
    }
}
</style>
