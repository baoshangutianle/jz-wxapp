<template>
    <div class="container">
        <div class="collect-comp-container">
            <auth-btn @pass="doCollect" />
            <img
                v-if="collectState"
                class="collect-comp-icon"
                src="/static/images/icon-common-collect@2x.png"
                alt="收藏"
            >
            <img
                v-else
                class="collect-comp-icon"
                src="/static/images/icon-common-uncollect@2x.png"
                alt="未收藏"
            >
            <span class="collectNum">{{collectNum}}</span>
        </div>
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import AuthBtn from '@/components/AuthBtn'
import request from '@/plugins/request'
import api from '@/plugins/api'
import wxUtils from '../plugins/wxUtils';
export default {
    components: {
        AuthBtn
    },
    // eslint-disable-next-line vue/require-prop-types
    props: ['contentType', 'contentId','collectNum','collectState'],
    data() {
        return {
            status: false
        }
    },
    watch: {
        contentId(newVal) {
            if (this.vipInfo && newVal) {
                //this.getStatus()
            }
        },
        vipInfo(newVal) {
            if (newVal) {
                //this.getStatus()
            }
        }
    },
    onShow(){
        this.status = false
    },
    methods: {
        getStatus() {
            let params = {
                "contentId": this.contentId,
                "contentType": this.contentType,
                "userCode": wxUtils.getUserCodeStorage()
            }
            let requestOptions = {
                path: api.getCollectStatus,
                method: 'post',
                data: params,
                hideLoading: true
            }
            request(requestOptions).then(res => {
                this.status = res.data
            })
        },
        doCollect() {
            //调用父级页面方法
            this.$emit('getCollectNum','collectFlag')
            // this.status = !this.status
            // let params = {
            //     "contentId": this.contentId,
            //     "contentType": this.contentType,
            //     "userCode": wxUtils.getUserCodeStorage()
            // }
            // let requestOptions = {
            //     //path: api.doCollect,
            //     path: api.creatCollect,
            //     method: 'post',
            //     data: params,
            //     hideLoading: true
            // }
            // request(requestOptions).then(res => {
            //     var msg = this.collectState ? '取消收藏' : '已收藏'
            //     wx.showToast({
            //         icon: 'success',
            //         title: msg
            //     })
            // })
        }
    },
}
</script>

<style lang="less" scoped>
.container {
    .collect-comp-container {
        text-align: center;
        float: left;
        position: relative;
        .auth-btn-container {
            width: 50px;
            height: 50px;
        }
        .collect-comp-icon {
            display: inline-block;
            width: 21px;
            height: 21px;
            margin-right: 2px;
        }
        .deliver-comp-icon {
            display: inline-block;
            width: 21px;
            height: 21px;
            margin-right: 3px;
        }
        p {
            color: #333;
            font-size: 15px;
            display: inline-block;
            height: 21px;
            line-height: 21px;
        }
    }
    .collectNum{
        font-size: 15px;
        color: #333333;
        padding-left: 3px;
        vertical-align: top;
    }
}
</style>
