<template>
    <div class="brand-comp-container">
        <div class="brand-comp-con">
            <div class="item-img">
                <img class="restaurant-img"
                    mode=""
                    :src="data.showIcon">
            </div>
            <div class="restaurant-info">
                <p>
                    <span class="restaurant-name">{{data.storeName}}</span>
                </p>
                <p>
                    <span class="restaurant-address">{{data.buildingName?(data.buildingName+'/'):''}}{{data.floorNo}}</span>
                </p>
                <p>
                    <span class="restaurant-categoryName">{{data.categoryName}}</span>
                </p>
                <!-- <p class="flex-wrp restaurant-type-address">
                    <span class="restaurant-type">{{data.categoryName}}</span>
                    <span class="restaurant-address">{{data.floorNo}}</span>
                </p> -->
                <!-- 隐藏标签属性 -->
                <!-- <ul class="restaurant-tags" >
                    <li v-for="(item,key) in data.userTag" :key="key">{{item}}</li>
                </ul> -->
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props:{
        data:{
            type: Object,
            default: {}
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.brand-comp-container{

    padding: 12px 14px;
    .brand-comp-con{
        display: flex;
        .item-img{
            margin-right: 10px;
            width: 68px;
            height: 68px;
            border:1px solid #e7e7e7;
            .restaurant-img{
                width: 68px;
                height: 68px;
            }
        }
        .restaurant-info{
            flex:1;
            padding-left: 5px;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            p{
                &:last-child{
                    margin-bottom: 0;
                }
                .restaurant-name{
                    font-size: 15px;
                    color: #333333;
                    overflow:hidden; //超出一行文字自动隐藏
                    text-overflow:ellipsis;//文字隐藏后添加省略号
                    white-space:nowrap; //强制不换行
                    display: inline-block;
                    width: 100%;
                }
                &.restaurant-price-grade{
                    align-items: center;
                    .restaurant-grade{
                        flex: 0 1 auto;
                    }
                    .restaurant-price{
                        flex: 1;
                        margin-left: 17px;
                        font-size: 12px;
                        color: #929292;
                    }
                }
                &.restaurant-type-address{
                    justify-content: space-between;
                    font-size: 13px;
                    color: #999999;
                    flex:1;
                    span{
                        display: inline-block;
                        margin-top: 10px;
                    }
                }
            }
            .restaurant-tags{
                // display: flex;
                li{
                    display: inline-block;
                    // flex: 1;
                    padding: 2px 6px;
                    border: 1px solid;
                    font-size: 12px;
                    color: @theme-color;
                    &+li{
                        margin-left: 5px;
                    }
                }
            }
            .restaurant-address{
                color: #333333;
                font-size: 13px;
                font-weight: 200;
                padding-top: 6px;
                display: inline-block;
            }
            .restaurant-categoryName{
                color: #999999;
                font-size: 13px;
                font-weight: 200;
                padding-top: 6px;
                display: inline-block;
            }
        }
    }
}
</style>
