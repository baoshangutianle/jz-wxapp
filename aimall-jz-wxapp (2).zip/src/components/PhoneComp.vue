<template name="paybulletCoverView">
    <cover-view v-show="isshow"
                class="pop-up-bg">
        <cover-view class="pop-up-container">
            <cover-view class="phone-info">
                <cover-view class="phone-item phone-number">{{ phone }}</cover-view>
                <cover-view class="phone-item phone-call"
                            @click="doPhone">呼叫</cover-view>
                <cover-view class="phone-item phone-cancel"
                            @click="cancel">取消</cover-view>
            </cover-view>
        </cover-view>
    </cover-view>
</template>

<script>
export default {
    props: {
        isshow: {
            type: Boolean,
            default: false
        }
    },
    data(){
        return{
            phone: "021-66666666"
        }
    },
    methods:{
        doPhone(){
            wx.makePhoneCall({
                phoneNumber: this.phone
            })
        },
        cancel(){
            // this.isshow = false
            this.$emit("close")
        }
    }
}
</script>


<style lang="less" scoped>
.pop-up-bg {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 9999;
  align-items: center;
  justify-content: center;
}
.pop-up-container {
    position: fixed;
    bottom: 0;
    left: 0;
    color: #666;
    font-size: 15px;
    right: 0;
    background: #fff;
    color: #888;
    line-height: 21px;
    text-align: center;
    .phone-info{
        .phone-item{
            &.phone-call,
            &.phone-cancel{
                font-size: 18px;
                color: #000;
            }
            &.phone-number{
                padding: 10px 0;
            }
            &.phone-call{
                padding: 10px 0;
                border-top: 1px solid #EFF1F8;;
            }
            &.phone-cancel{
                padding-top: 10px;
                border-top: 6px solid rgba(0, 0, 0, .6);
                &:after{
                    display: block;
                    content: '';
                    width: 135px;
                    height: 7px;
                    margin: 16px auto 6px;
                    background: #171717;
                    border-radius: 4px;
                }
            }
        }
    }
}

.top-view {
  height: 98rpx;
  width: 100%;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: center;
  background-color: #fff;
}

.top-view .title {
  height: 98rpx;
  line-height: 98rpx;
  width: 100%;
  font-size: 36rpx;
  text-align: center;
}

.top-view .cancel {
  position: absolute;
  width: 60rpx;
  height: 60rpx;
  right: 20rpx;
  top:50%;
  transform: translateY(-50%);
}

.line-view, .top-line-view {
  width: 100%;
  height: 2rpx;
  background-color: #eeeeee
}

.top-line-view {
  background-color: #39cc6a
}

.pay-money-title {
  width: 100%;
  height: 98rpx;
  line-height: 98rpx;
  color: #333333;
  font-size: 32;
  text-align: center;
}

.pay-money-view {
  height: 60rpx;
  margin: 36rpx 30rpx 20rpx;
  justify-content: center;
  display: flex;
}

.pay-money-view .symbol {
  width: 33%;
  height: 40rpx;
  line-height: 40rpx;
  margin-top: 20rpx;
  font-size: 30rpx;
  text-align: right;
}

.pay-money-view .price {
  width: 67%;
  height: 60rpx;
  line-height: 60rpx;
  margin-left: 10rpx;
  color: #000;
  font-size: 60rpx;
  text-align: left;
}

.pet-card-view {
  height: 86rpx;
  margin-left: 30rpx;
  margin-right: 30rpx;
  align-items: center;
  display: flex;
}

.pet-card-view .icon{
  width:46rpx;
  height:46rpx;
  border-radius:23rpx
}

.pet-card-view .title{
  width: 200rpx;
  height: 46rpx;
  line-height: 46rpx;
  margin: 20rpx;
  color: #6E726E;
  text-align: left;
}

.bottom-make-sure-button {
  height: 92rpx;
  line-height: 92rpx;
  margin: 40rpx 30rpx 20rpx;
  background-color: #06C160;
  border-radius: 8rpx;
  color: #fff;
  justify-content: center;
  align-items: center;
  text-align: center;
}
</style>
