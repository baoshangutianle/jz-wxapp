<template>
    <div class="login-prompt-container">
        <div
            v-show="isShow"
            class="pop-up-bg"
        >
            <div class="pop-up-container">
                <div class="pop-up-tit">请授权手机号码</div>
                <div class="login-prompt-info">
                    <div class="login-prompt-item login-prompt-msg">授权手机号码<br>享受会员特权</div>
                    <div class="login-prompt-item login-prompt-img">
                        <img
                            src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/6a79456edeea4c7f87e9367ae0bccd42.png"
                            alt="图片示例"
                            mode="scaleToFill"
                        >
                    </div>
                    <div class="login-prompt-item login-prompt-btns">
                        <div class="btn-item">
                            <button class="btn btn-operate">
                                <auth-btn
                                    auth="user"
                                    @pass="login"
                                />
                                立即登录
                            </button>
                        </div>
                        <div class="btn-item">
                            <span
                                class="btn-operate-not-pwd"
                                @click="refuseNogin"
                            >暂不登录</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils'
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import UserAuth from './UserAuth'
import AuthBtn from '@/components/AuthBtn'
export default {
    components: {
        UserAuth,
        AuthBtn
    },
    props: {
        isShow: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            phone: "021-66666666"
        }
    },
    computed: {
        ...mapState(['wxUserInfo', 'isVip', 'vipInfo'])
    },
    methods: {
        ...mapMutations(["update"]),
        refuseNogin() {
            let vm = this
            vm.$emit("close")
        },
        login(data) {
            let vm = this
            vm.$emit("close")
        },
        //保存用户信息
        saveUserInfo(cb) {
            let appid = wxUtils.getAppId()
            let sessionKey = wxUtils.getSessionKeyStorage()
            let wxUser = wxUtils.getUserStorage()
            let { signature, rawData, encryptedData, iv } = wxUser
            let params = {
                // appid,
                openId: wxUtils.getOpenIdStorage(),
                sessionKey,
                signature,
                rawData,
                encryptedData,
                iv
            }
            let requestOptions = {
                path: api.saveUserInfo,
                method: 'get',
                data: params
            }
            request(requestOptions).then(res => {
                if (res.code == 130007) {
                    console.log("Session失效，重新保存微信信息")
                    wxUtils.getUserSession(function() {
                        vm.saveUserInfo(cb)
                    })
                } else {
                    cb && cb.call(null)
                }
            })
        },
    }
}
</script>


<style lang="less" scoped>
@import '../assets/styles/vars';
.login-prompt-container {
    color: @black-color;
    .pop-up-bg {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 9999;
        align-items: center;
        justify-content: center;
    }
    .pop-up-container {
        position: fixed;
        top: 50%;
        left: 50%;
        width: 275px;
        border-radius: 10px;
        transform: translate(-50%, -50%);
        color: #666;
        font-size: 15px;
        background: #fff;
        color: #888;
        line-height: 21px;
        text-align: center;
        .pop-up-tit {
            padding: 15px 0;
            font-size: 20px;
            border-bottom: 1px solid @border-color;
            color: @black-color;
        }
        .login-prompt-info {
            .login-prompt-msg {
                font-size: 18px;
                color: @theme-color;
                margin-top: 17px;
            }
            .login-prompt-img {
                margin: 15px auto 0;
                display: inline-block;
                width: 136px;
                height: 128px;
                img {
                    width: 100%;
                    height: 100%;
                }
            }
            .login-prompt-btns {
                margin: 0 20px;
                .btn-operate {
                    margin: 40px 0 0;
                }
                .btn-operate-not-pwd {
                    display: inline-block;
                    text-align: center;
                    margin: 21px 0 20px;
                    font-size: 15px;
                    color: @theme-color;
                    &:hover {
                        opacity: 0.8;
                    }
                }
            }
        }
    }

    .top-view {
        height: 98rpx;
        width: 100%;
        display: flex;
        position: relative;
        align-items: center;
        justify-content: center;
        background-color: #fff;
    }

    .top-view .title {
        height: 98rpx;
        line-height: 98rpx;
        width: 100%;
        font-size: 36rpx;
        text-align: center;
    }

    .top-view .cancel {
        position: absolute;
        width: 60rpx;
        height: 60rpx;
        right: 20rpx;
        top: 50%;
        transform: translateY(-50%);
    }

    .line-view,
    .top-line-view {
        width: 100%;
        height: 2rpx;
        background-color: #eeeeee;
    }

    .top-line-view {
        background-color: #39cc6a;
    }

    .pay-money-title {
        width: 100%;
        height: 98rpx;
        line-height: 98rpx;
        color: #333333;
        font-size: 32;
        text-align: center;
    }

    .pay-money-view {
        height: 60rpx;
        margin: 36rpx 30rpx 20rpx;
        justify-content: center;
        display: flex;
    }

    .pay-money-view .symbol {
        width: 33%;
        height: 40rpx;
        line-height: 40rpx;
        margin-top: 20rpx;
        font-size: 30rpx;
        text-align: right;
    }

    .pay-money-view .price {
        width: 67%;
        height: 60rpx;
        line-height: 60rpx;
        margin-left: 10rpx;
        color: #000;
        font-size: 60rpx;
        text-align: left;
    }

    .pet-card-view {
        height: 86rpx;
        margin-left: 30rpx;
        margin-right: 30rpx;
        align-items: center;
        display: flex;
    }

    .pet-card-view .icon {
        width: 46rpx;
        height: 46rpx;
        border-radius: 23rpx;
    }

    .pet-card-view .title {
        width: 200rpx;
        height: 46rpx;
        line-height: 46rpx;
        margin: 20rpx;
        color: #6e726e;
        text-align: left;
    }

    .bottom-make-sure-button {
        height: 92rpx;
        line-height: 92rpx;
        margin: 40rpx 30rpx 20rpx;
        background-color: #06c160;
        border-radius: 8rpx;
        color: #fff;
        justify-content: center;
        align-items: center;
        text-align: center;
    }
}
</style>
