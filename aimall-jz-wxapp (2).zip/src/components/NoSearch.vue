<template>
    <div class="noSearch">
        <div class="noSearch-con">
            <span class="noSearch-icon"></span>
            <span>没有找到""相关结果</span>
            <p>为您推荐</p>
        </div>
    </div>
</template>
<style lang='less' scoped>
.noSearch{
    width: 100%;
    .noSearch-con{
        padding:10px;
    }
}
</style>
