<template name="barrage">
   <!--弹幕文字-->
        <view id="barrage" class='launchGird'>
            <view class='displayGroup'>
                <!-- <view class='dmGroup' v-for="(item,index) in dmData" :key="index" :style="{top:item.top+'%',animation: item.dmAnimation}" :class="'dmGroup'+index"> -->
                <!-- <view class='dmGroup' v-for="(item,index) in dmData" :key="index" :class="'dmGroup'+index">
                    <view class='dmItem'>
                    <view class='dm'>
                        <view class='avatarBox'>
                        <image :src='item.face' class='avatar' mode='aspectFit'></image>
                        </view>
                        <text class='content'>{{ item.name }}获得{{item.prizeName}}</text>
                        <image :src='iconGood' class='icon good' mode='aspectFill'></image>
                    </view>
                    </view>
                </view> -->


                <view id="dmGroup" class="groud1 dmGroup0">
                    <div class='dmGroup' v-for="(item,index) in dmData" :key="index">
                        <view class='dmItem' v-if="index<5">
                            <view class='dm'>
                                <view class='avatarBox'>
                                <image :src='item.face' class='avatar'></image>
                                </view>
                                <text class='content'>{{ item.name }}获得{{item.prizeName}}</text>
                            </view>
                        </view>
                    </div>
                </view>
                <view class="groud2 dmGroup1">
                    <div class='dmGroup' v-for="(item,index) in dmData" :key="index">
                        <view class='dmItem' v-if="index>4 && index<10">
                            <view class='dm'>
                                <view class='avatarBox'>
                                <image :src='item.face' class='avatar'></image>
                                </view>
                                <text class='content'>{{ item.name }}获得{{item.prizeName}}</text>
                            </view>
                        </view>
                    </div>
                </view>

            </view>
        </view>
</template>

<script>
export default {
    props: {
        dmData: {
            type: Array,
            default: {}
        }
    },
    data() {
        return {
            data: {
            }
        }
    },
    methods: {

    }
}
</script>
<style lang="less" scoped>
#barrage {
    position: absolute;
    z-index: 999;
    top: 200px;
    width: 100%;
    .container {
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        box-sizing: border-box;
    }
    .launchGird {
        padding: 20rpx;
        position: relative;
        height: 100%;
    }

    .displayGroup {
        height: 150px;
        position: relative;
        overflow: hidden;
    }
    .groud1 {
        white-space: nowrap;
        position: absolute;
        z-index: 99;
    }
    .groud2 {
        white-space: nowrap;
        position: absolute;
        z-index: 99;
        left: 100%;
        top: 50px;
    }
    .dmGroup {
        animation-timing-function: linear;
        animation-fill-mode: none;
        transform: translateZ(0);
        height: 38px;
        display: inline-block;
    }
    .dmItem {
        display: inline-flex;
        margin-right: 60rpx;
        white-space: nowrap;
    }
    .dmItem .dm {
        display: inline-flex;
        vertical-align: middle;
        align-items: center;
        position: relative;
        height: 38px;
        line-height: 38px;
        padding: 0 8px 0 0px;
        background: rgba(167, 167, 167, 0.24);
        border-radius: 19px;
        overflow: hidden;
        font-size: 16px;
        color: #a27114;
    }
    .dmItem .avatarBox {
        display: inline-block;
        position: relative;
        width: 38px;
        height: 38px;
        margin-right: 10rpx;
    }
    .dmItem .avatarBox .avatar {
        width: 38px;
        height: 38px;
        border: 0;
        border-radius: 50%;
        overflow: hidden;
    }
    .dmItem .dm .content {
        display: inline-block;
        max-width: 440rpx;
        height: 50rpx;
        line-height: 50rpx;
        margin-right: 10rpx;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }
    .dmGroup0 {
        transform: translateX(0);
        -webkit-transform: translateX(0);
        left: 100%;
        animation: dmAnimation 30s linear  3s infinite;
        -webkit-animation: dmAnimation 30s linear  3s infinite;
        animation-fill-mode: forwards;
        -webkit-animation-fill-mode: forwards;
    }
    .dmGroup1 {
        transform: translateX(0);
        -webkit-transform: translateX(0);
        left: 100%;
        animation: dmAnimation2 30s linear 7s infinite;
        -webkit-animation: dmAnimation2 30s linear 7s infinite;
        animation-fill-mode: forwards;
        -webkit-animation-fill-mode: forwards;
    }
    @keyframes dmAnimation2 {
        0% {
            transform: translateX(0);
            // left: 100%
        }
        100% {
            // left: 0;
            transform: translateX(-140%);
        }
    }
    @keyframes dmAnimation {
        0% {
            transform: translateX(0);
            // left: 100%
        }
        100% {
            // left: 0;
            transform: translateX(-140%);
        }
    }
    @-webkit-keyframes dmAnimation2 {
        0% {
            -webkit-transform: translateX(0);
            // left: 100%
        }
        100% {
            // left: 0;
            -webkit-transform: translateX(-140%);
        }
    }
    @-webkit-keyframes dmAnimation {
        0% {
            -webkit-transform: translateX(0);
            // left: 100%
        }
        100% {
            // left: 0;
            -webkit-transform: translateX(-140%);
        }
    }
}
</style>
