<!--
 * @Description: 倒计时组件
-->
<template>
  <div class="countDown" :class="[colorFul? 'colorFul':'noColor']">
    <span class="hour">{{hourTime ? hourTime : '00' }}</span>:<span class="min">{{minTime ? minTime : '00'}}</span>:<span class="sec">{{secTime ? secTime : '00'}}</span>
  </div>
</template>
<script>
import utils from '@/plugins/utils'
export default {
  data() {
    return {
      time: null,
      hourTime: '',
      minTime: '',
      secTime: '',
      sideTimer: ''
    }
  },
  props: {
    timer: {
      type: Number,
      default: ''
    },
    colorFul: {
      type: Boolean,
      default: false
    }
  },
  onHide () {
    clearInterval(this.time)
  },
  created() {
    this.sideTimer = this.timer;
    // this.countDown()
  },
  methods: {
    countDown () {
      const t = this;
      t.time = setInterval(()=>{
        if (t.sideTimer<=0) {
          clearInterval(t.time)
        } else {
          t.sideTimer-=1
          t.hourTime = utils.formatNumber(parseInt(t.sideTimer / 60 / 60 % 24));
          t.minTime = utils.formatNumber(parseInt(t.sideTimer / 60 % 60));
          t.secTime = utils.formatNumber(t.sideTimer % 60);
        }
      },1000)
    }
  },
}
</script>
<style lang="less" scoped>
  .countDown {
    display: flex;
    justify-content: center;
    align-items: center;
    span {
      display: flex;
      justify-content: center;
      align-items: center;
      width:21px;
      height:21px;
      border-radius:3px;
      font-size: 12px;
      margin:0 4px;
    }
  }
  .colorFul {
    color: #9975F3;
    span {
      background: #9975F3;
      color: #fff;
    }
  }
  .noColor {
    color: #fff;
    span {
      color: #9975F3;
      background: #fff;
    }
  }
</style>