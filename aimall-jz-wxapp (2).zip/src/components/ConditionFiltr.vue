<template>
    <div class="filter-box">
        <ul :class="{'filter-title':true, 'filter-title-border':isHasBorder}">
            <li
                v-for="(item,index) in filterData"
                :key="index"
                :class="{'sec_li':index == 1 && isHasBorder}"
                class="filter-title-text-wrap"
                @click="chooseType(item)"
            >
                <div>
                    <div class="ecllip filter-title-text">
                        {{ item.selectTitle }}
                    </div>
                    <span class="filter-title-img">
                        <img src="/static/images/arrow-down2.png">
                    </span>
                </div>
            </li>
        </ul>
        <div
            v-if="isshow"
            class="filter-condition"
            @touchmove.prevent="update"
            @click="update"
        >
            <ul class="filter-list">
                <li
                    v-for="(item,index) in filterList.data"
                    :key="index"
                    @click.stop="chooseCondition(item.name, filterList)"
                >
                    <span :class="item.class">{{ item.name }}</span>
                    <span
                        v-if="item.class[1]"
                        class="filter-img"
                    ><img src="/static/images/icon-check.png"></span>
                </li>
            </ul>
        </div>
    </div>

</template>

<script>
export default {
    props: {
        filterData: {
            type: Array,
            default: () => {
                return [];
            }
        },
        selectCache: {
            type: Object,
            default: () => {
                return {};
            }
        },
        filterWidth: {
            type: String,
            default: () => {
                return '100%';
            }
        },
        isHasBorder: {
            type: Boolean,
            default: false
        },
        isshow: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            filterList: [],
        }
    },
    computed: {
        params() {
            let obj = {}
            let types = Object.keys(this.selectCache)
            types.forEach(key => {
                let typeKey = Object.keys(this.selectCache[key])[0]
                let typeData = this.filterData.find(item => item.title === key)
                let selectValue = this.findValue(typeData.data, typeKey)
                obj[key] = selectValue
            })
            return obj
        }
    },
    watch: {
        params: {
            handler: function(v) {
                // console.log('xxxxxx',v)
            }
        },
        deep: true

    },
    created() {
        this.filterData.map(item => {
            item.selectTitle = item.title //选中值初始化
        })
    },
    // mounted(){
    //     console.log('6666',this.filterData);
    //     this.filterData.map(item=>{
    //         item.selectTitle = item.title //选中值初始化
    //     })
    // },
    methods: {
        calcParams() {
            let obj = {}
            let types = Object.keys(this.selectCache)
            types.forEach(key => {
                let typeKey = Object.keys(this.selectCache[key])[0]
                let typeData = this.filterData.find(item => item.title === key)
                let selectValue = this.findValue(typeData.data, typeKey)
                obj[key] = selectValue
            })

            return obj
        },
        findValue(data, label) {

            let obj = data.find(item => item.name === label);

            if (obj.class[1]) {
                return data.find(item => item.name === label).value
            } else {
                return ''
            }

        },
        chooseType(item) {
            this.filterList = item;
            var data = this.filterList.data.map(select => {
                return {
                    ...select,
                    class: ["filter-type", this.selectCache[item.title] && this.selectCache[item.title][select.name] ? "active-type" : null]
                }
            })
            this.$set(this.filterList, 'data', data)
            this.$emit('updateIsShow', true)
            // this.isshow = true;
        },
        chooseCondition(name, data) {
            const key = `${data.title}`

            if (this.selectCache[key] === undefined) {
                this.selectCache[key] = {
                    [name]: true
                }
            } else if (this.selectCache[key][name]) {
                this.selectCache[key][name] = false

            } else {
                this.selectCache[key] = {
                    [name]: true
                }
            }

            //设置选中值
            this.filterList.selectTitle = name == ("全部" || "不限") ? this.filterList.title :
                this.selectCache[key][name] ? name : this.filterList.title

            this.filterList.data = this.filterList.data.map(item => {
                return {
                    ...item,
                    class: ["filter-type", this.selectCache[key][item.name] ? "active-type" : null]
                }
            })

            this.$nextTick(() => {
                this.$emit('chooseData', this.calcParams(), data)
            })
            this.$emit('updateIsShow', false)
            // this.isshow = false;

        },
        update() {
            //  this.$emit('updateIsShow',false)
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.filter-box {
    height: 100%;
    width: 100%;
    .filter-title-border {
        border-bottom: 1px solid @border-color;
    }
    .filter-title {
        display: flex;
        height: 50px;
        .filter-title-text-wrap {
            display: flex;
            padding: 0 15px;
            justify-content: center;
            align-items: center;
            & > div {
                position: relative;
                display: inline-block;
                padding-right: 23px;
                height: 100%;
                overflow: hidden;
            }
            .filter-title-text {
                box-sizing: border-box;
                display: inline-block;
                width: 100%;
            }
        }
        li {
            overflow: hidden;
            flex: 1 1 50%;
            font-size: 15px;
            color: #333;
            line-height: 50px;
            text-align: center;
            position: relative;
            .filter-title-img {
                position: absolute;
                top: 50%;
                display: inline-block;
                right: 6px;
                transform: translateY(-50%);
                img {
                    width: 8px;
                    height: 5px;
                }
            }
        }
        .sec_li:before {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            left: -0;
            display: inline-block;
            content: '';
            width: 1px;
            height: 20px;
            background: #ddd;
            vertical-align: middle;
        }
    }
    .filter-condition {
        z-index: 2;
        flex: 1;
        position: absolute;
        left: 0;
        right: 0;
        background: #fff;
        box-shadow: 0 3px 8rpx rgba(0, 0, 0, 0.1);
        // margin-top: 1px;
        .filter-list {
            width: 100%;
            min-height: 100px;
            max-height: 200px;
            background: #fff;
            padding: 0 15px 10px;
            box-sizing: border-box;
            overflow-y: auto;
            li {
                height: 50px;
                line-height: 50px;
                font-size: 15px;
                display: flex;
                border-bottom: 1px solid @border-color;
                .filter-type {
                    flex: 1;
                    color: #999;
                }
                .active-type {
                    color: #9975F3;
                }
                .filter-img {
                    display: inline-block;
                    width: 12px;
                    align-self: center;
                    img {
                        width: 12px;
                        height: 9px;
                    }
                }
            }
            li:last-child {
                border-bottom: none;
            }
        }
    }
}
</style>
