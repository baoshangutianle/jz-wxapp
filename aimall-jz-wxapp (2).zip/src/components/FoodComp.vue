<template>
    <div class="food-comp-container">
        <div class="food-comp-con">
            <div class="item-img">
                <img class="restaurant-img"
                    mode="widthFix"
                    :src="data.showIcon">
            </div>
            <div class="restaurant-info">
                <p>
                    <span class="restaurant-name">{{data.storeName}}</span>
                </p>
                <p class="flex-wrp restaurant-price-grade">
                    <span class="flex-item restaurant-grade"><grade-star :value="data.grade"/></span>
                    <span v-show="data.average" class="flex-item restaurant-price">¥{{data.average}}/人</span>
                </p>
                <p class="flex-wrp restaurant-type-address">
                    <span class="restaurant-type">{{data.categoryName}}</span>
                    <span class="restaurant-address">{{data.floorNo}}</span>
                </p>
                <ul class="restaurant-tags" >
                    <li v-for="(item,key) in data.tags" :key="key">
                        <span class="ecllip" v-if="item !=''">{{item}}</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script>
import GradeStar from '@/components/GradeStar'
export default {
    components:{
        GradeStar
    },
    props:{
        data:{
            type: Object,
            default: {}
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.food-comp-container{
    .food-comp-con{
        display: flex;
        .item-img{
            margin-right: 10px;
            .restaurant-img{
                width: 100px;
                height: 100px;
            }
        }
        .restaurant-info{
            flex:1;
            padding-left: 5px;
            display: flex;
            flex-direction: column;
            p{
                &:last-child{
                    margin-bottom: 0;
                }
                .restaurant-name{
                    font-size: 15px;
                    color: #1E1E1E;
                    font-weight: bold;
                    margin-bottom: 10px;
                }
                &.restaurant-price-grade{
                    align-items: center;
                    .restaurant-grade{
                        flex: 0 1 auto;
                    }
                    .restaurant-price{
                        flex: 1;
                        margin-left: 17px;
                        font-size: 12px;
                        color: #929292;
                    }
                }
                &.restaurant-type-address{
                    justify-content: space-between;
                    font-size: 12px;
                    color: #929292;
                    flex:1;
                    span{
                        display: inline-block;
                        margin-top: 10px;
                    }
                }
            }
            .restaurant-tags{
                li{
                    display: inline-block;
                    max-width: 80px;
                    margin-right: 5px;
                    padding: 2px 6px;
                    font-size: 12px;
                    color: @theme-color;
                }
                .ecllip{
                    display: inline-block;
                    max-width: 80px;
                    padding: 2px 6px;
                    border: 1px solid;
                    font-size: 12px;
                    color: @theme-color;
                }
            }
        }
    }
}
</style>
