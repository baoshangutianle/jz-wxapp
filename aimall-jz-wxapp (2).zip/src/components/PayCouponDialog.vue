<template>
    <div class="pay-coupon-dialog" v-if="isShowDialog">
        <div class="box">
            <div class="coupon-box">
                <div
                    class="coupon-list-box"
                    v-for="(item,index) in list"
                    :key="item.id"
                    @click="checkboxClick(index)"
                    :style="{ 'opacity': (dedAmount >= payAmount || selcCount.length >= 3) && !item.checked ? 0.7 : 1 }"
                >
                    <div class="coupon-checkbox-box">
                        <img
                            style="width:18px;height:18px;"
                            v-show="!item.checked && (dedAmount < payAmount && selcCount.length < 3)"
                            src="/static/images/pay-unchecked.png"
                            alt
                        />
                        <img
                            style="width:18px;height:18px;"
                            v-show="item.checked"
                            src="/static/images/pay-checked.png"
                            alt
                        />
                        <img
                            style="width:18px;height:18px;"
                            v-show="!item.checked && (dedAmount >= payAmount || selcCount.length >= 3)"
                            src="/static/images/pay-lock.png"
                            alt
                        />
                    </div>
                    <div class="coupon-logo-box">
                        <img :src="item.couponfileUrl" alt />
                    </div>
                    <div class="coupon-msg-box">
                        <p class="coupon-title">{{item.couponName}}</p>
                        <!-- <p class="coupon-time">{{item.effectiveDate}}-{{item.expirationDate}}</p> -->
                        <p class="coupon-time">仅今日有效</p>
                    </div>
                </div>
            </div>
            <div class="btn-box">
                <button @click="couponSubmit">确定</button>
            </div>
        </div>
        <div>
            <img
                @click="closeClick()"
                class="btn-close"
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20200204/cb5bd737774b403ba8510cc51119e6a6.png"
                alt
            />
        </div>
    </div>
</template>

<script>
export default {
    props: {
        isShowDialog: {
            type: Boolean,
            default: () => {
                return false
            }
        },
        // 停车券列表数据
        payList: {
            type: Array,
            default: []
        },
        // 剩余支付金额
        payAmount: {
            type: Number,
            default: 0
        }
    },
    data() {
        return {
            list: this.payList,
            unSelect: false,
            // 抵扣金额
            dedAmount: 0
        }
    },
    onShow() {
        this.dedAmount = 0
    },
    computed: {
        selcCount: function() {
            var arr = []
            this.list.map(item => {
                if (item.checked == true) {
                    arr.push(item)
                }
            })
            return arr
        }
    },
    mounted() {},
    methods: {
        checkboxClick(index) {
            let t = this
            if (!t.list[index].checked && (t.dedAmount >= t.payAmount || this.selcCount.length >= 3)) {
                return
            }
            if (t.list[index].checked) {
                t.dedAmount -= t.list[index].amount
            } else {
                t.dedAmount += t.list[index].amount
            }
            t.list[index].checked = !t.list[index].checked
        },
        couponSubmit() {
            let t = this
            t.$emit('clickCouponSubmit', t.list)
            t.$emit('clickCouponClose', false)
        },
        closeClick() {
            let t = this
            t.$emit('clickCouponClose', false)
        }
    },
    watch: {
        payList(newVal) {
            if (newVal && newVal.length > 0) {
                this.list = newVal
            }
        }
    }
}
</script>

<style lang="less">
.pay-coupon-dialog {
    width: 100%;
    height: 100%;
    position: absolute;
    background: rgba(0, 0, 0, 0.8);
    top: 0;
    bottom: 0;
    z-index: 99999;
    .box {
        width: 80%;
        height: 400px;
        background: #fff;
        margin: 10% auto;
        z-index: 3;
        position: relative;
        .coupon-box {
            height: 300px;
            overflow: scroll;
        }
        .coupon-list-box {
            width: 80%;
            margin: 15px auto;
        }
        .coupon-checkbox-box {
            text-align: center;
            vertical-align: middle;
            display: inline-block;
            img {
                line-height: 50px;
                margin: 0;
                padding: 0;
            }
        }
        .coupon-logo-box {
            display: inline-block;
            vertical-align: middle;
            height: 50px;
            width: 50px;
            margin-left: 15px;
            img {
                height: 50px;
                width: 50px;
            }
        }
        .coupon-msg-box {
            display: inline-block;
            margin-left: 15px;
            vertical-align: middle;
            .coupon-title {
                font-size: 18px;
                font-weight: 600;
                color: rgba(51, 51, 51, 1);
                line-height: 28px;
            }
            .coupon-time {
                font-size: 12px;
                color: rgba(153, 153, 153, 1);
                line-height: 17px;
            }
        }
        .btn-box {
            background: rgba(255, 255, 255, 1);
            box-shadow: 0px 0px 4px 0px rgba(188, 188, 188, 0.3);
            border-radius: 0px 0px 4px 4px;
            padding: 30px 0;
            button {
                width: 275px;
                height: 44px;
                background: rgba(114, 197, 193, 1);
                border-radius: 4px;
                color: #fff;
            }
        }
    }
    .btn-close {
        width: 22px;
        height: 22px;
        margin: 0 auto;
    }
}
</style>
