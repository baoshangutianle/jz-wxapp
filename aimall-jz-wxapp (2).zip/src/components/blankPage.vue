<template>
    <div
        v-if="showBlankPage"
        id="blank-page"
    >
        <img src="/static/images/blank-page-icon.png">
        <!-- <span v-text="'没找到'+blankPageContent+'相关结果'" /> -->
        <span>抱歉，没找到相关结果~</span>
    </div>
</template>

<script>
export default {
    props: {
        showBlankPage: {
            type: Boolean,
            default: false
        },
        blankPageContent: {
            type: String,
            default: ''  //没找到“星球大战外…”相关结果
        }
    }
}
</script>

<style lang="less">
#blank-page {
    position: absolute;
    width: 100%;
    top: 150px;
    font-size: 15px;
    font-weight: 400;
    color: rgba(60, 60, 60, 1);
    display: flex;
    align-items: center;
    justify-content:center;
    img {
        width: 15px;
        height: 15px;
        margin-right: 10px;
    }
}
</style>
