<template>
    <div :style="{'background':gameBtnBoxBg}" 
         :class="{'parkour-bg':isParkour}"
         class="game-btn-bg">
        <button v-if="!isAuth && !vipInfo"
                :style="{'background':gameBtnBg}"
                :class="{'parkour':isParkour}"
                class="game-btn-start game-btn-authLogin">
            <auth-btn auth="user"
                      @pass="onGotUserInfo" />
            <span>授权登录</span>
        </button>
        <button v-if="vipInfo"
                :style="{'background':gameBtnBg}"
                :class="{'parkour':isParkour}"
                class="game-btn-start game-btn-startGame"
                @click="playGame">
            <span>开始游戏</span>
        </button>
        <button v-if="isAuth && !vipInfo"
                :style="{'background':gameBtnBg}"
                :class="{'parkour':isParkour}"
                class="game-btn-start game-btn-startGame">
            <auth-btn auth="phone"
                      @pass="getPhoneNumber" />
            <span>开始游戏</span>
        </button>

    </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import wxUtils from '@/plugins/wxUtils'
import AuthBtn from '@/components/AuthBtn'
import api from '@/plugins/api'
import request from '@/plugins/request'
import bigScreenGame from '@/plugins/bigScreenGame'

export default {
    components: {
        AuthBtn
    },
    props:{
        activityId:{
            type: Number,
            default: ()=>{
                return 1
            }
        },
        gameBtnBoxBg:{
            type: String,
            default: ()=>{
                return null;
            }
        },
        gameBtnBg:{
            type: String,
            default: ()=>{
                return null;
            }
        },
        isParkour: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            isAuth: null
        }
    },
    created(){
        //刷新session
        wxUtils.getUserSession()
        let userInfo = wxUtils.getUserStorage()
        userInfo ? (this.isAuth = true) : (this.isAuth = false)
        
    },
    mounted(){
    },
    computed: {
        ...mapState(['wxUserInfo', 'isVip', 'vipInfo', 'sessionId'])
    },
    methods:{
        ...mapMutations(['update']),
        onGotUserInfo(e) {
            this.isAuth = true
        },
        // 授权手机号登录
        getPhoneNumber(e) {
        },
        playGame(){
            let requestOptions = {
                path: api.checkLuckyDraw + this.activityId
            }
            request(requestOptions).then(res => {
                if (res.code == 200 || res.code == 0) {
                    if (res.ok) {
                        this.$emit('playGame',true)
                    }else{
                        this.$emit('playGame',false, res.message)
                    }

                }
            })
           
        },

    }
}
</script>

<style scoped lang="less">
.game-btn-bg {
    width: 168px;
    height: 168px;
    border-radius: 50%;
    // background: rgba(255, 115, 110, 0.18);
    display: flex;
    justify-content: center;
    align-items: center;
    &.parkour-bg {
        width: 200px;
        height: 200px;
    }
    .game-btn-start {
        position: relative;
        width: 138px;
        height: 138px;
        padding: 0;
        line-height: normal;
        // background: #ff736e;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        span {
            display: inline-block;
            width: 65px;
            font-size: 30px;
            color: #ffffff;
            letter-spacing: 2.38px;
        }
        &.parkour {
            background-image: url('https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/navigation/wxapp/start_game_btn.png');
            background-size: 100%,100%;
            width: 200px;
            height: 200px;
            top:243px;
        }
    }
}
</style>