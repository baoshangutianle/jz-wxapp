<template>
    <div class="coupon-item-conatiner">
        <!-- <div class="flex-item coupon-logo-wrap">
            <img src="/static/images/icon-coupon-small-bg1.png" alt="logo背景1" class="coupon-logo-bg">
            <img class="coupon-logo" :src="data.couponUrl" mode="scaleToFill" alt="">
        </div>
        <span class="flex-item coupon-item-info">
            <img src="/static/images/icon-coupon-small-bg2.png" alt="logo背景2" class="coupon-item-bg">
            <div class="flex-wrp coupon-item-info-wrap">
                <span class="flex-item coupon-item-info-con">
                    <div class="ecllip coupon-price">
                        {{data.couponType==6?data.couponName:(data.couponType==3?data.discount?data.discount+ '折':'' :(data.couponWorth+'元'))}}
                    </div>
                   <div v-if="data.shopNameList">
                       <div class="ecllip coupon-tip">{{data.shopNameList.length>2 || data.shopNameList.length==0?'通用券':data.shopNameList[0]}}</div>
                   </div>
                </span>
            </div>
        </span> -->
        <div class="coupon-list">
            <img src="https://img-cdn.aimall.cloud/as/20200601/9e0a9b7259e34abeb24ac4090546c568.png" class="coupon-list-bg">
            <div class="coupon-list-con">
                <div class="coupon-list-name">
                {{data.couponType==6?data.couponName:(data.couponType==3?data.discount?data.discount+ '折':'' :(data.couponWorth+'元'))}}
                </div>
                <div class="coupon-list-type" v-if="data.shopNameList">
                    <div class="ecllip coupon-tip">{{data.shopNameList.length>2 || data.shopNameList.length==0?'通用券':data.shopNameList[0]}}</div>
                </div>
            </div>
            <p class="coupon-btn"><button class="coupon-text">
                <auth-btn auth="user" @pass="goCouponDetail(data)" />
                立即抢券
            </button></p>
        </div>
    </div>
</template>

<script>
import AuthBtn from '@/components/AuthBtn'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
export default {
    props:{
        data:{
            type: Object,
            default: {}
        }
    },
    components: {
        AuthBtn
    },
    methods:{
        async goCouponDetail(data) {
            let { couponId, couponBatchId, couponName, chargeOffStatus } = data
            let params = {
                mallCode: this.mallCode,
                couponId: couponId,
                couponBatchId: couponBatchId
            }

            //埋点
            buryPoint.setF({
                id: pointCode.HOME_CARD,
                p_action_id: couponId,
                p_action: couponName
            })
            wx.navigateTo({
                url: `/pages/coupon/details?couponId=${couponId}&couponBatchId=${couponBatchId}`
            })
        },
    }
}
</script>

<style lang="less" scoped>
@import "../assets/styles/vars";
.coupon-item-conatiner{
    width: 100%;
    height: 100%;
    color: #fff;
    .coupon-list{
        position: relative;
        float: right;
    }

    .coupon-list-bg{
       width: 148px;
       height: 75px;
    }
    .coupon-list-con{
        position: absolute;
        z-index: 99;
        top: 0px;
        text-align: center;
        width: 100%;
        padding-top: 10px;
    }
    .coupon-list-name{
        font-size:15px;
        font-weight:500;
        color:#8B5EFB;
    }
    .coupon-list-type{
        font-size:12px;
        font-weight:400;
        color:#999999;
    }

    .coupon-btn{
    width: 148px;
    text-align: center;
    position: absolute;
    z-index: 99;
    top: 55px;
    }
.coupon-text{
    width:92px;
    height:28px;
    background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
    box-shadow:0px 2px 4px 0px rgba(0,0,0,0.12);
    border-radius:14px;

    font-size: 12px;
    color: #fff;
    font-weight: 400;
}
    .coupon-logo-wrap{
        position: relative;
        flex: 0 1 auto;
        display: flex;
        align-items: center;
        position: relative;
        background: #ffffff;
        padding: 6px 10px 6px 10px;
        .coupon-logo-bg{
            z-index: 1;
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: inline-block;
        }
        .coupon-logo{
            position: relative;
            z-index: 2;
            width: 47px;
            height: 47px;
        }
    }
    .coupon-item-info{
        overflow: hidden;
        position: relative;
        padding: 1px 0 1px 10px;
        background: #ffffff;
        .coupon-item-bg{
            z-index: 1;
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: inline-block;
        }
        .coupon-item-info-con{
            position: absolute;
            z-index: 2;
            overflow: hidden;
            margin-top: -1px;
            width: 98%;
        }
    }
    .coupon-item-info-wrap{
        height: 100%;
        margin-top: 11px;
        position: relative;
    }
    .coupon-price{
        font-size: 15px;
        line-height: 25px;
        font-weight: bold;
        color: #333333;
    }
    .coupon-tip{
        margin-top: 2px;
        font-size: 12px;
        line-height: 17px;
        white-space: nowrap;
        color: #333333;
    }
    .coupon-name{
        font-size: 14px;
        transform: scale(.8);
        transform-origin: 0 0;
        color: #333333;
    }
    .coupon-time{
        font-size: 12px;
    }
    .btn-wrp{
        display: flex;
        align-items: center;
        justify-content: flex-end;
        .btn-receive{
            width: 56px;
            height: 24px;
            padding: 0;
            border-radius: 12px;
            background: @theme-color;
            font-size: 12px;
            color: #fff;
            line-height: 24px;
            text-align: center;
        }
    }
}
</style>
