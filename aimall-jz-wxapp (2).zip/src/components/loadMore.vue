<template>
    <div class="reachText">
        <span class="reach-text">我是有底线的</span>
    </div>
</template>

<script>
export default {
    props: {
    // eslint-disable-next-line vue/require-default-prop
        data: {
            type: Object,
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.reachText {
    color: #e7e7e7;
    text-align: center;
    width: 100%;
    font-size: 14px;
    padding-top: 45px;
    letter-spacing: 1px;
    position: relative;
    padding-bottom: 30px;
}
.reach-text {
    display: block;
    position: relative;
    text-align: center;
}
.reach-text:before,
.reach-text:after {
    content: '';
    position: absolute;
    top: 50%;
    background: #f7f7f7;
    width: 32%;
    height: 1px;
}
.reach-text:before {
    left: 2%;
}
.reach-text:after {
    right: 2%;
}
</style>
