<template>
    <div class="qrcode-comp-conatiner">
        <view class="img-box">
            <image
                :src="imagePath"
                :style="{width:'100%',height:'100%'}"
                @tap="previewImg"
            />
        </view>

    </div>
</template>

<script>
import QR from '@/plugins/qrcode.js'
export default {
    // eslint-disable-next-line vue/require-prop-types
    props: ['data', 'width', 'height', 'frompage'],
    data() {
        return {
            imagePath: '',
            isShow: true
        }
    },
    watch: {
        data(newVal, oldVal) {
            if (newVal) {
                if (newVal.length > 0) {
                    this.generate()
                }
            }
        }
    },
    mounted() {
        if (this.data) {
            this.generate()
        }
    },
    onShow() {
        //为了防止从其他页面授权后不显示二维码
        if (this.data) {
            this.generate()
        }
    },
    methods: {
    //适配不同屏幕大小的canvas
        setCanvasSize: function() {
            var size = {};
            try {
                var res = wx.getSystemInfoSync();
                var scale = 750/686;//不同屏幕下canvas的适配比例；设计稿是750宽
                var width = res.windowWidth/scale + 28;
                var height = width;//canvas画布为正方形
                size.w = width;
                size.h = height;
            } catch (e) {
                // Do something when catch error
            }
            return size;
        },
        createQrCode: function(url, canvasId, cavW, cavH) {
            //调用插件中的draw方法，绘制二维码图片
            QR.api.draw(url, canvasId, cavW, cavH);
            setTimeout(() => { this.canvasToTempImage(); }, 1000);
        },
        //获取临时缓存照片路径，存入data中
        canvasToTempImage: function() {
            var that = this;
            wx.canvasToTempFilePath({
                canvasId: 'mycanvas',
                success: function(res) {
                    var tempFilePath = res.tempFilePath;
                    console.log(tempFilePath);
                    that.imagePath = tempFilePath
                },
                fail: function(res) {
                    console.log(res);
                }
            });
        },
        //点击图片进行预览，长按保存分享图片
        previewImg: function(e) {
            var img = this.imagePath;
            if (this.frompage === 'mimeIndex') {
                this.$emit('getimage', img)
            } else {
                wx.previewImage({
                    current: img, // 当前显示图片的http链接
                    urls: [img] // 需要预览的图片http链接列表
                })
            }
        },
        generate: function(url) {
            // 页面初始化 options为页面跳转所带来的参数
            var size = this.setCanvasSize();//动态设置画布大小
            var initUrl = this.data;
            this.createQrCode(initUrl, "mycanvas", size.w, size.h);
        },

    },
}
</script>

<style lang="less" scoped>
.qrcode-comp-conatiner {
    position: relative;
    height: 100%;
    // overflow: hidden;
    canvas {
        z-index: -1;
        position: absolute;
        top: 0;
        left: 0;
        opacity: 0;
    }
    .img-box {
        width: 100%;
        height: 100%;
    }
}
</style>
