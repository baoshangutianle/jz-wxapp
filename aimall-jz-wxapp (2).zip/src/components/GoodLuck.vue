<template>
        <div :class="['goodLuck','bottomPage',{'hAnimate':hAnimate}]"  >
            <div class="content">
                <div class="top">
                    <span class="name">晒好运</span>
                    <!-- <span class="close" @click="cancelPage">
                        <image src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/1e37b14de34544deba5509f2cd236616.png"/>
                    </span> -->
                </div>
                <ul>
                    <li class="share">
                        <button class="page" @click="cancelPage(1)" open-type="share">
                            <img
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/b6d728386cbb4f0ca5168d2d8d6d4e1d.png"
                            />
                        </button>
                        <button class="label"
                                open-type="share"
                            >分享给好友</button>
                        <!-- <div class="label">分享给好友</div> -->
                    </li>
                    <li class="download">
                        <div class="page" @click="downloadImg">
                            <img
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/717667ddedf44f9b90603982768e5f18.png"
                            />
                              <painter :customStyle="customStyle" @imgOK="getImg" :palette="prizeVos" :dirty="true" :isData="isData"/>
                            <div class="label">生成分享海报</div>
                        </div>
                    </li>
                </ul>
                <div class="good-close" @click="cancelPage">取消</div>
            </div>
        </div>
</template>

<script>
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
const customStyle = 'margin-left:40rpx'
export default {
    props: {
        prizeVos: {
            type: Object,
            default: {}
        },
        hAnimate: {
            type: Boolean,
            default: false
        },
        isData: {
            type: Boolean,
            default: false
        },
    },
    data() {
        return {
            ishide: false,
            postershare: false,
            bgImg: 'https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191125/acb7ef3d44c2482e947340474e49af14.png',
            shareImg: '',
            customStyle: customStyle,
            imgData: null,
            beShow: false,
            //isData: false
        }
    },
    onLoad(){
        //this.isData = false
    },
    methods: {
        cancelPage(data) {
            this.$emit("changeHeight")
        },
        downloadImg() {
            buryPoint.setF({
                id: pointCode.GASHAPON_RESULT_IMG_F
            })
            if(this.shareImg != ''){
                wx.saveImageToPhotosAlbum({
                    filePath: this.shareImg,
                    success: result => {
                        wx.showToast({
                            title: '海报已保存，快去分享给好友吧。',
                            icon: 'none'
                        })
                    },
                    fail: (err) => {
                        wx.showToast({
                            title: '保存失败',
                            icon: 'fail',
                            duration: 1500
                        })
                    }
                })
            }else{
                wx.showLoading({
                    title: '正在生成海报...',
                })
                this.isData = true
            }

        },
        getImg(e) {
            this.shareImg = e ? e.mp.detail.path : null
            if(this.isData){
                wx.saveImageToPhotosAlbum({
                    filePath: this.shareImg,
                    success: result => {
                        wx.showToast({
                            title: '海报已保存，快去分享给好友吧。',
                            icon: 'none'
                        })
                    },
                    fail: (err) => {
                        console.log(err)
                        wx.showToast({
                            title: '保存失败',
                            icon: 'fail',
                            duration: 1500
                        })
                    }
                })
            }
        }
    }
}
</script>

<style lang="less" scoped>
.hAnimate{
    height: 210px !important;
    position: fixed !important;
}
.goodLuck {
    position: absolute;
    bottom: -1px;
    height: 0;
    width: 100%;
    z-index: 200;
    overflow: hidden;
    background: #ffffff;
    // border-top-right-radius: 30rpx;
    // border-top-left-radius: 30rpx;
    .content {
        //padding: 4%;
        height: 100%;
        .top {
            height: 80rpx;
            // border-bottom: 1px solid #cacaca;
            //margin-bottom: 10px;
            text-align: center;
            padding-top: 20px;
            position: relative;

            .name {
                font-size: 18px;
                color: #333333;
                font-weight: 400;
                width: 100%;
                display: inline-block;
            }
            .close {
                width: 26px;
                height: 26px;
                position: absolute;
                z-index: 299;
                top: 25px;
                right: 20px;

                image {
                    width: 18px;
                    height: 18px;
                }
            }
        }
        ul {
            overflow: hidden;
            height: 80px;
            li {
                float: left;
                width: 50%;
                text-align: center;
                overflow: hidden;
                button {
                    background: #ffffff !important;
                }
                .page {
                    width: 100px;
                    overflow: hidden;
                    margin: 0 auto;
                    padding: 0;
                    img {
                        margin: 0 auto;
                        width: 40px;
                        height: 40px;
                        margin: 0 auto;
                    }
                }
                .label {
                    color: #666666;
                    font-size: 14px;
                    text-align: center;
                    line-height: 25px;
                    padding-top: 5px;
                }
            }
        }
    }
    .cancelPage {
        width: 100%;
        background: #fff;
        position: absolute;
        color: #333333;
        font-size: 18px;
        text-align: center;
        bottom: 0;
        padding: 4% 0;
    }
    .good-close{
        width: 100%;
        height: 86px;
        color: #666666;
        font-size: 20px;
        font-weight: 400;
        text-align: center;
        padding-top: 15px;
        border-top: solid 2px #F8F8F8;
    }
}
</style>
