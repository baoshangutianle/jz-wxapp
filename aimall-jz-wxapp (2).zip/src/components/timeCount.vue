<template>
    <div>{{countDownTimeString}}</div>
</template>

<script>
export default {
    components: {},
    props: {
        countDownTime: {
            type: Number,
            default: 0
        }
    },
    data() {
        return {
            countDownTimeString: '',
            countDownTimeCopy: 0,
            day: '',
            hour: '',
            branch: '',
            second: '',
            timer: null
        }
    },
    destroyed(){
        clearTimeout(this.timer)
    },
    methods: {
        dateformat(second) {
            // console.log(second)
            // 总秒数
            // let second = Math.floor(micro_second / 1000)
            // 天数
            let day = Math.floor(second / 3600 / 24)
            // 小时
            let hr = Math.floor((second / 3600) % 24)
            let hrStr = hr.toString()
            if (hrStr.length == 1) hrStr = '0' + hrStr
            // 分钟
            let min = Math.floor((second / 60) % 60)
            let minStr = min.toString()
            if (minStr.length == 1) minStr = '0' + minStr
            // 秒
            let sec = Math.floor(second % 60)
            let secStr = sec.toString()
            if (secStr.length == 1) secStr = '0' + secStr
            if (day < 1) {
                this.countDownTimeString = '剩余 ' + hrStr + ':' + minStr + ':' + secStr
            } else {
                this.countDownTimeString = '剩余 ' + day + ' 天 ' + hrStr + ':' + minStr + ':' + secStr
            }
            // console.log(this.countDownTimeString)
        },
        // 倒计时数组变更
        countDownArray() {
            const t = this
            clearTimeout(this.timer)
            t.secondsToDay(Number(t.countDownTimeCopy))
            // t.countDownTimeString = t.countDownTime - 1
            t.countDownTimeCopy--
            console.log(t.countDownTimeCopy)
            t.$forceUpdate()
            this.timer = setTimeout(() => {
                t.countDownArray()
            }, 1000)
        },
        // 秒转换为天时分秒
        secondsToDay(data) {
            const t = this
            var time = data
            console.log(time)
            if (null != time && '' != time) {
                if (time > 60 && time < 60 * 60) {
                    t.day = '00'
                    t.hour = '00'
                    t.branch = parseInt(time / 60.0)
                    t.second = parseInt((parseFloat(time / 60.0) - parseInt(time / 60.0)) * 60)
                    // time = '0天0时' + parseInt(time / 60.0) + '分' + parseInt((parseFloat(time / 60.0) - parseInt(time / 60.0)) * 60) + '秒'
                } else if (time >= 60 * 60 && time < 60 * 60 * 24) {
                    t.day = '00'
                    t.hour = parseInt(time / 3600.0)
                    t.branch = parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60)
                    t.second = parseInt((parseFloat((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60) - parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60)) * 60)
                    // time = '0天' + parseInt(time / 3600.0) + '时' + parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60) + '分' + parseInt((parseFloat((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60) - parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60)) * 60) + '秒'
                } else if (time >= 60 * 60 * 24) {
                    t.day = parseInt(time / 3600.0 / 24)
                    t.hour = parseInt((parseFloat(time / 3600.0 / 24) - parseInt(time / 3600.0 / 24)) * 24)
                    t.branch = parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60)
                    t.second = parseInt((parseFloat((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60) - parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60)) * 60)
                    // time = parseInt(time / 3600.0 / 24) + '天' + parseInt((parseFloat(time / 3600.0 / 24) - parseInt(time / 3600.0 / 24)) * 24) + '时' + parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60) + '分' + parseInt((parseFloat((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60) - parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60)) * 60) + '秒'
                } else {
                    t.day = '00'
                    t.hour = '00'
                    t.branch = '00'
                    t.second = parseInt(time)
                    // time = '0天0时0分' + parseInt(time) + '秒'
                }
            }
            console.log(t.second)
        },
        // 根据时间显示格式
        showDate() {
            this.day = parseInt(this.countDownTimeCopy / 86400)
            this.hour = parseInt(this.countDownTimeCopy / 3600) % 24
            this.branch = parseInt(this.countDownTimeCopy / 60) % 60
            this.second = this.countDownTimeCopy % 60
            // console.log(this.countDownTimeCopy % 60);
        }
    },
    created()  {
        var t = this // t.countDownTimeCopy = parseInt(t.countDownTime/1000); // 转成秒
        // t.countDownArray()
        // // t.countDownTimeCopy = t.countDownTime;
        // t.countDownTimeCopy = 100;
        // var t = this
        t.countDownTimeCopy = t.countDownTime
        t.$nextTick(() => {
            t.timer = setInterval(() => {
                t.countDownTimeCopy--
                if (t.countDownTimeCopy <= 0) {
                    clearTimeout(t.timer)
                    return
                } // 这里封装一个函数  用来处理数字变化以后 应该渲染上去的样式
                t.dateformat(t.countDownTimeCopy)
            }, 1000)
        })
    }
}
</script>

<style lang="less">
</style>
