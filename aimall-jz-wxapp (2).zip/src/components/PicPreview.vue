<template>
    <div class="pic-preview-container">
        <div v-show="isShow"
            catchtouchmove="preventTouchMove"
             class="value-point-mask">

            <div class="value-point-mask-con">
                <img :src="url"
                     class="value-point-mask-pic"
                     mode="aspectFit"
                     alt="图片">
            </div>

            <div class="value-point-mask-close"
                    @click="closePreview()">
                <img src="/static/images/point-close.png">
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data(){

    },
    props:['url','isShow'],
    methods:{
        closePreview(){
            this.$emit("update:isShow",false)
        }
    }
}
</script>

<style lang="less" scoped>
@import url(../assets/styles/vars);
.pic-preview-container{
    .value-point-mask{
        box-sizing: border-box;
        z-index: 2;
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: rgba(0,0,0,.7);
        text-align: center;
        overflow: hidden;
        .value-point-mask-close{
            padding-top: 26px;
                image{
                    display: inline-block;
                    width: 30px;
                    height: 30px;
                    &:active{
                        opacity: .8;
                    }
                }
            }
        .value-point-mask-con{
            position: relative;
            display: flex;
            flex-direction: column;
            width: 90vw;
            margin: 0 auto;
            background: #fff;
            margin-top: 30%;
            height: 70%;
            border-radius: 6px;
            .fail-con{
                overflow: hidden;
                padding-top: 25px;
                color: #333333;
                text-align: center;
                .fail-name{
                    // display: flex;
                    // align-items: center;
                    // justify-content: flex-start;
                    text-align: center;
                    font-size: 15px;
                    font-size: 18px;
                    color: #333333;
                    padding-bottom: 15px;
                    .icon-fail-info{
                        display: inline-block;
                        width: 20px;
                        height: 20px;
                        margin-right: 4px;
                    }
                }
                .fail-text{
                    font-size: 15px;
                    color: #333333;
                    font-weight: 200;
                    padding-bottom: 15px;
                }
            }
            .value-point-mask-pic{
                height: 90%;
                border: solid 1px #e7e7e7;
                margin: 15px auto;
                margin-top: 0px;
            }
            .btn-upload{
                height: 44px;
                line-height: 44px;
                margin: 35px 50px 0;
                font-size: 15px;
            }
            .btn-photo{
                display: inline-block;
                margin: 30px 0 60px;
                font-size: 15px;
                color: @theme-color;
            }
        }
    }
}
</style>
