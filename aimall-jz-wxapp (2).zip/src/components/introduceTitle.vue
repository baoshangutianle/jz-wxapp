<template>
    <p class="shopping_ptext">
        <span class="shopping_icon"></span>
        <span class="shopping_title">{{ text }}</span>
    </p>
</template>

<script>
export default {
    props: {
        text: {
            type: String,
            default: ''
        }
    }

}
</script>

<style scoped lang="less">
.shopping_ptext {
    position: relative;
    margin-bottom: 15px;
}
.shopping_title {
    color: #333333;
    font-weight: 500;
    font-size: 18px;
    margin-left: 15px;
}
.shopping_icon {
    position: absolute;
    top: 7px;
    left: 0px;
    width:4px;
    height:10px;
    background:rgba(119,199,198,1);
    border-radius:3px;
}

</style>
