<template>
    <div class="sel-enum-container">
        <view class='list-fix' @tap='outbtn' @touchmove="outbtn" v-if="mengShow"/>
        <div class="item-all">
            <div class="item-all-div" @click="clickShow">
                <span class="select-name">{{itemName}}</span>
                <span class="select-icon">
                    <img src="/static/images/arrow-down2.png"/>
                </span>
            </div>
            <div class="item-line"></div>
            <div class="item-ul">
                <ul>
                    <li :class="activeClass == i ?'active':''" v-for="(item,i) in itemAll" :key="i" @click="selectType(item,i)">{{item.name}}</li>
                </ul>
            </div>
        </div>
        <div>
            <scroll-view class="in-list brand_sel_enum" scroll-y v-if="isShow">
                <ul>
                    <li :class="selectItem == index ?'selectItem' :''"  v-for="(item,index) in itemList" :key="index" @click="select(item,index)">
                        <div class="brand_nav_li_text">
                            {{item.dictName}}
                            <img class="brand_nav_arrow" src="/static/images/icon-check.png" >
                        </div>
                    </li>
                </ul>
            </scroll-view>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        itemName: {
            type: String,
            default: ''
        },
        chargeOffStatus: {
            type: String,
            default: ""
        },
        outOfDate: {
            type: String,
            default: ""
        },
        itemAll:{
            type: Array,
            default: []
        },
        itemList: {
            type: Array,
            default: []
        }
    },
    data(){
        return{
            mengShow:false,//蒙层的显示与否
            isShow:false,
            showName: '',
            active: false,
            activeClass: 0,
            selectItem: 0,
        }
    },
    onLoad(){
        this.mengShow = false
        this.isShow = false
        this.showName = ''
        this.active = false
        this.activeClass = 0
        this.selectItem = 0
    },
    methods:{
        stopScroll(){
            return true
        },
        outbtn:function(e){
            this.hideAll()
        },
        select(data,index){
            this.selectItem = index;
            this.isShow = !this.isShow
            this.mengShow = !this.mengShow
            this.itemName = data.dictName
            const dictVal = {
                'dictValue':data.dictValue,
                'dictName':data.dictName
            }
            this.$emit('selectType',dictVal)

        },
        hideAll(){
        },
        selectType(item,index){
            this.activeClass = index
            if(index == 0){
                //可以用
                this.chargeOffStatus = 1
                this.outOfDate = 0
            }else if(index == 1){
                //已用
                this.chargeOffStatus = 2
                this.outOfDate = ''
            }else if(index == 2){
                //已过期
                this.chargeOffStatus = 1
                this.outOfDate = 1
            }
            let val = {
                "chargeOffStatus":this.chargeOffStatus,
                "outOfDate":this.outOfDate
            }
            this.$emit('change',val)
        },
        clickShow(){
            this.isShow = !this.isShow
            this.mengShow = !this.mengShow
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        wx.stopPullDownRefresh()
        this.mengShow = false
        this.isShow = false
        this.showName = ''
        this.active = false
        this.activeClass = 0
        this.selectItem = 0
    },
    watch:{
       typeData(newVal){
           if(newVal&&newVal.length>0){
               this.currType = newVal[0]
           }
       },
       buildingData(newVal){
           if(newVal&&newVal.length>0){
               this.currBuilding = newVal[0]
           }
       },
       floorData(newVal){
           if(newVal&&newVal.length>0){
               this.currFloor = newVal[0]
           }
       },
       moneyData(newVal){
           if(newVal&&newVal.length>0){
               this.currMoeny = newVal[0]
           }
       },
       isTypePopShow(newVal){
            if(newVal){
                this.popData = this.typeData
                this.curr = this.currType
                this.showName = 'type'
            }
            this.hideAll()
            this.$set(this.show,this.showName,newVal)
       },
       isBuildingPopShow(newVal){
           if(newVal){
                this.popData = this.buildingData
                this.curr = this.currBuilding
                this.showName = 'building'
            }
            this.hideAll()
            this.$set(this.show,this.showName,newVal)
       },
       isFloorPopShow(newVal){
            if(newVal){
                this.popData = this.floorData
                this.curr = this.currFloor
                this.showName = 'floor'
            }
            this.hideAll()
            this.$set(this.show,this.showName,newVal)
       },
    }
}
</script>

<style lang="less" scoped>
@import url(../assets/styles/vars);
.sel-enum-container{
    position: relative;
    .list-fix{
        background: rgba(0, 0, 0, 0.4);
        top: 50px;
    }
    .item-all{
        position: relative;
        height: 50px;
        border: solid 1px #EFF1F8;
        overflow: hidden;
        display: flex;
        .item-all-div{
            //padding: 13px 22px;
            color: #333333;
            font-size: 17px;
            height: 50px;
            line-height: 50px;
            padding-left: 22px;
        }
        .select-name{
            padding-right: 7px;
            vertical-align: middle;
        }
        .select-icon{
            width: 6px;
            height: 4px;
            display: inline-block;
            vertical-align: middle;
            img{
                width: 6px;
                height: 4px;
            }
        }
        .item-line{
            height: 36px;
            width: 1px;
            border-right: 1px solid #f2f2f2;
            padding-left: 30px;
            margin-top: 7px;
        }
        .item-ul{
            padding-left: 44px;
            flex: 1;
            line-height: 50px;
            ul{
                display: flex;
            }
            ul li{
                flex: 1;
                color: #999999;
                font-size: 17px;
                position: relative;
            }
        }
        .item-ul .active{
            color: #333333 !important;
        }
        .item-ul .active:after{
            position: absolute;
            bottom: 8px;
            left: 8px;
            right: 30px;
            transform: scale(1);
            display: block;
            content: '';
            height: 2px;
            background: #9975F3;
            transition: all 0.2s;
        }
    }
    .selectItem{
        color: #9975F3 !important;
        .brand_nav_arrow{
            display: inline-block !important;
        }
    }
    .brand_box{
        flex: 1;
        display: flex;
        overflow: hidden;
        width: 100%;
        height: 50px;
        border-bottom: 1px solid @border-color;
        .brand_nav{
            position: relative;
            overflow: hidden;
            flex: 1;
            height: 100%;
            color: #000;
            font-size:12px;
            // overflow-y: auto;
            // overflow-x: hidden;
            .brand_sel{
                position: relative;
                height: 100%;
                line-height: 50px;
                background: #fff;
                text-align: center;
                font-size: 15px;
                color: @black-color;
                border-bottom: 1px solid #ddd;
                padding: 0 15px;
                &:after{
                    display: inline-block;
                    content: '';
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    right: 0;
                    height: 20px;
                    width: 1px;
                    background: #ddd;
                }
                .brand_sel_text_wrap{
                    width: 100%;
                    height: 100%;
                    display: inline-block;
                    .brand_sel_text{
                        position: relative;
                        box-sizing: border-box;
                        width: 100%;
                        height: 100%;
                        padding-right: 16px;
                        box-sizing: none;
                        display: inline-block;
                        .brand_sel_text_2{
                            display: inline-block;
                        }
                    }
                }
                .brand_sel_arrow{
                    position: absolute;
                    top: 50%;
                    transform: translateY(-50%);
                    display: inline-block;
                    right: 6px;
                    display: inline-block;
                    width: 8px;
                    height: 5px;
                    img{
                        display: inline-block;
                        width: 100%;
                        height: 100%;
                    }
                }
            }
        }
        .brand_content{
            overflow: hidden;
            flex: 2;
            display: flex;
            flex-direction: column;
            .brand_type{
                height: 50px;
            }
            .brand_list{
                flex: 1;
                overflow-y: auto;
                z-index:9;
                .noMore{
                    text-align: center;
                    color: #999;
                    padding-bottom: 10px;
                }
            }
        }
    }
    .brand_sel{
        position: relative;
        height: 100%;
        line-height: 50px;
        background: #fff;
        text-align: center;
        font-size: 15px;
        color: @black-color;
        border-bottom: 1px solid #ddd;
        padding: 0 15px;
        &:after{
            display: inline-block;
            content: '';
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            right: 0;
            height: 20px;
            width: 1px;
            background: #ddd;
        }
        .brand_sel_text_wrap{
            width: 100%;
            height: 100%;
            display: inline-block;
            .brand_sel_text{
                position: relative;
                box-sizing: border-box;
                width: 100%;
                height: 100%;
                padding-right: 16px;
                box-sizing: none;
                display: inline-block;
                .brand_sel_text_2{
                    display: inline-block;
                }
            }
        }
        .brand_sel_arrow{
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            display: inline-block;
            right: 6px;
            display: inline-block;
            width: 8px;
            height: 5px;
            img{
                display: inline-block;
                width: 100%;
                height: 100%;
            }
        }
    }
    .brand_sel_enum{
        position: absolute;
        top: 50px;
        box-sizing: border-box;
        max-height: 200px;
        background: #fff;
        overflow: auto;
        z-index: 999;
        width: 100%;
        margin-top: 0px;
        box-shadow: 0 3px 8rpx rgba(0, 0, 0, 0.1);
        .slide-ul{
            position: relative;
        }
        li{
            height: 50px;
            padding: 0 15px;
            line-height: 50px;
            font-size: 14px;
            color: #333333;
            display: flex;
            .brand_nav_li_text{
                position: relative;
                width: 100%;
                border-bottom: 1px solid @border-color;
                .brand_nav_arrow{
                    position: absolute;
                    top: 50%;
                    right: 0;
                    transform: translateY(-50%);
                    width: 24rpx;
                    height: 18rpx;
                    display: none;
                }
            }
            &.brand_nav_active{
                color: @theme-color;
            }
        }
    }
    .filter-title-text-wrap{
        overflow: hidden;
        font-size:15px;
        color: #333;
        line-height: 50px;
        text-align: center;
        position: relative;
        display: flex;
        padding: 0 15px;
        justify-content: center;
        align-items: center;
        &>div{
            position: relative;
            display: inline-block;
            padding-right: 23px;
            height: 100%;
            overflow: hidden;
        }
        .filter-title-text{
            box-sizing: border-box;
            display: inline-block;
            width: 100%;
        }
        .filter-title-img{
            position: absolute;
            top: 50%;
            display: inline-block;
            right: 6px;
            transform: translateY(-50%);
            img{
                width: 8px;
                height: 5px;
            }
        }
    }
}
</style>
