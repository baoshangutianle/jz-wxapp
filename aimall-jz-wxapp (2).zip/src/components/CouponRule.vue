<template>
    <div class="coupon-rule-container">
        <div class="card-item card-preferential">
            <div>
                <p class="instructions_title">
                    <span class="instructions_line"></span>
                    <span class="instructions_pl">优惠详情</span>
                </p>
                <div class="card-preferential-condition card-rule-list">

                    <!-- <div>
                        <span>1.</span>
                        <span v-if="data.couponType == '1'">现金券</span>
                        <span v-if="data.couponType == '2'">满减券</span>
                        <span v-if="data.couponType == '3'">满折券</span>
                        <span v-if="data.couponType == '4'">停车券</span>
                        <span v-if="data.couponType == '5'">积分券</span>
                        <span v-if="data.couponType == '6'">礼品券</span>
                    </div>
                    <div>
                        <span> 2.</span>
                        <span v-if="data.couponType !='3'">价值{{ data.couponWorth }}元</span>
                        <span v-else>{{ data.discount }}折</span>
                    </div> -->
                    {{data.couponDesc}}
                </div>
                <!-- <div class="card-preferential-condition">
                    适用品牌：zara
                </div> -->
            </div>
            <!-- <div v-if="type!='detail'">
                <img v-if="data.status==1" class="card-status" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191107/d0224ab3a5e94a8aa32fd826f43fc098.png" alt="状态图片">
                <img v-else class="card-status" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191107/6f3e8ab3bad94844bfc9a11460a069d2.png" alt="状态图片">
            </div> -->

        </div>
        <div class="card-bg"></div>
        <div class="card-item card-rule">
            <div>
                <div class="card-item-tit">
                    <p class="instructions_title">
                        <span class="instructions_line"></span>
                        <span class="instructions_pl">使用规则</span>
                    </p>
                </div>
                <div class="card-rule-list card-rule-use">
                    <span v-html="data.useRuleDesc" />
                    <!-- {{data.useRuleDesc}} -->
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        data: {
            type: Object,
            default: {}
        },
        type: {
            type: String,
            default: ''
        }
    },
    data() {
        return {
            status: 2,
            useRuleDesc: '',
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.coupon-rule-container {
    .card-bg{
        width: 100%;
        height: 12px;
        background: #F4F4F4;
    }
    .card-item {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        border-top: 1px solid @border-color;
        padding: 0 15px;
        &.card-rule {
            padding-bottom: 0;
        }
        .card-preferential-condition {
            margin-top: 10px;
            font-size: 18px;
            color: @dark-color;
            font-weight: 200;
        }
        .card-rule-list {
            margin-top: 10px;
            font-size: 18px;
            color: @dark-color;
            font-weight: 200;
            padding-left: 5px;
            padding-bottom: 10px;
            span {
                font-size: 14px !important;
                line-height: 24px;
                color: #666666;
                font-weight: 300;
            }
        }
        .card-rule-use{
            padding-bottom: 100px;
        }
        .card-status {
            position: absolute;
            top: 50%;
            right: 0;
            transform: translateY(-50%);
            display: inline-block;
            width: 95px;
            height: 73px;
        }
    }
    .instructions_title{
        padding-top: 16px;
        color: #333333;
        font-size: 15px;
    }
    .instructions_line{
        width: 2px;
        height: 10px;
        border-radius:2px;
        background: #9975F3;
        display: inline-block;
    }
    .instructions_pl{
        padding-left: 6px;
        color: #333333;
        font-size: 15px;
    }
    .card-rule-use{
        margin-top: 0px !important;
        padding-top: 15px !important;
    }
}
</style>
