<template>
    <div class="phone-auth-container">
        <button class="btn-auth"
            open-type="getPhoneNumber"
            lang="zh_CN"
            @getphonenumber="getPhoneNumber">
            {{text}}
        </button>
    </div>
</template>

<script>
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils'
import api from '@/plugins/api'
export default {
    props: {
        text: {
            type: String,
            default: ''
        }
    },
    methods: {
        // 授权手机号登录
        getPhoneNumber(e) {
            if(e.mp.detail.errMsg == "getPhoneNumber:ok"){
                let vm = this
                vm.$emit("afterBind",e.mp.detail)
            }else{
                // 用户按了拒绝按钮
                wx.showModal({
                    title: '温馨提示',
                    content: '您还没有授权登录无法享受我们的会员福利啦～',
                    showCancel: false,
                    confirmText: '知道了'
                })
            }

        }
    }
}
</script>


<style lang="less" scoped>
.phone-auth-container{
    position: relative;
    height: 100%;
    .phone-auth-decor{
        height: 100%;
    }
    .btn-auth{
        z-index: 2;
        opacity: 0;
        position: absolute;
        display: inline-block;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
    }
}
</style>
