<template>
    <div class="user-auth-container">
        <button class="btn-auth"
                open-type="getUserInfo"
                lang="zh_CN"
                @getuserinfo="bindGetUserInfo">
            {{text}}
        </button>
    </div>
</template>

<script>
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils'
import api from '../plugins/api'

export default {
    props: {
        text: {
            type: String,
            default: ''
        }
    },
    methods: {
        bindGetUserInfo(e){
            let vm = this
            if (e.mp.detail.errMsg == "getUserInfo:ok") {
                vm.$emit("afterBind",e.mp.detail)
            } else {
                // 用户按了拒绝按钮
                wx.showModal({
                    title: '温馨提示',
                    content: '您还没有授权登录无法享受我们的会员福利啦～!',
                    showCancel: false,
                    confirmText: '知道了'
                })
            }
        },
        saveUserInfo(cb){
            let appid = wxUtils.getAppId()
            let sessionKey = wxUtils.getSessionKeyStorage()
            let wxUser = wxUtils.getUserStorage()
            let {signature,rawData,encryptedData,iv}  = wxUser
            let params = {
                // appid,
                openId: wxUtils.getOpenIdStorage(),
                sessionKey,
                signature,
                rawData,
                encryptedData,
                iv
            }
            let requestOptions = {
                path: api.saveUserInfo,
                method: 'get',
                data: params
            }
            request(requestOptions).then(res=>{
                if (res.code == 200) {
                    cb&&cb.call(null)
                }else{
                    let msg = res.message
                    wxUtils.showConfirmMsg(msg)
                }
            })
        }
    }
}
</script>


<style lang="less" scoped>
.user-auth-container{
    position: relative;
    height: 100%;
    .user-auth-decor{
        height: 100%;
    }
    .btn-auth{
        z-index: 2;
        opacity: 0;
        position: absolute;
        display: inline-block;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
    }
}
</style>
