<template>
    <div id="popularSuccess">
        <!-- 活动信息 -->
        <div class="content">
            <!-- <img
                style="width: 80px;"
                mode="widthFix"
                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20190911/5b94913ab7af41109d8d4cf660433929.png"
            /> -->
            <img
                style="width: 80px;"
                mode="widthFix"
                src="/src/static/images/submitSuccess.png"
            />
            <p class="success">提交成功</p>
            <p class="msg">请留意活动开始时间以免错过精彩活动</p>
            <button @click="goHome" class="back">返回首页</button>
            <p class="go-activity" @click="goMyActivity">查看更多活动</p>
        </div>
    </div>
</template>

<script>
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import wxUtils from '@/plugins/wxUtils'
export default {
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            mobile: wxUtils.getPhoneStorage(),
            username: '',
            status: 'success'
        }
    },
    onShow() {
        // 埋点
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.ACTIVITY_SIGN_UP_SUCCESS_P
        })
    },
    onUnload() {
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        // 埋点
        buryPoint.setZ({
            id: pointCode.ACTIVITY_SIGN_UP_SUCCESS_Z,
            p_stay_time: this.pageStayTime
        })
    },
    methods: {
        goHome() {
            buryPoint.setF({
                id: pointCode.ACTIVITY_SIGN_UP_SUCCESS_GOHOME_F,
            })
            wx.reLaunch({
                url: '/pages/home'
            })
        },
        goMyActivity() {
            buryPoint.setF({
                id: pointCode.ACTIVITY_SIGN_UP_SUCCESS_F,
            })
            // wx.redirectTo({
            //     //url: `/pages/listOfActivities/signUpDetail?id=${this.$root.$mp.query.id}`
            //     url: `/pages/listOfActivities/myActivity?status=2&id=${this.$root.$mp.query.id}&type=goDetail`
            // })
             wx.reLaunch({
                url: '/pages/home?pageId=goActivities'
            });
        }
    }
}
</script>

<style lang="less" scoped>
#popularSuccess {
    padding: 15px;
    .content {
        width: 100%;
        margin: 0;
        padding: 0;
        text-align: center;
        img {
            width: 84px;
            height: 84px;
            border-radius: 50%;
            margin: 30px auto;
        }
        .success {
            font-size: 18px;
            font-weight: 500;
            color: rgba(51, 51, 51, 1);
        }
        .msg {
            width: 168px;
            margin: 20px auto;
        }
        button {
            // background: rgba(114, 197, 193, 1);
            background: #9975F3;
            height: 50px;
            line-height: 50px;
            color: #fff;
            border-radius: 25px;
        }
        .go-activity {
            color: #9975F3;
            font-size: 18px;
            font-weight: 400;
            margin-top: 30px;
        }
    }
}

</style>
