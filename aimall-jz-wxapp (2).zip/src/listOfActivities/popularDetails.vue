<template>
    <div id="popularPurchaseDetails">
        <div v-show="isShareShow" class="actives-deail">
            <img :src="detailData.thumbnail" class="activies-img" />
            <p class="actives-title">{{ detailData.activityName }}</p>
            <!-- <div class="actives-oper">
                <span style="float: right;color: #333;">
                    <share />
                    <img src="/static/images/icon_share.png"/>
                    <span style="font-size: 15px;margin-left: 15px;">分享</span>
                </span>
            </div>-->
            <div class="actives-oper">
                <span style="float: right;color: #333;" @click="sharePage">
                    <img src="/static/images/icon_share.png" />
                    <span style="font-size: 15px;margin-left: 15px;">分享</span>
                </span>
            </div>
            <div class="pop-bg"></div>
            <div class="user-msg-box">
                <p class="title">报名时间</p>
                <p class="msg">{{detailData.applyStartTime}} 至 {{detailData.applyEndTime}}</p>
                <p class="title">活动开始时间</p>
                <p class="msg">{{ detailData.startTime }} 至 {{detailData.endTime}}</p>
                <p class="title">活动地点</p>
                <p class="msg">{{detailData.activitySite}}</p>
                <p class="title">开放名额</p>
                <p class="msg">共{{detailData.openPlace}}人</p>
                <p class="title" v-if="detailData.applyType != '1'">使用积分</p>
                <div v-if="detailData.applyType != '1'">
                    <div class="table">
                        <div class="tr">
                            <div class="th" style="width: 200px;color:#666;border-right: none;">
                                <span>卡等级</span>
                            </div>
                            <div class="th" style="width: 200px;color:#666">
                                <span>消费积分</span>
                            </div>
                        </div>
                        <div
                            v-for="item in detailData.mmcApplyActivityIntegralRuleVOs"
                            :key="item.integralGradeId"
                            class="tr"
                        >
                            <div
                                class="td"
                                style="display:inline-block;width: 200px;border-right: none;"
                            >
                                <span>{{item.integralGradeName}}</span>
                            </div>
                            <div class="td" style="display:inline-block;width: 200px;">
                                <span>{{item.integral ? item.integral : '0'}}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pop-bg"></div>
            <div class="actives-con">
                <p class="instructions_title">
                    <span class="instructions_line"></span>
                    <span class="instructions_pl">活动详情</span>
                </p>

                <wxParse :content="detailData.applyActivityDetail" :image-prop="imageProp" />
            </div>
        </div>
        <div class="footer">
            <!-- 即将开始 -->
            <div v-show="detailData.statusButton == '0'" class="activity-over-box">
                <span class="activity-over activity-button">即将开始</span>
            </div>
            <!-- 立即报名 -->
            <div v-show="detailData.statusButton == '1'" class="activity-sign-up-box">
                <span class="activity-sign-up">
                    <span
                        :class="detailData.applyType == '1' ? 'activity-coupon-small' : 'activity-coupon'"
                        class="activity-coupon activity-button"
                    >{{ detailData.applyType == '1' ? '免费活动' : detailData.applyIntegral ? detailData.applyIntegral+ '积分' : '0' + '积分' }}</span>
                    <span @click="goSignUp" class="sign-up-btn activity-button">立即报名</span>
                </span>
            </div>
            <!-- 去签到 -->
            <div v-show="detailData.statusButton == '3'" class="activity-sign-in-box">
                <span class="activity-sign-in activity-button" @click="goMyActivity">去签到</span>
            </div>
            <!-- 查看报名状态 -->
            <div v-show="detailData.statusButton == '2'" class="activity-status-box">
                <span class="activity-status activity-button" @click="goMyActivity">查看报名状态</span>
            </div>
            <!-- 报名结束 -->
            <div v-show="detailData.statusButton == '5'" class="activity-over-box">
                <span class="activity-over activity-button">报名结束</span>
            </div>
            <!-- 活动已结束 -->
            <div v-show="detailData.statusButton == '6'" class="activity-over-box">
                <span class="activity-over activity-button">活动已结束</span>
            </div>
            <!-- 签到成功 -->
            <div v-show="detailData.statusButton == '4'" class="activity-over-box">
                <span class="activity-over activity-button">签到成功</span>
            </div>
        </div>
        <div class="maskPage" v-if="maskFalg">
            <div class="posterPage" v-show="posterFalg">
                <img
                    class="close"
                    @click="cancelPage"
                    src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191114/d856597f8f3148faacf920e9fe6120bf.png"
                />
                <img class="img" :src="detailData.thumbnail" />
                <div class="content">
                    <div class="topPage">
                        <div class="titlePage">
                            <div class="title">{{detailData.activityName}}</div>
                            <div class="text">{{detailData.activityDesc}}</div>
                            <!-- <div class="logo">
                               <img src="http://img1.uat1.rs.com/g2/M00/01/D0/CgsZkF3NAmSAJA74AAD_CbJw6-4426.jpg!"/>
                               <span>南海嘉洲广场</span>
                            </div>-->
                        </div>
                        <div class="qrcode">
                            <img :src="qrcoeUrl" />
                            <div class="des" style="margin-top:20rpx;">{{desTextOne}}</div>
                            <div class="des">{{desTextTwo}}</div>
                        </div>
                    </div>
                    <div class="saveImg" @click="saveImg">保存图片</div>
                </div>
            </div>
            <!-- <div style="width:100%;height:100%;position: absolute;z-index:99999">
                <image :src='shareImg' style="width:100%;height:100%"/>
            </div>-->
        </div>

        <!-- 晒好运 -->
        <div :class="['goodLuck','bottomPage',{'hAnimate':hAnimate}]">
            <div class="content">
                <div class="top">
                    <span class="name">分享活动</span>
                </div>
                <ul>
                    <li class="share">
                        <button class="page" @click="cancelPage(1)" open-type="share">
                            <img
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/b6d728386cbb4f0ca5168d2d8d6d4e1d.png"
                            />
                        </button>
                        <button class="label" open-type="share">分享给好友</button>
                    </li>
                    <li class="download">
                        <div class="page" @click="downloadImg">
                            <img
                                src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191127/717667ddedf44f9b90603982768e5f18.png"
                            />
                            <painter @imgOK="getImg" :palette="templateBill" />
                            <div class="label">生成分享海报</div>
                        </div>
                    </li>
                </ul>
                <div class="good-close" @click="cancleShare">取消</div>
            </div>
        </div>
    </div>
</template>

<script>
import wxParse from 'mpvue-wxparse'
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import collectComp from '@/components/CollectComp'
import share from '@/components/ShareBtn'
import moment from 'moment'
import { mapState, mapMutations } from 'vuex'
export default {
    components: {
        wxParse,
        share,
        collectComp
    },
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            detailData: {},
            article: '<div>我是HTML代码</div>',
            contentId: '',
            contentType: 1,
            imageProp: {
                mode: 'widthFix'
            },
            p_url: '0',
            isShareShow: false,
            maskFalg: false,
            posterFalg: false,
            //hAnimate: 0,  //下划框高度
            qrcoeUrl: '', //小程序码地址
            shareImg: '',
            desTextOne: '长按识别进入',
            desTextTwo: '小程序参加活动',
            canvasFalg: true,
            isImgOk: false,
            hAnimate: false,
            isData: false,
            template: {},
            templateBill: {},
            activityDesTop: '',
            qrcoeUrlTop: '',
            desTextOneTop: '',
            desTextTwoTop: ''
        }
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo', 'isLogined'])
    },
    onShow() {
        // 埋点
        this.pageStayTime = new Date().getTime()
        if (typeof this.$root.$mp.query.share != 'undefined' && this.$root.$mp.query.share == '1') {
            this.p_url = 1
        }
        buryPoint.setP({
            id: 45,
            p_url: this.p_url
        })
        this.template = {}
        this.shareImg = ''
        this.hAnimate = false
        this.getDetailById()
    },
    onUnload() {
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        this.cancelPage()
        // 埋点
        buryPoint.setZ({
            id: 46,
            p_stay_time: this.pageStayTime
        })
        // this.template = {}
        this.canvasFalg = false
    },
    methods: {
        ...mapMutations(['update']),

        /**
         * @description printer 图片绘制路径回调
         */
        getImg(e) {
            this.shareImg = e ? e.mp.detail.path : null
            this.templateBill = {}
        },

        /**
         * @description 海报图片保存到本地相册操作
         * @return
         */
        saveImg() {
            if (this.shareImg != '') {
                wx.saveImageToPhotosAlbum({
                    filePath: this.shareImg,
                    success: result => {
                        wx.showToast({
                            title: '海报已保存，快去分享给好友吧。',
                            icon: 'none'
                        })
                    },
                    fail: err => {
                        wx.showToast({
                            title: '保存失败',
                            icon: 'fail',
                            duration: 1500
                        })
                    }
                })
            } else {
                wx.showLoading({
                    title: '正在生成海报...'
                })
                this.isData = true
            }
        },

        /**
         * @description canvas 图片信息绘制 样式设置
         * @return {Object} template
         */
        drawnCanvas() {
            const t = this
            //console.log('这里是绘制样式开始')
            //console.log(t.detailData.thumbnail)
            //t.detailData.activityName = '真好看好看好看好看就好看看见好看就好看好看阿斯顿发啥发的啥饭'
            //t.detailData.activityDesc = ''
            if (t.detailData.activityName.trim().length / 21 > 1) {
                t.activityDesTop = '520rpx'
                //多行活动简介
                if (t.detailData.activityDesc && t.detailData.activityDesc.trim().length / 21 > 1 && t.detailData.activityDesc.trim().length / 21 < 2) {
                    //console.log(666)
                    t.qrcoeUrlTop = '640rpx'
                    t.desTextOneTop = '910rpx'
                    t.desTextTwoTop = '955rpx'
                } else if (t.detailData.activityDesc && t.detailData.activityDesc.trim().length / 21 > 2) {
                    //console.log(444)
                    t.qrcoeUrlTop = '670rpx'
                    t.desTextOneTop = '940rpx'
                    t.desTextTwoTop = '980rpx'
                } else if (t.detailData.activityDesc && t.detailData.activityDesc.trim().length / 21 < 1) {
                    //console.log(555,1)
                    t.qrcoeUrlTop = '590rpx'
                    t.desTextOneTop = '860rpx'
                    t.desTextTwoTop = '900rpx'
                } else {
                    //console.log(12123)
                    t.qrcoeUrlTop = '540rpx'
                    t.desTextOneTop = '800rpx'
                    t.desTextTwoTop = '840rpx'
                }
            } else {
                t.activityDesTop = '490rpx'
                //console.log(t.detailData.activityDesc,888)
                //多行活动简介
                if (t.detailData.activityDesc && t.detailData.activityDesc.trim().length / 2 > 1 && t.detailData.activityDesc.trim().length / 21 < 2) {
                    //console.log(111)
                    t.qrcoeUrlTop = '620rpx'
                    t.desTextOneTop = '890rpx'
                    t.desTextTwoTop = '930rpx'
                } else if (t.detailData.activityDesc && t.detailData.activityDesc.trim().length / 21 > 2) {
                    //console.log(2222)
                    t.qrcoeUrlTop = '640rpx'
                    t.desTextOneTop = '910rpx'
                    t.desTextTwoTop = '950rpx'
                } else if (t.detailData.activityDesc && t.detailData.activityDesc.trim().length / 21 < 1) {
                    //console.log(333,t.detailData.activityDesc.trim().length /21)
                    t.qrcoeUrlTop = '540rpx'
                    t.desTextOneTop = '810rpx'
                    t.desTextTwoTop = '850rpx'
                } else {
                    //console.log(777,t.detailData.activityDesc.trim().length /21)
                    t.qrcoeUrlTop = '520rpx'
                    t.desTextOneTop = '790rpx'
                    t.desTextTwoTop = '820rpx'
                }
            }
            // 绘制样式
            t.template = {
                width: '375px',
                height: '670px',
                background: '#ffffff',
                views: [
                    {
                        type: 'image',
                        url: t.detailData.thumbnail,
                        css: {
                            width: '375px',
                            height: '400rpx',
                            top: '0px'
                        }
                    },
                    {
                        type: 'text',
                        text: t.detailData.activityName.trim(),
                        css: {
                            left: '40rpx',
                            top: '420rpx',
                            width: '340px',
                            fontSize: '32rpx',
                            fontWeight: 500,
                            // color: "#333333",
                            lineHeight: '40rpx',
                            maxLines: '2'
                        }
                    },
                    {
                        type: 'text',
                        text: t.detailData.activityDesc.trim(),
                        css: {
                            left: '40rpx',
                            // top: t.detailData.activityName.trim().length / 16 > 1 ? '470rpx' : '430rpx',
                            top: t.activityDesTop,
                            width: '340px',
                            fontSize: '28rpx',
                            color: '#666666',
                            lineHeight: '40rpx',
                            breakWord: 'true',
                            maxLines: '3'
                        }
                    },
                    {
                        type: 'image',
                        url: t.qrcoeUrl,
                        css: {
                            left: '252rpx',
                            right: 0,
                            //top: '590rpx',
                            top: t.qrcoeUrlTop,
                            width: '230rpx',
                            height: '230rpx',
                            margin: 'auto',
                            borderWidth: '12rpx',
                            borderStyle: 'solid',
                            borderColor: '#F4F4F4',
                            borderRadius: '2rpx'
                        }
                    },
                    {
                        type: 'text',
                        text: t.desTextOne,
                        css: {
                            right: 0,
                            lineHeight: '30rpx',
                            //top: '850rpx',
                            top: t.desTextOneTop,
                            width: '375px',
                            textAlign: 'center',
                            fontSize: '14px',
                            color: '#999999'
                        }
                    },
                    {
                        type: 'text',
                        text: t.desTextTwo,
                        css: {
                            textAlign: 'center',
                            lineHeight: '30rpx',
                            //top: '890rpx',
                            top: t.desTextTwoTop,
                            width: '375px',
                            fontSize: '14px',
                            color: '#999999'
                        }
                    }
                ]
            }
            t.templateBill = t.template
            console.log('这里是绘制样式结束')
        },

        /**
         * @description 分享点触事件 底部框弹出 cavans图片信息绘制
         * @return
         */
        sharePage() {
            this.canvasFalg = true

            this.hAnimate = true
        },
        downloadImg() {
            wx.showToast({ title: '图片生成中...', icon: 'loading', duration: 2000 })
            setTimeout(() => {
                this.hAnimate = false
                this.posterFalg = true
                this.maskFalg = true
            }, 2000)
            this.drawnCanvas()
        },
        cancleShare() {
            wx.hideLoading()
            this.isData = false
            this.hAnimate = false
        },

        /**
         * @description 底部框关闭操作
         * @return
         */
        closePage() {
            this.template = {}
        },

        /**
         * @description 取消操作
         */
        cancelPage() {
            this.closePage()
            this.template = {}
            this.maskFalg = false
            this.posterFalg = false
        },

        /**
         * @description 点击生成分享海报
         * @return
         */
        posterClick() {
            // 海报预览界面内容展示
            wx.showToast({ title: '图片生成中...', icon: 'loading', duration: 2000 })
            setTimeout(() => {
                this.posterFalg = true
            }, 2000)
            this.closePage()
        },

        /**
         * @description 获取活动详情id
         * @return
         */
        getDetailById() {
            let t = this
            let id = t.$root.$mp.query.id || 17
            t.contentId = id
            // let opsiton = { path: api.getCmsContentById + id }
            wx.request({
                url: api.getMmcApplyActivity + '/' + id,
                method: 'GET',
                data: null,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code === 200) {
                        t.isShareShow = true
                        res.data.data.createTime = moment(res.data.data.createTime).format('YYYY-MM-DD HH:mm')
                        res.data.data.startTime = moment(res.data.data.startTime).format('YYYY-MM-DD HH:mm')
                        res.data.data.endTime = moment(res.data.data.endTime).format('YYYY-MM-DD HH:mm')
                        res.data.data.applyStartTime = moment(res.data.data.applyStartTime).format('YYYY-MM-DD HH:mm')
                        res.data.data.applyEndTime = moment(res.data.data.applyEndTime).format('YYYY-MM-DD HH:mm')
                        if (res.data.data.mmcApplyActivityIntegralRuleVOs) {
                            let busString = ''
                            res.data.data.mmcApplyActivityIntegralRuleVOs.forEach((item, index) => {
                                busString += item.integralGradeName + '会员' + item.integral + '积分'
                                if (index != res.data.data.mmcApplyActivityIntegralRuleVOs.length - 1) {
                                    busString += '、'
                                }
                            })
                            res.data.data.couponRuleText = busString
                        }
                        t.detailData = res.data.data
                        t.contentId = t.detailData.id
                        t.getQrcode()
                    } else if (res.data.code === 4000) {
                        wx.navigateTo({
                            url: `/listOfActivities/shareAuth?id=${t.$root.$mp.query.id}`
                        })
                    } else if (res.data.code === 4001) {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                let oldIsLogined = t.isLogined
                                wxUtils.clearLoginStorage()
                                t.update({
                                    vipInfo: null,
                                    sessionId: '',
                                    isLogined: oldIsLogined
                                })
                                wx.navigateTo({
                                    url: `/pages/auth/index`
                                })
                            }
                        })
                    } else {
                        wx.showModal({
                            title: '温馨提示',
                            content: res.data.message,
                            showCancel: false,
                            confirmText: '确认',
                            confirmColor: '#4694FA',
                            success(res) {
                                wx.redirectTo({
                                    url: `/listOfActivities/popularList`
                                })
                            }
                        })
                    }
                }
            })
        },

        /**
         * @description 获取小程序码
         * @return
         */
        getQrcode() {
            const t = this
            let id = this.$root.$mp.query.id || 17
            wx.request({
                url: api.getQrcodeUrl + '?id=' + id,
                method: 'GET',
                data: null,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code == 200) {
                        t.qrcoeUrl = res.data.data
                        //t.save()
                    }
                }
            })
        },

        /**
         * @description  立即报名
         * @return
         */
        goSignUp() {
            buryPoint.setF({
                id: pointCode.POPULAR_ACTIVITY_F,
                p_url: this.p_url
            })
            wx.navigateTo({
                url: `/listOfActivities/submitSignUp?id=${this.$root.$mp.query.id}`
            })
        },

        /**
         * @description 跳转到我的活动详情
         * @return
         */
        goMyActivity() {
            wx.navigateTo({
                url: `/listOfActivities/signUpDetail?id=${this.detailData.memberApplyId}`
            })
        }
    },
    onShareAppMessage() {
        return {
            title: this.detailData.activityName,
            desc: this.detailData.activityDesc,
            path: 'pages/home?pageId=activites&id=' + this.$root.$mp.query.id,
            success: function(res) {
                console.log(res)
            },
            fail: function(err) {
                console.log(err)
            }
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
@import url('~mpvue-wxparse/src/wxParse.css');
.postarCanvas {
    visibility: hidden;
    position: absolute;
    left: -100%;
}
#popularPurchaseDetails {
    padding-bottom: 85px;
    background: #ffffff;
    .btn-share-wrap {
        width: 18px !important;
        height: 18px !important;
        margin-top: 3px !important;
    }
    .actives-deail {
        max-width: 100%;
        overflow: hidden;
    }
    .activies-img {
        width: 100%;
        height: 194px;
    }
    .actives-title {
        font-size: 20px;
        font-weight: bold;
        color: #333333;
        padding: 15px 15px 0;
    }
    .actives-oper {
        align-items: center;
        font-size: 15px;
        color: #999999;
        padding: 10px 15px 15px 15px;
        overflow: hidden;
        .clicknumber {
            padding-left: 30px;
            background: url('../static/images/icon-home-eye.png') no-repeat left center;
            background-size: 20px 13px;
            vertical-align: top;
            padding-right: 30px;
        }
        img {
            width: 20px;
            height: 20px;
            display: inline-block;
            position: relative;
            top: 4px;
        }
    }
    .actives-aut {
        display: inline-block;
    }
    .actives-todo {
        float: right;
    }
    .actives-con {
        margin-top: 15px;
        padding: 0 15px 30px;
        .activity-title {
            margin-top: 15px;
            font-size: 18px;
            font-weight: 500;
            color: rgba(51, 51, 51, 1);
        }
    }
    .wxParse {
        padding-left: 6px;
        view {
            word-break: break-all;
            image {
                width: 100% !important;
            }
        }
    }
    .restaurant-footer > div {
        display: block;
    }
    .activity-sign-up-box {
        padding: 10px 15px;
        // 立即报名
        .activity-coupon {
            color: #ff4747;
            font-size: 20px;
            float: left;
            padding: 10px 0;
        }
        .activity-coupon-small {
            color: #ff4747;
            font-size: 20px;
            float: left;
            padding: 10px 0;
        }
        .sign-up-btn {
            float: right;
            background: linear-gradient(144deg, rgba(179, 116, 248, 1) 0%, rgba(109, 120, 238, 1) 100%);
            border-radius: 50px;
            color: #fff;
            font-size: 18px;
            padding: 10px 50px;
        }
    }
    .user-msg-box {
        width: 100%;
        background: rgba(239, 247, 247, 1);
        text-align: center;
        padding: 3px 0 15px;
        .title {
            margin-top: 15px;
            font-size: 15px;
            font-weight: 400;
            color: rgba(153, 153, 153, 1);
        }
        .msg {
            font-size: 15px;
            font-weight: 400;
            color: rgba(51, 51, 51, 1);
            margin-top: 3px;
        }
        .success {
            font-weight: 600;
            font-size: 15px;
            color: rgba(114, 197, 193, 1);
        }
        .loading {
            font-size: 15px;
            font-weight: 400;
            color: rgba(218, 195, 59, 1);
        }
        .fail {
            font-size: 15px;
            font-weight: 400;
            color: rgba(255, 71, 71, 1);
        }
        .table {
            width: 320px;
            margin: 15px auto;
        }
        .tr {
            display: flex;
            width: 320px;
            justify-content: center;
            height: 35px;
            align-items: center;
            margin-top: 2px;
        }
        .td {
            width: 30%;
            justify-content: center;
            text-align: center;
            border: 1px solid #fff;
            padding: 6.5px;
        }
        .th {
            width: 30%;
            justify-content: center;
            color: #333;
            text-align: center;
            border: 1px solid #fff;
            display: flex;
            align-items: center;
            padding: 6.5px;
        }
    }
    .footer {
        height: 84px;
        width: 100%;
        position: fixed;
        bottom: 0;
        box-sizing: border-box;
        background: #fff;
        box-shadow: 0px 4px 15px 5px rgba(0, 0, 0, 0.09);
        .activity-sign-in-box,
        .activity-status-box,
        .activity-over-box {
            margin-top: 22px;
            text-align: center;
            .activity-sign-in {
                font-size: 18px;
                color: #fff;
                // background: rgba(114, 197, 193, 1);
                // border-radius: 4px;
                background: #9975f3;
                border-radius: 84rpx;
                padding: 10px 150px;
            }
            .activity-status {
                font-size: 18px;
                color: #fff;
                // background: rgba(114, 197, 193, 1);
                // border-radius: 4px;
                background: #9975f3;
                border-radius: 84rpx;
                padding: 10px 120px;
            }
            .activity-over {
                font-size: 18px;
                color: #fff;
                // background: rgba(114, 197, 193, 0.5);
                // border-radius: 4px;
                background: rgba(153, 117, 243, 0.5);
                border-radius: 84rpx;
                padding: 10px 130px;
            }
        }
    }
    .pop-bg {
        width: 100%;
        height: 12px;
        background: #f4f4f4;
    }
    .instructions_title {
        color: #333333;
        font-size: 15px;
    }
    .instructions_line {
        width: 2px;
        height: 10px;
        border-radius: 2px;
        background: #9975f3;
        display: inline-block;
    }
    .instructions_pl {
        padding-left: 6px;
    }
    .maskPage {
        position: fixed;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        top: 0;
        z-index: 100;
        .posterPage {
            position: absolute;
            top: 65px;
            left: 0;
            right: 0;
            margin: auto;
            width: 300px;
            background: #ffffff;
            .close {
                width: 30px;
                height: 30px;
                position: absolute;
                right: 15px;
                top: 15px;
            }
            .img {
                width: 100%;
                height: 180px;
            }
            .content {
                padding: 10px 15px;
                overflow: hidden;
                .topPage {
                    margin: 0 auto 10px;
                    overflow: hidden;
                }
                .titlePage {
                    .title {
                        font-size: 16px;
                        font-weight: 500;
                        color: #333333;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        display: -webkit-box;
                        line-clamp: 1;
                        -webkit-box-orient: vertical; /*使用该属性的前提是display:box;*/
                        -webkit-line-clamp: 1; /*显示的行数*/
                    }
                    .text {
                        font-size: 14px;
                        color: #666666;
                        text-overflow: -o-ellipsis-lastline;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        display: -webkit-box;
                        line-clamp: 2;
                        -webkit-box-orient: vertical; /*使用该属性的前提是display:box;*/
                        -webkit-line-clamp: 2; /*显示的行数*/
                        line-height: 20px;
                        margin: 9px 0;
                    }
                    .logo {
                        img {
                            width: 20px;
                            height: 20px;
                            margin-right: 5px;
                            display: inline-block;
                            position: relative;
                            top: 5px;
                        }
                        span {
                            font-size: 14px;
                        }
                    }
                }
                .qrcode {
                    img {
                        width: 115px;
                        height: 115px;
                        margin: 0 auto;
                        border: 6px solid #f4f4f4;
                        border-radius: 6px;
                    }
                    .des {
                        width: 115px;
                        font-size: 14px;
                        color: #999999;
                        margin: 0 auto;
                        text-align: center;
                    }
                }
            }
            .saveImg {
                width: 186px;
                height: 45px;
                line-height: 45px;
                text-align: center;
                color: #ffffff;
                background: #9975f3;
                border-radius: 100px;
                margin: 0 auto;
                margin-bottom: 10px;
            }
        }
    }
    .hAnimate {
        height: 210px !important;
        position: fixed !important;
    }
    .goodLuck {
        position: absolute;
        bottom: -1px;
        height: 0;
        width: 100%;
        z-index: 200;
        overflow: hidden;
        background: #ffffff;
        // border-top-right-radius: 30rpx;
        // border-top-left-radius: 30rpx;
        .content {
            //padding: 4%;
            height: 100%;
            .top {
                height: 80rpx;
                // border-bottom: 1px solid #cacaca;
                //margin-bottom: 10px;
                text-align: center;
                padding-top: 20px;
                position: relative;

                .name {
                    font-size: 18px;
                    color: #333333;
                    font-weight: 400;
                    width: 100%;
                    display: inline-block;
                }
                .close {
                    width: 26px;
                    height: 26px;
                    position: absolute;
                    z-index: 299;
                    top: 25px;
                    right: 20px;

                    image {
                        width: 18px;
                        height: 18px;
                    }
                }
            }
            ul {
                overflow: hidden;
                height: 80px;
                li {
                    float: left;
                    width: 50%;
                    text-align: center;
                    overflow: hidden;
                    button {
                        background: #ffffff !important;
                    }
                    .page {
                        width: 100px;
                        overflow: hidden;
                        margin: 0 auto;
                        padding: 0;
                        img {
                            margin: 0 auto;
                            width: 40px;
                            height: 40px;
                            margin: 0 auto;
                        }
                    }
                    .label {
                        color: #666666;
                        font-size: 14px;
                        text-align: center;
                        line-height: 25px;
                        padding-top: 5px;
                    }
                }
            }
        }
        .cancelPage {
            width: 100%;
            background: #fff;
            position: absolute;
            color: #333333;
            font-size: 18px;
            text-align: center;
            bottom: 0;
            padding: 4% 0;
        }
        .good-close {
            width: 100%;
            height: 86px;
            color: #666666;
            font-size: 20px;
            font-weight: 400;
            text-align: center;
            padding-top: 15px;
            border-top: solid 2px #f8f8f8;
        }
    }
}
</style>
