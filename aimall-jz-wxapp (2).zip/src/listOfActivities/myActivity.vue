<template>
    <div id="myActivity">
        <view class="section">
            <scroll-view
                :scroll-y="true"
                class="actives-list"
                @bindscrolltoupper="upper"
                @scrollToLower="onReachBottom"
                @bindscroll="scroll"
                @scroll-into-view="toView"
                @scroll-top="scrollTop"
            >
                <div v-show="isDown" class="search-btn">
                    <div class="search-btn-wrap">
                        <img class="icon-search" src="/static/images/icon-common-search@2x.png" />
                        <input
                            v-model="ipt"
                            :focus="false"
                            class="active-search-input"
                            type="text"
                            placeholder="搜索活动"
                            @confirm="searchPopConfrim"
                        />
                        <img
                            v-show="ipt"
                            class="btn-clear"
                            src="/static/images/icon-common-clear@2x.png"
                            @tap="clearSearch()"
                        />
                        <!-- <img
                        class="btn-clear"
                        src="/static/images/icon-common-clear@2x.png"
                        @tap="clearSearch()"
                        >-->
                    </div>
                </div>
                <div class="is-opening-box">
                    <div class="opening-box" @click="activityStatusChange(true,1)">
                        <span :class="isStatus == '1' ? 'is-opening' : ''">
                            报<span>名成</span>功
                        </span>
                    </div>
                    <div class="ending-box" @click="activityStatusChange(true,2)">
                        <span :class="isStatus == '2' ? 'is-opening' : ''">
                            审<span>核</span>中
                        </span>
                    </div>
                    <div class="ending-box" @click="activityStatusChange(true,3)">
                        <span :class="isStatus == '3' ? 'is-opening' : ''">
                            报<span>名失</span>败
                        </span>
                    </div>
                    <div class="ending-box" @click="activityStatusChange(true,4)">
                        <span :class="isStatus == '4' ? 'is-opening' : ''">
                            已<span>过</span>期
                        </span>
                    </div>
                </div>
                <div
                    class="actives-con"
                    v-for="(item,index) in listData"
                    :key="index"
                    :class="getPromtionPageRequest.applyStatusList == '5' ? 'expiredCons' :''"
                    @click="goMyActivityDetail(item.id)"
                >
                    <div class="img-box">
                        <img :src="item.thumbnail" alt />
                    </div>
                    <div class="title-box">
                        <text class="active-text">{{item.activityName}}</text>
                        <!-- <p class="time">{{item.startTime}}至{{item.endTime}}</p> -->
                        <div class="msg">
                            <span class="coupon">{{item.applyIntegral ? item.applyIntegral +'积分' : '免费活动'}}</span>
                            <button v-show="item.applyStatus == '2'" class="success">报名成功</button>
                            <button v-show="item.applyStatus == '1'" class="loading">审核中</button>
                            <button v-show="item.applyStatus == '3'" class="fail">报名失败</button>
                            <button v-show="item.applyStatus == '4'" class="success">签到成功</button>
                            <button v-show="item.applyStatus == '5' && item.signStatus != '1'" class="expired">已过期</button>
                            <button v-show="item.applyStatus == '5' && item.signStatus == '1'" class="expired">签到成功</button>
                        </div>
                    </div>

                </div>
                <div v-if="hasFetchData&&listData.length==0 &&noList==true">
                    <block-page :type="typeText"></block-page>
                </div>
                <load-more v-if="reachFinish" />
            </scroll-view>
            <!-- <blank-page
                :show-blank-page="hasFetchData&&listData.length===0&&noList==false"
                :blank-page-content="`“${ipt}…”`"
            />-->
        </view>
        <!-- <search-comp :is-show="isSearchPopShow"
                     @cancel="myEvent"
                     @confirm="searchPopConfrim"
        @myevent="myEvent" />-->
    </div>
</template>

<script>
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import moment from 'moment'
import SearchComp from '@/components/SearchComp'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import loadMore from '@/components/loadMore'
import BlankPage from '@/components/blankPage'
import BlockPage from '@/components/blockPage'
import { setTimeout } from 'timers'
import { mapState, mapMutations } from 'vuex'
export default {
    components: {
        SearchComp,
        loadMore,
        BlankPage,
        BlockPage
    },
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            //  热门活动列表
            listData: [],
            loaderMore: true,
            titleLike: '',
            ipt: '搜索',
            getPromtionPageRequest: {
                pageNo: 1,
                pageSize: 10,
                applyStatusList: [2, 4]
            },
            order: ['red', 'yellow', 'blue', 'green', 'red'],
            toView: 'red',
            scrollTop: 100,
            isSearchPopShow: false,
            isClear: false,
            serachVal: false,
            reachFinish: false,
            isDown: false, //是否下拉
            hasFetchData: false, //拉取数据状态
            typeText: '我的活动',
            noList: false,
            isStatus: '1',
            doubleClick: false
        }
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo'])
    },
    onShow() {
        this.isSearchPopShow = false
        this.loaderMore = true
        this.ipt = ''
        // this.getPromtionPageRequest.titleLike = this.ipt

        this.reachFinish = false
        this.listData = []
        this.getPromtionPageRequest.pageNo = 1
        if(typeof this.$root.$mp.query.status == 'undefined'){
            this.isStatus = '1'
            this.getPromtionPageRequest.applyStatusList = [2, 4]
            this.getActivityContent(0)
        }else{
            let num = this.$root.$mp.query.status;
            this.isStatus = num;
            if (num == 1) {
                this.getPromtionPageRequest.applyStatusList = [2, 4]
            } else if (num == 2) {
                this.getPromtionPageRequest.applyStatusList = [1]
            } else if (num == 3) {
                this.getPromtionPageRequest.applyStatusList = [3]
            } else if (num == 4) {
                this.getPromtionPageRequest.applyStatusList = [5]
            }
            this.getActivityContent(0)
        }
    },
    onHide() {
        this.hidePage()
    },
    onUnload() {
        this.hidePage()
    },
    methods: {
        hidePage() {
            this.hasFetchData = false

            this.ipt = ''
            this.isSearchPopShow = false
            this.serachVal = false
        },
        myEvent(val) {
            this.isClear = val.clear
            this.getPromtionPageRequest.pageNo = 1
            this.ipt = ''
            this.listData = []
            this.isSearchPopShow = false
            this.getPromtionPageRequest.titleLike = ''
            this.getActivityContent(0)
        },
        clearSearch() {
            this.getPromtionPageRequest.pageNo = 1
            this.ipt = ''
            this.listData = []
            this.isSearchPopShow = false
            this.getPromtionPageRequest.titleLike = this.ipt
            this.serachVal = false
            this.getActivityContent(0)
        },
        searchPopCancel() {
            this.isSearchPopShow = false
        },
        searchPopConfrim(val) {
            this.listData = []
            // this.ipt = val
            this.isSearchPopShow = false
            this.serachVal = true
            this.resetRefresh()
        },
        resetRefresh() {
            //重置刷新
            this.getPromtionPageRequest.pageNo = 1
            this.getPromtionPageRequest.titleLike = this.ipt
            this.listData = []
            this.getActivityContent(0)
        },
        toSearch() {
            this.isSearchPopShow = true
        },
        // 获取热门活动列表
        getActivityContent(times) {
            this.hasFetchData = false
            return new Promise(resolve => {
                let options = {
                    path: api.getMyActivity,
                    method: 'post',
                    data: this.getPromtionPageRequest
                }
                request(options).then(res => {
                    this.hasFetchData = true
                    this.doubleClick = false
                    if (res.code == 200) {
                        if (times == 1) {
                            this.noList = false
                            var records = res.data.records
                            if (0 <= res.data.records.length && res.data.records.length < this.getPromtionPageRequest.pageSize) {
                                this.loaderMore = false
                                this.reachFinish = true
                            }
                            let list = records
                            records.forEach(v => {
                                v.createTime = moment(v.createTime).format('YYYY-MM-DD HH:mm')
                                v.startTime = moment(v.startTime).format('YYYY-MM-DD HH:mm')
                                v.endTime = moment(v.endTime).format('YYYY-MM-DD HH:mm')
                            })
                            this.listData = this.listData.concat(list)
                        } else {
                            this.reachFinish = false
                            if (res.data.records) {
                                if (this.getPromtionPageRequest.pageNo == 1 && res.data.records.length == 0) {
                                    this.listData = []
                                    this.loaderMore = false
                                    if (this.ipt != '') {
                                        this.noList = false
                                    } else {
                                        this.noList = true
                                    }
                                    return
                                } else {
                                    this.noList = false
                                    if (res.data.records.length < 10) {
                                        this.loaderMore = false
                                        this.reachFinish = false
                                    }
                                    var records = res.data.records
                                    records.forEach(v => {
                                        v.createTime = moment(v.createTime).format('YYYY-MM-DD HH:mm')
                                        v.startTime = moment(v.startTime).format('YYYY-MM-DD HH:mm')
                                        v.endTime = moment(v.endTime).format('YYYY-MM-DD HH:mm')
                                    })
                                    let list = records

                                    this.listData = this.listData.concat(list)
                                }
                            }
                            resolve()
                        }
                    }
                })
            })
        },
        upper(e) {
            console.log(e)
        },
        lower(e) {
            console.log(e)
        },
        scroll(e) {
            console.log(e)
        },
        // 跳转至详情页
        goMyActivityDetail(id) {
            if(this.getPromtionPageRequest.applyStatusList != 5){
                this.$root.$mp.query.status = this.isStatus
                setTimeout(item => {
                    this.listData = []
                }, 500)
                wx.navigateTo({
                    url: `/listOfActivities/signUpDetail?id=${id}`
                })
            }

        },
        // 活动状态选择切换
        activityStatusChange(status, num) {
            let t = this
            //将下拉刷新的标识重新置为true
            t.loaderMore = true
            if (!t.doubleClick) {
                t.listData = []
                t.isOpening = status
                t.isStatus = num
                if (num == 1) {
                    t.getPromtionPageRequest.applyStatusList = [2, 4]
                } else if (num == 2) {
                    t.getPromtionPageRequest.applyStatusList = [1]
                } else if (num == 3) {
                    t.getPromtionPageRequest.applyStatusList = [3]
                } else if (num == 4) {
                    t.getPromtionPageRequest.applyStatusList = [5]
                }
                if (status) {
                    t.clearSearch()
                    t.doubleClick = true
                }
            }
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        this.isDown = true
        this.loaderMore = true
        this.resetRefresh()
        wx.stopPullDownRefresh()
    },
    // 触底加载更多
    onReachBottom() {

        if (this.loaderMore) {
            this.getPromtionPageRequest.pageNo++
            this.getActivityContent(1)
        } else {
            if (this.listData.length > 10) {
                this.reachFinish = true
            } else {
                this.reachFinish = false
            }
        }
    }
}
</script>

<style lang="less">
@import '../assets/styles/vars';
#myActivity {
    min-height: 100vh;
    background-color: #f2f2f2;
    .active-text {
        width: 100%;
        display: -webkit-box;
        text-overflow: ellipsis;
        font-size: 18px !important;
        color: #333333;
        overflow: hidden; //一定要写
        text-overflow: ellipsis; //超出省略号
        -webkit-line-clamp: 2; //控制行数
        -webkit-box-orient: vertical;
    }
    .actives-list {
        min-height: 100vh;
        background: #ffffff;
    }
    .actives-con {
        margin-top: 15px;
        padding: 0 15px 15px;
        .img-box,
        .title-box {
            display: inline-block;
            height: 75px;
            position: relative;
        }
        .img-box {
            width: 40%;
            img {
                width: 125px;
                height: 70px;
                border-radius: 4px;
            }
        }
        .title-box {
            width: 60%;
            float: right;
            .time {
                font-size: 12px;
            }
        }
    }
    .activies-img {
        width: 100%;
        height: 194px;
        border-radius: 4px 4px 0 0;
    }
    .actives-title {
        font-size: 13px;
        width: 100%;
        margin-top: 10px;
    }
    .active-text {
        display: -webkit-box;
        font-size: 28rpx;
        color: #000000;
        line-height: 40rpx;
        word-break: break-all;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .actives-detail {
        color: #fff;
        border-radius: 12px;
        width: 52px;
        height: 24px;
        border: solid 1px #9975F3;
        background: #9975F3;
        padding-left: 4px;
        padding-right: 4px;
        line-height: 24px;
        display: block;
        float: right;
        text-align: center;
        cursor: pointer;
    }
    .actives-time {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 8px;
        font-size: 15px;
        color: #999999;
        margin-bottom: 4px;
        font-weight: 200;
    }
    .actives-timespan {
        margin-top: -4px;
        display: inline-block;
    }
    .btn-clear {
        z-index: 10;
        width: 15px;
        height: 16px;
        padding: 9.5px;
        position: absolute;
        top: 50%;
        right: 15px;
        transform: translateY(-50%);
        font-size: 15px;
    }
    .search-btn {
        text-align: left;
        line-height: 50%;
        .search-btn-wrap {
            background-color: #ffffff;
            border-radius: 4px;
        }
        .icon-search {
            position: absolute;
            top: 50%;
            left: 15%;
        }
        .search-input {
            padding-left: 30px;
        }
        .active-search-input {
            height: 38px;
            line-height: 28px;
            width: 90%;
            background: #ffffff;
            display: inline-block;
            padding-left: 30px;
            background-color: #ffffff;
        }
    }
    .is-opening-box {
        height: 50px;
        width: 100%;
        border-bottom: 1px solid #dddddd;
        line-height: 50px;
        .opening-box,
        .ending-box {
            display: inline-block;
            width: 25%;
            text-align: center;
            color: rgba(153, 153, 153, 1);
            font-size: 18px;
        }
        .is-opening {
            color: #333333;
            span {
                border-bottom: 2px solid #9975F3;
            }
        }
    }
    .msg {
        height: 35px;
        line-height: 35px;
        position: absolute;
        bottom: 0px;
        width: 100%;
        .coupon {
            font-size: 15px;
            // font-weight: 600;
            // color: rgba(255, 71, 71, 1);
            font-weight: bolder;
            color: #ea5205;
        }
        button {
            display: inline-block;
            font-size: 15px;
            padding: 5px 5px;
            line-height: 1.5;
            float: right;
            border-radius: 4px;
        }
        .success {
            // background: rgba(242, 247, 247, 1);
            // color: rgba(114, 197, 193, 1);
            background: #F4F2FC;
            color: #9975f3;
        }
        .loading {
            // background: rgba(246, 245, 239, 1);
            // color: rgba(218, 195, 59, 1);
            background: #F4F2FC;
            color: #9975f3;
        }
        .fail {
            // background: rgba(252, 239, 239, 1);
            // color: rgba(255, 71, 71, 1);
            background: #F4F2FC;
            color: #9975f3;
        }
        .over {
            background: rgba(244, 244, 244, 1);
            color: rgba(206, 206, 206, 1);
        }
    }
    .expiredCons .img-box ._img{
        opacity: 0.5;
    }
    .expiredCons .active-text,.expiredCons .coupon{
        color: #CECECE
    }
    .expiredCons .msg .expired{
        background: #f4f4f4;
        color: #CECECE
    }
}
</style>
