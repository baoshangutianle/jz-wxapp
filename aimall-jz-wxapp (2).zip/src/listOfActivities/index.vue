<template>
    <div id="listOfActivities">
        <view class="section">
            <scroll-view
                :scroll-y="true"
                class="actives-list"
                @bindscrolltoupper="upper"
                @scrollToLower="onReachBottom"
                @bindscroll="scroll"
                @scroll-into-view="toView"
                @scroll-top="scrollTop"
            >
                <div
                    v-show="isDown"
                    class="search-btn"
                >
                    <div class="search-btn-wrap">
                        <img
                            class="icon-search"
                            src="/static/images/icon-common-search@2x.png"
                        >
                        <input
                            v-model="ipt"
                            :focus="false"
                            class="active-search-input"
                            type="text"
                            placeholder="搜索"
                            @confirm="searchPopConfrim"
                        >
                        <img
                            v-show="ipt"
                            class="btn-clear"
                            src="/static/images/icon-common-clear@2x.png"
                            @tap="clearSearch()"
                        >
                        <!-- <img
                        class="btn-clear"
                        src="/static/images/icon-common-clear@2x.png"
                        @tap="clearSearch()"
                    > -->
                    </div>
                </div>
                <div class="actives-con">
                    <ul>
                        <li
                            v-for="item in listData"
                            :key="item.id"
                            :data-id="item.id"
                            :data-title="item.title"
                            class="my-shadow actives-item"
                            @click="toDetails"
                        >
                            <img
                                :src="item.pictureUrl"
                                class="activies-img"
                            >
                            <div class="actives-info">
                                <p class="actives-title">
                                    <span class="active-text">{{ item.title }}</span>
                                </p>
                                <p class="actives-time">
                                    <span class="actives-timespan">{{ item.startTime }} 至 {{ item.endTime }}</span>
                                    <!-- <span>
                                        <span
                                            class="actives-detail"
                                            @click="getDetail"
                                        >查看</span>
                                    </span> -->
                                </p>
                            </div>
                        </li>
                    </ul>

                    <div v-if="hasFetchData&&listData.length==0 &&noList==true">
                        <block-page :type="typeText"></block-page>
                    </div>
                    <load-more v-if="reachFinish" />
                </div>
            </scroll-view>
            <blank-page :show-blank-page="hasFetchData&&listData.length===0&&noList==false"
                        :blank-page-content="`“${ipt}…”`" />
        </view>
    <!-- <search-comp :is-show="isSearchPopShow"
                     @cancel="myEvent"
                     @confirm="searchPopConfrim"
                     @myevent="myEvent" /> -->
    </div>
</template>

<script>
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils'
import moment from 'moment'
import SearchComp from '@/components/SearchComp'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import loadMore from '@/components/loadMore'
import BlankPage from '@/components/blankPage'
import BlockPage from '@/components/blockPage'
import { setTimeout } from 'timers'
export default {
    components: {
        SearchComp,
        loadMore,
        BlankPage,
        BlockPage
    },
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            //  热门活动列表
            listData: [],
            loaderMore: true,
            titleLike: '',
            ipt: '搜索',
            getPromtionPageRequest: {
                pageNo: 1,
                pageSize: 10,
                putChannel: 1,
                putPosition: 2,
                titleLike: ''
            },
            order: ['red', 'yellow', 'blue', 'green', 'red'],
            toView: 'red',
            scrollTop: 100,
            isSearchPopShow: false,
            isClear: false,
            serachVal: false,
            reachFinish: false,
            isDown: false, //是否下拉
            hasFetchData: false, //拉取数据状态
            typeText:'热门活动',
            noList:false
        }
    },
    onShow() {
    // 埋点
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.ACTIVITY_P
        })
        this.isSearchPopShow = false
        this.loaderMore = true
        this.ipt = ''
        this.getPromtionPageRequest.titleLike = this.ipt

        this.reachFinish = false
        this.listData = []
        this.getPromtionPageRequest.pageNo = 1
        this.getCmsContent(0)
    },
    onHide() {
        this.hidePage()
    },
    onUnload() {
        this.hidePage()
    },
    methods: {
        hidePage() {
            this.hasFetchData = false

            this.ipt = ''
            this.isSearchPopShow = false
            this.serachVal = false
            this.pageStayTime = new Date().getTime() - this.pageStayTime
            // 埋点
            buryPoint.setZ({
                id: pointCode.ACTIVITY_Z,
                p_stay_time: this.pageStayTime
            })
        },
        myEvent(val) {
            this.isClear = val.clear
            this.getPromtionPageRequest.pageNo = 1
            this.ipt = ''
            this.listData = []
            this.isSearchPopShow = false
            this.getPromtionPageRequest.titleLike = ''
            this.getCmsContent(0)
        },
        clearSearch() {
            this.getPromtionPageRequest.pageNo = 1
            this.ipt = ''
            this.listData = []
            this.isSearchPopShow = false
            this.getPromtionPageRequest.titleLike = this.ipt
            this.serachVal = false
            this.getCmsContent(0)
        },
        searchPopCancel() {
            this.isSearchPopShow = false
        },
        searchPopConfrim(val) {
            this.listData = []
            // this.ipt = val
            this.isSearchPopShow = false
            this.serachVal = true
            this.resetRefresh()
        },
        resetRefresh() {
            //重置刷新
            this.getPromtionPageRequest.pageNo = 1
            this.getPromtionPageRequest.titleLike = this.ipt
            this.listData = []
            this.getCmsContent(0)
        },
        toSearch() {
            this.isSearchPopShow = true
        },
        // 获取热门活动列表
        getCmsContent(times) {
            this.hasFetchData = false
            return new Promise(resolve => {
                let options = {
                    path: api.getCmsContent,
                    method: 'post',
                    data: this.getPromtionPageRequest
                }
                request(options).then(res => {
                    this.hasFetchData = true
                    if (res.code == 200) {
                        if (times == 1) {
                            this.noList = false;
                            var records = res.data.records
                            if (0 <= res.data.records.length && res.data.records.length < this.getPromtionPageRequest.pageSize) {
                                this.loaderMore = false
                                this.reachFinish = true
                            }
                            records.forEach(v => {
                                v.startTime = moment(v.startTime).format('YYYY-MM-DD hh:mm')
                                v.endTime = moment(v.endTime).format('YYYY-MM-DD hh:mm')
                            })
                            let list = records
                            this.listData = this.listData.concat(list)
                        } else {
                            this.reachFinish = false
                            if (res.data.records) {
                                if (this.getPromtionPageRequest.pageNo == 1 && res.data.records.length == 0) {
                                    this.listData = []
                                    this.loaderMore = false
                                    if(this.ipt != ''){
                                        this.noList = false;
                                    }else{
                                        this.noList = true;
                                    }
                                    return
                                } else {
                                    this.noList = false;
                                    if (res.data.records.length < 20) {
                                        this.loaderMore = false
                                    }
                                    var records = res.data.records
                                    records.forEach(v => {
                                        v.startTime = moment(v.startTime).format('YYYY-MM-DD')
                                        v.endTime = moment(v.endTime).format('YYYY-MM-DD')
                                    })
                                    let list = records
                                    this.listData = this.listData.concat(list)
                                }
                            }
                            resolve()
                        }
                    }
                })
            })
        },
        upper(e) {
            console.log(e)
        },
        lower(e) {
            console.log(e)
        },
        scroll(e) {
            console.log(e)
        },
        // 跳转至详情页
        toDetails(e) {
            let { id, title } = e.currentTarget.dataset
            //埋点
            buryPoint.setF({
                id: pointCode.ACTIVITY_F_DETAIL,
                p_action_id: id,
                p_action: title
            })
            wx.navigateTo({
                url: `/listOfActivities/details?id=${id}`
            })
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        this.isDown = true
        this.loaderMore = true
        this.resetRefresh()
        wx.stopPullDownRefresh()
    },
    // 触底加载更多
    onReachBottom() {
        if (this.loaderMore) {
            this.getPromtionPageRequest.pageNo++
            this.getCmsContent(1)
        } else {
            if (this.listData.length > 2) {
                this.reachFinish = true
            } else {
                this.reachFinish = false
            }
        }
    }
}
</script>

<style lang="less">
@import '../assets/styles/vars';
#listOfActivities {
    min-height: 100vh;
    background-color: #f2f2f2;
    .actives-list {
        min-height: 100vh;
        background: #ffffff;
    }
    .actives-con {
        padding: 0 15px 15px;
        .actives-item {
            margin-top: 15px;
            overflow: hidden;
            padding-bottom: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            //box-shadow: 0 0px 8px #eaeaee;
            // box-shadow: 0 10px 17px -8px #ff8c1a inset;
            // box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 0, 0, 0.1) inset;

            border-radius: 4px;
            .actives-info {
                padding: 0 10px;
            }
        }
    }
    .actives-con ul li:nth-child(1) {
        padding-top: 0px;
    }
    .actives-con ul li {
        cursor: pointer;
    }
    .activies-img {
        width: 100%;
        height: 194px;
        border-radius: 4px 4px 0 0;
    }
    .actives-title {
        font-size: 17px;
        width: 100%;
        margin-top: 10px;
    }
    .active-text {
        font-family:'Times New Roman', Times, serif;
        width: 100%;
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        font-size: 18px !important;
        color: #333333;
        overflow: hidden; //一定要写
        text-overflow: ellipsis; //超出省略号
        // display: -webkit-box; //一定要写
        -webkit-line-clamp: 2; //控制行数
        -webkit-box-orient: vertical; //一定要写
    }
    .actives-detail {
        color: #fff;
        border-radius: 12px;
        width: 52px;
        height: 24px;
        border: solid 1px #9975F3;
        background: #9975F3;
        padding-left: 4px;
        padding-right: 4px;
        line-height: 24px;
        display: block;
        float: right;
        text-align: center;
        cursor: pointer;
    }
    .actives-time {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 8px;
        font-size: 15px;
        color: #999999;
        margin-bottom: 4px;
        font-weight: 200;
    }
    .actives-timespan {
        margin-top: -4px;
        display: inline-block;
    }
    .btn-clear {
        z-index: 10;
        width: 15px;
        height: 16px;
        padding: 9.5px;
        position: absolute;
        top: 50%;
        right: 15px;
        transform: translateY(-50%);
        font-size: 15px;
    }
    .search-btn {
        text-align: left;
        line-height: 50%;
        .search-btn-wrap {
            background-color: #ffffff;
            border-radius: 4px;
        }
        .icon-search {
            position: absolute;
            top: 50%;
            left: 15%;
        }
        .search-input {
            padding-left: 30px;
        }
        .active-search-input {
            height: 38px;
            line-height: 28px;
            width: 90%;
            background: #ffffff;
            display: inline-block;
            padding-left: 30px;
            background-color: #ffffff;
        }
    }
}
</style>
