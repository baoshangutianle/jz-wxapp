<template>
    <div id="submitSignUp">
        <form @submit="doSubmitForm" report-submit="true">
            <!-- 活动信息 -->
            <div class="content">
                <div class="img-box">
                    <img :src="detailData.thumbnail" alt />
                </div>
                <div class="title-box">
                    <p>{{ detailData.activityName }}</p>
                    <p class="coupon">{{detailData.applyIntegral ? detailData.applyIntegral +'积分' : '免费活动'}}</p>
                </div>
                <div class="user-msg-box">
                    <p class="title">填写报名信息</p>
                    <p class="msg">您的信息仅作为报名使用，请放心填写</p>
                    <div class="phone">
                        <span>
                            联系电话
                            <span style="color: red;">*</span>
                        </span>
                        <span style="float: right;">{{ mobile }}</span>
                    </div>
                    <div class="username">
                        <span>
                            真实姓名
                            <span style="color: red;">*</span>
                            <input class="inputVal" placeholder-style="color:#cecece" v-model="username" placeholder=" " type="text" @focus="focusInput" @blur="blurInput"/>
                            <text  class='inputtext' v-if="inputText">请输入真实姓名</text>
                        </span>
                    </div>
                </div>
            </div>
            <div class="footer">
                <!-- 去签到 -->
                <form @submit="submit" report-submit="true">
                    <button formType="submit"
                            class="activity-sign-in act"
                            type="primary">
                        提交报名
                    </button>
                </form>
            </div>
        </form>
    </div>
</template>

<script>
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import wxUtils from '@/plugins/wxUtils'
import api from '@/plugins/api'
import { mapState, mapMutations } from 'vuex'
export default {
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            mobile: "",
            username: '',
            detailData: {},
            formId: '',
            isRepeat: false,
            inputText: true
        }
    },
    onShow() {
        this.username = ""
        this.isRepeat = false
        this.inputText = true
        this.getDetailById();
        this.mobile = wxUtils.getPhoneStorage()
        // 埋点
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.ACTIVITY_SIGN_UP_P
        })
    },
    onUnload() {
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        // 埋点
        buryPoint.setZ({
            id: pointCode.ACTIVITY_SIGN_UP_Z,
            p_stay_time: this.pageStayTime
        })
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo'])
    },
    methods: {
        focusInput(){
            this.inputText = false
        },
        blurInput(){
            if(this.username != ''){
                this.inputText = false
            }else{
                this.inputText = true
            }
        },
        getDetailById() {
            let t = this;
            let id = t.$root.$mp.query.id || 17
            t.contentId = id
            // let opsiton = { path: api.getCmsContentById + id }
            //
            wx.request({
                url: api.getMmcApplyActivity + '/' + id,
                method: 'GET',
                data: null,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code === 200) {
                        t.detailData = res.data.data
                    }
                }
            })
        },
        doSubmitForm(e){
            let vm = this
            let formId = e.mp.detail.formId
            vm.formId = formId
        },
        submit(e){
            let t = this;
            //防止重复提交
            if(!t.isRepeat){

                let formId = e.mp.detail.formId
                if(t.username == ""){
                    let success = {
                        title: '请输入真实姓名',
                        icon: 'none'
                    }
                    wx.showToast(success)
                    return
                }
                let data = {
                    activityId: t.$root.$mp.query.id,
                    mobile: t.mobile,
                    realName: t.username,
                    wxFormId: formId
                }

                t.isRepeat = true
                wx.request({
                    url: api.mmcMemberApply,
                    method: 'POST',
                    data: data,
                    header: {
                        Authorization: t.sessionId,
                        'L-A-Platform': 'mini-program' //后端日志埋点渠道
                    },
                    success(res) {
                        if (res.data.code === 200) {
                            buryPoint.setF({
                                id: pointCode.ACTIVITY_SIGN_UP_F,
                            })
                            wx.navigateTo({
                                url: `/listOfActivities/submitSuccess?id=${res.data.data}`
                            })
                        }else{
                            let success = {
                                title: res.data.message,
                                icon: 'none'
                            }
                            wx.showToast(success)
                            t.isRepeat =  false
                        }
                    }
                })
            }

        }
    }
}
</script>

<style lang="less" scoped>
#submitSignUp {
    padding: 15px;
    .content {
        width: 100%;
        margin: 0;
        padding: 0;
        .img-box,
        .title-box {
            display: inline-block;
            height: 70px;
            position: relative;
        }
        .img-box {
            width: 40%;
            img {
                width: 125px;
                height: 70px;
            }
        }
        .title-box {
            width: 60%;
            float: right;
            .coupon {
                float: right;
                color: #ff4747;
                position: absolute;
                bottom: 0px;
                left: 0px;
            }
        }
        .user-msg-box {
            width: 100%;
            .title {
                margin-top: 15px;
                font-size: 18px;
                font-weight: 500;
                color: rgba(51, 51, 51, 1);
            }
            .msg {
                font-weight: 300;
                color: rgba(153, 153, 153, 1);
                font-size: 13px;
                padding-top: 5px;
            }
            .phone,
            .username {
                width: 100%;
                height: 50px;
                position: relative;
                span {
                    line-height: 50px;
                }
                .inputVal{
                    position: absolute;
                    z-index: 99;
                    top: 0px;
                    right: 0px;
                }
                .inputtext{
                    position: absolute;
                    z-index: 33;
                    top: 0px;
                    right: 0px;
                    color: #cecece;
                }
            }


            .phone {
                margin-top: 20px;
                border-top: 1px solid #f7f7f7;
                border-bottom: 1px solid #f7f7f7;
            }
            .username {
                border-bottom: 1px solid #f7f7f7;
                input {
                    display: inline-block;
                    float: right;
                    text-align: right;
                    margin-top: 10px;
                }
            }
        }
    }
    .footer {
        height: 130rpx;
        width: 100%;
        position: fixed;
        bottom: 0;
        box-sizing: border-box;
        left: 0;
    }
}
.activity-sign-in-box {
    margin-top: 22px;
    text-align: center;

}
.activity-sign-in {

    margin: 0px 15px !important;
    font-size: 18px;
    color: #fff;
    background: #9975F3;
    // border-radius: 4px;
    margin-left: -30px;

}
.activity-sign-in.act{

    border-radius: 47rpx;
}

</style>
