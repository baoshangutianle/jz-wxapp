<template>
    <div id="listOfActivitiesPopular">
        <view class="section">
            <scroll-view
                :scroll-y="true"
                class="actives-list"
                @bindscrolltoupper="upper"
                @scrollToLower="onReachBottom"
                @bindscroll="scroll"
                @scroll-into-view="toView"
                @scroll-top="scrollTop"
            >
                <div v-show="isDown" class="search-btn">
                    <div class="search-btn-wrap">
                        <img class="icon-search" src="/static/images/icon-common-search@2x.png" />
                        <input
                            v-model="ipt"
                            :focus="false"
                            class="active-search-input"
                            type="text"
                            placeholder="搜索活动"
                            @confirm="searchPopConfrim"
                        />
                        <img
                            v-show="ipt"
                            class="btn-clear"
                            src="/static/images/icon-common-clear@2x.png"
                            @tap="clearSearch()"
                        />
                        <!-- <img
                        class="btn-clear"
                        src="/static/images/icon-common-clear@2x.png"
                        @tap="clearSearch()"
                        >-->
                    </div>
                </div>
                <div class="is-opening-box">
                    <div class="opening-box" @click="activityStatusChange(true)">
                        <span :class="isOpening ? 'is-opening' : ''">
                            活<span>动</span>中
                        </span>
                    </div>
                    <div class="ending-box" @click="activityStatusChange(false)">
                        <span :class="!isOpening ? 'is-opening' : ''">
                            已<span>结</span>束
                        </span>
                    </div>
                </div>
                <div class="actives-con">
                    <ul>
                        <li
                            v-for="item in listData"
                            :key="item.id"
                            :data-id="item.id"
                            :data-title="item.title"
                            class="my-shadow actives-item"
                            style="position:relative"
                        >
                            <auth-btn @pass="toDetails(item)" />
                            <img v-show="item.isRecommend == '1' && isOpening" class="activity-hot" src="https://prd-aegeanai-oss.oss-cn-shanghai.aliyuncs.com/as/20191223/4e1a265f964b478a9622288df45548f3.jpg" alt />
                            <img :src="item.thumbnail" class="activies-img" />
                            <span v-show="isOpening" class="activity-people">已报名{{ item.applyNumber ? item.applyNumber : '0' }}人</span>
                            <span v-show="!isOpening" class="activity-people">{{ item.applyNumber ? item.applyNumber : '0' }}人参与</span>
                            <div class="actives-info">
                                <p class="actives-title">
                                    <span class="active-text">{{ item.activityName }}</span>
                                </p>
                                <p class="actives-time">
                                    <span
                                        class="actives-timespan"
                                    >{{ item.startTime }} 至 {{ item.endTime }}</span>
                                    <!-- <span>
                                        <span
                                            class="actives-detail"
                                            @click="getDetail"
                                        >查看</span>
                                    </span>-->
                                </p>
                            </div>
                            <!-- 标签参与人数 -->
                            <div class="label-people">
                                <span class="activity-label" v-for="(a,i) in item.activityTags" :key="i"># {{ a }}</span>
                                <span v-show="isOpening && item.applyStatus != '1'" class="activity-status" style="float: right;">{{ item.applyStatus == '2' ? '立即报名' : '报名已结束'}}</span>
                            </div>
                        </li>
                    </ul>
                    <div v-if="listData.length==0">
                        <block-page :type="typeText"></block-page>
                    </div>
                    <load-more v-if="reachFinish" />
                </div>
            </scroll-view>
            <blank-page
                :show-blank-page="hasFetchData&&listData.length===0&&noList==false"
                :blank-page-content="`“${ipt}…”`"
            />
        </view>
        <!-- <search-comp :is-show="isSearchPopShow"
                     @cancel="myEvent"
                     @confirm="searchPopConfrim"
        @myevent="myEvent" />-->
    </div>
</template>

<script>
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import moment from 'moment'
import SearchComp from '@/components/SearchComp'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import loadMore from '@/components/loadMore'
import BlankPage from '@/components/blankPage'
import BlockPage from '@/components/blockPage'
import { setTimeout } from 'timers'
import { mapState, mapMutations } from 'vuex'
import AuthBtn from '@/components/AuthBtn'
export default {
    components: {
        SearchComp,
        loadMore,
        BlankPage,
        BlockPage,
        AuthBtn
    },
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            //  热门活动列表
            listData: [],
            loaderMore: true,
            activityNameLike: '',
            ipt: '搜索',
            getPromtionPageRequest: {
                pageNo: 1,
                pageSize: 10,
                activityStatus: "2"
            },
            order: ['red', 'yellow', 'blue', 'green', 'red'],
            toView: 'red',
            scrollTop: 100,
            isSearchPopShow: false,
            isClear: false,
            serachVal: false,
            reachFinish: false,
            isDown: false, //是否下拉
            hasFetchData: false, //拉取数据状态
            typeText: '热门活动',
            noList: false,
            isOpening: true,
        }
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo'])
    },
    onShow() {
        this.getPromtionPageRequest.activityNameLike = ''
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: 42
        })
       this.isDown = false;
    },
    mounted() {
        this.isSearchPopShow = false
        this.loaderMore = true
        this.ipt = ''
        // this.getPromtionPageRequest.activityNameLike = this.ipt

        this.reachFinish = false
        this.listData = []
        this.getPromtionPageRequest.pageNo = 1
        this.getCmsContent(0)
    },
    onHide() {
        this.hidePage()
    },
    onUnload() {
        //埋点
        this.pageStayTime = new Date().getTime() - this.pageStayTime
        buryPoint.setZ({
            id: 43,
            p_stay_time: this.pageStayTime
        })
        this.hidePage()
    },
    methods: {
        hidePage() {
            this.hasFetchData = false

            this.ipt = ''
            this.isSearchPopShow = false
            this.serachVal = false


        },
        myEvent(val) {
            this.isClear = val.clear
            this.getPromtionPageRequest.pageNo = 1
            this.ipt = ''
            this.listData = []
            this.isSearchPopShow = false
            this.getPromtionPageRequest.activityNameLike = ''
            this.getCmsContent(0)
        },
        clearSearch() {
            this.getPromtionPageRequest.pageNo = 1
            this.ipt = ''
            this.listData = []
            this.isSearchPopShow = false
            this.getPromtionPageRequest.activityNameLike = this.ipt
            this.serachVal = false
            this.getCmsContent(0)
        },
        searchPopCancel() {
            this.isSearchPopShow = false
        },
        searchPopConfrim(val) {
            this.listData = []
            // this.ipt = val
            this.isSearchPopShow = false
            this.serachVal = true
            this.resetRefresh()
        },
        resetRefresh() {
            //重置刷新
            this.getPromtionPageRequest.pageNo = 1
            this.getPromtionPageRequest.activityNameLike = this.ipt
            this.listData = []
            this.getCmsContent(0)
        },
        toSearch() {
            this.isSearchPopShow = true
        },
        // 获取热门活动列表
        getCmsContent(times) {
            let t = this
            t.hasFetchData = false
            wx.request({
                url: api.queryMmcApplyActivity,
                method: 'POST',
                data: t.getPromtionPageRequest,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code === 200) {
                        let records = res.data.data.records;
                        if(records){
                          records.forEach(v => {
                              v.applyStartTime = moment(v.applyStartTime).format('YYYY-MM-DD HH:mm');
                              v.startTime = moment(v.startTime).format('YYYY-MM-DD HH:mm');
                              v.endTime = moment(v.endTime).format('YYYY-MM-DD HH:mm');
                              v.activityTags = v.activityTags.split(',');
                              v.activityTags = v.activityTags.slice(0,2)
                          })
                          let list = records
                          t.listData = t.listData.concat(list)
                          t.reachFinish = false
                        }else{
                            let list = []
                            t.listData = t.listData.concat(list)
                            if(t.listData.length != 0) {
                                t.reachFinish = true
                            }else{
                                t.reachFinish = false
                            }
                        }
                    }
                }
            })
        },
        upper(e) {
            console.log(e)
        },
        lower(e) {
            console.log(e)
        },
        scroll(e) {
            console.log(e)
        },
        // 跳转至详情页
        toDetails(item) {
            //埋点
            buryPoint.setF({
                id: 44
            })
            wx.navigateTo({
                url: `/listOfActivities/popularDetails?id=${item.id}`
            })
        },
        // 活动状态选择切换
        activityStatusChange(status) {
            let t = this
            t.isOpening = status
            t.listData = [];
            t.getPromtionPageRequest.pageNo = 1;
            t.reachFinish = false;
            if (status) {
                // 活动中
                t.getPromtionPageRequest.activityStatus = '2'
            }else{
                // 已结束
                t.getPromtionPageRequest.activityStatus = '3'
            }
            t.getCmsContent()
        }
    },
    // 下拉刷新
    onPullDownRefresh() {
        this.isDown = true
        this.loaderMore = true
        this.resetRefresh()
        wx.stopPullDownRefresh()
    },
    // 触底加载更多
    onReachBottom() {
        if (this.loaderMore) {
            this.getPromtionPageRequest.pageNo++
            this.getCmsContent(1)
        } else {
            if (this.listData.length > 2) {
                this.reachFinish = true
            } else {
                this.reachFinish = false
            }
        }
    }
}
</script>

<style lang="less">
@import '../assets/styles/vars';
#listOfActivitiesPopular {
    min-height: 100vh;
    background-color: #f2f2f2;
    .actives-list {
        min-height: 100vh;
        background: #ffffff;
    }
    .actives-con {
        padding: 0 15px 15px;
        .actives-item {
            margin-top: 15px;
            overflow: hidden;
            padding-bottom: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            //box-shadow: 0 0px 8px #eaeaee;
            // box-shadow: 0 10px 17px -8px #ff8c1a inset;
            // box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 0, 0, 0.1) inset;

            border-radius: 4px;
            .actives-info {
                padding: 0 10px;
            }
        }
    }
    .actives-con ul li:nth-child(1) {
        padding-top: 0px;
    }
    .actives-con ul li {
        cursor: pointer;
    }
    .activies-img {
        width: 100%;
        height: 194px;
        border-radius: 4px 4px 0 0;
    }
    .actives-title {
        font-size: 13px;
        width: 100%;
        margin-top: 10px;
    }
    .active-text {
        //font-family: 'Times New Roman', Times, serif;
        width: 100%;
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        font-size: 18px !important;
        color: #333333;
        overflow: hidden; //一定要写
        text-overflow: ellipsis; //超出省略号
        // display: -webkit-box; //一定要写
        -webkit-line-clamp: 2; //控制行数
        -webkit-box-orient: vertical; //一定要写
    }
    .actives-detail {
        color: #fff;
        border-radius: 12px;
        width: 52px;
        height: 24px;
        border: solid 1px #9975F3;
        background: #9975F3;
        padding-left: 4px;
        padding-right: 4px;
        line-height: 24px;
        display: block;
        float: right;
        text-align: center;
        cursor: pointer;
    }
    .actives-time {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 10px;
        font-size: 15px;
        color: #999999;
        margin-bottom: 10px;
        font-weight: 200;
    }
    .actives-timespan {
        margin-top: -4px;
        display: inline-block;
    }
    .btn-clear {
        z-index: 10;
        width: 15px;
        height: 16px;
        padding: 9.5px;
        position: absolute;
        top: 50%;
        right: 15px;
        transform: translateY(-50%);
        font-size: 15px;
    }
    .search-btn {
        text-align: left;
        line-height: 50%;
        .search-btn-wrap {
            background-color: #ffffff;
            border-radius: 4px;
        }
        .icon-search {
            position: absolute;
            top: 50%;
            left: 15%;
        }
        .search-input {
            padding-left: 30px;
        }
        .active-search-input {
            height: 38px;
            line-height: 28px;
            width: 90%;
            background: #ffffff;
            display: inline-block;
            padding-left: 30px;
            background-color: #ffffff;
        }
    }
    .is-opening-box {
        height: 50px;
        width: 100%;
        border-bottom: 1px solid #dddddd;
        line-height: 50px;
        position: relative;
        z-index: 4;
        .opening-box,
        .ending-box {
            display: inline-block;
            width: 50%;
            text-align: center;
            color: rgba(153, 153, 153, 1);
        }
        .is-opening {
            color: #333333;
            span {
                border-bottom: 2px solid #9975F3;
            }
        }
    }
    .activity-status {
        // width: 100px;
        height: 21px;
        background:linear-gradient(144deg,rgba(179,116,248,1) 0%,rgba(109,120,238,1) 100%);
        border-radius: 50px;
        float: right;
        color: #fff;
        text-align: center;
        margin-right: 15px;
        padding: 3px 10px;
        font-size: 15px;
    }
    .activity-people {
        position: absolute;
        right: 0px;
        margin-top: -29px;
        background: rgba(0, 0, 0, 0.29);
        border-radius: 4px 0px 0px 0px;
        color: #fff;
        padding: 3px 10px;
    }
    .activity-hot {
        position: absolute;
        right: 15px;
        width: 41px;
        height: 34px;
    }
    .activity-label {
        // width: 86px;
        height: 22px;
        background: #F4F2FC;
        border-radius: 4px;
        margin-left: 11px;
        color: #9975F3;
        padding: 3px 10px;
        vertical-align: middle;
        font-size: 15px;
    }
}
</style>
