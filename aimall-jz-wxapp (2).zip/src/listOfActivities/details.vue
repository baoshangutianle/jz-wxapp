<template>
    <div id="stockPurchaseDetails">
        <div class="actives-deail">
            <img
                :src="detailData.pictureUrl"
                class="activies-img"
            >
            <p class="actives-title">{{ detailData.title }}</p>
            <div class="actives-oper">
                <span class="actives-aut">{{ detailData.subtitle }}</span>
            </div>
            <div class="actives-con">
                <wxParse
                    :content="detailData.content"
                    :image-prop="imageProp"
                />
            </div>
        </div>
        <!-- 吸底 -->
        <div class="restaurant-footer">
            <div>
                <span>
                    <share />
                </span>
                <!-- <span>分享</span> -->
                <!-- <span class="collect-icon">
                    <collect-comp
                        :content-id="contentId"
                        :content-type="contentType"
                    />
                </span> -->
                <!-- <span>收藏</span> -->
            </div>
        </div>
    </div>
</template>

<script>
import wxParse from 'mpvue-wxparse'
import utils from '@/plugins/utils'
import api from '@/plugins/api'
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils'
// import ShareBtn from '@/components/ShareBtn'
// import collectComp from '@/components/CollectComp'
import buryPoint from '@/plugins/buryPoint'
import pointCode from '@/plugins/pointCode'
import collectComp from '@/components/CollectComp'
import share from '@/components/ShareBtn'
export default {
    components: {
        wxParse,
        share,
        collectComp,
    },
    data() {
        return {
            pageStayTime: 0,//页面停留时间
            detailData: {},
            article: '<div>我是HTML代码</div>',
            contentId: '',
            contentType: 1,
            imageProp: {
                mode: 'widthFix'
            }
        }
    },
    onShow() {
    // 埋点
        this.pageStayTime = new Date().getTime()
        buryPoint.setP({
            id: pointCode.ACTIVITY_P_DETAIL
        })
        this.getDetailById()
    },
    onUnload() {
        this.pageStayTime = new Date().getTime() - this.pageStayTime
    // 埋点
        buryPoint.setZ({
            id: pointCode.ACTIVITY_Z_DETAIL,
            p_stay_time: this.pageStayTime
        })
    },
    methods: {
        getDetailById() {
            let id = this.$root.$mp.query.id || 17
            this.contentId = id;
            let opsiton = { path: api.getCmsContentById + id }
            request(opsiton).then(res => {
                if (res.code == 200) {
                    this.detailData = res.data
                    this.contentId = this.detailData.id
                }
            })
        }
    },
    onShareAppMessage() {
        return {
            title: this.detailData.title,
            desc: this.detailData.subTitle,
            path: 'pages/home?pageId=activites&id=' + this.$root.$mp.query.id,
            success: function(res) {
                console.log(res)
            },
            fail: function(err) {
                console.log(err)
            }
        }
    }
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
@import url('~mpvue-wxparse/src/wxParse.css');
#stockPurchaseDetails {
    padding-bottom: 85px;
    background: #ffffff;
    .actives-deail {
        max-width: 100%;
        overflow: hidden;
    }
    .activies-img {
        width: 100%;
        height: 194px;
        border-radius: 4px;
    }
    .actives-title {
        font-size: 20px;
        font-weight: bold;
        color: #333333;
        padding: 15px 15px 0;
    }
    .actives-oper {
        // display: flex;
        // justify-content: space-between;
        align-items: center;
        font-size: 15px;
        color: #999999;
        padding: 10px 25px 0 15px;
        .clicknumber {
            padding-left: 30px;
            background: url('../static/images/icon-home-eye.png') no-repeat left center;
            background-size: 20px 13px;
            vertical-align: top;
            padding-right: 30px;
        }
    }
    .actives-aut {
        display: inline-block;
    }
    .actives-todo {
        float: right;
    }
    .actives-con {
        padding: 0 25px 30px;
    }
    .wxParse {
        view {
            word-break: break-all;
            image {
                width: 100% !important;
            }
        }
    }
}
</style>
