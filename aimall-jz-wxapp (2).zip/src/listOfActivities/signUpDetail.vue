<template>
    <div class="exchange-detail-container">
        <div class="card-detail-main">
            <div class="card-detail-con">
                <div class="card">
                    <div class="card_con">
                        <div class="card_img">
                            <img :src="detailData.thumbnail"/>
                        </div>
                        <div class="card_info">
                            <p class="card_title">{{detailData.activityName}}</p>
                            <div class="card_type">
                                <span class="type_span">{{detailData.applyIntegral ? detailData.applyIntegral +'积分' : '免费活动'}}</span>
                            </div>
                        </div>
                    </div> 
                </div>
                <div class="card_time">
                    <div class="times">
                        <span class="times">活动时间: {{detailData.startTime}}-{{detailData.endTime}}</span>
                    </div>
                    <div class="times_btn">
                        <!-- <button class="time_btn" @click="goToDetail">查看详情</button> -->
                    </div>
                </div>
            </div>

            <div
                class="card-code-wrap"
                v-if="detailData.couponType != '4'"
            >

                <div class="card-qrcode-wrap">
                    <div class="card-qrcode">
                        <qrcode-comp
                            :data="qrCode"
                            width="274"
                            height="274"
                        />
                    </div>
                </div>
                <!-- <div class="card-code">
                    券号：{{ couponCode }}
                </div> -->
            </div>

            <div class="coupon-rule-wrap">

                <div class="exchange_remark">
                    <!-- <p class="p-text">报名提交时间</p> -->
                    <p class="p-text">
                        <span class="line"></span>
                        <span class="text">报名提交时间</span>
                    </p>
                    <p class="msg">{{detailData.createTime}}</p>
                    <p class="p-text">
                        <span class="line"></span>
                        <span class="text">活动时间</span>
                    </p>
                    <p class="msg">{{detailData.startTime}} 至 {{detailData.endTime}}</p>
                    <p class="p-text">
                        <span class="line"></span>
                        <span class="text">状态</span>
                    </p>
                    <p v-show="detailData.applyStatus == '2'" class="success" style="color:#9975f3">报名成功</p>
                    <p v-show="detailData.applyStatus == '4'" class="success" style="color:#9975f3">签到成功</p>
                    <p v-show="detailData.applyStatus == '1'" class="loading" style="color:#9975f3">审核中</p>
                    <p v-show="detailData.applyStatus == '3'" class="fail" style="color:#9975f3">报名失败</p>
                    <p v-show="detailData.applyStatus == '5'" class="fail" style="color:#999999">已过期</p>
                    <!-- <p>1.门店扫码使用</p>
                    <p>2.兑换成功后在"我的"-"我的卡券"内查看</p>
                    <p>3.请到麦麦山云南呢菜门店出示卡券使用</p> -->
                </div>
            </div>
        </div>
        <canvas
            style="margin-top:100px;width: 686rpx;height: 686rpx;background:#f1f1f1;opacity:0;"
            canvas-id="mycanvas"
        />
    </div>
</template>

<script>
import { mapState, mapMutations } from "vuex"
import api from '@/plugins/api'
import moment from 'moment'
import request from '@/plugins/request'
import wxUtils from '@/plugins/wxUtils';
import CardItem from '@/components/CardItem';
import QrcodeComp from '@/components/QrcodeComp'
import CouponRule from '@/components/CouponRule'
export default {
    components: {
        CardItem,
        QrcodeComp,
        CouponRule
    },
    data() {
        return {
            pageStayTime: 0, //页面停留时间
            mobile: wxUtils.getPhoneStorage(),
            qrCode: '',
            detailData: {

            }
        }
    },
    computed: {
        ...mapState(['sessionId', 'vipInfo'])
    },
    methods: {
        goMyActivityDetail(){
            let t = this;
            console.log(t.$root.$mp.query.id,444)
            wx.request({
                url: api.getMmcMemberApply + '/' + t.$root.$mp.query.id,
                method: 'GET',
                data: null,
                header: {
                    Authorization: t.sessionId,
                    'L-A-Platform': 'mini-program' //后端日志埋点渠道
                },
                success(res) {
                    if (res.data.code === 200) {
                        console.log(res.data);
                        // res.data.data.applyStatus = 2;
                        res.data.data.createTime = moment(res.data.data.createTime).format('YYYY-MM-DD HH:mm')
                        res.data.data.startTime = moment(res.data.data.startTime).format('YYYY-MM-DD HH:mm')
                        res.data.data.endTime = moment(res.data.data.endTime).format('YYYY-MM-DD HH:mm')
                        t.detailData = res.data.data;
                    }
                }
            })
        },
        setQrCode() {
            let id = this.$root.$mp.query.id;
            let data = "form=activity&activityId=" + id;
            if (!this.qrCode) {
                this.qrCode = data
            }
        }
    },
     onShow() {
        this.goMyActivityDetail();
        this.setQrCode();
    },
    onUnload() {
        this.qrCode = "";
    },
}
</script>

<style lang="less" scoped>
@import '../assets/styles/vars';
.exchange-detail-container {
    color: @black-color;
    height: 100vh;
    overflow: hidden;
    background: #F4F4F4;
    .card-detail-main {
        height: 100vh;
        overflow: auto;
    }
    .card-detail-con{

        background: #ffffff;
        padding: 0 15px;
    }
    .card {
        overflow: hidden;
        padding-bottom: 18px;
        border-bottom: solid 1px #F0F0F0;
        .card_con{
            display: flex;
            padding-top: 15px;
        }
        .card_img{
            width: 134px;
            height: 78px;
            img{
                width: 134px;
                height: 78px;
            }
        }
        .card_info{
            padding-left: 18px;
            height: 78px;
            width: 100%;
            position: relative;
        }
        .card_title{
            color: #333333;
            font-size: 14px;
             display: -webkit-box;
            word-break: break-all;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .card_type{
            padding-top: 17px;
            display: flex;
            position: absolute;
            z-index: 99;
            bottom: 0;
        }
        .type_span{
            display: inline-block;
            font-size: 14px;
            // color: #ED8C5A;
            color: #ea5205;
            border-radius: 11px;
            padding: 1px 0px;
            // border: solid 1px #ED8C5A;
            // border: solid 1px #ea5205;
            // font-weight: 200;
            font-weight: bolder;

        }

        .card_intall{
            flex: 1;
            color: #9975F3;
            text-align: right;
            float: right;
        }
    }
    .card_time{
        overflow: hidden;
        height: 65px;
        line-height: 65px;
        .times{
            color: #999999;
            font-size: 14px;
            float: left;
            font-weight: 200;
        }
        .times_btn{
            float: right;
            text-align: right;
            padding-top: 15px;
            padding-bottom: 15px;
        }
        .time_btn{
            background: #9975F3;
            width: 72px;
            color: #fff;
            border-radius: 4px;
            font-size: 14px;
            height: 28px;
            line-height: 28px;
            padding: 0;
        }
    }
    .card-code-wrap {
        text-align: center;
        border-bottom: 0.5px solid #D8D8D8;
        .card-code {
            font-size: 14px;
            color: #333333;
            padding-bottom: 24px;
        }
        .card-qrcode-wrap{
            width: 186px;
            height: 186px;
            margin: 37px 0px 24px;
            background: #DCDCDC;
            display: inline-block;
        }
        .card-qrcode {
            display: inline-block;
            width: 174px;
            height: 174px;
            padding-top: 6px
        }
    }

    .coupon-rule-wrap {
        margin-bottom: 48px;
        padding: 19px 15px;
        .line{
            width: 2px;
            height: 10px;
            background: #9975F3;
            display: inline-block;
        }
        .text{
            color: #333333;
            font-size: 15px;
            padding-left: 6px;
        }
        .exchange_remark{
            padding-top: 10px;
            color: #666666;
            font-size: 14px;
            padding-left: 6px;
            font-weight: 200;
            span{
                font-weight: 200;
            }
        }
    }
    .msg {
        font-weight: 300;
        color: rgba(153, 153, 153, 1);
        font-size: 15px;
        margin-top: 3px !important;
    }
    .success{
        font-size: 15px;
        color: rgba(114, 197, 193, 1);
    }
    .loading{
        font-size: 15px;
        color: rgba(218, 195, 59, 1);
    }
    .fail{
        font-size: 15px;
        color: rgba(255, 71, 71, 1);
    }
    .p-text{
        color: #333333;
        font-size: 15px;
        font-weight: 300;
        padding-bottom: 5px;
        padding-top: 5px;
    }
}
</style>
